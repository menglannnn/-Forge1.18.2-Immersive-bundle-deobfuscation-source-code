/*      */ package com.fasterxml.jackson.databind.util.internal;
/*      */ 
/*      */ import java.io.InvalidObjectException;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.Serializable;
/*      */ import java.util.AbstractCollection;
/*      */ import java.util.AbstractMap;
/*      */ import java.util.AbstractSet;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.Map;
/*      */ import java.util.Queue;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.ConcurrentLinkedQueue;
/*      */ import java.util.concurrent.ConcurrentMap;
/*      */ import java.util.concurrent.atomic.AtomicLong;
/*      */ import java.util.concurrent.atomic.AtomicLongArray;
/*      */ import java.util.concurrent.atomic.AtomicReference;
/*      */ import java.util.concurrent.atomic.AtomicReferenceArray;
/*      */ import java.util.concurrent.locks.Lock;
/*      */ import java.util.concurrent.locks.ReentrantLock;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class PrivateMaxEntriesMap<K, V>
/*      */   extends AbstractMap<K, V>
/*      */   implements ConcurrentMap<K, V>, Serializable
/*      */ {
/*  132 */   static final int NCPU = Runtime.getRuntime().availableProcessors();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final long MAXIMUM_CAPACITY = 9223372034707292160L;
/*      */ 
/*      */ 
/*      */   
/*  141 */   static final int NUMBER_OF_READ_BUFFERS = Math.min(4, ceilingNextPowerOfTwo(NCPU));
/*      */ 
/*      */   
/*  144 */   static final int READ_BUFFERS_MASK = NUMBER_OF_READ_BUFFERS - 1;
/*      */   
/*      */   static final int READ_BUFFER_THRESHOLD = 4;
/*      */   
/*      */   static final int READ_BUFFER_DRAIN_THRESHOLD = 8;
/*      */   
/*      */   static final int READ_BUFFER_SIZE = 16;
/*      */   
/*      */   static final int READ_BUFFER_INDEX_MASK = 15;
/*      */   
/*      */   static final int WRITE_BUFFER_DRAIN_THRESHOLD = 16;
/*      */   
/*      */   final ConcurrentMap<K, Node<K, V>> data;
/*      */   
/*      */   final int concurrencyLevel;
/*      */   
/*      */   final long[] readBufferReadCount;
/*      */   
/*      */   final LinkedDeque<Node<K, V>> evictionDeque;
/*      */   final AtomicLong weightedSize;
/*      */   
/*      */   static int ceilingNextPowerOfTwo(int x) {
/*  166 */     return 1 << 32 - Integer.numberOfLeadingZeros(x - 1);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   final AtomicLong capacity;
/*      */ 
/*      */   
/*      */   final Lock evictionLock;
/*      */ 
/*      */   
/*      */   final Queue<Runnable> writeBuffer;
/*      */   
/*      */   final AtomicLongArray readBufferWriteCount;
/*      */   
/*      */   final AtomicLongArray readBufferDrainAtWriteCount;
/*      */   
/*      */   final AtomicReferenceArray<Node<K, V>> readBuffers;
/*      */   
/*      */   final AtomicReference<DrainStatus> drainStatus;
/*      */   
/*      */   transient Set<K> keySet;
/*      */   
/*      */   transient Collection<V> values;
/*      */   
/*      */   transient Set<Map.Entry<K, V>> entrySet;
/*      */   
/*      */   static final long serialVersionUID = 1L;
/*      */ 
/*      */   
/*      */   private static int readBufferIndex(int bufferIndex, int entryIndex) {
/*  197 */     return 16 * bufferIndex + entryIndex;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private PrivateMaxEntriesMap(Builder<K, V> builder) {
/*  206 */     this.concurrencyLevel = builder.concurrencyLevel;
/*  207 */     this.capacity = new AtomicLong(Math.min(builder.capacity, 9223372034707292160L));
/*  208 */     this.data = new ConcurrentHashMap<>(builder.initialCapacity, 0.75F, this.concurrencyLevel);
/*      */ 
/*      */     
/*  211 */     this.evictionLock = new ReentrantLock();
/*  212 */     this.weightedSize = new AtomicLong();
/*  213 */     this.evictionDeque = new LinkedDeque<>();
/*  214 */     this.writeBuffer = new ConcurrentLinkedQueue<>();
/*  215 */     this.drainStatus = new AtomicReference<>(DrainStatus.IDLE);
/*      */     
/*  217 */     this.readBufferReadCount = new long[NUMBER_OF_READ_BUFFERS];
/*  218 */     this.readBufferWriteCount = new AtomicLongArray(NUMBER_OF_READ_BUFFERS);
/*  219 */     this.readBufferDrainAtWriteCount = new AtomicLongArray(NUMBER_OF_READ_BUFFERS);
/*  220 */     this.readBuffers = new AtomicReferenceArray<>(NUMBER_OF_READ_BUFFERS * 16);
/*      */   }
/*      */ 
/*      */   
/*      */   static void checkNotNull(Object o) {
/*  225 */     if (o == null) {
/*  226 */       throw new NullPointerException();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static void checkArgument(boolean expression) {
/*  232 */     if (!expression) {
/*  233 */       throw new IllegalArgumentException();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static void checkState(boolean expression) {
/*  239 */     if (!expression) {
/*  240 */       throw new IllegalStateException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long capacity() {
/*  252 */     return this.capacity.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCapacity(long capacity) {
/*  263 */     checkArgument((capacity >= 0L));
/*  264 */     this.evictionLock.lock();
/*      */     try {
/*  266 */       this.capacity.lazySet(Math.min(capacity, 9223372034707292160L));
/*  267 */       drainBuffers();
/*  268 */       evict();
/*      */     } finally {
/*  270 */       this.evictionLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   boolean hasOverflowed() {
/*  277 */     return (this.weightedSize.get() > this.capacity.get());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void evict() {
/*  292 */     while (hasOverflowed()) {
/*  293 */       Node<K, V> node = this.evictionDeque.poll();
/*      */ 
/*      */ 
/*      */       
/*  297 */       if (node == null) {
/*      */         return;
/*      */       }
/*      */       
/*  301 */       this.data.remove(node.key, node);
/*      */       
/*  303 */       makeDead(node);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void afterRead(Node<K, V> node) {
/*  313 */     int bufferIndex = readBufferIndex();
/*  314 */     long writeCount = recordRead(bufferIndex, node);
/*  315 */     drainOnReadIfNeeded(bufferIndex, writeCount);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static int readBufferIndex() {
/*  323 */     return (int)Thread.currentThread().getId() & READ_BUFFERS_MASK;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   long recordRead(int bufferIndex, Node<K, V> node) {
/*  337 */     long writeCount = this.readBufferWriteCount.get(bufferIndex);
/*  338 */     this.readBufferWriteCount.lazySet(bufferIndex, writeCount + 1L);
/*      */     
/*  340 */     int index = (int)(writeCount & 0xFL);
/*  341 */     this.readBuffers.lazySet(readBufferIndex(bufferIndex, index), node);
/*      */     
/*  343 */     return writeCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void drainOnReadIfNeeded(int bufferIndex, long writeCount) {
/*  354 */     long pending = writeCount - this.readBufferDrainAtWriteCount.get(bufferIndex);
/*  355 */     boolean delayable = (pending < 4L);
/*  356 */     DrainStatus status = this.drainStatus.get();
/*  357 */     if (status.shouldDrainBuffers(delayable)) {
/*  358 */       tryToDrainBuffers();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void afterWrite(Runnable task) {
/*  368 */     this.writeBuffer.add(task);
/*  369 */     this.drainStatus.lazySet(DrainStatus.REQUIRED);
/*  370 */     tryToDrainBuffers();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void tryToDrainBuffers() {
/*  378 */     if (this.evictionLock.tryLock()) {
/*      */       try {
/*  380 */         this.drainStatus.lazySet(DrainStatus.PROCESSING);
/*  381 */         drainBuffers();
/*      */       } finally {
/*  383 */         this.drainStatus.compareAndSet(DrainStatus.PROCESSING, DrainStatus.IDLE);
/*  384 */         this.evictionLock.unlock();
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void drainBuffers() {
/*  392 */     drainReadBuffers();
/*  393 */     drainWriteBuffer();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void drainReadBuffers() {
/*  399 */     int start = (int)Thread.currentThread().getId();
/*  400 */     int end = start + NUMBER_OF_READ_BUFFERS;
/*  401 */     for (int i = start; i < end; i++) {
/*  402 */       drainReadBuffer(i & READ_BUFFERS_MASK);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void drainReadBuffer(int bufferIndex) {
/*  409 */     long writeCount = this.readBufferWriteCount.get(bufferIndex);
/*  410 */     for (int i = 0; i < 8; i++) {
/*  411 */       int index = (int)(this.readBufferReadCount[bufferIndex] & 0xFL);
/*  412 */       int arrayIndex = readBufferIndex(bufferIndex, index);
/*  413 */       Node<K, V> node = this.readBuffers.get(arrayIndex);
/*  414 */       if (node == null) {
/*      */         break;
/*      */       }
/*      */       
/*  418 */       this.readBuffers.lazySet(arrayIndex, null);
/*  419 */       applyRead(node);
/*  420 */       this.readBufferReadCount[bufferIndex] = this.readBufferReadCount[bufferIndex] + 1L;
/*      */     } 
/*  422 */     this.readBufferDrainAtWriteCount.lazySet(bufferIndex, writeCount);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void applyRead(Node<K, V> node) {
/*  432 */     if (this.evictionDeque.contains(node)) {
/*  433 */       this.evictionDeque.moveToBack(node);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void drainWriteBuffer() {
/*  440 */     for (int i = 0; i < 16; i++) {
/*  441 */       Runnable task = this.writeBuffer.poll();
/*  442 */       if (task == null) {
/*      */         break;
/*      */       }
/*  445 */       task.run();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean tryToRetire(Node<K, V> node, WeightedValue<V> expect) {
/*  458 */     if (expect.isAlive()) {
/*  459 */       WeightedValue<V> retired = new WeightedValue<>(expect.value, -expect.weight);
/*  460 */       return node.compareAndSet(expect, retired);
/*      */     } 
/*  462 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void makeRetired(Node<K, V> node) {
/*      */     WeightedValue<V> current;
/*      */     WeightedValue<V> retired;
/*      */     do {
/*  473 */       current = node.get();
/*  474 */       if (!current.isAlive()) {
/*      */         return;
/*      */       }
/*  477 */       retired = new WeightedValue<>(current.value, -current.weight);
/*  478 */     } while (!node.compareAndSet(current, retired));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void makeDead(Node<K, V> node) {
/*      */     while (true) {
/*  493 */       WeightedValue<V> current = node.get();
/*  494 */       WeightedValue<V> dead = new WeightedValue<>(current.value, 0);
/*  495 */       if (node.compareAndSet(current, dead)) {
/*  496 */         this.weightedSize.lazySet(this.weightedSize.get() - Math.abs(current.weight));
/*      */         return;
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   final class AddTask
/*      */     implements Runnable {
/*      */     final PrivateMaxEntriesMap.Node<K, V> node;
/*      */     final int weight;
/*      */     
/*      */     AddTask(PrivateMaxEntriesMap.Node<K, V> node, int weight) {
/*  508 */       this.weight = weight;
/*  509 */       this.node = node;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void run() {
/*  515 */       PrivateMaxEntriesMap.this.weightedSize.lazySet(PrivateMaxEntriesMap.this.weightedSize.get() + this.weight);
/*      */ 
/*      */       
/*  518 */       if (this.node.get().isAlive()) {
/*  519 */         PrivateMaxEntriesMap.this.evictionDeque.add(this.node);
/*  520 */         PrivateMaxEntriesMap.this.evict();
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   final class RemovalTask
/*      */     implements Runnable {
/*      */     final PrivateMaxEntriesMap.Node<K, V> node;
/*      */     
/*      */     RemovalTask(PrivateMaxEntriesMap.Node<K, V> node) {
/*  530 */       this.node = node;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void run() {
/*  537 */       PrivateMaxEntriesMap.this.evictionDeque.remove(this.node);
/*  538 */       PrivateMaxEntriesMap.this.makeDead(this.node);
/*      */     }
/*      */   }
/*      */   
/*      */   final class UpdateTask
/*      */     implements Runnable {
/*      */     final int weightDifference;
/*      */     final PrivateMaxEntriesMap.Node<K, V> node;
/*      */     
/*      */     UpdateTask(PrivateMaxEntriesMap.Node<K, V> node, int weightDifference) {
/*  548 */       this.weightDifference = weightDifference;
/*  549 */       this.node = node;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void run() {
/*  555 */       PrivateMaxEntriesMap.this.weightedSize.lazySet(PrivateMaxEntriesMap.this.weightedSize.get() + this.weightDifference);
/*  556 */       PrivateMaxEntriesMap.this.applyRead(this.node);
/*  557 */       PrivateMaxEntriesMap.this.evict();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEmpty() {
/*  565 */     return this.data.isEmpty();
/*      */   }
/*      */ 
/*      */   
/*      */   public int size() {
/*  570 */     return this.data.size();
/*      */   }
/*      */ 
/*      */   
/*      */   public void clear() {
/*  575 */     this.evictionLock.lock();
/*      */     
/*      */     try {
/*      */       Node<K, V> node;
/*  579 */       while ((node = this.evictionDeque.poll()) != null) {
/*  580 */         this.data.remove(node.key, node);
/*  581 */         makeDead(node);
/*      */       } 
/*      */ 
/*      */       
/*  585 */       for (int i = 0; i < this.readBuffers.length(); i++) {
/*  586 */         this.readBuffers.lazySet(i, null);
/*      */       }
/*      */       
/*      */       Runnable task;
/*      */       
/*  591 */       while ((task = this.writeBuffer.poll()) != null) {
/*  592 */         task.run();
/*      */       }
/*      */     } finally {
/*  595 */       this.evictionLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean containsKey(Object key) {
/*  601 */     return this.data.containsKey(key);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean containsValue(Object value) {
/*  606 */     checkNotNull(value);
/*      */     
/*  608 */     for (Node<K, V> node : this.data.values()) {
/*  609 */       if (node.getValue().equals(value)) {
/*  610 */         return true;
/*      */       }
/*      */     } 
/*  613 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public V get(Object key) {
/*  618 */     Node<K, V> node = this.data.get(key);
/*  619 */     if (node == null) {
/*  620 */       return null;
/*      */     }
/*  622 */     afterRead(node);
/*  623 */     return node.getValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public V put(K key, V value) {
/*  628 */     return put(key, value, false);
/*      */   }
/*      */ 
/*      */   
/*      */   public V putIfAbsent(K key, V value) {
/*  633 */     return put(key, value, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   V put(K key, V value, boolean onlyIfAbsent) {
/*  647 */     checkNotNull(key);
/*  648 */     checkNotNull(value);
/*      */     
/*  650 */     int weight = 1;
/*  651 */     WeightedValue<V> weightedValue = new WeightedValue<>(value, 1);
/*  652 */     Node<K, V> node = new Node<>(key, weightedValue);
/*      */     
/*      */     label21: while (true) {
/*  655 */       Node<K, V> prior = this.data.putIfAbsent(node.key, node);
/*  656 */       if (prior == null) {
/*  657 */         afterWrite(new AddTask(node, 1));
/*  658 */         return null;
/*  659 */       }  if (onlyIfAbsent) {
/*  660 */         afterRead(prior);
/*  661 */         return prior.getValue();
/*      */       } 
/*      */       while (true) {
/*  664 */         WeightedValue<V> oldWeightedValue = prior.get();
/*  665 */         if (!oldWeightedValue.isAlive()) {
/*      */           continue label21;
/*      */         }
/*      */         
/*  669 */         if (prior.compareAndSet(oldWeightedValue, weightedValue)) {
/*  670 */           int weightedDifference = 1 - oldWeightedValue.weight;
/*  671 */           if (weightedDifference == 0) {
/*  672 */             afterRead(prior);
/*      */           } else {
/*  674 */             afterWrite(new UpdateTask(prior, weightedDifference));
/*      */           } 
/*  676 */           return oldWeightedValue.value;
/*      */         } 
/*      */       } 
/*      */       break;
/*      */     } 
/*      */   }
/*      */   
/*      */   public V remove(Object key) {
/*  684 */     Node<K, V> node = this.data.remove(key);
/*  685 */     if (node == null) {
/*  686 */       return null;
/*      */     }
/*      */     
/*  689 */     makeRetired(node);
/*  690 */     afterWrite(new RemovalTask(node));
/*  691 */     return node.getValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean remove(Object key, Object value) {
/*  696 */     Node<K, V> node = this.data.get(key);
/*  697 */     if (node == null || value == null) {
/*  698 */       return false;
/*      */     }
/*      */     
/*  701 */     WeightedValue<V> weightedValue = node.get();
/*      */     
/*  703 */     while (weightedValue.contains(value)) {
/*  704 */       if (tryToRetire(node, weightedValue)) {
/*  705 */         if (this.data.remove(key, node)) {
/*  706 */           afterWrite(new RemovalTask(node));
/*  707 */           return true;
/*      */         }  break;
/*      */       } 
/*  710 */       weightedValue = node.get();
/*  711 */       if (weightedValue.isAlive());
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  718 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public V replace(K key, V value) {
/*  724 */     checkNotNull(key);
/*  725 */     checkNotNull(value);
/*      */     
/*  727 */     int weight = 1;
/*  728 */     WeightedValue<V> weightedValue = new WeightedValue<>(value, 1);
/*      */     
/*  730 */     Node<K, V> node = this.data.get(key);
/*  731 */     if (node == null) {
/*  732 */       return null;
/*      */     }
/*      */     while (true) {
/*  735 */       WeightedValue<V> oldWeightedValue = node.get();
/*  736 */       if (!oldWeightedValue.isAlive()) {
/*  737 */         return null;
/*      */       }
/*  739 */       if (node.compareAndSet(oldWeightedValue, weightedValue)) {
/*  740 */         int weightedDifference = 1 - oldWeightedValue.weight;
/*  741 */         if (weightedDifference == 0) {
/*  742 */           afterRead(node);
/*      */         } else {
/*  744 */           afterWrite(new UpdateTask(node, weightedDifference));
/*      */         } 
/*  746 */         return oldWeightedValue.value;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean replace(K key, V oldValue, V newValue) {
/*  753 */     checkNotNull(key);
/*  754 */     checkNotNull(oldValue);
/*  755 */     checkNotNull(newValue);
/*      */     
/*  757 */     int weight = 1;
/*  758 */     WeightedValue<V> newWeightedValue = new WeightedValue<>(newValue, 1);
/*      */     
/*  760 */     Node<K, V> node = this.data.get(key);
/*  761 */     if (node == null) {
/*  762 */       return false;
/*      */     }
/*      */     while (true) {
/*  765 */       WeightedValue<V> weightedValue = node.get();
/*  766 */       if (!weightedValue.isAlive() || !weightedValue.contains(oldValue)) {
/*  767 */         return false;
/*      */       }
/*  769 */       if (node.compareAndSet(weightedValue, newWeightedValue)) {
/*  770 */         int weightedDifference = 1 - weightedValue.weight;
/*  771 */         if (weightedDifference == 0) {
/*  772 */           afterRead(node);
/*      */         } else {
/*  774 */           afterWrite(new UpdateTask(node, weightedDifference));
/*      */         } 
/*  776 */         return true;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public Set<K> keySet() {
/*  783 */     Set<K> ks = this.keySet;
/*  784 */     return (ks == null) ? (this.keySet = new KeySet()) : ks;
/*      */   }
/*      */ 
/*      */   
/*      */   public Collection<V> values() {
/*  789 */     Collection<V> vs = this.values;
/*  790 */     return (vs == null) ? (this.values = new Values()) : vs;
/*      */   }
/*      */ 
/*      */   
/*      */   public Set<Map.Entry<K, V>> entrySet() {
/*  795 */     Set<Map.Entry<K, V>> es = this.entrySet;
/*  796 */     return (es == null) ? (this.entrySet = new EntrySet()) : es;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   enum DrainStatus
/*      */   {
/*  803 */     IDLE {
/*      */       boolean shouldDrainBuffers(boolean delayable) {
/*  805 */         return !delayable;
/*      */       }
/*      */     },
/*      */ 
/*      */     
/*  810 */     REQUIRED {
/*      */       boolean shouldDrainBuffers(boolean delayable) {
/*  812 */         return true;
/*      */       }
/*      */     },
/*      */ 
/*      */     
/*  817 */     PROCESSING {
/*      */       boolean shouldDrainBuffers(boolean delayable) {
/*  819 */         return false;
/*      */       }
/*      */     };
/*      */ 
/*      */ 
/*      */     
/*      */     abstract boolean shouldDrainBuffers(boolean param1Boolean);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static final class WeightedValue<V>
/*      */   {
/*      */     final int weight;
/*      */ 
/*      */     
/*      */     final V value;
/*      */ 
/*      */     
/*      */     WeightedValue(V value, int weight) {
/*  839 */       this.weight = weight;
/*  840 */       this.value = value;
/*      */     }
/*      */     
/*      */     boolean contains(Object o) {
/*  844 */       return (o == this.value || this.value.equals(o));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     boolean isAlive() {
/*  851 */       return (this.weight > 0);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static final class Node<K, V>
/*      */     extends AtomicReference<WeightedValue<V>>
/*      */     implements Linked<Node<K, V>>
/*      */   {
/*      */     final K key;
/*      */ 
/*      */     
/*      */     Node<K, V> prev;
/*      */     
/*      */     Node<K, V> next;
/*      */ 
/*      */     
/*      */     Node(K key, PrivateMaxEntriesMap.WeightedValue<V> weightedValue) {
/*  870 */       super(weightedValue);
/*  871 */       this.key = key;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Node<K, V> getPrevious() {
/*  877 */       return this.prev;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void setPrevious(Node<K, V> prev) {
/*  883 */       this.prev = prev;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Node<K, V> getNext() {
/*  889 */       return this.next;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void setNext(Node<K, V> next) {
/*  895 */       this.next = next;
/*      */     }
/*      */ 
/*      */     
/*      */     V getValue() {
/*  900 */       return (get()).value;
/*      */     }
/*      */   }
/*      */   
/*      */   final class KeySet
/*      */     extends AbstractSet<K> {
/*  906 */     final PrivateMaxEntriesMap<K, V> map = PrivateMaxEntriesMap.this;
/*      */ 
/*      */     
/*      */     public int size() {
/*  910 */       return this.map.size();
/*      */     }
/*      */ 
/*      */     
/*      */     public void clear() {
/*  915 */       this.map.clear();
/*      */     }
/*      */ 
/*      */     
/*      */     public Iterator<K> iterator() {
/*  920 */       return new PrivateMaxEntriesMap.KeyIterator();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean contains(Object obj) {
/*  925 */       return PrivateMaxEntriesMap.this.containsKey(obj);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean remove(Object obj) {
/*  930 */       return (this.map.remove(obj) != null);
/*      */     }
/*      */ 
/*      */     
/*      */     public Object[] toArray() {
/*  935 */       return this.map.data.keySet().toArray();
/*      */     }
/*      */ 
/*      */     
/*      */     public <T> T[] toArray(T[] array) {
/*  940 */       return (T[])this.map.data.keySet().toArray((Object[])array);
/*      */     }
/*      */   }
/*      */   
/*      */   final class KeyIterator
/*      */     implements Iterator<K> {
/*  946 */     final Iterator<K> iterator = PrivateMaxEntriesMap.this.data.keySet().iterator();
/*      */     
/*      */     K current;
/*      */     
/*      */     public boolean hasNext() {
/*  951 */       return this.iterator.hasNext();
/*      */     }
/*      */ 
/*      */     
/*      */     public K next() {
/*  956 */       this.current = this.iterator.next();
/*  957 */       return this.current;
/*      */     }
/*      */ 
/*      */     
/*      */     public void remove() {
/*  962 */       PrivateMaxEntriesMap.checkState((this.current != null));
/*  963 */       PrivateMaxEntriesMap.this.remove(this.current);
/*  964 */       this.current = null;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   final class Values
/*      */     extends AbstractCollection<V>
/*      */   {
/*      */     public int size() {
/*  973 */       return PrivateMaxEntriesMap.this.size();
/*      */     }
/*      */ 
/*      */     
/*      */     public void clear() {
/*  978 */       PrivateMaxEntriesMap.this.clear();
/*      */     }
/*      */ 
/*      */     
/*      */     public Iterator<V> iterator() {
/*  983 */       return new PrivateMaxEntriesMap.ValueIterator();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean contains(Object o) {
/*  988 */       return PrivateMaxEntriesMap.this.containsValue(o);
/*      */     }
/*      */   }
/*      */   
/*      */   final class ValueIterator
/*      */     implements Iterator<V> {
/*  994 */     final Iterator<PrivateMaxEntriesMap.Node<K, V>> iterator = PrivateMaxEntriesMap.this.data.values().iterator();
/*      */     
/*      */     PrivateMaxEntriesMap.Node<K, V> current;
/*      */     
/*      */     public boolean hasNext() {
/*  999 */       return this.iterator.hasNext();
/*      */     }
/*      */ 
/*      */     
/*      */     public V next() {
/* 1004 */       this.current = this.iterator.next();
/* 1005 */       return this.current.getValue();
/*      */     }
/*      */ 
/*      */     
/*      */     public void remove() {
/* 1010 */       PrivateMaxEntriesMap.checkState((this.current != null));
/* 1011 */       PrivateMaxEntriesMap.this.remove(this.current.key);
/* 1012 */       this.current = null;
/*      */     }
/*      */   }
/*      */   
/*      */   final class EntrySet
/*      */     extends AbstractSet<Map.Entry<K, V>> {
/* 1018 */     final PrivateMaxEntriesMap<K, V> map = PrivateMaxEntriesMap.this;
/*      */ 
/*      */     
/*      */     public int size() {
/* 1022 */       return this.map.size();
/*      */     }
/*      */ 
/*      */     
/*      */     public void clear() {
/* 1027 */       this.map.clear();
/*      */     }
/*      */ 
/*      */     
/*      */     public Iterator<Map.Entry<K, V>> iterator() {
/* 1032 */       return new PrivateMaxEntriesMap.EntryIterator();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean contains(Object obj) {
/* 1037 */       if (!(obj instanceof Map.Entry)) {
/* 1038 */         return false;
/*      */       }
/* 1040 */       Map.Entry<?, ?> entry = (Map.Entry<?, ?>)obj;
/* 1041 */       PrivateMaxEntriesMap.Node<K, V> node = this.map.data.get(entry.getKey());
/* 1042 */       return (node != null && node.getValue().equals(entry.getValue()));
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean add(Map.Entry<K, V> entry) {
/* 1047 */       throw new UnsupportedOperationException("ConcurrentLinkedHashMap does not allow add to be called on entrySet()");
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean remove(Object obj) {
/* 1052 */       if (!(obj instanceof Map.Entry)) {
/* 1053 */         return false;
/*      */       }
/* 1055 */       Map.Entry<?, ?> entry = (Map.Entry<?, ?>)obj;
/* 1056 */       return this.map.remove(entry.getKey(), entry.getValue());
/*      */     }
/*      */   }
/*      */   
/*      */   final class EntryIterator
/*      */     implements Iterator<Map.Entry<K, V>> {
/* 1062 */     final Iterator<PrivateMaxEntriesMap.Node<K, V>> iterator = PrivateMaxEntriesMap.this.data.values().iterator();
/*      */     
/*      */     PrivateMaxEntriesMap.Node<K, V> current;
/*      */     
/*      */     public boolean hasNext() {
/* 1067 */       return this.iterator.hasNext();
/*      */     }
/*      */ 
/*      */     
/*      */     public Map.Entry<K, V> next() {
/* 1072 */       this.current = this.iterator.next();
/* 1073 */       return new PrivateMaxEntriesMap.WriteThroughEntry(this.current);
/*      */     }
/*      */ 
/*      */     
/*      */     public void remove() {
/* 1078 */       PrivateMaxEntriesMap.checkState((this.current != null));
/* 1079 */       PrivateMaxEntriesMap.this.remove(this.current.key);
/* 1080 */       this.current = null;
/*      */     }
/*      */   }
/*      */   
/*      */   final class WriteThroughEntry
/*      */     extends AbstractMap.SimpleEntry<K, V> {
/*      */     static final long serialVersionUID = 1L;
/*      */     
/*      */     WriteThroughEntry(PrivateMaxEntriesMap.Node<K, V> node) {
/* 1089 */       super(node.key, node.getValue());
/*      */     }
/*      */ 
/*      */     
/*      */     public V setValue(V value) {
/* 1094 */       PrivateMaxEntriesMap.this.put(getKey(), value);
/* 1095 */       return super.setValue(value);
/*      */     }
/*      */     
/*      */     Object writeReplace() {
/* 1099 */       return new AbstractMap.SimpleEntry<>(this);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Object writeReplace() {
/* 1108 */     return new SerializationProxy<>(this);
/*      */   }
/*      */   
/*      */   private void readObject(ObjectInputStream stream) throws InvalidObjectException {
/* 1112 */     throw new InvalidObjectException("Proxy required");
/*      */   }
/*      */ 
/*      */   
/*      */   static final class SerializationProxy<K, V>
/*      */     implements Serializable
/*      */   {
/*      */     final int concurrencyLevel;
/*      */     
/*      */     final Map<K, V> data;
/*      */     
/*      */     final long capacity;
/*      */     
/*      */     static final long serialVersionUID = 1L;
/*      */     
/*      */     SerializationProxy(PrivateMaxEntriesMap<K, V> map) {
/* 1128 */       this.concurrencyLevel = map.concurrencyLevel;
/* 1129 */       this.data = new HashMap<>(map);
/* 1130 */       this.capacity = map.capacity.get();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     Object readResolve() {
/* 1136 */       PrivateMaxEntriesMap<K, V> map = (new PrivateMaxEntriesMap.Builder<>()).maximumCapacity(this.capacity).build();
/* 1137 */       map.putAll(this.data);
/* 1138 */       return map;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final class Builder<K, V>
/*      */   {
/* 1166 */     long capacity = -1L;
/* 1167 */     int initialCapacity = 16;
/* 1168 */     int concurrencyLevel = 16;
/*      */ 
/*      */ 
/*      */     
/*      */     static final int DEFAULT_INITIAL_CAPACITY = 16;
/*      */ 
/*      */ 
/*      */     
/*      */     static final int DEFAULT_CONCURRENCY_LEVEL = 16;
/*      */ 
/*      */ 
/*      */     
/*      */     public Builder<K, V> initialCapacity(int initialCapacity) {
/* 1181 */       PrivateMaxEntriesMap.checkArgument((initialCapacity >= 0));
/* 1182 */       this.initialCapacity = initialCapacity;
/* 1183 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Builder<K, V> maximumCapacity(long capacity) {
/* 1194 */       PrivateMaxEntriesMap.checkArgument((capacity >= 0L));
/* 1195 */       this.capacity = capacity;
/* 1196 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Builder<K, V> concurrencyLevel(int concurrencyLevel) {
/* 1210 */       PrivateMaxEntriesMap.checkArgument((concurrencyLevel > 0));
/* 1211 */       this.concurrencyLevel = concurrencyLevel;
/* 1212 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public PrivateMaxEntriesMap<K, V> build() {
/* 1222 */       PrivateMaxEntriesMap.checkState((this.capacity >= 0L));
/* 1223 */       return new PrivateMaxEntriesMap<>(this);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databin\\util\internal\PrivateMaxEntriesMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */