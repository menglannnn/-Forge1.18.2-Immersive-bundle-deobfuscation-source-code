package com.fasterxml.jackson.databind.util;

public interface LookupCache<K, V> {
  int size();
  
  V get(Object paramObject);
  
  V put(K paramK, V paramV);
  
  V putIfAbsent(K paramK, V paramV);
  
  void clear();
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databin\\util\LookupCache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */