/*     */ package com.fasterxml.jackson.databind.node;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonPointer;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.TreeNode;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.util.RawValue;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ContainerNode<T extends ContainerNode<T>>
/*     */   extends BaseJsonNode
/*     */   implements JsonNodeCreator
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final JsonNodeFactory _nodeFactory;
/*     */   
/*     */   protected ContainerNode(JsonNodeFactory nc) {
/*  29 */     this._nodeFactory = nc;
/*     */   }
/*     */   protected ContainerNode() {
/*  32 */     this._nodeFactory = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String asText() {
/*  41 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final BooleanNode booleanNode(boolean v) {
/*  70 */     return this._nodeFactory.booleanNode(v);
/*     */   }
/*     */   public JsonNode missingNode() {
/*  73 */     return this._nodeFactory.missingNode();
/*     */   }
/*     */   
/*     */   public final NullNode nullNode() {
/*  77 */     return this._nodeFactory.nullNode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ArrayNode arrayNode() {
/*  90 */     return this._nodeFactory.arrayNode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ArrayNode arrayNode(int capacity) {
/*  98 */     return this._nodeFactory.arrayNode(capacity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObjectNode objectNode() {
/* 105 */     return this._nodeFactory.objectNode();
/*     */   }
/*     */   public final NumericNode numberNode(byte v) {
/* 108 */     return this._nodeFactory.numberNode(v);
/*     */   } public final NumericNode numberNode(short v) {
/* 110 */     return this._nodeFactory.numberNode(v);
/*     */   } public final NumericNode numberNode(int v) {
/* 112 */     return this._nodeFactory.numberNode(v);
/*     */   }
/*     */   public final NumericNode numberNode(long v) {
/* 115 */     return this._nodeFactory.numberNode(v);
/*     */   }
/*     */   
/*     */   public final NumericNode numberNode(float v) {
/* 119 */     return this._nodeFactory.numberNode(v);
/*     */   } public final NumericNode numberNode(double v) {
/* 121 */     return this._nodeFactory.numberNode(v);
/*     */   }
/*     */   public final ValueNode numberNode(BigInteger v) {
/* 124 */     return this._nodeFactory.numberNode(v);
/*     */   } public final ValueNode numberNode(BigDecimal v) {
/* 126 */     return this._nodeFactory.numberNode(v);
/*     */   }
/*     */   public final ValueNode numberNode(Byte v) {
/* 129 */     return this._nodeFactory.numberNode(v);
/*     */   } public final ValueNode numberNode(Short v) {
/* 131 */     return this._nodeFactory.numberNode(v);
/*     */   } public final ValueNode numberNode(Integer v) {
/* 133 */     return this._nodeFactory.numberNode(v);
/*     */   } public final ValueNode numberNode(Long v) {
/* 135 */     return this._nodeFactory.numberNode(v);
/*     */   }
/*     */   public final ValueNode numberNode(Float v) {
/* 138 */     return this._nodeFactory.numberNode(v);
/*     */   } public final ValueNode numberNode(Double v) {
/* 140 */     return this._nodeFactory.numberNode(v);
/*     */   }
/*     */   public final TextNode textNode(String text) {
/* 143 */     return this._nodeFactory.textNode(text);
/*     */   }
/*     */   public final BinaryNode binaryNode(byte[] data) {
/* 146 */     return this._nodeFactory.binaryNode(data);
/*     */   } public final BinaryNode binaryNode(byte[] data, int offset, int length) {
/* 148 */     return this._nodeFactory.binaryNode(data, offset, length);
/*     */   }
/*     */   public final ValueNode pojoNode(Object pojo) {
/* 151 */     return this._nodeFactory.pojoNode(pojo);
/*     */   }
/*     */   public final ValueNode rawValueNode(RawValue value) {
/* 154 */     return this._nodeFactory.rawValueNode(value);
/*     */   }
/*     */   
/*     */   public abstract JsonToken asToken();
/*     */   
/*     */   public abstract int size();
/*     */   
/*     */   public abstract JsonNode get(int paramInt);
/*     */   
/*     */   public abstract JsonNode get(String paramString);
/*     */   
/*     */   protected abstract ObjectNode _withObject(JsonPointer paramJsonPointer1, JsonPointer paramJsonPointer2, JsonNode.OverwriteMode paramOverwriteMode, boolean paramBoolean);
/*     */   
/*     */   public abstract T removeAll();
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\node\ContainerNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */