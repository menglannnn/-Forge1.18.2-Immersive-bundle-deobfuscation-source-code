/*     */ package com.fasterxml.jackson.databind.deser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.core.JacksonException;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.annotation.JacksonStdImpl;
/*     */ import com.fasterxml.jackson.databind.cfg.CoercionAction;
/*     */ import com.fasterxml.jackson.databind.cfg.CoercionInputShape;
/*     */ import com.fasterxml.jackson.databind.deser.ContextualDeserializer;
/*     */ import com.fasterxml.jackson.databind.deser.NullValueProvider;
/*     */ import com.fasterxml.jackson.databind.deser.impl.NullsConstantProvider;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*     */ import com.fasterxml.jackson.databind.type.LogicalType;
/*     */ import com.fasterxml.jackson.databind.util.AccessPattern;
/*     */ import com.fasterxml.jackson.databind.util.ObjectBuffer;
/*     */ import java.io.IOException;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @JacksonStdImpl
/*     */ public final class StringArrayDeserializer
/*     */   extends StdDeserializer<String[]>
/*     */   implements ContextualDeserializer
/*     */ {
/*     */   private static final long serialVersionUID = 2L;
/*  37 */   private static final String[] NO_STRINGS = new String[0];
/*     */   
/*  39 */   public static final StringArrayDeserializer instance = new StringArrayDeserializer();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonDeserializer<String> _elementDeserializer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final NullValueProvider _nullProvider;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Boolean _unwrapSingle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean _skipNullValues;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StringArrayDeserializer() {
/*  71 */     this((JsonDeserializer<?>)null, (NullValueProvider)null, (Boolean)null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected StringArrayDeserializer(JsonDeserializer<?> deser, NullValueProvider nuller, Boolean unwrapSingle) {
/*  77 */     super(String[].class);
/*  78 */     this._elementDeserializer = (JsonDeserializer)deser;
/*  79 */     this._nullProvider = nuller;
/*  80 */     this._unwrapSingle = unwrapSingle;
/*  81 */     this._skipNullValues = NullsConstantProvider.isSkipper(nuller);
/*     */   }
/*     */ 
/*     */   
/*     */   public LogicalType logicalType() {
/*  86 */     return LogicalType.Array;
/*     */   }
/*     */ 
/*     */   
/*     */   public Boolean supportsUpdate(DeserializationConfig config) {
/*  91 */     return Boolean.TRUE;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public AccessPattern getEmptyAccessPattern() {
/*  97 */     return AccessPattern.CONSTANT;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getEmptyValue(DeserializationContext ctxt) throws JsonMappingException {
/* 102 */     return NO_STRINGS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonDeserializer<?> createContextual(DeserializationContext ctxt, BeanProperty property) throws JsonMappingException {
/* 113 */     JsonDeserializer<?> deser = this._elementDeserializer;
/*     */     
/* 115 */     deser = findConvertingContentDeserializer(ctxt, property, deser);
/* 116 */     JavaType type = ctxt.constructType(String.class);
/* 117 */     if (deser == null) {
/* 118 */       deser = ctxt.findContextualValueDeserializer(type, property);
/*     */     } else {
/* 120 */       deser = ctxt.handleSecondaryContextualization(deser, property, type);
/*     */     } 
/*     */     
/* 123 */     Boolean unwrapSingle = findFormatFeature(ctxt, property, String[].class, JsonFormat.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY);
/*     */     
/* 125 */     NullValueProvider nuller = findContentNullProvider(ctxt, property, deser);
/*     */     
/* 127 */     if (deser != null && isDefaultDeserializer(deser)) {
/* 128 */       deser = null;
/*     */     }
/* 130 */     if (this._elementDeserializer == deser && 
/* 131 */       Objects.equals(this._unwrapSingle, unwrapSingle) && this._nullProvider == nuller)
/*     */     {
/* 133 */       return this;
/*     */     }
/* 135 */     return new StringArrayDeserializer(deser, nuller, unwrapSingle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 142 */     if (!p.isExpectedStartArrayToken()) {
/* 143 */       return handleNonArray(p, ctxt);
/*     */     }
/* 145 */     if (this._elementDeserializer != null) {
/* 146 */       return _deserializeCustom(p, ctxt, (String[])null);
/*     */     }
/*     */     
/* 149 */     ObjectBuffer buffer = ctxt.leaseObjectBuffer();
/* 150 */     Object[] chunk = buffer.resetAndStart();
/*     */     
/* 152 */     int ix = 0;
/*     */     
/*     */     try {
/*     */       while (true) {
/* 156 */         String value = p.nextTextValue();
/* 157 */         if (value == null) {
/* 158 */           JsonToken t = p.currentToken();
/* 159 */           if (t == JsonToken.END_ARRAY) {
/*     */             break;
/*     */           }
/* 162 */           if (t == JsonToken.VALUE_NULL) {
/* 163 */             if (this._skipNullValues) {
/*     */               continue;
/*     */             }
/* 166 */             value = (String)this._nullProvider.getNullValue(ctxt);
/*     */           } else {
/* 168 */             value = _parseString(p, ctxt, this._nullProvider);
/*     */           } 
/*     */         } 
/* 171 */         if (ix >= chunk.length) {
/* 172 */           chunk = buffer.appendCompletedChunk(chunk);
/* 173 */           ix = 0;
/*     */         } 
/* 175 */         chunk[ix++] = value;
/*     */       } 
/* 177 */     } catch (Exception e) {
/* 178 */       throw JsonMappingException.wrapWithPath(e, chunk, buffer.bufferedSize() + ix);
/*     */     } 
/* 180 */     String[] result = (String[])buffer.completeAndClearBuffer(chunk, ix, String.class);
/* 181 */     ctxt.returnObjectBuffer(buffer);
/* 182 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String[] _deserializeCustom(JsonParser p, DeserializationContext ctxt, String[] old) throws IOException {
/*     */     int ix;
/*     */     Object[] chunk;
/* 191 */     ObjectBuffer buffer = ctxt.leaseObjectBuffer();
/*     */ 
/*     */ 
/*     */     
/* 195 */     if (old == null) {
/* 196 */       ix = 0;
/* 197 */       chunk = buffer.resetAndStart();
/*     */     } else {
/* 199 */       ix = old.length;
/* 200 */       chunk = buffer.resetAndStart((Object[])old, ix);
/*     */     } 
/*     */     
/* 203 */     JsonDeserializer<String> deser = this._elementDeserializer;
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*     */       while (true) {
/*     */         String value;
/*     */ 
/*     */ 
/*     */         
/* 213 */         if (p.nextTextValue() == null) {
/* 214 */           JsonToken t = p.currentToken();
/* 215 */           if (t == JsonToken.END_ARRAY) {
/*     */             break;
/*     */           }
/*     */           
/* 219 */           if (t == JsonToken.VALUE_NULL) {
/* 220 */             if (this._skipNullValues) {
/*     */               continue;
/*     */             }
/* 223 */             value = (String)this._nullProvider.getNullValue(ctxt);
/*     */           } else {
/* 225 */             value = (String)deser.deserialize(p, ctxt);
/*     */           } 
/*     */         } else {
/* 228 */           value = (String)deser.deserialize(p, ctxt);
/*     */         } 
/* 230 */         if (ix >= chunk.length) {
/* 231 */           chunk = buffer.appendCompletedChunk(chunk);
/* 232 */           ix = 0;
/*     */         } 
/* 234 */         chunk[ix++] = value;
/*     */       } 
/* 236 */     } catch (Exception e) {
/*     */       
/* 238 */       throw JsonMappingException.wrapWithPath(e, String.class, ix);
/*     */     } 
/* 240 */     String[] result = (String[])buffer.completeAndClearBuffer(chunk, ix, String.class);
/* 241 */     ctxt.returnObjectBuffer(buffer);
/* 242 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object deserializeWithType(JsonParser p, DeserializationContext ctxt, TypeDeserializer typeDeserializer) throws IOException {
/* 247 */     return typeDeserializer.deserializeTypedFromArray(p, ctxt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] deserialize(JsonParser p, DeserializationContext ctxt, String[] intoValue) throws IOException {
/* 255 */     if (!p.isExpectedStartArrayToken()) {
/* 256 */       String[] arr = handleNonArray(p, ctxt);
/* 257 */       if (arr == null) {
/* 258 */         return intoValue;
/*     */       }
/* 260 */       int offset = intoValue.length;
/* 261 */       String[] arrayOfString1 = new String[offset + arr.length];
/* 262 */       System.arraycopy(intoValue, 0, arrayOfString1, 0, offset);
/* 263 */       System.arraycopy(arr, 0, arrayOfString1, offset, arr.length);
/* 264 */       return arrayOfString1;
/*     */     } 
/*     */     
/* 267 */     if (this._elementDeserializer != null) {
/* 268 */       return _deserializeCustom(p, ctxt, intoValue);
/*     */     }
/* 270 */     ObjectBuffer buffer = ctxt.leaseObjectBuffer();
/* 271 */     int ix = intoValue.length;
/* 272 */     Object[] chunk = buffer.resetAndStart((Object[])intoValue, ix);
/*     */     
/*     */     try {
/*     */       while (true) {
/* 276 */         String value = p.nextTextValue();
/* 277 */         if (value == null) {
/* 278 */           JsonToken t = p.currentToken();
/* 279 */           if (t == JsonToken.END_ARRAY) {
/*     */             break;
/*     */           }
/* 282 */           if (t == JsonToken.VALUE_NULL) {
/*     */             
/* 284 */             if (this._skipNullValues) {
/* 285 */               return NO_STRINGS;
/*     */             }
/* 287 */             value = (String)this._nullProvider.getNullValue(ctxt);
/*     */           } else {
/* 289 */             value = _parseString(p, ctxt, this._nullProvider);
/*     */           } 
/*     */         } 
/* 292 */         if (ix >= chunk.length) {
/* 293 */           chunk = buffer.appendCompletedChunk(chunk);
/* 294 */           ix = 0;
/*     */         } 
/* 296 */         chunk[ix++] = value;
/*     */       } 
/* 298 */     } catch (Exception e) {
/* 299 */       throw JsonMappingException.wrapWithPath(e, chunk, buffer.bufferedSize() + ix);
/*     */     } 
/* 301 */     String[] result = (String[])buffer.completeAndClearBuffer(chunk, ix, String.class);
/* 302 */     ctxt.returnObjectBuffer(buffer);
/* 303 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String[] handleNonArray(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 311 */     boolean canWrap = (this._unwrapSingle == Boolean.TRUE || (this._unwrapSingle == null && ctxt.isEnabled(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY)));
/* 312 */     if (canWrap) {
/*     */       String value;
/* 314 */       if (p.hasToken(JsonToken.VALUE_NULL)) {
/* 315 */         value = (String)this._nullProvider.getNullValue(ctxt);
/*     */       } else {
/* 317 */         if (p.hasToken(JsonToken.VALUE_STRING)) {
/* 318 */           String textValue = p.getText();
/*     */           
/* 320 */           if (textValue.isEmpty()) {
/* 321 */             CoercionAction act = ctxt.findCoercionAction(logicalType(), handledType(), CoercionInputShape.EmptyString);
/*     */             
/* 323 */             if (act != CoercionAction.Fail) {
/* 324 */               return (String[])_deserializeFromEmptyString(p, ctxt, act, handledType(), "empty String (\"\")");
/*     */             }
/*     */           }
/* 327 */           else if (_isBlank(textValue)) {
/* 328 */             CoercionAction act = ctxt.findCoercionFromBlankString(logicalType(), handledType(), CoercionAction.Fail);
/*     */             
/* 330 */             if (act != CoercionAction.Fail) {
/* 331 */               return (String[])_deserializeFromEmptyString(p, ctxt, act, handledType(), "blank String (all whitespace)");
/*     */             }
/*     */           } 
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 338 */         value = _parseString(p, ctxt, this._nullProvider);
/*     */       } 
/* 340 */       return new String[] { value };
/*     */     } 
/* 342 */     if (p.hasToken(JsonToken.VALUE_STRING)) {
/* 343 */       return _deserializeFromString(p, ctxt);
/*     */     }
/* 345 */     return (String[])ctxt.handleUnexpectedToken(this._valueClass, p);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\deser\std\StringArrayDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */