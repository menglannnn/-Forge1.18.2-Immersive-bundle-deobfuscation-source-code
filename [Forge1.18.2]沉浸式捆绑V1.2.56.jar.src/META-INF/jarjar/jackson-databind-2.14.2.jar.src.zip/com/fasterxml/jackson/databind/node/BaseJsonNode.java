/*     */ package com.fasterxml.jackson.databind.node;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonPointer;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.ObjectCodec;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BaseJsonNode
/*     */   extends JsonNode
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */   Object writeReplace() {
/*  28 */     return NodeSerialization.from(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final JsonNode findPath(String fieldName) {
/*  42 */     JsonNode value = findValue(fieldName);
/*  43 */     if (value == null) {
/*  44 */       return MissingNode.getInstance();
/*     */     }
/*  46 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract int hashCode();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonNode required(String fieldName) {
/*  60 */     return (JsonNode)_reportRequiredViolation("Node of type `%s` has no fields", new Object[] {
/*  61 */           getClass().getSimpleName()
/*     */         });
/*     */   }
/*     */   
/*     */   public JsonNode required(int index) {
/*  66 */     return (JsonNode)_reportRequiredViolation("Node of type `%s` has no indexed values", new Object[] {
/*  67 */           getClass().getSimpleName()
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonParser traverse() {
/*  78 */     return (JsonParser)new TreeTraversingParser(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonParser traverse(ObjectCodec codec) {
/*  83 */     return (JsonParser)new TreeTraversingParser(this, codec);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract JsonToken asToken();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonParser.NumberType numberType() {
/* 103 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectNode withObject(JsonPointer ptr, JsonNode.OverwriteMode overwriteMode, boolean preferIndex) {
/* 117 */     if (ptr.matches()) {
/* 118 */       if (this instanceof ObjectNode) {
/* 119 */         return (ObjectNode)this;
/*     */       }
/* 121 */       _reportWrongNodeType("Can only call `withObject()` with empty JSON Pointer on `ObjectNode`, not `%s`", new Object[] {
/* 122 */             getClass().getName()
/*     */           });
/*     */     } 
/* 125 */     ObjectNode n = _withObject(ptr, ptr, overwriteMode, preferIndex);
/* 126 */     if (n == null)
/* 127 */       _reportWrongNodeType("Cannot replace context node (of type `%s`) using `withObject()` with  JSON Pointer '%s'", new Object[] {
/* 128 */             getClass().getName(), ptr
/*     */           }); 
/* 130 */     return n;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ObjectNode _withObject(JsonPointer origPtr, JsonPointer currentPtr, JsonNode.OverwriteMode overwriteMode, boolean preferIndex) {
/* 148 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _withXxxVerifyReplace(JsonPointer origPtr, JsonPointer currentPtr, JsonNode.OverwriteMode overwriteMode, boolean preferIndex, JsonNode toReplace) {
/* 156 */     if (!_withXxxMayReplace(toReplace, overwriteMode)) {
/* 157 */       _reportWrongNodeType("Cannot replace `JsonNode` of type `%s` for property \"%s\" in JSON Pointer \"%s\" (mode `OverwriteMode.%s`)", new Object[] { toReplace
/*     */             
/* 159 */             .getClass().getName(), currentPtr.getMatchingProperty(), origPtr, overwriteMode });
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean _withXxxMayReplace(JsonNode node, JsonNode.OverwriteMode overwriteMode) {
/* 165 */     switch (overwriteMode) {
/*     */       case NONE:
/* 167 */         return false;
/*     */       case NULLS:
/* 169 */         return node.isNull();
/*     */       case SCALARS:
/* 171 */         return !node.isContainerNode();
/*     */     } 
/*     */     
/* 174 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayNode withArray(JsonPointer ptr, JsonNode.OverwriteMode overwriteMode, boolean preferIndex) {
/* 183 */     if (ptr.matches()) {
/* 184 */       if (this instanceof ArrayNode) {
/* 185 */         return (ArrayNode)this;
/*     */       }
/* 187 */       _reportWrongNodeType("Can only call `withArray()` with empty JSON Pointer on `ArrayNode`, not `%s`", new Object[] {
/* 188 */             getClass().getName()
/*     */           });
/*     */     } 
/* 191 */     ArrayNode n = _withArray(ptr, ptr, overwriteMode, preferIndex);
/* 192 */     if (n == null)
/* 193 */       _reportWrongNodeType("Cannot replace context node (of type `%s`) using `withArray()` with  JSON Pointer '%s'", new Object[] {
/* 194 */             getClass().getName(), ptr
/*     */           }); 
/* 196 */     return n;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ArrayNode _withArray(JsonPointer origPtr, JsonPointer currentPtr, JsonNode.OverwriteMode overwriteMode, boolean preferIndex) {
/* 205 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void serialize(JsonGenerator paramJsonGenerator, SerializerProvider paramSerializerProvider) throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void serializeWithType(JsonGenerator paramJsonGenerator, SerializerProvider paramSerializerProvider, TypeSerializer paramTypeSerializer) throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 238 */     return InternalNodeMapper.nodeToString(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toPrettyString() {
/* 243 */     return InternalNodeMapper.nodeToPrettyString(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected <T> T _reportWrongNodeType(String msgTemplate, Object... args) {
/* 257 */     throw new UnsupportedOperationException(String.format(msgTemplate, args));
/*     */   }
/*     */   
/*     */   protected <T> T _reportWrongNodeOperation(String msgTemplate, Object... args) {
/* 261 */     throw new UnsupportedOperationException(String.format(msgTemplate, args));
/*     */   }
/*     */ 
/*     */   
/*     */   protected JsonPointer _jsonPointerIfValid(String exprOrProperty) {
/* 266 */     if (exprOrProperty.isEmpty() || exprOrProperty.charAt(0) == '/') {
/* 267 */       return JsonPointer.compile(exprOrProperty);
/*     */     }
/* 269 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\node\BaseJsonNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */