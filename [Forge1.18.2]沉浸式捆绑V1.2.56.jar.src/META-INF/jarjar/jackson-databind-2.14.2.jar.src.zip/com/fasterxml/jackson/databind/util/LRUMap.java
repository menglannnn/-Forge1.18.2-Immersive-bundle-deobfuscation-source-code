/*    */ package com.fasterxml.jackson.databind.util;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.util.internal.PrivateMaxEntriesMap;
/*    */ import java.io.Serializable;
/*    */ import java.util.Map;
/*    */ import java.util.function.BiConsumer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LRUMap<K, V>
/*    */   implements LookupCache<K, V>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 2L;
/*    */   protected final int _initialEntries;
/*    */   protected final int _maxEntries;
/*    */   protected final transient PrivateMaxEntriesMap<K, V> _map;
/*    */   
/*    */   public LRUMap(int initialEntries, int maxEntries) {
/* 33 */     this._initialEntries = initialEntries;
/* 34 */     this._maxEntries = maxEntries;
/*    */     
/* 36 */     this
/*    */ 
/*    */ 
/*    */       
/* 40 */       ._map = (new PrivateMaxEntriesMap.Builder()).initialCapacity(initialEntries).maximumCapacity(maxEntries).concurrencyLevel(4).build();
/*    */   }
/*    */ 
/*    */   
/*    */   public V put(K key, V value) {
/* 45 */     return (V)this._map.put(key, value);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public V putIfAbsent(K key, V value) {
/* 53 */     return (V)this._map.putIfAbsent(key, value);
/*    */   }
/*    */ 
/*    */   
/*    */   public V get(Object key) {
/* 58 */     return (V)this._map.get(key);
/*    */   }
/*    */   public void clear() {
/* 61 */     this._map.clear();
/*    */   }
/*    */   public int size() {
/* 64 */     return this._map.size();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void contents(BiConsumer<K, V> consumer) {
/* 73 */     for (Map.Entry<K, V> entry : (Iterable<Map.Entry<K, V>>)this._map.entrySet()) {
/* 74 */       consumer.accept(entry.getKey(), entry.getValue());
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Object readResolve() {
/* 85 */     return new LRUMap(this._initialEntries, this._maxEntries);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databin\\util\LRUMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */