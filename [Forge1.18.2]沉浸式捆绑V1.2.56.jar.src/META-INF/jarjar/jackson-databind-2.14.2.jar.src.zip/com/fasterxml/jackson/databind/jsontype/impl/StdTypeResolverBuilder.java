/*     */ package com.fasterxml.jackson.databind.jsontype.impl;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonTypeInfo;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.SerializationConfig;
/*     */ import com.fasterxml.jackson.databind.annotation.NoClass;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import com.fasterxml.jackson.databind.jsontype.NamedType;
/*     */ import com.fasterxml.jackson.databind.jsontype.PolymorphicTypeValidator;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeIdResolver;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeResolverBuilder;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import java.util.Collection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StdTypeResolverBuilder
/*     */   implements TypeResolverBuilder<StdTypeResolverBuilder>
/*     */ {
/*     */   protected JsonTypeInfo.Id _idType;
/*     */   protected JsonTypeInfo.As _includeAs;
/*     */   protected String _typeProperty;
/*     */   protected boolean _typeIdVisible = false;
/*     */   protected Class<?> _defaultImpl;
/*     */   protected TypeIdResolver _customIdResolver;
/*     */   
/*     */   protected StdTypeResolverBuilder(JsonTypeInfo.Id idType, JsonTypeInfo.As idAs, String propName) {
/*  58 */     this._idType = idType;
/*  59 */     this._includeAs = idAs;
/*  60 */     this._typeProperty = propName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected StdTypeResolverBuilder(StdTypeResolverBuilder base, Class<?> defaultImpl) {
/*  71 */     this._idType = base._idType;
/*  72 */     this._includeAs = base._includeAs;
/*  73 */     this._typeProperty = base._typeProperty;
/*  74 */     this._typeIdVisible = base._typeIdVisible;
/*  75 */     this._customIdResolver = base._customIdResolver;
/*     */     
/*  77 */     this._defaultImpl = defaultImpl;
/*     */   }
/*     */   
/*     */   public static StdTypeResolverBuilder noTypeInfoBuilder() {
/*  81 */     return (new StdTypeResolverBuilder()).init(JsonTypeInfo.Id.NONE, (TypeIdResolver)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StdTypeResolverBuilder init(JsonTypeInfo.Id idType, TypeIdResolver idRes) {
/*  88 */     if (idType == null) {
/*  89 */       throw new IllegalArgumentException("idType cannot be null");
/*     */     }
/*  91 */     this._idType = idType;
/*  92 */     this._customIdResolver = idRes;
/*     */     
/*  94 */     this._typeProperty = idType.getDefaultPropertyName();
/*  95 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeSerializer buildTypeSerializer(SerializationConfig config, JavaType baseType, Collection<NamedType> subtypes) {
/* 102 */     if (this._idType == JsonTypeInfo.Id.NONE) return null;
/*     */ 
/*     */     
/* 105 */     if (baseType.isPrimitive())
/*     */     {
/* 107 */       if (!allowPrimitiveTypes((MapperConfig<?>)config, baseType)) {
/* 108 */         return null;
/*     */       }
/*     */     }
/* 111 */     if (this._idType == JsonTypeInfo.Id.DEDUCTION)
/*     */     {
/*     */       
/* 114 */       return AsDeductionTypeSerializer.instance();
/*     */     }
/*     */     
/* 117 */     TypeIdResolver idRes = idResolver((MapperConfig<?>)config, baseType, subTypeValidator((MapperConfig<?>)config), subtypes, true, false);
/*     */     
/* 119 */     switch (this._includeAs) {
/*     */       case DEDUCTION:
/* 121 */         return new AsArrayTypeSerializer(idRes, null);
/*     */       case CLASS:
/* 123 */         return new AsPropertyTypeSerializer(idRes, null, this._typeProperty);
/*     */       case MINIMAL_CLASS:
/* 125 */         return new AsWrapperTypeSerializer(idRes, null);
/*     */       case NAME:
/* 127 */         return new AsExternalTypeSerializer(idRes, null, this._typeProperty);
/*     */       
/*     */       case NONE:
/* 130 */         return new AsExistingPropertyTypeSerializer(idRes, null, this._typeProperty);
/*     */     } 
/* 132 */     throw new IllegalStateException("Do not know how to construct standard type serializer for inclusion type: " + this._includeAs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeDeserializer buildTypeDeserializer(DeserializationConfig config, JavaType baseType, Collection<NamedType> subtypes) {
/* 145 */     if (this._idType == JsonTypeInfo.Id.NONE) return null;
/*     */ 
/*     */     
/* 148 */     if (baseType.isPrimitive())
/*     */     {
/* 150 */       if (!allowPrimitiveTypes((MapperConfig<?>)config, baseType)) {
/* 151 */         return null;
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 157 */     PolymorphicTypeValidator subTypeValidator = verifyBaseTypeValidity((MapperConfig<?>)config, baseType);
/*     */     
/* 159 */     TypeIdResolver idRes = idResolver((MapperConfig<?>)config, baseType, subTypeValidator, subtypes, false, true);
/*     */     
/* 161 */     JavaType defaultImpl = defineDefaultImpl(config, baseType);
/*     */     
/* 163 */     if (this._idType == JsonTypeInfo.Id.DEDUCTION)
/*     */     {
/* 165 */       return new AsDeductionTypeDeserializer(baseType, idRes, defaultImpl, config, subtypes);
/*     */     }
/*     */ 
/*     */     
/* 169 */     switch (this._includeAs) {
/*     */       case DEDUCTION:
/* 171 */         return new AsArrayTypeDeserializer(baseType, idRes, this._typeProperty, this._typeIdVisible, defaultImpl);
/*     */       
/*     */       case CLASS:
/*     */       case NONE:
/* 175 */         return new AsPropertyTypeDeserializer(baseType, idRes, this._typeProperty, this._typeIdVisible, defaultImpl, this._includeAs);
/*     */       
/*     */       case MINIMAL_CLASS:
/* 178 */         return new AsWrapperTypeDeserializer(baseType, idRes, this._typeProperty, this._typeIdVisible, defaultImpl);
/*     */       
/*     */       case NAME:
/* 181 */         return new AsExternalTypeDeserializer(baseType, idRes, this._typeProperty, this._typeIdVisible, defaultImpl);
/*     */     } 
/*     */     
/* 184 */     throw new IllegalStateException("Do not know how to construct standard type serializer for inclusion type: " + this._includeAs);
/*     */   }
/*     */ 
/*     */   
/*     */   protected JavaType defineDefaultImpl(DeserializationConfig config, JavaType baseType) {
/* 189 */     if (this._defaultImpl != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 196 */       if (this._defaultImpl == Void.class || this._defaultImpl == NoClass.class)
/*     */       {
/*     */         
/* 199 */         return config.getTypeFactory().constructType(this._defaultImpl);
/*     */       }
/* 201 */       if (baseType.hasRawClass(this._defaultImpl)) {
/* 202 */         return baseType;
/*     */       }
/* 204 */       if (baseType.isTypeOrSuperTypeOf(this._defaultImpl))
/*     */       {
/* 206 */         return config.getTypeFactory()
/* 207 */           .constructSpecializedType(baseType, this._defaultImpl);
/*     */       }
/* 209 */       if (baseType.hasRawClass(this._defaultImpl)) {
/* 210 */         return baseType;
/*     */       }
/*     */     } 
/*     */     
/* 214 */     if (config.isEnabled(MapperFeature.USE_BASE_TYPE_AS_DEFAULT_IMPL) && 
/* 215 */       !baseType.isAbstract())
/*     */     {
/* 217 */       return baseType;
/*     */     }
/* 219 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StdTypeResolverBuilder inclusion(JsonTypeInfo.As includeAs) {
/* 230 */     if (includeAs == null) {
/* 231 */       throw new IllegalArgumentException("includeAs cannot be null");
/*     */     }
/* 233 */     this._includeAs = includeAs;
/* 234 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StdTypeResolverBuilder typeProperty(String typeIdPropName) {
/* 244 */     if (typeIdPropName == null || typeIdPropName.isEmpty()) {
/* 245 */       typeIdPropName = this._idType.getDefaultPropertyName();
/*     */     }
/* 247 */     this._typeProperty = typeIdPropName;
/* 248 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public StdTypeResolverBuilder defaultImpl(Class<?> defaultImpl) {
/* 253 */     this._defaultImpl = defaultImpl;
/* 254 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public StdTypeResolverBuilder typeIdVisibility(boolean isVisible) {
/* 259 */     this._typeIdVisible = isVisible;
/* 260 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public StdTypeResolverBuilder withDefaultImpl(Class<?> defaultImpl) {
/* 265 */     if (this._defaultImpl == defaultImpl) {
/* 266 */       return this;
/*     */     }
/* 268 */     ClassUtil.verifyMustOverride(StdTypeResolverBuilder.class, this, "withDefaultImpl");
/*     */ 
/*     */     
/* 271 */     return new StdTypeResolverBuilder(this, defaultImpl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getDefaultImpl() {
/* 280 */     return this._defaultImpl;
/*     */   }
/* 282 */   public String getTypeProperty() { return this._typeProperty; } public boolean isTypeIdVisible() {
/* 283 */     return this._typeIdVisible;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TypeIdResolver idResolver(MapperConfig<?> config, JavaType baseType, PolymorphicTypeValidator subtypeValidator, Collection<NamedType> subtypes, boolean forSer, boolean forDeser) {
/* 301 */     if (this._customIdResolver != null) return this._customIdResolver; 
/* 302 */     if (this._idType == null) throw new IllegalStateException("Cannot build, 'init()' not yet called"); 
/* 303 */     switch (this._idType) {
/*     */       case DEDUCTION:
/*     */       case CLASS:
/* 306 */         return ClassNameIdResolver.construct(baseType, config, subtypeValidator);
/*     */       case MINIMAL_CLASS:
/* 308 */         return MinimalClassNameIdResolver.construct(baseType, config, subtypeValidator);
/*     */       case NAME:
/* 310 */         return TypeNameIdResolver.construct(config, baseType, subtypes, forSer, forDeser);
/*     */       case NONE:
/* 312 */         return null;
/*     */     } 
/*     */     
/* 315 */     throw new IllegalStateException("Do not know how to construct standard type id resolver for idType: " + this._idType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PolymorphicTypeValidator subTypeValidator(MapperConfig<?> config) {
/* 334 */     return config.getPolymorphicTypeValidator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected PolymorphicTypeValidator verifyBaseTypeValidity(MapperConfig<?> config, JavaType baseType) {
/* 347 */     PolymorphicTypeValidator ptv = subTypeValidator(config);
/* 348 */     if (this._idType == JsonTypeInfo.Id.CLASS || this._idType == JsonTypeInfo.Id.MINIMAL_CLASS) {
/* 349 */       PolymorphicTypeValidator.Validity validity = ptv.validateBaseType(config, baseType);
/*     */       
/* 351 */       if (validity == PolymorphicTypeValidator.Validity.DENIED) {
/* 352 */         return reportInvalidBaseType(config, baseType, ptv);
/*     */       }
/*     */       
/* 355 */       if (validity == PolymorphicTypeValidator.Validity.ALLOWED) {
/* 356 */         return (PolymorphicTypeValidator)LaissezFaireSubTypeValidator.instance;
/*     */       }
/*     */     } 
/*     */     
/* 360 */     return ptv;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected PolymorphicTypeValidator reportInvalidBaseType(MapperConfig<?> config, JavaType baseType, PolymorphicTypeValidator ptv) {
/* 369 */     throw new IllegalArgumentException(String.format("Configured `PolymorphicTypeValidator` (of type %s) denied resolution of all subtypes of base type %s", new Object[] {
/*     */             
/* 371 */             ClassUtil.classNameOf(ptv), ClassUtil.classNameOf(baseType.getRawClass())
/*     */           }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean allowPrimitiveTypes(MapperConfig<?> config, JavaType baseType) {
/* 399 */     return false;
/*     */   }
/*     */   
/*     */   public StdTypeResolverBuilder() {}
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\jsontype\impl\StdTypeResolverBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */