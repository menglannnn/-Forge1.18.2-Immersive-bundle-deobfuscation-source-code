/*     */ package com.fasterxml.jackson.databind.deser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.deser.ContextualDeserializer;
/*     */ import com.fasterxml.jackson.databind.deser.ResolvableDeserializer;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*     */ import com.fasterxml.jackson.databind.type.LogicalType;
/*     */ import com.fasterxml.jackson.databind.util.AccessPattern;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import com.fasterxml.jackson.databind.util.Converter;
/*     */ import java.io.IOException;
/*     */ import java.util.Collection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StdDelegatingDeserializer<T>
/*     */   extends StdDeserializer<T>
/*     */   implements ContextualDeserializer, ResolvableDeserializer
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final Converter<Object, T> _converter;
/*     */   protected final JavaType _delegateType;
/*     */   protected final JsonDeserializer<Object> _delegateDeserializer;
/*     */   
/*     */   public StdDelegatingDeserializer(Converter<?, T> converter) {
/*  68 */     super(Object.class);
/*  69 */     this._converter = (Converter)converter;
/*  70 */     this._delegateType = null;
/*  71 */     this._delegateDeserializer = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StdDelegatingDeserializer(Converter<Object, T> converter, JavaType delegateType, JsonDeserializer<?> delegateDeserializer) {
/*  78 */     super(delegateType);
/*  79 */     this._converter = converter;
/*  80 */     this._delegateType = delegateType;
/*  81 */     this._delegateDeserializer = (JsonDeserializer)delegateDeserializer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected StdDelegatingDeserializer(StdDelegatingDeserializer<T> src) {
/*  89 */     super(src);
/*  90 */     this._converter = src._converter;
/*  91 */     this._delegateType = src._delegateType;
/*  92 */     this._delegateDeserializer = src._delegateDeserializer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected StdDelegatingDeserializer<T> withDelegate(Converter<Object, T> converter, JavaType delegateType, JsonDeserializer<?> delegateDeserializer) {
/* 102 */     ClassUtil.verifyMustOverride(StdDelegatingDeserializer.class, this, "withDelegate");
/* 103 */     return new StdDelegatingDeserializer(converter, delegateType, delegateDeserializer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resolve(DeserializationContext ctxt) throws JsonMappingException {
/* 118 */     if (this._delegateDeserializer != null && this._delegateDeserializer instanceof ResolvableDeserializer) {
/* 119 */       ((ResolvableDeserializer)this._delegateDeserializer).resolve(ctxt);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonDeserializer<?> createContextual(DeserializationContext ctxt, BeanProperty property) throws JsonMappingException {
/* 128 */     if (this._delegateDeserializer != null) {
/* 129 */       JsonDeserializer<?> deser = ctxt.handleSecondaryContextualization(this._delegateDeserializer, property, this._delegateType);
/*     */       
/* 131 */       if (deser != this._delegateDeserializer) {
/* 132 */         return withDelegate(this._converter, this._delegateType, deser);
/*     */       }
/* 134 */       return this;
/*     */     } 
/*     */     
/* 137 */     JavaType delegateType = this._converter.getInputType(ctxt.getTypeFactory());
/* 138 */     return withDelegate(this._converter, delegateType, ctxt
/* 139 */         .findContextualValueDeserializer(delegateType, property));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 151 */     Object delegateValue = this._delegateDeserializer.deserialize(p, ctxt);
/* 152 */     if (delegateValue == null) {
/* 153 */       return null;
/*     */     }
/* 155 */     return convertValue(delegateValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserializeWithType(JsonParser p, DeserializationContext ctxt, TypeDeserializer typeDeserializer) throws IOException {
/* 173 */     Object delegateValue = this._delegateDeserializer.deserialize(p, ctxt);
/* 174 */     if (delegateValue == null) {
/* 175 */       return null;
/*     */     }
/* 177 */     return convertValue(delegateValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T deserialize(JsonParser p, DeserializationContext ctxt, Object intoValue) throws IOException {
/* 185 */     if (this._delegateType.getRawClass().isAssignableFrom(intoValue.getClass())) {
/* 186 */       return (T)this._delegateDeserializer.deserialize(p, ctxt, intoValue);
/*     */     }
/* 188 */     return (T)_handleIncompatibleUpdateValue(p, ctxt, intoValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object _handleIncompatibleUpdateValue(JsonParser p, DeserializationContext ctxt, Object intoValue) throws IOException {
/* 204 */     throw new UnsupportedOperationException(
/* 205 */         String.format("Cannot update object of type %s (using deserializer for type %s)" + intoValue
/* 206 */           .getClass().getName(), new Object[] { this._delegateType }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> handledType() {
/* 217 */     return this._delegateDeserializer.handledType();
/*     */   }
/*     */ 
/*     */   
/*     */   public LogicalType logicalType() {
/* 222 */     return this._delegateDeserializer.logicalType();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCachable() {
/* 228 */     return (this._delegateDeserializer != null && this._delegateDeserializer.isCachable());
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonDeserializer<?> getDelegatee() {
/* 233 */     return this._delegateDeserializer;
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<Object> getKnownPropertyNames() {
/* 238 */     return this._delegateDeserializer.getKnownPropertyNames();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T getNullValue(DeserializationContext ctxt) throws JsonMappingException {
/* 249 */     return _convertIfNonNull(this._delegateDeserializer.getNullValue(ctxt));
/*     */   }
/*     */ 
/*     */   
/*     */   public AccessPattern getNullAccessPattern() {
/* 254 */     return this._delegateDeserializer.getNullAccessPattern();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getAbsentValue(DeserializationContext ctxt) throws JsonMappingException {
/* 259 */     return _convertIfNonNull(this._delegateDeserializer.getAbsentValue(ctxt));
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getEmptyValue(DeserializationContext ctxt) throws JsonMappingException {
/* 264 */     return _convertIfNonNull(this._delegateDeserializer.getEmptyValue(ctxt));
/*     */   }
/*     */ 
/*     */   
/*     */   public AccessPattern getEmptyAccessPattern() {
/* 269 */     return this._delegateDeserializer.getEmptyAccessPattern();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean supportsUpdate(DeserializationConfig config) {
/* 280 */     return this._delegateDeserializer.supportsUpdate(config);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected T convertValue(Object delegateValue) {
/* 302 */     return (T)this._converter.convert(delegateValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected T _convertIfNonNull(Object delegateValue) {
/* 313 */     return (delegateValue == null) ? null : (T)this._converter
/* 314 */       .convert(delegateValue);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\deser\std\StdDelegatingDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */