package com.fasterxml.jackson.databind.jsonFormatVisitors;

public interface JsonAnyFormatVisitor {
  public static class Base implements JsonAnyFormatVisitor {}
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\jsonFormatVisitors\JsonAnyFormatVisitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */