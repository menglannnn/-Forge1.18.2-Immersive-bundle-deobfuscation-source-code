/*     */ package com.fasterxml.jackson.databind.deser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.StreamReadCapability;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.annotation.JacksonStdImpl;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*     */ import com.fasterxml.jackson.databind.type.LogicalType;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @JacksonStdImpl
/*     */ final class UntypedObjectDeserializerNR
/*     */   extends StdDeserializer<Object>
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  32 */   protected static final Object[] NO_OBJECTS = new Object[0];
/*     */   
/*  34 */   public static final UntypedObjectDeserializerNR std = new UntypedObjectDeserializerNR();
/*     */   
/*     */   protected final boolean _nonMerging;
/*     */   
/*     */   public UntypedObjectDeserializerNR() {
/*  39 */     this(false);
/*     */   }
/*     */   protected UntypedObjectDeserializerNR(boolean nonMerging) {
/*  42 */     super(Object.class);
/*  43 */     this._nonMerging = nonMerging;
/*     */   }
/*     */   
/*     */   public static UntypedObjectDeserializerNR instance(boolean nonMerging) {
/*  47 */     if (nonMerging) {
/*  48 */       return new UntypedObjectDeserializerNR(true);
/*     */     }
/*  50 */     return std;
/*     */   }
/*     */ 
/*     */   
/*     */   public LogicalType logicalType() {
/*  55 */     return LogicalType.Untyped;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean supportsUpdate(DeserializationConfig config) {
/*  62 */     return this._nonMerging ? Boolean.FALSE : null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  68 */     switch (p.currentTokenId()) {
/*     */       case 1:
/*  70 */         return _deserializeNR(p, ctxt, 
/*  71 */             Scope.rootObjectScope(ctxt.isEnabled(StreamReadCapability.DUPLICATE_PROPERTIES)));
/*     */ 
/*     */       
/*     */       case 2:
/*  75 */         return Scope.emptyMap();
/*     */       case 5:
/*  77 */         return _deserializeObjectAtName(p, ctxt);
/*     */       case 3:
/*  79 */         return _deserializeNR(p, ctxt, Scope.rootArrayScope());
/*     */       
/*     */       case 6:
/*  82 */         return p.getText();
/*     */       case 7:
/*  84 */         if (ctxt.hasSomeOfFeatures(F_MASK_INT_COERCIONS)) {
/*  85 */           return _coerceIntegral(p, ctxt);
/*     */         }
/*  87 */         return p.getNumberValue();
/*     */       case 8:
/*  89 */         if (ctxt.isEnabled(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS)) {
/*  90 */           return p.getDecimalValue();
/*     */         }
/*  92 */         return p.getNumberValue();
/*     */       case 9:
/*  94 */         return Boolean.TRUE;
/*     */       case 10:
/*  96 */         return Boolean.FALSE;
/*     */       case 11:
/*  98 */         return null;
/*     */       case 12:
/* 100 */         return p.getEmbeddedObject();
/*     */     } 
/*     */     
/* 103 */     return ctxt.handleUnexpectedToken(getValueType(ctxt), p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserializeWithType(JsonParser p, DeserializationContext ctxt, TypeDeserializer typeDeserializer) throws IOException {
/* 111 */     switch (p.currentTokenId()) {
/*     */       case 1:
/*     */       case 3:
/*     */       case 5:
/* 115 */         return typeDeserializer.deserializeTypedFromAny(p, ctxt);
/*     */     } 
/* 117 */     return _deserializeAnyScalar(p, ctxt, p.currentTokenId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserialize(JsonParser p, DeserializationContext ctxt, Object intoValue) throws IOException {
/*     */     JsonToken t;
/* 126 */     if (this._nonMerging) {
/* 127 */       return deserialize(p, ctxt);
/*     */     }
/* 129 */     switch (p.currentTokenId()) {
/*     */       case 2:
/*     */       case 4:
/* 132 */         return intoValue;
/*     */       
/*     */       case 1:
/* 135 */         t = p.nextToken();
/* 136 */         if (t == JsonToken.END_OBJECT) {
/* 137 */           return intoValue;
/*     */         }
/*     */ 
/*     */       
/*     */       case 5:
/* 142 */         if (intoValue instanceof Map) {
/* 143 */           Map<Object, Object> m = (Map<Object, Object>)intoValue;
/*     */           
/* 145 */           String key = p.currentName(); while (true) {
/*     */             Object newV;
/* 147 */             p.nextToken();
/*     */             
/* 149 */             Object old = m.get(key);
/*     */             
/* 151 */             if (old != null) {
/* 152 */               newV = deserialize(p, ctxt, old);
/*     */             } else {
/* 154 */               newV = deserialize(p, ctxt);
/*     */             } 
/* 156 */             if (newV != old) {
/* 157 */               m.put(key, newV);
/*     */             }
/* 159 */             if ((key = p.nextFieldName()) == null)
/* 160 */               return intoValue; 
/*     */           } 
/*     */         } 
/*     */         break;
/*     */       case 3:
/* 165 */         t = p.nextToken();
/* 166 */         if (t == JsonToken.END_ARRAY) {
/* 167 */           return intoValue;
/*     */         }
/*     */ 
/*     */         
/* 171 */         if (intoValue instanceof Collection) {
/* 172 */           Collection<Object> c = (Collection<Object>)intoValue;
/*     */           
/*     */           while (true) {
/* 175 */             c.add(deserialize(p, ctxt));
/* 176 */             if (p.nextToken() == JsonToken.END_ARRAY) {
/* 177 */               return intoValue;
/*     */             }
/*     */           } 
/*     */         } 
/*     */         break;
/*     */     } 
/*     */     
/* 184 */     return deserialize(p, ctxt);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Object _deserializeObjectAtName(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 190 */     Scope rootObject = Scope.rootObjectScope(ctxt.isEnabled(StreamReadCapability.DUPLICATE_PROPERTIES));
/* 191 */     String key = p.currentName();
/* 192 */     for (; key != null; key = p.nextFieldName()) {
/*     */       Object value;
/* 194 */       JsonToken t = p.nextToken();
/* 195 */       if (t == null) {
/* 196 */         t = JsonToken.NOT_AVAILABLE;
/*     */       }
/* 198 */       switch (t.id()) {
/*     */         case 1:
/* 200 */           value = _deserializeNR(p, ctxt, rootObject.childObject());
/*     */           break;
/*     */         case 2:
/* 203 */           return rootObject.finishRootObject();
/*     */         case 3:
/* 205 */           value = _deserializeNR(p, ctxt, rootObject.childArray());
/*     */           break;
/*     */         default:
/* 208 */           value = _deserializeAnyScalar(p, ctxt, t.id()); break;
/*     */       } 
/* 210 */       rootObject.putValue(key, value);
/*     */     } 
/* 212 */     return rootObject.finishRootObject();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object _deserializeNR(JsonParser p, DeserializationContext ctxt, Scope rootScope) throws IOException {
/*     */     // Byte code:
/*     */     //   0: aload_2
/*     */     //   1: getstatic com/fasterxml/jackson/databind/deser/std/UntypedObjectDeserializerNR.F_MASK_INT_COERCIONS : I
/*     */     //   4: invokevirtual hasSomeOfFeatures : (I)Z
/*     */     //   7: istore #4
/*     */     //   9: aload_2
/*     */     //   10: getstatic com/fasterxml/jackson/databind/DeserializationFeature.USE_JAVA_ARRAY_FOR_JSON_ARRAY : Lcom/fasterxml/jackson/databind/DeserializationFeature;
/*     */     //   13: invokevirtual isEnabled : (Lcom/fasterxml/jackson/databind/DeserializationFeature;)Z
/*     */     //   16: istore #5
/*     */     //   18: aload_3
/*     */     //   19: astore #6
/*     */     //   21: aload #6
/*     */     //   23: invokevirtual isObject : ()Z
/*     */     //   26: ifeq -> 288
/*     */     //   29: aload_1
/*     */     //   30: invokevirtual nextFieldName : ()Ljava/lang/String;
/*     */     //   33: astore #7
/*     */     //   35: aload #7
/*     */     //   37: ifnull -> 266
/*     */     //   40: aload_1
/*     */     //   41: invokevirtual nextToken : ()Lcom/fasterxml/jackson/core/JsonToken;
/*     */     //   44: astore #9
/*     */     //   46: aload #9
/*     */     //   48: ifnonnull -> 56
/*     */     //   51: getstatic com/fasterxml/jackson/core/JsonToken.NOT_AVAILABLE : Lcom/fasterxml/jackson/core/JsonToken;
/*     */     //   54: astore #9
/*     */     //   56: aload #9
/*     */     //   58: invokevirtual id : ()I
/*     */     //   61: tableswitch default -> 237, 1 -> 124, 2 -> 237, 3 -> 136, 4 -> 237, 5 -> 237, 6 -> 148, 7 -> 157, 8 -> 180, 9 -> 206, 10 -> 214, 11 -> 222, 12 -> 228
/*     */     //   124: aload #6
/*     */     //   126: aload #7
/*     */     //   128: invokevirtual childObject : (Ljava/lang/String;)Lcom/fasterxml/jackson/databind/deser/std/UntypedObjectDeserializerNR$Scope;
/*     */     //   131: astore #6
/*     */     //   133: goto -> 257
/*     */     //   136: aload #6
/*     */     //   138: aload #7
/*     */     //   140: invokevirtual childArray : (Ljava/lang/String;)Lcom/fasterxml/jackson/databind/deser/std/UntypedObjectDeserializerNR$Scope;
/*     */     //   143: astore #6
/*     */     //   145: goto -> 21
/*     */     //   148: aload_1
/*     */     //   149: invokevirtual getText : ()Ljava/lang/String;
/*     */     //   152: astore #8
/*     */     //   154: goto -> 248
/*     */     //   157: iload #4
/*     */     //   159: ifeq -> 171
/*     */     //   162: aload_0
/*     */     //   163: aload_1
/*     */     //   164: aload_2
/*     */     //   165: invokevirtual _coerceIntegral : (Lcom/fasterxml/jackson/core/JsonParser;Lcom/fasterxml/jackson/databind/DeserializationContext;)Ljava/lang/Object;
/*     */     //   168: goto -> 175
/*     */     //   171: aload_1
/*     */     //   172: invokevirtual getNumberValue : ()Ljava/lang/Number;
/*     */     //   175: astore #8
/*     */     //   177: goto -> 248
/*     */     //   180: aload_2
/*     */     //   181: getstatic com/fasterxml/jackson/databind/DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS : Lcom/fasterxml/jackson/databind/DeserializationFeature;
/*     */     //   184: invokevirtual isEnabled : (Lcom/fasterxml/jackson/databind/DeserializationFeature;)Z
/*     */     //   187: ifeq -> 197
/*     */     //   190: aload_1
/*     */     //   191: invokevirtual getDecimalValue : ()Ljava/math/BigDecimal;
/*     */     //   194: goto -> 201
/*     */     //   197: aload_1
/*     */     //   198: invokevirtual getNumberValue : ()Ljava/lang/Number;
/*     */     //   201: astore #8
/*     */     //   203: goto -> 248
/*     */     //   206: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
/*     */     //   209: astore #8
/*     */     //   211: goto -> 248
/*     */     //   214: getstatic java/lang/Boolean.FALSE : Ljava/lang/Boolean;
/*     */     //   217: astore #8
/*     */     //   219: goto -> 248
/*     */     //   222: aconst_null
/*     */     //   223: astore #8
/*     */     //   225: goto -> 248
/*     */     //   228: aload_1
/*     */     //   229: invokevirtual getEmbeddedObject : ()Ljava/lang/Object;
/*     */     //   232: astore #8
/*     */     //   234: goto -> 248
/*     */     //   237: aload_2
/*     */     //   238: aload_0
/*     */     //   239: aload_2
/*     */     //   240: invokevirtual getValueType : (Lcom/fasterxml/jackson/databind/DeserializationContext;)Lcom/fasterxml/jackson/databind/JavaType;
/*     */     //   243: aload_1
/*     */     //   244: invokevirtual handleUnexpectedToken : (Lcom/fasterxml/jackson/databind/JavaType;Lcom/fasterxml/jackson/core/JsonParser;)Ljava/lang/Object;
/*     */     //   247: areturn
/*     */     //   248: aload #6
/*     */     //   250: aload #7
/*     */     //   252: aload #8
/*     */     //   254: invokevirtual putValue : (Ljava/lang/String;Ljava/lang/Object;)V
/*     */     //   257: aload_1
/*     */     //   258: invokevirtual nextFieldName : ()Ljava/lang/String;
/*     */     //   261: astore #7
/*     */     //   263: goto -> 35
/*     */     //   266: aload #6
/*     */     //   268: aload_3
/*     */     //   269: if_acmpne -> 278
/*     */     //   272: aload #6
/*     */     //   274: invokevirtual finishRootObject : ()Ljava/lang/Object;
/*     */     //   277: areturn
/*     */     //   278: aload #6
/*     */     //   280: invokevirtual finishBranchObject : ()Lcom/fasterxml/jackson/databind/deser/std/UntypedObjectDeserializerNR$Scope;
/*     */     //   283: astore #6
/*     */     //   285: goto -> 21
/*     */     //   288: aload_1
/*     */     //   289: invokevirtual nextToken : ()Lcom/fasterxml/jackson/core/JsonToken;
/*     */     //   292: astore #7
/*     */     //   294: aload #7
/*     */     //   296: ifnonnull -> 304
/*     */     //   299: getstatic com/fasterxml/jackson/core/JsonToken.NOT_AVAILABLE : Lcom/fasterxml/jackson/core/JsonToken;
/*     */     //   302: astore #7
/*     */     //   304: aload #7
/*     */     //   306: invokevirtual id : ()I
/*     */     //   309: tableswitch default -> 507, 1 -> 372, 2 -> 507, 3 -> 382, 4 -> 392, 5 -> 507, 6 -> 418, 7 -> 427, 8 -> 450, 9 -> 476, 10 -> 484, 11 -> 492, 12 -> 498
/*     */     //   372: aload #6
/*     */     //   374: invokevirtual childObject : ()Lcom/fasterxml/jackson/databind/deser/std/UntypedObjectDeserializerNR$Scope;
/*     */     //   377: astore #6
/*     */     //   379: goto -> 21
/*     */     //   382: aload #6
/*     */     //   384: invokevirtual childArray : ()Lcom/fasterxml/jackson/databind/deser/std/UntypedObjectDeserializerNR$Scope;
/*     */     //   387: astore #6
/*     */     //   389: goto -> 21
/*     */     //   392: aload #6
/*     */     //   394: aload_3
/*     */     //   395: if_acmpne -> 406
/*     */     //   398: aload #6
/*     */     //   400: iload #5
/*     */     //   402: invokevirtual finishRootArray : (Z)Ljava/lang/Object;
/*     */     //   405: areturn
/*     */     //   406: aload #6
/*     */     //   408: iload #5
/*     */     //   410: invokevirtual finishBranchArray : (Z)Lcom/fasterxml/jackson/databind/deser/std/UntypedObjectDeserializerNR$Scope;
/*     */     //   413: astore #6
/*     */     //   415: goto -> 21
/*     */     //   418: aload_1
/*     */     //   419: invokevirtual getText : ()Ljava/lang/String;
/*     */     //   422: astore #8
/*     */     //   424: goto -> 518
/*     */     //   427: iload #4
/*     */     //   429: ifeq -> 441
/*     */     //   432: aload_0
/*     */     //   433: aload_1
/*     */     //   434: aload_2
/*     */     //   435: invokevirtual _coerceIntegral : (Lcom/fasterxml/jackson/core/JsonParser;Lcom/fasterxml/jackson/databind/DeserializationContext;)Ljava/lang/Object;
/*     */     //   438: goto -> 445
/*     */     //   441: aload_1
/*     */     //   442: invokevirtual getNumberValue : ()Ljava/lang/Number;
/*     */     //   445: astore #8
/*     */     //   447: goto -> 518
/*     */     //   450: aload_2
/*     */     //   451: getstatic com/fasterxml/jackson/databind/DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS : Lcom/fasterxml/jackson/databind/DeserializationFeature;
/*     */     //   454: invokevirtual isEnabled : (Lcom/fasterxml/jackson/databind/DeserializationFeature;)Z
/*     */     //   457: ifeq -> 467
/*     */     //   460: aload_1
/*     */     //   461: invokevirtual getDecimalValue : ()Ljava/math/BigDecimal;
/*     */     //   464: goto -> 471
/*     */     //   467: aload_1
/*     */     //   468: invokevirtual getNumberValue : ()Ljava/lang/Number;
/*     */     //   471: astore #8
/*     */     //   473: goto -> 518
/*     */     //   476: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
/*     */     //   479: astore #8
/*     */     //   481: goto -> 518
/*     */     //   484: getstatic java/lang/Boolean.FALSE : Ljava/lang/Boolean;
/*     */     //   487: astore #8
/*     */     //   489: goto -> 518
/*     */     //   492: aconst_null
/*     */     //   493: astore #8
/*     */     //   495: goto -> 518
/*     */     //   498: aload_1
/*     */     //   499: invokevirtual getEmbeddedObject : ()Ljava/lang/Object;
/*     */     //   502: astore #8
/*     */     //   504: goto -> 518
/*     */     //   507: aload_2
/*     */     //   508: aload_0
/*     */     //   509: aload_2
/*     */     //   510: invokevirtual getValueType : (Lcom/fasterxml/jackson/databind/DeserializationContext;)Lcom/fasterxml/jackson/databind/JavaType;
/*     */     //   513: aload_1
/*     */     //   514: invokevirtual handleUnexpectedToken : (Lcom/fasterxml/jackson/databind/JavaType;Lcom/fasterxml/jackson/core/JsonParser;)Ljava/lang/Object;
/*     */     //   517: areturn
/*     */     //   518: aload #6
/*     */     //   520: aload #8
/*     */     //   522: invokevirtual addValue : (Ljava/lang/Object;)V
/*     */     //   525: goto -> 288
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #219	-> 0
/*     */     //   #220	-> 9
/*     */     //   #222	-> 18
/*     */     //   #226	-> 21
/*     */     //   #227	-> 29
/*     */     //   #230	-> 35
/*     */     //   #232	-> 40
/*     */     //   #233	-> 46
/*     */     //   #234	-> 51
/*     */     //   #236	-> 56
/*     */     //   #238	-> 124
/*     */     //   #240	-> 133
/*     */     //   #242	-> 136
/*     */     //   #244	-> 145
/*     */     //   #246	-> 148
/*     */     //   #247	-> 154
/*     */     //   #249	-> 157
/*     */     //   #250	-> 177
/*     */     //   #252	-> 180
/*     */     //   #253	-> 191
/*     */     //   #254	-> 203
/*     */     //   #256	-> 206
/*     */     //   #257	-> 211
/*     */     //   #259	-> 214
/*     */     //   #260	-> 219
/*     */     //   #262	-> 222
/*     */     //   #263	-> 225
/*     */     //   #265	-> 228
/*     */     //   #266	-> 234
/*     */     //   #268	-> 237
/*     */     //   #270	-> 248
/*     */     //   #230	-> 257
/*     */     //   #273	-> 266
/*     */     //   #274	-> 272
/*     */     //   #276	-> 278
/*     */     //   #277	-> 285
/*     */     //   #281	-> 288
/*     */     //   #282	-> 294
/*     */     //   #283	-> 299
/*     */     //   #286	-> 304
/*     */     //   #288	-> 372
/*     */     //   #289	-> 379
/*     */     //   #291	-> 382
/*     */     //   #292	-> 389
/*     */     //   #294	-> 392
/*     */     //   #295	-> 398
/*     */     //   #297	-> 406
/*     */     //   #298	-> 415
/*     */     //   #300	-> 418
/*     */     //   #301	-> 424
/*     */     //   #303	-> 427
/*     */     //   #304	-> 447
/*     */     //   #306	-> 450
/*     */     //   #307	-> 461
/*     */     //   #308	-> 473
/*     */     //   #310	-> 476
/*     */     //   #311	-> 481
/*     */     //   #313	-> 484
/*     */     //   #314	-> 489
/*     */     //   #316	-> 492
/*     */     //   #317	-> 495
/*     */     //   #319	-> 498
/*     */     //   #320	-> 504
/*     */     //   #322	-> 507
/*     */     //   #324	-> 518
/*     */     //   #325	-> 525
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   154	3	8	value	Ljava/lang/Object;
/*     */     //   177	3	8	value	Ljava/lang/Object;
/*     */     //   203	3	8	value	Ljava/lang/Object;
/*     */     //   211	3	8	value	Ljava/lang/Object;
/*     */     //   219	3	8	value	Ljava/lang/Object;
/*     */     //   225	3	8	value	Ljava/lang/Object;
/*     */     //   234	3	8	value	Ljava/lang/Object;
/*     */     //   248	9	8	value	Ljava/lang/Object;
/*     */     //   46	211	9	t	Lcom/fasterxml/jackson/core/JsonToken;
/*     */     //   35	250	7	propName	Ljava/lang/String;
/*     */     //   424	3	8	value	Ljava/lang/Object;
/*     */     //   447	3	8	value	Ljava/lang/Object;
/*     */     //   473	3	8	value	Ljava/lang/Object;
/*     */     //   481	3	8	value	Ljava/lang/Object;
/*     */     //   489	3	8	value	Ljava/lang/Object;
/*     */     //   495	3	8	value	Ljava/lang/Object;
/*     */     //   504	3	8	value	Ljava/lang/Object;
/*     */     //   294	231	7	t	Lcom/fasterxml/jackson/core/JsonToken;
/*     */     //   518	7	8	value	Ljava/lang/Object;
/*     */     //   0	528	0	this	Lcom/fasterxml/jackson/databind/deser/std/UntypedObjectDeserializerNR;
/*     */     //   0	528	1	p	Lcom/fasterxml/jackson/core/JsonParser;
/*     */     //   0	528	2	ctxt	Lcom/fasterxml/jackson/databind/DeserializationContext;
/*     */     //   0	528	3	rootScope	Lcom/fasterxml/jackson/databind/deser/std/UntypedObjectDeserializerNR$Scope;
/*     */     //   9	519	4	intCoercions	Z
/*     */     //   18	510	5	useJavaArray	Z
/*     */     //   21	507	6	currScope	Lcom/fasterxml/jackson/databind/deser/std/UntypedObjectDeserializerNR$Scope;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object _deserializeAnyScalar(JsonParser p, DeserializationContext ctxt, int tokenType) throws IOException {
/* 334 */     switch (tokenType) {
/*     */       case 6:
/* 336 */         return p.getText();
/*     */       case 7:
/* 338 */         if (ctxt.isEnabled(DeserializationFeature.USE_BIG_INTEGER_FOR_INTS)) {
/* 339 */           return p.getBigIntegerValue();
/*     */         }
/* 341 */         return p.getNumberValue();
/*     */       
/*     */       case 8:
/* 344 */         if (ctxt.isEnabled(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS)) {
/* 345 */           return p.getDecimalValue();
/*     */         }
/* 347 */         return p.getNumberValue();
/*     */       case 9:
/* 349 */         return Boolean.TRUE;
/*     */       case 10:
/* 351 */         return Boolean.FALSE;
/*     */       case 12:
/* 353 */         return p.getEmbeddedObject();
/*     */       
/*     */       case 11:
/* 356 */         return null;
/*     */     } 
/*     */ 
/*     */     
/* 360 */     return ctxt.handleUnexpectedToken(getValueType(ctxt), p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object _mapObjectWithDups(JsonParser p, DeserializationContext ctxt, Map<String, Object> result, String initialKey, Object oldValue, Object newValue, String nextKey) throws IOException {
/* 369 */     boolean squashDups = ctxt.isEnabled(StreamReadCapability.DUPLICATE_PROPERTIES);
/*     */     
/* 371 */     if (squashDups) {
/* 372 */       _squashDups(result, initialKey, oldValue, newValue);
/*     */     }
/*     */     
/* 375 */     while (nextKey != null) {
/* 376 */       p.nextToken();
/* 377 */       newValue = deserialize(p, ctxt);
/* 378 */       oldValue = result.put(nextKey, newValue);
/* 379 */       if (oldValue != null && squashDups) {
/* 380 */         _squashDups(result, nextKey, oldValue, newValue);
/*     */       }
/* 382 */       nextKey = p.nextFieldName();
/*     */     } 
/*     */     
/* 385 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void _squashDups(Map<String, Object> result, String key, Object oldValue, Object newValue) {
/* 393 */     if (oldValue instanceof List) {
/* 394 */       ((List<Object>)oldValue).add(newValue);
/* 395 */       result.put(key, oldValue);
/*     */     } else {
/* 397 */       ArrayList<Object> l = new ArrayList();
/* 398 */       l.add(oldValue);
/* 399 */       l.add(newValue);
/* 400 */       result.put(key, l);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class Scope
/*     */   {
/*     */     private final Scope _parent;
/*     */ 
/*     */     
/*     */     private Scope _child;
/*     */ 
/*     */     
/*     */     private boolean _isObject;
/*     */ 
/*     */     
/*     */     private boolean _squashDups;
/*     */ 
/*     */     
/*     */     private String _deferredKey;
/*     */ 
/*     */     
/*     */     private Map<String, Object> _map;
/*     */ 
/*     */     
/*     */     private List<Object> _list;
/*     */ 
/*     */ 
/*     */     
/*     */     private Scope(Scope p) {
/* 432 */       this._parent = p;
/* 433 */       this._isObject = false;
/* 434 */       this._squashDups = false;
/*     */     }
/*     */ 
/*     */     
/*     */     private Scope(Scope p, boolean isObject, boolean squashDups) {
/* 439 */       this._parent = p;
/* 440 */       this._isObject = isObject;
/* 441 */       this._squashDups = squashDups;
/*     */     }
/*     */     
/*     */     public static Scope rootObjectScope(boolean squashDups) {
/* 445 */       return new Scope(null, true, squashDups);
/*     */     }
/*     */     
/*     */     public static Scope rootArrayScope() {
/* 449 */       return new Scope(null);
/*     */     }
/*     */     
/*     */     private Scope resetAsArray() {
/* 453 */       this._isObject = false;
/* 454 */       return this;
/*     */     }
/*     */     
/*     */     private Scope resetAsObject(boolean squashDups) {
/* 458 */       this._isObject = true;
/* 459 */       this._squashDups = squashDups;
/* 460 */       return this;
/*     */     }
/*     */     
/*     */     public Scope childObject() {
/* 464 */       if (this._child == null) {
/* 465 */         return new Scope(this, true, this._squashDups);
/*     */       }
/* 467 */       return this._child.resetAsObject(this._squashDups);
/*     */     }
/*     */     
/*     */     public Scope childObject(String deferredKey) {
/* 471 */       this._deferredKey = deferredKey;
/* 472 */       if (this._child == null) {
/* 473 */         return new Scope(this, true, this._squashDups);
/*     */       }
/* 475 */       return this._child.resetAsObject(this._squashDups);
/*     */     }
/*     */     
/*     */     public Scope childArray() {
/* 479 */       if (this._child == null) {
/* 480 */         return new Scope(this);
/*     */       }
/* 482 */       return this._child.resetAsArray();
/*     */     }
/*     */     
/*     */     public Scope childArray(String deferredKey) {
/* 486 */       this._deferredKey = deferredKey;
/* 487 */       if (this._child == null) {
/* 488 */         return new Scope(this);
/*     */       }
/* 490 */       return this._child.resetAsArray();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isObject() {
/* 500 */       return this._isObject;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void putValue(String key, Object value) {
/* 510 */       if (this._squashDups) {
/* 511 */         _putValueHandleDups(key, value);
/*     */         return;
/*     */       } 
/* 514 */       if (this._map == null) {
/* 515 */         this._map = new LinkedHashMap<>();
/*     */       }
/* 517 */       this._map.put(key, value);
/*     */     }
/*     */     
/*     */     public Scope putDeferredValue(Object value) {
/* 521 */       String key = Objects.<String>requireNonNull(this._deferredKey);
/* 522 */       this._deferredKey = null;
/* 523 */       if (this._squashDups) {
/* 524 */         _putValueHandleDups(key, value);
/* 525 */         return this;
/*     */       } 
/* 527 */       if (this._map == null) {
/* 528 */         this._map = new LinkedHashMap<>();
/*     */       }
/* 530 */       this._map.put(key, value);
/* 531 */       return this;
/*     */     }
/*     */     
/*     */     public void addValue(Object value) {
/* 535 */       if (this._list == null) {
/* 536 */         this._list = new ArrayList();
/*     */       }
/* 538 */       this._list.add(value);
/*     */     }
/*     */     
/*     */     public Object finishRootObject() {
/* 542 */       if (this._map == null) {
/* 543 */         return emptyMap();
/*     */       }
/* 545 */       return this._map;
/*     */     }
/*     */     
/*     */     public Scope finishBranchObject() {
/*     */       Object<String, Object> value;
/* 550 */       if (this._map == null) {
/* 551 */         Object<Object, Object> object = (Object<Object, Object>)new LinkedHashMap<>();
/*     */       } else {
/* 553 */         value = (Object<String, Object>)this._map;
/* 554 */         this._map = null;
/*     */       } 
/* 556 */       if (this._parent.isObject()) {
/* 557 */         return this._parent.putDeferredValue(value);
/*     */       }
/* 559 */       this._parent.addValue(value);
/* 560 */       return this._parent;
/*     */     }
/*     */     
/*     */     public Object finishRootArray(boolean asJavaArray) {
/* 564 */       if (this._list == null) {
/* 565 */         if (asJavaArray) {
/* 566 */           return UntypedObjectDeserializerNR.NO_OBJECTS;
/*     */         }
/* 568 */         return emptyList();
/*     */       } 
/* 570 */       if (asJavaArray) {
/* 571 */         return this._list.toArray(UntypedObjectDeserializerNR.NO_OBJECTS);
/*     */       }
/* 573 */       return this._list;
/*     */     }
/*     */     
/*     */     public Scope finishBranchArray(boolean asJavaArray) {
/*     */       Object<Object> value;
/* 578 */       if (this._list == null) {
/* 579 */         if (asJavaArray) {
/* 580 */           value = (Object<Object>)UntypedObjectDeserializerNR.NO_OBJECTS;
/*     */         } else {
/* 582 */           value = (Object<Object>)emptyList();
/*     */         } 
/*     */       } else {
/* 585 */         if (asJavaArray) {
/* 586 */           value = this._list.toArray(UntypedObjectDeserializerNR.NO_OBJECTS);
/*     */         } else {
/* 588 */           value = (Object<Object>)this._list;
/*     */         } 
/* 590 */         this._list = null;
/*     */       } 
/* 592 */       if (this._parent.isObject()) {
/* 593 */         return this._parent.putDeferredValue(value);
/*     */       }
/* 595 */       this._parent.addValue(value);
/* 596 */       return this._parent;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void _putValueHandleDups(String key, Object newValue) {
/* 605 */       if (this._map == null) {
/* 606 */         this._map = new LinkedHashMap<>();
/* 607 */         this._map.put(key, newValue);
/*     */         return;
/*     */       } 
/* 610 */       Object old = this._map.put(key, newValue);
/* 611 */       if (old != null)
/*     */       {
/* 613 */         if (old instanceof List) {
/* 614 */           ((List<Object>)old).add(newValue);
/* 615 */           this._map.put(key, old);
/*     */         } else {
/* 617 */           ArrayList<Object> l = new ArrayList();
/* 618 */           l.add(old);
/* 619 */           l.add(newValue);
/* 620 */           this._map.put(key, l);
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Map<String, Object> emptyMap() {
/* 633 */       return new LinkedHashMap<>(2);
/*     */     }
/*     */     
/*     */     public static List<Object> emptyList() {
/* 637 */       return new ArrayList(2);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\deser\std\UntypedObjectDeserializerNR.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */