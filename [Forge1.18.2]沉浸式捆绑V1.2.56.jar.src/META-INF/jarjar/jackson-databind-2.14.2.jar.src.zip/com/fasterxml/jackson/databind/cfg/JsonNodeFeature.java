/*    */ package com.fasterxml.jackson.databind.cfg;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum JsonNodeFeature
/*    */   implements DatatypeFeature
/*    */ {
/* 20 */   READ_NULL_PROPERTIES(true),
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 28 */   WRITE_NULL_PROPERTIES(true);
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static final int FEATURE_INDEX = 1;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private final boolean _enabledByDefault;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private final int _mask;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   JsonNodeFeature(boolean enabledByDefault) {
/* 50 */     this._enabledByDefault = enabledByDefault;
/* 51 */     this._mask = 1 << ordinal();
/*    */   }
/*    */   
/*    */   public boolean enabledByDefault() {
/* 55 */     return this._enabledByDefault;
/*    */   } public boolean enabledIn(int flags) {
/* 57 */     return ((flags & this._mask) != 0);
/*    */   } public int getMask() {
/* 59 */     return this._mask;
/*    */   }
/*    */   
/*    */   public int featureIndex() {
/* 63 */     return 1;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\cfg\JsonNodeFeature.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */