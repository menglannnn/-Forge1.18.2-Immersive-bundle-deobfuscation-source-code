/*     */ package com.fasterxml.jackson.databind.ser;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonInclude;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.SerializableString;
/*     */ import com.fasterxml.jackson.core.io.SerializedString;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.PropertyMetadata;
/*     */ import com.fasterxml.jackson.databind.PropertyName;
/*     */ import com.fasterxml.jackson.databind.SerializationConfig;
/*     */ import com.fasterxml.jackson.databind.SerializationFeature;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.annotation.JacksonStdImpl;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*     */ import com.fasterxml.jackson.databind.introspect.BeanPropertyDefinition;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonObjectFormatVisitor;
/*     */ import com.fasterxml.jackson.databind.jsonschema.JsonSchema;
/*     */ import com.fasterxml.jackson.databind.jsonschema.SchemaAware;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*     */ import com.fasterxml.jackson.databind.node.ObjectNode;
/*     */ import com.fasterxml.jackson.databind.ser.impl.PropertySerializerMap;
/*     */ import com.fasterxml.jackson.databind.ser.impl.UnwrappingBeanPropertyWriter;
/*     */ import com.fasterxml.jackson.databind.util.Annotations;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import com.fasterxml.jackson.databind.util.NameTransformer;
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.HashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @JacksonStdImpl
/*     */ public class BeanPropertyWriter
/*     */   extends PropertyWriter
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  49 */   public static final Object MARKER_FOR_EMPTY = JsonInclude.Include.NON_EMPTY;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final SerializedString _name;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final PropertyName _wrapperName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final JavaType _declaredType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final JavaType _cfgSerializationType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JavaType _nonTrivialBaseType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final transient Annotations _contextAnnotations;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final AnnotatedMember _member;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected transient Method _accessorMethod;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected transient Field _field;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonSerializer<Object> _serializer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonSerializer<Object> _nullSerializer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TypeSerializer _typeSerializer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected transient PropertySerializerMap _dynamicSerializers;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean _suppressNulls;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Object _suppressableValue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Class<?>[] _includeInViews;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected transient HashMap<Object, Object> _internalSettings;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanPropertyWriter(BeanPropertyDefinition propDef, AnnotatedMember member, Annotations contextAnnotations, JavaType declaredType, JsonSerializer<?> ser, TypeSerializer typeSer, JavaType serType, boolean suppressNulls, Object suppressableValue, Class<?>[] includeInViews) {
/* 217 */     super(propDef);
/* 218 */     this._member = member;
/* 219 */     this._contextAnnotations = contextAnnotations;
/*     */     
/* 221 */     this._name = new SerializedString(propDef.getName());
/* 222 */     this._wrapperName = propDef.getWrapperName();
/*     */     
/* 224 */     this._declaredType = declaredType;
/* 225 */     this._serializer = (JsonSerializer)ser;
/* 226 */     this
/* 227 */       ._dynamicSerializers = (ser == null) ? PropertySerializerMap.emptyForProperties() : null;
/* 228 */     this._typeSerializer = typeSer;
/* 229 */     this._cfgSerializationType = serType;
/*     */     
/* 231 */     if (member instanceof com.fasterxml.jackson.databind.introspect.AnnotatedField) {
/* 232 */       this._accessorMethod = null;
/* 233 */       this._field = (Field)member.getMember();
/* 234 */     } else if (member instanceof com.fasterxml.jackson.databind.introspect.AnnotatedMethod) {
/* 235 */       this._accessorMethod = (Method)member.getMember();
/* 236 */       this._field = null;
/*     */     }
/*     */     else {
/*     */       
/* 240 */       this._accessorMethod = null;
/* 241 */       this._field = null;
/*     */     } 
/* 243 */     this._suppressNulls = suppressNulls;
/* 244 */     this._suppressableValue = suppressableValue;
/*     */ 
/*     */     
/* 247 */     this._nullSerializer = null;
/* 248 */     this._includeInViews = includeInViews;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public BeanPropertyWriter(BeanPropertyDefinition propDef, AnnotatedMember member, Annotations contextAnnotations, JavaType declaredType, JsonSerializer<?> ser, TypeSerializer typeSer, JavaType serType, boolean suppressNulls, Object suppressableValue) {
/* 258 */     this(propDef, member, contextAnnotations, declaredType, ser, typeSer, serType, suppressNulls, suppressableValue, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BeanPropertyWriter() {
/* 271 */     super(PropertyMetadata.STD_REQUIRED_OR_OPTIONAL);
/* 272 */     this._member = null;
/* 273 */     this._contextAnnotations = null;
/*     */     
/* 275 */     this._name = null;
/* 276 */     this._wrapperName = null;
/* 277 */     this._includeInViews = null;
/*     */     
/* 279 */     this._declaredType = null;
/* 280 */     this._serializer = null;
/* 281 */     this._dynamicSerializers = null;
/* 282 */     this._typeSerializer = null;
/* 283 */     this._cfgSerializationType = null;
/*     */     
/* 285 */     this._accessorMethod = null;
/* 286 */     this._field = null;
/* 287 */     this._suppressNulls = false;
/* 288 */     this._suppressableValue = null;
/*     */     
/* 290 */     this._nullSerializer = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BeanPropertyWriter(BeanPropertyWriter base) {
/* 297 */     this(base, base._name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BeanPropertyWriter(BeanPropertyWriter base, PropertyName name) {
/* 304 */     super(base);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 311 */     this._name = new SerializedString(name.getSimpleName());
/* 312 */     this._wrapperName = base._wrapperName;
/*     */     
/* 314 */     this._contextAnnotations = base._contextAnnotations;
/* 315 */     this._declaredType = base._declaredType;
/*     */     
/* 317 */     this._member = base._member;
/* 318 */     this._accessorMethod = base._accessorMethod;
/* 319 */     this._field = base._field;
/*     */     
/* 321 */     this._serializer = base._serializer;
/* 322 */     this._nullSerializer = base._nullSerializer;
/*     */     
/* 324 */     if (base._internalSettings != null) {
/* 325 */       this._internalSettings = new HashMap<>(base._internalSettings);
/*     */     }
/*     */     
/* 328 */     this._cfgSerializationType = base._cfgSerializationType;
/* 329 */     this._dynamicSerializers = base._dynamicSerializers;
/* 330 */     this._suppressNulls = base._suppressNulls;
/* 331 */     this._suppressableValue = base._suppressableValue;
/* 332 */     this._includeInViews = base._includeInViews;
/* 333 */     this._typeSerializer = base._typeSerializer;
/* 334 */     this._nonTrivialBaseType = base._nonTrivialBaseType;
/*     */   }
/*     */   
/*     */   protected BeanPropertyWriter(BeanPropertyWriter base, SerializedString name) {
/* 338 */     super(base);
/* 339 */     this._name = name;
/* 340 */     this._wrapperName = base._wrapperName;
/*     */     
/* 342 */     this._member = base._member;
/* 343 */     this._contextAnnotations = base._contextAnnotations;
/* 344 */     this._declaredType = base._declaredType;
/* 345 */     this._accessorMethod = base._accessorMethod;
/* 346 */     this._field = base._field;
/* 347 */     this._serializer = base._serializer;
/* 348 */     this._nullSerializer = base._nullSerializer;
/* 349 */     if (base._internalSettings != null) {
/* 350 */       this._internalSettings = new HashMap<>(base._internalSettings);
/*     */     }
/*     */     
/* 353 */     this._cfgSerializationType = base._cfgSerializationType;
/* 354 */     this._dynamicSerializers = base._dynamicSerializers;
/* 355 */     this._suppressNulls = base._suppressNulls;
/* 356 */     this._suppressableValue = base._suppressableValue;
/* 357 */     this._includeInViews = base._includeInViews;
/* 358 */     this._typeSerializer = base._typeSerializer;
/* 359 */     this._nonTrivialBaseType = base._nonTrivialBaseType;
/*     */   }
/*     */   
/*     */   public BeanPropertyWriter rename(NameTransformer transformer) {
/* 363 */     String newName = transformer.transform(this._name.getValue());
/* 364 */     if (newName.equals(this._name.toString())) {
/* 365 */       return this;
/*     */     }
/* 367 */     return _new(PropertyName.construct(newName));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BeanPropertyWriter _new(PropertyName newName) {
/* 376 */     return new BeanPropertyWriter(this, newName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void assignTypeSerializer(TypeSerializer typeSer) {
/* 386 */     this._typeSerializer = typeSer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void assignSerializer(JsonSerializer<Object> ser) {
/* 394 */     if (this._serializer != null && this._serializer != ser)
/* 395 */       throw new IllegalStateException(String.format("Cannot override _serializer: had a %s, trying to set to %s", new Object[] {
/*     */               
/* 397 */               ClassUtil.classNameOf(this._serializer), ClassUtil.classNameOf(ser)
/*     */             })); 
/* 399 */     this._serializer = ser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void assignNullSerializer(JsonSerializer<Object> nullSer) {
/* 407 */     if (this._nullSerializer != null && this._nullSerializer != nullSer)
/* 408 */       throw new IllegalStateException(String.format("Cannot override _nullSerializer: had a %s, trying to set to %s", new Object[] {
/*     */               
/* 410 */               ClassUtil.classNameOf(this._nullSerializer), ClassUtil.classNameOf(nullSer)
/*     */             })); 
/* 412 */     this._nullSerializer = nullSer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanPropertyWriter unwrappingWriter(NameTransformer unwrapper) {
/* 420 */     return (BeanPropertyWriter)new UnwrappingBeanPropertyWriter(this, unwrapper);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNonTrivialBaseType(JavaType t) {
/* 429 */     this._nonTrivialBaseType = t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void fixAccess(SerializationConfig config) {
/* 440 */     this._member.fixAccess(config.isEnabled(MapperFeature.OVERRIDE_PUBLIC_ACCESS_MODIFIERS));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object readResolve() {
/* 455 */     if (this._member instanceof com.fasterxml.jackson.databind.introspect.AnnotatedField) {
/* 456 */       this._accessorMethod = null;
/* 457 */       this._field = (Field)this._member.getMember();
/* 458 */     } else if (this._member instanceof com.fasterxml.jackson.databind.introspect.AnnotatedMethod) {
/* 459 */       this._accessorMethod = (Method)this._member.getMember();
/* 460 */       this._field = null;
/*     */     } 
/* 462 */     if (this._serializer == null) {
/* 463 */       this._dynamicSerializers = PropertySerializerMap.emptyForProperties();
/*     */     }
/* 465 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 477 */     return this._name.getValue();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertyName getFullName() {
/* 483 */     return new PropertyName(this._name.getValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public JavaType getType() {
/* 488 */     return this._declaredType;
/*     */   }
/*     */ 
/*     */   
/*     */   public PropertyName getWrapperName() {
/* 493 */     return this._wrapperName;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <A extends java.lang.annotation.Annotation> A getAnnotation(Class<A> acls) {
/* 499 */     return (this._member == null) ? null : (A)this._member.getAnnotation(acls);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <A extends java.lang.annotation.Annotation> A getContextAnnotation(Class<A> acls) {
/* 505 */     return (this._contextAnnotations == null) ? null : (A)this._contextAnnotations
/* 506 */       .get(acls);
/*     */   }
/*     */ 
/*     */   
/*     */   public AnnotatedMember getMember() {
/* 511 */     return this._member;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _depositSchemaProperty(ObjectNode propertiesNode, JsonNode schemaNode) {
/* 517 */     propertiesNode.set(getName(), schemaNode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getInternalSetting(Object key) {
/* 533 */     return (this._internalSettings == null) ? null : this._internalSettings.get(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object setInternalSetting(Object key, Object value) {
/* 542 */     if (this._internalSettings == null) {
/* 543 */       this._internalSettings = new HashMap<>();
/*     */     }
/* 545 */     return this._internalSettings.put(key, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object removeInternalSetting(Object key) {
/* 554 */     Object removed = null;
/* 555 */     if (this._internalSettings != null) {
/* 556 */       removed = this._internalSettings.remove(key);
/*     */       
/* 558 */       if (this._internalSettings.size() == 0) {
/* 559 */         this._internalSettings = null;
/*     */       }
/*     */     } 
/* 562 */     return removed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializableString getSerializedName() {
/* 572 */     return (SerializableString)this._name;
/*     */   }
/*     */   
/*     */   public boolean hasSerializer() {
/* 576 */     return (this._serializer != null);
/*     */   }
/*     */   
/*     */   public boolean hasNullSerializer() {
/* 580 */     return (this._nullSerializer != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeSerializer getTypeSerializer() {
/* 587 */     return this._typeSerializer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isUnwrapping() {
/* 601 */     return false;
/*     */   }
/*     */   
/*     */   public boolean willSuppressNulls() {
/* 605 */     return this._suppressNulls;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean wouldConflictWithName(PropertyName name) {
/* 615 */     if (this._wrapperName != null) {
/* 616 */       return this._wrapperName.equals(name);
/*     */     }
/*     */     
/* 619 */     return (name.hasSimpleName(this._name.getValue()) && !name.hasNamespace());
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonSerializer<Object> getSerializer() {
/* 624 */     return this._serializer;
/*     */   }
/*     */   
/*     */   public JavaType getSerializationType() {
/* 628 */     return this._cfgSerializationType;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public Class<?> getRawSerializationType() {
/* 633 */     return (this._cfgSerializationType == null) ? null : this._cfgSerializationType
/* 634 */       .getRawClass();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Class<?> getPropertyType() {
/* 642 */     if (this._accessorMethod != null) {
/* 643 */       return this._accessorMethod.getReturnType();
/*     */     }
/* 645 */     if (this._field != null) {
/* 646 */       return this._field.getType();
/*     */     }
/* 648 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Type getGenericPropertyType() {
/* 660 */     if (this._accessorMethod != null) {
/* 661 */       return this._accessorMethod.getGenericReturnType();
/*     */     }
/* 663 */     if (this._field != null) {
/* 664 */       return this._field.getGenericType();
/*     */     }
/* 666 */     return null;
/*     */   }
/*     */   
/*     */   public Class<?>[] getViews() {
/* 670 */     return this._includeInViews;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serializeAsField(Object bean, JsonGenerator gen, SerializerProvider prov) throws Exception {
/* 689 */     Object value = (this._accessorMethod == null) ? this._field.get(bean) : this._accessorMethod.invoke(bean, (Object[])null);
/*     */ 
/*     */     
/* 692 */     if (value == null) {
/*     */       
/* 694 */       if (this._suppressableValue != null && prov
/* 695 */         .includeFilterSuppressNulls(this._suppressableValue)) {
/*     */         return;
/*     */       }
/* 698 */       if (this._nullSerializer != null) {
/* 699 */         gen.writeFieldName((SerializableString)this._name);
/* 700 */         this._nullSerializer.serialize(null, gen, prov);
/*     */       } 
/*     */       
/*     */       return;
/*     */     } 
/* 705 */     JsonSerializer<Object> ser = this._serializer;
/* 706 */     if (ser == null) {
/* 707 */       Class<?> cls = value.getClass();
/* 708 */       PropertySerializerMap m = this._dynamicSerializers;
/* 709 */       ser = m.serializerFor(cls);
/* 710 */       if (ser == null) {
/* 711 */         ser = _findAndAddDynamic(m, cls, prov);
/*     */       }
/*     */     } 
/*     */     
/* 715 */     if (this._suppressableValue != null) {
/* 716 */       if (MARKER_FOR_EMPTY == this._suppressableValue) {
/* 717 */         if (ser.isEmpty(prov, value)) {
/*     */           return;
/*     */         }
/* 720 */       } else if (this._suppressableValue.equals(value)) {
/*     */         return;
/*     */       } 
/*     */     }
/*     */     
/* 725 */     if (value == bean)
/*     */     {
/* 727 */       if (_handleSelfReference(bean, gen, prov, ser)) {
/*     */         return;
/*     */       }
/*     */     }
/* 731 */     gen.writeFieldName((SerializableString)this._name);
/* 732 */     if (this._typeSerializer == null) {
/* 733 */       ser.serialize(value, gen, prov);
/*     */     } else {
/* 735 */       ser.serializeWithType(value, gen, prov, this._typeSerializer);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serializeAsOmittedField(Object bean, JsonGenerator gen, SerializerProvider prov) throws Exception {
/* 749 */     if (!gen.canOmitFields()) {
/* 750 */       gen.writeOmittedField(this._name.getValue());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serializeAsElement(Object bean, JsonGenerator gen, SerializerProvider prov) throws Exception {
/* 766 */     Object value = (this._accessorMethod == null) ? this._field.get(bean) : this._accessorMethod.invoke(bean, (Object[])null);
/* 767 */     if (value == null) {
/* 768 */       if (this._nullSerializer != null) {
/* 769 */         this._nullSerializer.serialize(null, gen, prov);
/*     */       } else {
/* 771 */         gen.writeNull();
/*     */       } 
/*     */       
/*     */       return;
/*     */     } 
/* 776 */     JsonSerializer<Object> ser = this._serializer;
/* 777 */     if (ser == null) {
/* 778 */       Class<?> cls = value.getClass();
/* 779 */       PropertySerializerMap map = this._dynamicSerializers;
/* 780 */       ser = map.serializerFor(cls);
/* 781 */       if (ser == null) {
/* 782 */         ser = _findAndAddDynamic(map, cls, prov);
/*     */       }
/*     */     } 
/*     */     
/* 786 */     if (this._suppressableValue != null) {
/* 787 */       if (MARKER_FOR_EMPTY == this._suppressableValue) {
/* 788 */         if (ser.isEmpty(prov, value)) {
/*     */           
/* 790 */           serializeAsPlaceholder(bean, gen, prov);
/*     */           return;
/*     */         } 
/* 793 */       } else if (this._suppressableValue.equals(value)) {
/*     */         
/* 795 */         serializeAsPlaceholder(bean, gen, prov);
/*     */         
/*     */         return;
/*     */       } 
/*     */     }
/* 800 */     if (value == bean && 
/* 801 */       _handleSelfReference(bean, gen, prov, ser)) {
/*     */       return;
/*     */     }
/*     */     
/* 805 */     if (this._typeSerializer == null) {
/* 806 */       ser.serialize(value, gen, prov);
/*     */     } else {
/* 808 */       ser.serializeWithType(value, gen, prov, this._typeSerializer);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serializeAsPlaceholder(Object bean, JsonGenerator gen, SerializerProvider prov) throws Exception {
/* 823 */     if (this._nullSerializer != null) {
/* 824 */       this._nullSerializer.serialize(null, gen, prov);
/*     */     } else {
/* 826 */       gen.writeNull();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void depositSchemaProperty(JsonObjectFormatVisitor v, SerializerProvider provider) throws JsonMappingException {
/* 840 */     if (v != null) {
/* 841 */       if (isRequired()) {
/* 842 */         v.property((BeanProperty)this);
/*     */       } else {
/* 844 */         v.optionalProperty((BeanProperty)this);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void depositSchemaProperty(ObjectNode propertiesNode, SerializerProvider provider) throws JsonMappingException {
/*     */     JsonNode schemaNode;
/* 866 */     JavaType propType = getSerializationType();
/*     */ 
/*     */     
/* 869 */     Type hint = (propType == null) ? (Type)getType() : propType.getRawClass();
/*     */ 
/*     */     
/* 872 */     JsonSerializer<Object> ser = getSerializer();
/* 873 */     if (ser == null) {
/* 874 */       ser = provider.findValueSerializer(getType(), (BeanProperty)this);
/*     */     }
/* 876 */     boolean isOptional = !isRequired();
/* 877 */     if (ser instanceof SchemaAware) {
/* 878 */       schemaNode = ((SchemaAware)ser).getSchema(provider, hint, isOptional);
/*     */     }
/*     */     else {
/*     */       
/* 882 */       schemaNode = JsonSchema.getDefaultSchemaNode();
/*     */     } 
/* 884 */     _depositSchemaProperty(propertiesNode, schemaNode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonSerializer<Object> _findAndAddDynamic(PropertySerializerMap map, Class<?> type, SerializerProvider provider) throws JsonMappingException {
/*     */     PropertySerializerMap.SerializerAndMapResult result;
/* 897 */     if (this._nonTrivialBaseType != null) {
/* 898 */       JavaType t = provider.constructSpecializedType(this._nonTrivialBaseType, type);
/*     */       
/* 900 */       result = map.findAndAddPrimarySerializer(t, provider, (BeanProperty)this);
/*     */     } else {
/* 902 */       result = map.findAndAddPrimarySerializer(type, provider, (BeanProperty)this);
/*     */     } 
/*     */     
/* 905 */     if (map != result.map) {
/* 906 */       this._dynamicSerializers = result.map;
/*     */     }
/* 908 */     return result.serializer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Object get(Object bean) throws Exception {
/* 920 */     return (this._accessorMethod == null) ? this._field.get(bean) : this._accessorMethod
/* 921 */       .invoke(bean, (Object[])null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean _handleSelfReference(Object bean, JsonGenerator gen, SerializerProvider prov, JsonSerializer<?> ser) throws IOException {
/* 942 */     if (!ser.usesObjectId()) {
/* 943 */       if (prov.isEnabled(SerializationFeature.FAIL_ON_SELF_REFERENCES)) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 948 */         if (ser instanceof com.fasterxml.jackson.databind.ser.std.BeanSerializerBase) {
/* 949 */           prov.reportBadDefinition(getType(), "Direct self-reference leading to cycle");
/*     */         }
/* 951 */       } else if (prov.isEnabled(SerializationFeature.WRITE_SELF_REFERENCES_AS_NULL)) {
/* 952 */         if (this._nullSerializer != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 958 */           if (!gen.getOutputContext().inArray()) {
/* 959 */             gen.writeFieldName((SerializableString)this._name);
/*     */           }
/* 961 */           this._nullSerializer.serialize(null, gen, prov);
/*     */         } 
/* 963 */         return true;
/*     */       } 
/*     */     }
/* 966 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 971 */     StringBuilder sb = new StringBuilder(40);
/* 972 */     sb.append("property '").append(getName()).append("' (");
/* 973 */     if (this._accessorMethod != null) {
/* 974 */       sb.append("via method ")
/* 975 */         .append(this._accessorMethod.getDeclaringClass().getName())
/* 976 */         .append("#").append(this._accessorMethod.getName());
/* 977 */     } else if (this._field != null) {
/* 978 */       sb.append("field \"").append(this._field.getDeclaringClass().getName())
/* 979 */         .append("#").append(this._field.getName());
/*     */     } else {
/* 981 */       sb.append("virtual");
/*     */     } 
/* 983 */     if (this._serializer == null) {
/* 984 */       sb.append(", no static serializer");
/*     */     } else {
/* 986 */       sb.append(", static serializer of type " + this._serializer
/* 987 */           .getClass().getName());
/*     */     } 
/* 989 */     sb.append(')');
/* 990 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\ser\BeanPropertyWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */