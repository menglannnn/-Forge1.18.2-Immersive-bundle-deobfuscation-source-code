/*     */ package com.fasterxml.jackson.databind.deser;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.KeyDeserializer;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.deser.impl.JDKValueInstantiators;
/*     */ import com.fasterxml.jackson.databind.deser.impl.ReadableObjectId;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedField;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMethod;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*     */ import com.fasterxml.jackson.databind.node.JsonNodeFactory;
/*     */ import com.fasterxml.jackson.databind.node.ObjectNode;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SettableAnyProperty
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final BeanProperty _property;
/*     */   protected final AnnotatedMember _setter;
/*     */   protected final boolean _setterIsField;
/*     */   protected final JavaType _type;
/*     */   protected JsonDeserializer<Object> _valueDeserializer;
/*     */   protected final TypeDeserializer _valueTypeDeserializer;
/*     */   protected final KeyDeserializer _keyDeserializer;
/*     */   
/*     */   public SettableAnyProperty(BeanProperty property, AnnotatedMember setter, JavaType type, KeyDeserializer keyDeser, JsonDeserializer<Object> valueDeser, TypeDeserializer typeDeser) {
/*  66 */     this._property = property;
/*  67 */     this._setter = setter;
/*  68 */     this._type = type;
/*  69 */     this._valueDeserializer = valueDeser;
/*  70 */     this._valueTypeDeserializer = typeDeser;
/*  71 */     this._keyDeserializer = keyDeser;
/*  72 */     this._setterIsField = setter instanceof AnnotatedField;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SettableAnyProperty constructForMethod(DeserializationContext ctxt, BeanProperty property, AnnotatedMember field, JavaType valueType, KeyDeserializer keyDeser, JsonDeserializer<Object> valueDeser, TypeDeserializer typeDeser) {
/*  83 */     return new MethodAnyProperty(property, field, valueType, keyDeser, valueDeser, typeDeser);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SettableAnyProperty constructForMapField(DeserializationContext ctxt, BeanProperty property, AnnotatedMember field, JavaType valueType, KeyDeserializer keyDeser, JsonDeserializer<Object> valueDeser, TypeDeserializer typeDeser) {
/*  96 */     Class<?> mapType = field.getRawType();
/*     */ 
/*     */ 
/*     */     
/* 100 */     if (mapType == Map.class) {
/* 101 */       mapType = LinkedHashMap.class;
/*     */     }
/* 103 */     ValueInstantiator vi = JDKValueInstantiators.findStdValueInstantiator(ctxt.getConfig(), mapType);
/* 104 */     return new MapFieldAnyProperty(property, field, valueType, keyDeser, valueDeser, typeDeser, vi);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SettableAnyProperty constructForJsonNodeField(DeserializationContext ctxt, BeanProperty property, AnnotatedMember field, JavaType valueType, JsonDeserializer<Object> valueDeser) {
/* 115 */     return new JsonNodeFieldAnyProperty(property, field, valueType, valueDeser, ctxt
/*     */         
/* 117 */         .getNodeFactory());
/*     */   }
/*     */ 
/*     */   
/*     */   public abstract SettableAnyProperty withValueDeserializer(JsonDeserializer<Object> paramJsonDeserializer);
/*     */   
/*     */   public void fixAccess(DeserializationConfig config) {
/* 124 */     this._setter.fixAccess(config
/* 125 */         .isEnabled(MapperFeature.OVERRIDE_PUBLIC_ACCESS_MODIFIERS));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object readResolve() {
/* 139 */     if (this._setter == null || this._setter.getAnnotated() == null) {
/* 140 */       throw new IllegalArgumentException("Missing method/field (broken JDK (de)serialization?)");
/*     */     }
/* 142 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanProperty getProperty() {
/* 151 */     return this._property;
/*     */   } public boolean hasValueDeserializer() {
/* 153 */     return (this._valueDeserializer != null);
/*     */   } public JavaType getType() {
/* 155 */     return this._type;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getPropertyName() {
/* 160 */     return this._property.getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void deserializeAndSet(JsonParser p, DeserializationContext ctxt, Object instance, String propName) throws IOException {
/*     */     try {
/* 178 */       Object key = (this._keyDeserializer == null) ? propName : this._keyDeserializer.deserializeKey(propName, ctxt);
/* 179 */       set(instance, key, deserialize(p, ctxt));
/* 180 */     } catch (UnresolvedForwardReference reference) {
/* 181 */       if (this._valueDeserializer.getObjectIdReader() == null) {
/* 182 */         throw JsonMappingException.from(p, "Unresolved forward reference but no identity info.", reference);
/*     */       }
/*     */       
/* 185 */       AnySetterReferring referring = new AnySetterReferring(this, reference, this._type.getRawClass(), instance, propName);
/* 186 */       reference.getRoid().appendReferring(referring);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Object deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 192 */     if (p.hasToken(JsonToken.VALUE_NULL)) {
/* 193 */       return this._valueDeserializer.getNullValue(ctxt);
/*     */     }
/* 195 */     if (this._valueTypeDeserializer != null) {
/* 196 */       return this._valueDeserializer.deserializeWithType(p, ctxt, this._valueTypeDeserializer);
/*     */     }
/* 198 */     return this._valueDeserializer.deserialize(p, ctxt);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void set(Object instance, Object propName, Object value) throws IOException {
/*     */     try {
/* 205 */       _set(instance, propName, value);
/* 206 */     } catch (IOException e) {
/* 207 */       throw e;
/* 208 */     } catch (Exception e) {
/* 209 */       _throwAsIOE(e, propName, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void _set(Object paramObject1, Object paramObject2, Object paramObject3) throws Exception;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _throwAsIOE(Exception e, Object propName, Object value) throws IOException {
/* 229 */     if (e instanceof IllegalArgumentException) {
/* 230 */       String actType = ClassUtil.classNameOf(value);
/* 231 */       StringBuilder msg = (new StringBuilder("Problem deserializing \"any-property\" '")).append(propName);
/* 232 */       msg.append("' of class " + getClassName() + " (expected type: ").append(this._type);
/* 233 */       msg.append("; actual type: ").append(actType).append(")");
/* 234 */       String origMsg = ClassUtil.exceptionMessage(e);
/* 235 */       if (origMsg != null) {
/* 236 */         msg.append(", problem: ").append(origMsg);
/*     */       } else {
/* 238 */         msg.append(" (no error message provided)");
/*     */       } 
/* 240 */       throw new JsonMappingException(null, msg.toString(), e);
/*     */     } 
/* 242 */     ClassUtil.throwIfIOE(e);
/* 243 */     ClassUtil.throwIfRTE(e);
/*     */     
/* 245 */     Throwable t = ClassUtil.getRootCause(e);
/* 246 */     throw new JsonMappingException(null, ClassUtil.exceptionMessage(t), t);
/*     */   }
/*     */   private String getClassName() {
/* 249 */     return ClassUtil.nameOf(this._setter.getDeclaringClass());
/*     */   } public String toString() {
/* 251 */     return "[any property on class " + getClassName() + "]";
/*     */   }
/*     */   
/*     */   private static class AnySetterReferring
/*     */     extends ReadableObjectId.Referring {
/*     */     private final SettableAnyProperty _parent;
/*     */     private final Object _pojo;
/*     */     private final String _propName;
/*     */     
/*     */     public AnySetterReferring(SettableAnyProperty parent, UnresolvedForwardReference reference, Class<?> type, Object instance, String propName) {
/* 261 */       super(reference, type);
/* 262 */       this._parent = parent;
/* 263 */       this._pojo = instance;
/* 264 */       this._propName = propName;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void handleResolvedForwardReference(Object id, Object value) throws IOException {
/* 271 */       if (!hasId(id)) {
/* 272 */         throw new IllegalArgumentException("Trying to resolve a forward reference with id [" + id.toString() + "] that wasn't previously registered.");
/*     */       }
/*     */       
/* 275 */       this._parent.set(this._pojo, this._propName, value);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static class MethodAnyProperty
/*     */     extends SettableAnyProperty
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MethodAnyProperty(BeanProperty property, AnnotatedMember field, JavaType valueType, KeyDeserializer keyDeser, JsonDeserializer<Object> valueDeser, TypeDeserializer typeDeser) {
/* 297 */       super(property, field, valueType, keyDeser, valueDeser, typeDeser);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void _set(Object instance, Object propName, Object value) throws Exception {
/* 305 */       ((AnnotatedMethod)this._setter).callOnWith(instance, new Object[] { propName, value });
/*     */     }
/*     */ 
/*     */     
/*     */     public SettableAnyProperty withValueDeserializer(JsonDeserializer<Object> deser) {
/* 310 */       return new MethodAnyProperty(this._property, this._setter, this._type, this._keyDeserializer, deser, this._valueTypeDeserializer);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static class MapFieldAnyProperty
/*     */     extends SettableAnyProperty
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */     
/*     */     protected final ValueInstantiator _valueInstantiator;
/*     */ 
/*     */ 
/*     */     
/*     */     public MapFieldAnyProperty(BeanProperty property, AnnotatedMember field, JavaType valueType, KeyDeserializer keyDeser, JsonDeserializer<Object> valueDeser, TypeDeserializer typeDeser, ValueInstantiator inst) {
/* 330 */       super(property, field, valueType, keyDeser, valueDeser, typeDeser);
/*     */       
/* 332 */       this._valueInstantiator = inst;
/*     */     }
/*     */ 
/*     */     
/*     */     public SettableAnyProperty withValueDeserializer(JsonDeserializer<Object> deser) {
/* 337 */       return new MapFieldAnyProperty(this._property, this._setter, this._type, this._keyDeserializer, deser, this._valueTypeDeserializer, this._valueInstantiator);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void _set(Object instance, Object propName, Object value) throws Exception {
/* 346 */       AnnotatedField field = (AnnotatedField)this._setter;
/* 347 */       Map<Object, Object> val = (Map<Object, Object>)field.getValue(instance);
/*     */ 
/*     */       
/* 350 */       if (val == null) {
/* 351 */         val = _createAndSetMap((DeserializationContext)null, field, instance, propName);
/*     */       }
/*     */       
/* 354 */       val.put(propName, value);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected Map<Object, Object> _createAndSetMap(DeserializationContext ctxt, AnnotatedField field, Object instance, Object propName) throws IOException {
/* 362 */       if (this._valueInstantiator == null)
/* 363 */         throw JsonMappingException.from(ctxt, String.format("Cannot create an instance of %s for use as \"any-setter\" '%s'", new Object[] {
/*     */                 
/* 365 */                 ClassUtil.nameOf(this._type.getRawClass()), this._property.getName()
/*     */               })); 
/* 367 */       Map<Object, Object> map = (Map<Object, Object>)this._valueInstantiator.createUsingDefault(ctxt);
/* 368 */       field.setValue(instance, map);
/* 369 */       return map;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected static class JsonNodeFieldAnyProperty
/*     */     extends SettableAnyProperty
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     
/*     */     protected final JsonNodeFactory _nodeFactory;
/*     */ 
/*     */ 
/*     */     
/*     */     public JsonNodeFieldAnyProperty(BeanProperty property, AnnotatedMember field, JavaType valueType, JsonDeserializer<Object> valueDeser, JsonNodeFactory nodeFactory) {
/* 387 */       super(property, field, valueType, null, valueDeser, null);
/* 388 */       this._nodeFactory = nodeFactory;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void deserializeAndSet(JsonParser p, DeserializationContext ctxt, Object instance, String propName) throws IOException {
/* 397 */       setProperty(instance, propName, (JsonNode)deserialize(p, ctxt));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Object deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 404 */       return this._valueDeserializer.deserialize(p, ctxt);
/*     */     }
/*     */ 
/*     */     
/*     */     protected void _set(Object instance, Object propName, Object value) throws Exception {
/* 409 */       setProperty(instance, (String)propName, (JsonNode)value);
/*     */     }
/*     */ 
/*     */     
/*     */     protected void setProperty(Object instance, String propName, JsonNode value) throws IOException {
/*     */       ObjectNode objectNode;
/* 415 */       AnnotatedField field = (AnnotatedField)this._setter;
/* 416 */       Object val0 = field.getValue(instance);
/*     */ 
/*     */       
/* 419 */       if (val0 == null)
/* 420 */       { objectNode = this._nodeFactory.objectNode();
/* 421 */         field.setValue(instance, objectNode); }
/* 422 */       else { if (!(val0 instanceof ObjectNode))
/* 423 */           throw JsonMappingException.from((DeserializationContext)null, String.format("Value \"any-setter\" '%s' not `ObjectNode` but %s", new Object[] {
/*     */                   
/* 425 */                   getPropertyName(), 
/* 426 */                   ClassUtil.nameOf(val0.getClass())
/*     */                 })); 
/* 428 */         objectNode = (ObjectNode)val0; }
/*     */ 
/*     */       
/* 431 */       objectNode.set(propName, value);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public SettableAnyProperty withValueDeserializer(JsonDeserializer<Object> deser) {
/* 437 */       return this;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\deser\SettableAnyProperty.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */