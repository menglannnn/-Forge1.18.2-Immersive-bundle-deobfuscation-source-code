/*    */ package com.fasterxml.jackson.databind.node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum JsonNodeType
/*    */ {
/* 19 */   ARRAY,
/* 20 */   BINARY,
/* 21 */   BOOLEAN,
/* 22 */   MISSING,
/* 23 */   NULL,
/* 24 */   NUMBER,
/* 25 */   OBJECT,
/* 26 */   POJO,
/* 27 */   STRING;
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\node\JsonNodeType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */