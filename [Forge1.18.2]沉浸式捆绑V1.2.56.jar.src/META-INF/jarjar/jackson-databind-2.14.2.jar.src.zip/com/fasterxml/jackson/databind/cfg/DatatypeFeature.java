package com.fasterxml.jackson.databind.cfg;

import com.fasterxml.jackson.core.util.JacksonFeature;

public interface DatatypeFeature extends JacksonFeature {
  int featureIndex();
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\cfg\DatatypeFeature.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */