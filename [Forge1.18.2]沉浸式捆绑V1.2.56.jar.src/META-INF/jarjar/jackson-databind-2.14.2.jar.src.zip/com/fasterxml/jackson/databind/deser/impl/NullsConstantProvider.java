/*    */ package com.fasterxml.jackson.databind.deser.impl;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.DeserializationContext;
/*    */ import com.fasterxml.jackson.databind.deser.NullValueProvider;
/*    */ import com.fasterxml.jackson.databind.util.AccessPattern;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NullsConstantProvider
/*    */   implements NullValueProvider, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/* 19 */   private static final NullsConstantProvider SKIPPER = new NullsConstantProvider(null);
/*    */   
/* 21 */   private static final NullsConstantProvider NULLER = new NullsConstantProvider(null);
/*    */   
/*    */   protected final Object _nullValue;
/*    */   
/*    */   protected final AccessPattern _access;
/*    */   
/*    */   protected NullsConstantProvider(Object nvl) {
/* 28 */     this._nullValue = nvl;
/* 29 */     this._access = (this._nullValue == null) ? AccessPattern.ALWAYS_NULL : AccessPattern.CONSTANT;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static NullsConstantProvider skipper() {
/* 40 */     return SKIPPER;
/*    */   }
/*    */   
/*    */   public static NullsConstantProvider nuller() {
/* 44 */     return NULLER;
/*    */   }
/*    */   
/*    */   public static NullsConstantProvider forValue(Object nvl) {
/* 48 */     if (nvl == null) {
/* 49 */       return NULLER;
/*    */     }
/* 51 */     return new NullsConstantProvider(nvl);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean isSkipper(NullValueProvider p) {
/* 60 */     return (p == SKIPPER);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean isNuller(NullValueProvider p) {
/* 69 */     return (p == NULLER);
/*    */   }
/*    */ 
/*    */   
/*    */   public AccessPattern getNullAccessPattern() {
/* 74 */     return this._access;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getNullValue(DeserializationContext ctxt) {
/* 79 */     return this._nullValue;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\deser\impl\NullsConstantProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */