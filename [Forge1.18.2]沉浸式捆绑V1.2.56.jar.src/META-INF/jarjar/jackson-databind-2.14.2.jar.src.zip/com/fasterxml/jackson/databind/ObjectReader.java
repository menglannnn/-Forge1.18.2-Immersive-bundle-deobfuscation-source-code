/*      */ package com.fasterxml.jackson.databind;
/*      */ 
/*      */ import com.fasterxml.jackson.core.Base64Variant;
/*      */ import com.fasterxml.jackson.core.FormatFeature;
/*      */ import com.fasterxml.jackson.core.FormatSchema;
/*      */ import com.fasterxml.jackson.core.JacksonException;
/*      */ import com.fasterxml.jackson.core.JsonFactory;
/*      */ import com.fasterxml.jackson.core.JsonGenerator;
/*      */ import com.fasterxml.jackson.core.JsonParseException;
/*      */ import com.fasterxml.jackson.core.JsonParser;
/*      */ import com.fasterxml.jackson.core.JsonPointer;
/*      */ import com.fasterxml.jackson.core.JsonProcessingException;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.core.ObjectCodec;
/*      */ import com.fasterxml.jackson.core.StreamReadFeature;
/*      */ import com.fasterxml.jackson.core.TreeNode;
/*      */ import com.fasterxml.jackson.core.Version;
/*      */ import com.fasterxml.jackson.core.Versioned;
/*      */ import com.fasterxml.jackson.core.exc.StreamReadException;
/*      */ import com.fasterxml.jackson.core.filter.FilteringParserDelegate;
/*      */ import com.fasterxml.jackson.core.filter.JsonPointerBasedFilter;
/*      */ import com.fasterxml.jackson.core.filter.TokenFilter;
/*      */ import com.fasterxml.jackson.core.type.ResolvedType;
/*      */ import com.fasterxml.jackson.core.type.TypeReference;
/*      */ import com.fasterxml.jackson.databind.cfg.ContextAttributes;
/*      */ import com.fasterxml.jackson.databind.cfg.DatatypeFeature;
/*      */ import com.fasterxml.jackson.databind.cfg.PackageVersion;
/*      */ import com.fasterxml.jackson.databind.deser.DataFormatReaders;
/*      */ import com.fasterxml.jackson.databind.deser.DefaultDeserializationContext;
/*      */ import com.fasterxml.jackson.databind.deser.DeserializationProblemHandler;
/*      */ import com.fasterxml.jackson.databind.node.JsonNodeFactory;
/*      */ import com.fasterxml.jackson.databind.node.NullNode;
/*      */ import com.fasterxml.jackson.databind.node.TreeTraversingParser;
/*      */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*      */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*      */ import java.io.DataInput;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.Serializable;
/*      */ import java.lang.reflect.Type;
/*      */ import java.net.URL;
/*      */ import java.util.Iterator;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.TimeZone;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ObjectReader
/*      */   extends ObjectCodec
/*      */   implements Versioned, Serializable
/*      */ {
/*      */   private static final long serialVersionUID = 2L;
/*      */   protected final DeserializationConfig _config;
/*      */   protected final DefaultDeserializationContext _context;
/*      */   protected final JsonFactory _parserFactory;
/*      */   protected final boolean _unwrapRoot;
/*      */   private final TokenFilter _filter;
/*      */   protected final JavaType _valueType;
/*      */   protected final JsonDeserializer<Object> _rootDeserializer;
/*      */   protected final Object _valueToUpdate;
/*      */   protected final FormatSchema _schema;
/*      */   protected final InjectableValues _injectableValues;
/*      */   protected final DataFormatReaders _dataFormatReaders;
/*      */   protected final ConcurrentHashMap<JavaType, JsonDeserializer<Object>> _rootDeserializers;
/*      */   protected transient JavaType _jsonNodeType;
/*      */   
/*      */   protected ObjectReader(ObjectMapper mapper, DeserializationConfig config) {
/*  173 */     this(mapper, config, null, null, null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectReader(ObjectMapper mapper, DeserializationConfig config, JavaType valueType, Object valueToUpdate, FormatSchema schema, InjectableValues injectableValues) {
/*  184 */     this._config = config;
/*  185 */     this._context = mapper._deserializationContext;
/*  186 */     this._rootDeserializers = mapper._rootDeserializers;
/*  187 */     this._parserFactory = mapper._jsonFactory;
/*  188 */     this._valueType = valueType;
/*  189 */     this._valueToUpdate = valueToUpdate;
/*  190 */     this._schema = schema;
/*  191 */     this._injectableValues = injectableValues;
/*  192 */     this._unwrapRoot = config.useRootWrapping();
/*      */     
/*  194 */     this._rootDeserializer = _prefetchRootDeserializer(valueType);
/*  195 */     this._dataFormatReaders = null;
/*  196 */     this._filter = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectReader(ObjectReader base, DeserializationConfig config, JavaType valueType, JsonDeserializer<Object> rootDeser, Object valueToUpdate, FormatSchema schema, InjectableValues injectableValues, DataFormatReaders dataFormatReaders) {
/*  207 */     this._config = config;
/*  208 */     this._context = base._context;
/*      */     
/*  210 */     this._rootDeserializers = base._rootDeserializers;
/*  211 */     this._parserFactory = base._parserFactory;
/*      */     
/*  213 */     this._valueType = valueType;
/*  214 */     this._rootDeserializer = rootDeser;
/*  215 */     this._valueToUpdate = valueToUpdate;
/*  216 */     this._schema = schema;
/*  217 */     this._injectableValues = injectableValues;
/*  218 */     this._unwrapRoot = config.useRootWrapping();
/*  219 */     this._dataFormatReaders = dataFormatReaders;
/*  220 */     this._filter = base._filter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectReader(ObjectReader base, DeserializationConfig config) {
/*  228 */     this._config = config;
/*  229 */     this._context = base._context;
/*      */     
/*  231 */     this._rootDeserializers = base._rootDeserializers;
/*  232 */     this._parserFactory = base._parserFactory;
/*      */     
/*  234 */     this._valueType = base._valueType;
/*  235 */     this._rootDeserializer = base._rootDeserializer;
/*  236 */     this._valueToUpdate = base._valueToUpdate;
/*  237 */     this._schema = base._schema;
/*  238 */     this._injectableValues = base._injectableValues;
/*  239 */     this._unwrapRoot = config.useRootWrapping();
/*  240 */     this._dataFormatReaders = base._dataFormatReaders;
/*  241 */     this._filter = base._filter;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectReader(ObjectReader base, JsonFactory f) {
/*  247 */     this
/*  248 */       ._config = (DeserializationConfig)base._config.with(MapperFeature.SORT_PROPERTIES_ALPHABETICALLY, f.requiresPropertyOrdering());
/*  249 */     this._context = base._context;
/*      */     
/*  251 */     this._rootDeserializers = base._rootDeserializers;
/*  252 */     this._parserFactory = f;
/*      */     
/*  254 */     this._valueType = base._valueType;
/*  255 */     this._rootDeserializer = base._rootDeserializer;
/*  256 */     this._valueToUpdate = base._valueToUpdate;
/*  257 */     this._schema = base._schema;
/*  258 */     this._injectableValues = base._injectableValues;
/*  259 */     this._unwrapRoot = base._unwrapRoot;
/*  260 */     this._dataFormatReaders = base._dataFormatReaders;
/*  261 */     this._filter = base._filter;
/*      */   }
/*      */   
/*      */   protected ObjectReader(ObjectReader base, TokenFilter filter) {
/*  265 */     this._config = base._config;
/*  266 */     this._context = base._context;
/*  267 */     this._rootDeserializers = base._rootDeserializers;
/*  268 */     this._parserFactory = base._parserFactory;
/*  269 */     this._valueType = base._valueType;
/*  270 */     this._rootDeserializer = base._rootDeserializer;
/*  271 */     this._valueToUpdate = base._valueToUpdate;
/*  272 */     this._schema = base._schema;
/*  273 */     this._injectableValues = base._injectableValues;
/*  274 */     this._unwrapRoot = base._unwrapRoot;
/*  275 */     this._dataFormatReaders = base._dataFormatReaders;
/*  276 */     this._filter = filter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Version version() {
/*  285 */     return PackageVersion.VERSION;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectReader _new(ObjectReader base, JsonFactory f) {
/*  302 */     return new ObjectReader(base, f);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectReader _new(ObjectReader base, DeserializationConfig config) {
/*  311 */     return new ObjectReader(base, config);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectReader _new(ObjectReader base, DeserializationConfig config, JavaType valueType, JsonDeserializer<Object> rootDeser, Object valueToUpdate, FormatSchema schema, InjectableValues injectableValues, DataFormatReaders dataFormatReaders) {
/*  323 */     return new ObjectReader(base, config, valueType, rootDeser, valueToUpdate, schema, injectableValues, dataFormatReaders);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <T> MappingIterator<T> _newIterator(JsonParser p, DeserializationContext ctxt, JsonDeserializer<?> deser, boolean parserManaged) {
/*  336 */     return new MappingIterator<>(this._valueType, p, ctxt, deser, parserManaged, this._valueToUpdate);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _initForReading(DeserializationContext ctxt, JsonParser p) throws IOException {
/*  349 */     this._config.initialize(p, this._schema);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  355 */     JsonToken t = p.currentToken();
/*  356 */     if (t == null) {
/*  357 */       t = p.nextToken();
/*  358 */       if (t == null)
/*      */       {
/*  360 */         ctxt.reportInputMismatch(this._valueType, "No content to map due to end-of-input", new Object[0]);
/*      */       }
/*      */     } 
/*      */     
/*  364 */     return t;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _initForMultiRead(DeserializationContext ctxt, JsonParser p) throws IOException {
/*  379 */     this._config.initialize(p, this._schema);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader with(DeserializationFeature feature) {
/*  393 */     return _with(this._config.with(feature));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader with(DeserializationFeature first, DeserializationFeature... other) {
/*  403 */     return _with(this._config.with(first, other));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader withFeatures(DeserializationFeature... features) {
/*  411 */     return _with(this._config.withFeatures(features));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader without(DeserializationFeature feature) {
/*  419 */     return _with(this._config.without(feature));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader without(DeserializationFeature first, DeserializationFeature... other) {
/*  428 */     return _with(this._config.without(first, other));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader withoutFeatures(DeserializationFeature... features) {
/*  436 */     return _with(this._config.withoutFeatures(features));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader with(DatatypeFeature feature) {
/*  452 */     return _with((DeserializationConfig)this._config.with(feature));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader withFeatures(DatatypeFeature... features) {
/*  462 */     return _with((DeserializationConfig)this._config.withFeatures(features));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader without(DatatypeFeature feature) {
/*  472 */     return _with((DeserializationConfig)this._config.without(feature));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader withoutFeatures(DatatypeFeature... features) {
/*  482 */     return _with((DeserializationConfig)this._config.withoutFeatures(features));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader with(JsonParser.Feature feature) {
/*  501 */     return _with(this._config.with(feature));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader withFeatures(JsonParser.Feature... features) {
/*  513 */     return _with(this._config.withFeatures(features));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader without(JsonParser.Feature feature) {
/*  525 */     return _with(this._config.without(feature));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader withoutFeatures(JsonParser.Feature... features) {
/*  537 */     return _with(this._config.withoutFeatures(features));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader with(StreamReadFeature feature) {
/*  555 */     return _with(this._config.with(feature.mappedFeature()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader without(StreamReadFeature feature) {
/*  567 */     return _with(this._config.without(feature.mappedFeature()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader with(FormatFeature feature) {
/*  583 */     return _with(this._config.with(feature));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader withFeatures(FormatFeature... features) {
/*  593 */     return _with(this._config.withFeatures(features));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader without(FormatFeature feature) {
/*  603 */     return _with(this._config.without(feature));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader withoutFeatures(FormatFeature... features) {
/*  613 */     return _with(this._config.withoutFeatures(features));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader at(String pointerExpr) {
/*  628 */     _assertNotNull("pointerExpr", pointerExpr);
/*  629 */     return new ObjectReader(this, (TokenFilter)new JsonPointerBasedFilter(pointerExpr));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader at(JsonPointer pointer) {
/*  638 */     _assertNotNull("pointer", pointer);
/*  639 */     return new ObjectReader(this, (TokenFilter)new JsonPointerBasedFilter(pointer));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader with(DeserializationConfig config) {
/*  650 */     return _with(config);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader with(InjectableValues injectableValues) {
/*  662 */     if (this._injectableValues == injectableValues) {
/*  663 */       return this;
/*      */     }
/*  665 */     return _new(this, this._config, this._valueType, this._rootDeserializer, this._valueToUpdate, this._schema, injectableValues, this._dataFormatReaders);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader with(JsonNodeFactory f) {
/*  679 */     return _with(this._config.with(f));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader with(JsonFactory f) {
/*  694 */     if (f == this._parserFactory) {
/*  695 */       return this;
/*      */     }
/*  697 */     ObjectReader r = _new(this, f);
/*      */     
/*  699 */     if (f.getCodec() == null) {
/*  700 */       f.setCodec(r);
/*      */     }
/*  702 */     return r;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader withRootName(String rootName) {
/*  715 */     return _with((DeserializationConfig)this._config.withRootName(rootName));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader withRootName(PropertyName rootName) {
/*  722 */     return _with(this._config.withRootName(rootName));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader withoutRootName() {
/*  736 */     return _with(this._config.withRootName(PropertyName.NO_NAME));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader with(FormatSchema schema) {
/*  749 */     if (this._schema == schema) {
/*  750 */       return this;
/*      */     }
/*  752 */     _verifySchemaType(schema);
/*  753 */     return _new(this, this._config, this._valueType, this._rootDeserializer, this._valueToUpdate, schema, this._injectableValues, this._dataFormatReaders);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader forType(JavaType valueType) {
/*  768 */     if (valueType != null && valueType.equals(this._valueType)) {
/*  769 */       return this;
/*      */     }
/*  771 */     JsonDeserializer<Object> rootDeser = _prefetchRootDeserializer(valueType);
/*      */     
/*  773 */     DataFormatReaders det = this._dataFormatReaders;
/*  774 */     if (det != null) {
/*  775 */       det = det.withType(valueType);
/*      */     }
/*  777 */     return _new(this, this._config, valueType, rootDeser, this._valueToUpdate, this._schema, this._injectableValues, det);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader forType(Class<?> valueType) {
/*  791 */     return forType(this._config.constructType(valueType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader forType(TypeReference<?> valueTypeRef) {
/*  804 */     return forType(this._config.getTypeFactory().constructType(valueTypeRef.getType()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ObjectReader withType(JavaType valueType) {
/*  812 */     return forType(valueType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ObjectReader withType(Class<?> valueType) {
/*  820 */     return forType(this._config.constructType(valueType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ObjectReader withType(Type valueType) {
/*  828 */     return forType(this._config.getTypeFactory().constructType(valueType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ObjectReader withType(TypeReference<?> valueTypeRef) {
/*  836 */     return forType(this._config.getTypeFactory().constructType(valueTypeRef.getType()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader withValueToUpdate(Object value) {
/*      */     JavaType t;
/*  849 */     if (value == this._valueToUpdate) return this; 
/*  850 */     if (value == null)
/*      */     {
/*      */       
/*  853 */       return _new(this, this._config, this._valueType, this._rootDeserializer, null, this._schema, this._injectableValues, this._dataFormatReaders);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  862 */     if (this._valueType == null) {
/*  863 */       t = this._config.constructType(value.getClass());
/*      */     } else {
/*  865 */       t = this._valueType;
/*      */     } 
/*  867 */     return _new(this, this._config, t, this._rootDeserializer, value, this._schema, this._injectableValues, this._dataFormatReaders);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader withView(Class<?> activeView) {
/*  879 */     return _with(this._config.withView(activeView));
/*      */   }
/*      */   
/*      */   public ObjectReader with(Locale l) {
/*  883 */     return _with((DeserializationConfig)this._config.with(l));
/*      */   }
/*      */   
/*      */   public ObjectReader with(TimeZone tz) {
/*  887 */     return _with((DeserializationConfig)this._config.with(tz));
/*      */   }
/*      */   
/*      */   public ObjectReader withHandler(DeserializationProblemHandler h) {
/*  891 */     return _with(this._config.withHandler(h));
/*      */   }
/*      */   
/*      */   public ObjectReader with(Base64Variant defaultBase64) {
/*  895 */     return _with((DeserializationConfig)this._config.with(defaultBase64));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader withFormatDetection(ObjectReader... readers) {
/*  921 */     return withFormatDetection(new DataFormatReaders(readers));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader withFormatDetection(DataFormatReaders readers) {
/*  940 */     return _new(this, this._config, this._valueType, this._rootDeserializer, this._valueToUpdate, this._schema, this._injectableValues, readers);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader with(ContextAttributes attrs) {
/*  948 */     return _with(this._config.with(attrs));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader withAttributes(Map<?, ?> attrs) {
/*  955 */     return _with((DeserializationConfig)this._config.withAttributes(attrs));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader withAttribute(Object key, Object value) {
/*  962 */     return _with((DeserializationConfig)this._config.withAttribute(key, value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader withoutAttribute(Object key) {
/*  969 */     return _with((DeserializationConfig)this._config.withoutAttribute(key));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectReader _with(DeserializationConfig newConfig) {
/*  979 */     if (newConfig == this._config) {
/*  980 */       return this;
/*      */     }
/*  982 */     ObjectReader r = _new(this, newConfig);
/*  983 */     if (this._dataFormatReaders != null) {
/*  984 */       r = r.withFormatDetection(this._dataFormatReaders.with(newConfig));
/*      */     }
/*  986 */     return r;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEnabled(DeserializationFeature f) {
/*  996 */     return this._config.isEnabled(f);
/*      */   }
/*      */   
/*      */   public boolean isEnabled(MapperFeature f) {
/* 1000 */     return this._config.isEnabled(f);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEnabled(DatatypeFeature f) {
/* 1007 */     return this._config.isEnabled(f);
/*      */   }
/*      */   
/*      */   public boolean isEnabled(JsonParser.Feature f) {
/* 1011 */     return this._config.isEnabled(f, this._parserFactory);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEnabled(StreamReadFeature f) {
/* 1018 */     return this._config.isEnabled(f.mappedFeature(), this._parserFactory);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializationConfig getConfig() {
/* 1025 */     return this._config;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonFactory getFactory() {
/* 1033 */     return this._parserFactory;
/*      */   }
/*      */   
/*      */   public TypeFactory getTypeFactory() {
/* 1037 */     return this._config.getTypeFactory();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ContextAttributes getAttributes() {
/* 1044 */     return this._config.getAttributes();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InjectableValues getInjectableValues() {
/* 1051 */     return this._injectableValues;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType getValueType() {
/* 1058 */     return this._valueType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(File src) throws IOException {
/* 1076 */     _assertNotNull("src", src);
/* 1077 */     return this._config.initialize(this._parserFactory.createParser(src), this._schema);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(URL src) throws IOException {
/* 1089 */     _assertNotNull("src", src);
/* 1090 */     return this._config.initialize(this._parserFactory.createParser(src), this._schema);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(InputStream in) throws IOException {
/* 1102 */     _assertNotNull("in", in);
/* 1103 */     return this._config.initialize(this._parserFactory.createParser(in), this._schema);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(Reader r) throws IOException {
/* 1115 */     _assertNotNull("r", r);
/* 1116 */     return this._config.initialize(this._parserFactory.createParser(r), this._schema);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(byte[] content) throws IOException {
/* 1128 */     _assertNotNull("content", content);
/* 1129 */     return this._config.initialize(this._parserFactory.createParser(content), this._schema);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(byte[] content, int offset, int len) throws IOException {
/* 1141 */     _assertNotNull("content", content);
/* 1142 */     return this._config.initialize(this._parserFactory.createParser(content, offset, len), this._schema);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(String content) throws IOException {
/* 1154 */     _assertNotNull("content", content);
/* 1155 */     return this._config.initialize(this._parserFactory.createParser(content), this._schema);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(char[] content) throws IOException {
/* 1167 */     _assertNotNull("content", content);
/* 1168 */     return this._config.initialize(this._parserFactory.createParser(content), this._schema);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(char[] content, int offset, int len) throws IOException {
/* 1180 */     _assertNotNull("content", content);
/* 1181 */     return this._config.initialize(this._parserFactory.createParser(content, offset, len), this._schema);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(DataInput content) throws IOException {
/* 1193 */     _assertNotNull("content", content);
/* 1194 */     return this._config.initialize(this._parserFactory.createParser(content), this._schema);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createNonBlockingByteArrayParser() throws IOException {
/* 1206 */     return this._config.initialize(this._parserFactory.createNonBlockingByteArrayParser(), this._schema);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(JsonParser p) throws IOException {
/* 1228 */     _assertNotNull("p", p);
/* 1229 */     return (T)_bind(p, this._valueToUpdate);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(JsonParser p, Class<T> valueType) throws IOException {
/* 1246 */     _assertNotNull("p", p);
/* 1247 */     return forType(valueType).readValue(p);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(JsonParser p, TypeReference<T> valueTypeRef) throws IOException {
/* 1264 */     _assertNotNull("p", p);
/* 1265 */     return forType(valueTypeRef).readValue(p);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(JsonParser p, ResolvedType valueType) throws IOException {
/* 1281 */     _assertNotNull("p", p);
/* 1282 */     return forType((JavaType)valueType).readValue(p);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(JsonParser p, JavaType valueType) throws IOException {
/* 1293 */     _assertNotNull("p", p);
/* 1294 */     return forType(valueType).readValue(p);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> Iterator<T> readValues(JsonParser p, Class<T> valueType) throws IOException {
/* 1318 */     _assertNotNull("p", p);
/* 1319 */     return forType(valueType).readValues(p);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> Iterator<T> readValues(JsonParser p, TypeReference<T> valueTypeRef) throws IOException {
/* 1343 */     _assertNotNull("p", p);
/* 1344 */     return forType(valueTypeRef).readValues(p);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> Iterator<T> readValues(JsonParser p, ResolvedType valueType) throws IOException {
/* 1368 */     _assertNotNull("p", p);
/* 1369 */     return readValues(p, (JavaType)valueType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> Iterator<T> readValues(JsonParser p, JavaType valueType) throws IOException {
/* 1392 */     _assertNotNull("p", p);
/* 1393 */     return forType(valueType).readValues(p);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNode createArrayNode() {
/* 1404 */     return (JsonNode)this._config.getNodeFactory().arrayNode();
/*      */   }
/*      */ 
/*      */   
/*      */   public JsonNode createObjectNode() {
/* 1409 */     return (JsonNode)this._config.getNodeFactory().objectNode();
/*      */   }
/*      */ 
/*      */   
/*      */   public JsonNode missingNode() {
/* 1414 */     return this._config.getNodeFactory().missingNode();
/*      */   }
/*      */ 
/*      */   
/*      */   public JsonNode nullNode() {
/* 1419 */     return (JsonNode)this._config.getNodeFactory().nullNode();
/*      */   }
/*      */ 
/*      */   
/*      */   public JsonParser treeAsTokens(TreeNode n) {
/* 1424 */     _assertNotNull("n", n);
/*      */ 
/*      */     
/* 1427 */     ObjectReader codec = withValueToUpdate(null);
/* 1428 */     return (JsonParser)new TreeTraversingParser((JsonNode)n, codec);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T extends TreeNode> T readTree(JsonParser p) throws IOException {
/* 1452 */     _assertNotNull("p", p);
/* 1453 */     return (T)_bindAsTreeOrNull(p);
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeTree(JsonGenerator g, TreeNode rootNode) {
/* 1458 */     throw new UnsupportedOperationException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(InputStream src) throws IOException {
/* 1478 */     if (this._dataFormatReaders != null) {
/* 1479 */       return (T)_detectBindAndClose(this._dataFormatReaders.findFormat(src), false);
/*      */     }
/* 1481 */     return (T)_bindAndClose(_considerFilter(createParser(src), false));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(InputStream src, Class<T> valueType) throws IOException {
/* 1496 */     return forType(valueType).readValue(src);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(Reader src) throws IOException {
/* 1510 */     if (this._dataFormatReaders != null) {
/* 1511 */       _reportUndetectableSource(src);
/*      */     }
/* 1513 */     return (T)_bindAndClose(_considerFilter(createParser(src), false));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(Reader src, Class<T> valueType) throws IOException {
/* 1528 */     return forType(valueType).readValue(src);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(String src) throws JsonProcessingException, JsonMappingException {
/* 1542 */     if (this._dataFormatReaders != null) {
/* 1543 */       _reportUndetectableSource(src);
/*      */     }
/*      */     try {
/* 1546 */       return (T)_bindAndClose(_considerFilter(createParser(src), false));
/* 1547 */     } catch (JsonProcessingException e) {
/* 1548 */       throw e;
/* 1549 */     } catch (IOException e) {
/* 1550 */       throw JsonMappingException.fromUnexpectedIOE(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(String src, Class<T> valueType) throws IOException {
/* 1566 */     return forType(valueType).readValue(src);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(byte[] content) throws IOException {
/* 1580 */     if (this._dataFormatReaders != null) {
/* 1581 */       return (T)_detectBindAndClose(content, 0, content.length);
/*      */     }
/* 1583 */     return (T)_bindAndClose(_considerFilter(createParser(content), false));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(byte[] content, Class<T> valueType) throws IOException {
/* 1598 */     return forType(valueType).readValue(content);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(byte[] buffer, int offset, int length) throws IOException {
/* 1614 */     if (this._dataFormatReaders != null) {
/* 1615 */       return (T)_detectBindAndClose(buffer, offset, length);
/*      */     }
/* 1617 */     return (T)_bindAndClose(_considerFilter(createParser(buffer, offset, length), false));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(byte[] buffer, int offset, int length, Class<T> valueType) throws IOException {
/* 1635 */     return forType(valueType).readValue(buffer, offset, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(File src) throws IOException {
/* 1649 */     if (this._dataFormatReaders != null) {
/* 1650 */       return (T)_detectBindAndClose(this._dataFormatReaders.findFormat(_inputStream(src)), true);
/*      */     }
/*      */     
/* 1653 */     return (T)_bindAndClose(_considerFilter(createParser(src), false));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(File src, Class<T> valueType) throws IOException {
/* 1668 */     return forType(valueType).readValue(src);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(URL src) throws IOException {
/* 1687 */     if (this._dataFormatReaders != null) {
/* 1688 */       return (T)_detectBindAndClose(this._dataFormatReaders.findFormat(_inputStream(src)), true);
/*      */     }
/* 1690 */     return (T)_bindAndClose(_considerFilter(createParser(src), false));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(URL src, Class<T> valueType) throws IOException {
/* 1705 */     return forType(valueType).readValue(src);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(JsonNode content) throws IOException {
/* 1720 */     _assertNotNull("content", content);
/* 1721 */     if (this._dataFormatReaders != null) {
/* 1722 */       _reportUndetectableSource(content);
/*      */     }
/* 1724 */     return (T)_bindAndClose(_considerFilter(treeAsTokens(content), false));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(JsonNode content, Class<T> valueType) throws IOException {
/* 1739 */     return forType(valueType).readValue(content);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(DataInput src) throws IOException {
/* 1745 */     if (this._dataFormatReaders != null) {
/* 1746 */       _reportUndetectableSource(src);
/*      */     }
/* 1748 */     return (T)_bindAndClose(_considerFilter(createParser(src), false));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(DataInput content, Class<T> valueType) throws IOException {
/* 1763 */     return forType(valueType).readValue(content);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNode readTree(InputStream src) throws IOException {
/* 1791 */     if (this._dataFormatReaders != null) {
/* 1792 */       return _detectBindAndCloseAsTree(src);
/*      */     }
/* 1794 */     return _bindAndCloseAsTree(_considerFilter(createParser(src), false));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNode readTree(Reader src) throws IOException {
/* 1803 */     if (this._dataFormatReaders != null) {
/* 1804 */       _reportUndetectableSource(src);
/*      */     }
/* 1806 */     return _bindAndCloseAsTree(_considerFilter(createParser(src), false));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNode readTree(String json) throws JsonProcessingException, JsonMappingException {
/* 1815 */     if (this._dataFormatReaders != null) {
/* 1816 */       _reportUndetectableSource(json);
/*      */     }
/*      */     try {
/* 1819 */       return _bindAndCloseAsTree(_considerFilter(createParser(json), false));
/* 1820 */     } catch (JsonProcessingException e) {
/* 1821 */       throw e;
/* 1822 */     } catch (IOException e) {
/* 1823 */       throw JsonMappingException.fromUnexpectedIOE(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNode readTree(byte[] json) throws IOException {
/* 1833 */     _assertNotNull("json", json);
/* 1834 */     if (this._dataFormatReaders != null) {
/* 1835 */       _reportUndetectableSource(json);
/*      */     }
/* 1837 */     return _bindAndCloseAsTree(_considerFilter(createParser(json), false));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNode readTree(byte[] json, int offset, int len) throws IOException {
/* 1846 */     if (this._dataFormatReaders != null) {
/* 1847 */       _reportUndetectableSource(json);
/*      */     }
/* 1849 */     return _bindAndCloseAsTree(_considerFilter(createParser(json, offset, len), false));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNode readTree(DataInput src) throws IOException {
/* 1858 */     if (this._dataFormatReaders != null) {
/* 1859 */       _reportUndetectableSource(src);
/*      */     }
/* 1861 */     return _bindAndCloseAsTree(_considerFilter(createParser(src), false));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> MappingIterator<T> readValues(JsonParser p) throws IOException {
/* 1883 */     _assertNotNull("p", p);
/* 1884 */     DefaultDeserializationContext defaultDeserializationContext = createDeserializationContext(p);
/*      */     
/* 1886 */     return _newIterator(p, (DeserializationContext)defaultDeserializationContext, _findRootDeserializer((DeserializationContext)defaultDeserializationContext), false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> MappingIterator<T> readValues(InputStream src) throws IOException {
/* 1911 */     if (this._dataFormatReaders != null) {
/* 1912 */       return _detectBindAndReadValues(this._dataFormatReaders.findFormat(src), false);
/*      */     }
/*      */     
/* 1915 */     return _bindAndReadValues(_considerFilter(createParser(src), true));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> MappingIterator<T> readValues(Reader src) throws IOException {
/* 1923 */     if (this._dataFormatReaders != null) {
/* 1924 */       _reportUndetectableSource(src);
/*      */     }
/* 1926 */     JsonParser p = _considerFilter(createParser(src), true);
/* 1927 */     DefaultDeserializationContext defaultDeserializationContext = createDeserializationContext(p);
/* 1928 */     _initForMultiRead((DeserializationContext)defaultDeserializationContext, p);
/* 1929 */     p.nextToken();
/* 1930 */     return _newIterator(p, (DeserializationContext)defaultDeserializationContext, _findRootDeserializer((DeserializationContext)defaultDeserializationContext), true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> MappingIterator<T> readValues(String json) throws IOException {
/* 1940 */     if (this._dataFormatReaders != null) {
/* 1941 */       _reportUndetectableSource(json);
/*      */     }
/* 1943 */     JsonParser p = _considerFilter(createParser(json), true);
/* 1944 */     DefaultDeserializationContext defaultDeserializationContext = createDeserializationContext(p);
/* 1945 */     _initForMultiRead((DeserializationContext)defaultDeserializationContext, p);
/* 1946 */     p.nextToken();
/* 1947 */     return _newIterator(p, (DeserializationContext)defaultDeserializationContext, _findRootDeserializer((DeserializationContext)defaultDeserializationContext), true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> MappingIterator<T> readValues(byte[] src, int offset, int length) throws IOException {
/* 1955 */     if (this._dataFormatReaders != null) {
/* 1956 */       return _detectBindAndReadValues(this._dataFormatReaders.findFormat(src, offset, length), false);
/*      */     }
/* 1958 */     return _bindAndReadValues(_considerFilter(createParser(src, offset, length), true));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <T> MappingIterator<T> readValues(byte[] src) throws IOException {
/* 1966 */     _assertNotNull("src", src);
/* 1967 */     return readValues(src, 0, src.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> MappingIterator<T> readValues(File src) throws IOException {
/* 1975 */     if (this._dataFormatReaders != null) {
/* 1976 */       return _detectBindAndReadValues(this._dataFormatReaders
/* 1977 */           .findFormat(_inputStream(src)), false);
/*      */     }
/* 1979 */     return _bindAndReadValues(_considerFilter(createParser(src), true));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> MappingIterator<T> readValues(URL src) throws IOException {
/* 1995 */     if (this._dataFormatReaders != null) {
/* 1996 */       return _detectBindAndReadValues(this._dataFormatReaders
/* 1997 */           .findFormat(_inputStream(src)), true);
/*      */     }
/* 1999 */     return _bindAndReadValues(_considerFilter(createParser(src), true));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> MappingIterator<T> readValues(DataInput src) throws IOException {
/* 2007 */     if (this._dataFormatReaders != null) {
/* 2008 */       _reportUndetectableSource(src);
/*      */     }
/* 2010 */     return _bindAndReadValues(_considerFilter(createParser(src), true));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T treeToValue(TreeNode n, Class<T> valueType) throws JsonProcessingException {
/* 2022 */     _assertNotNull("n", n);
/*      */     try {
/* 2024 */       return readValue(treeAsTokens(n), valueType);
/* 2025 */     } catch (JsonProcessingException e) {
/* 2026 */       throw e;
/* 2027 */     } catch (IOException e) {
/* 2028 */       throw JsonMappingException.fromUnexpectedIOE(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T treeToValue(TreeNode n, JavaType valueType) throws JsonProcessingException {
/* 2039 */     _assertNotNull("n", n);
/*      */     try {
/* 2041 */       return readValue(treeAsTokens(n), valueType);
/* 2042 */     } catch (JsonProcessingException e) {
/* 2043 */       throw e;
/* 2044 */     } catch (IOException e) {
/* 2045 */       throw JsonMappingException.fromUnexpectedIOE(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeValue(JsonGenerator gen, Object value) throws IOException {
/* 2051 */     throw new UnsupportedOperationException("Not implemented for ObjectReader");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object _bind(JsonParser p, Object valueToUpdate) throws IOException {
/*      */     Object result;
/* 2068 */     DefaultDeserializationContext ctxt = createDeserializationContext(p);
/* 2069 */     JsonToken t = _initForReading((DeserializationContext)ctxt, p);
/* 2070 */     if (t == JsonToken.VALUE_NULL) {
/* 2071 */       if (valueToUpdate == null) {
/* 2072 */         result = _findRootDeserializer((DeserializationContext)ctxt).getNullValue((DeserializationContext)ctxt);
/*      */       } else {
/* 2074 */         result = valueToUpdate;
/*      */       } 
/* 2076 */     } else if (t == JsonToken.END_ARRAY || t == JsonToken.END_OBJECT) {
/* 2077 */       result = valueToUpdate;
/*      */     } else {
/* 2079 */       result = ctxt.readRootValue(p, this._valueType, _findRootDeserializer((DeserializationContext)ctxt), this._valueToUpdate);
/*      */     } 
/*      */     
/* 2082 */     p.clearCurrentToken();
/* 2083 */     if (this._config.isEnabled(DeserializationFeature.FAIL_ON_TRAILING_TOKENS)) {
/* 2084 */       _verifyNoTrailingTokens(p, (DeserializationContext)ctxt, this._valueType);
/*      */     }
/* 2086 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   protected Object _bindAndClose(JsonParser p0) throws IOException {
/* 2091 */     try (JsonParser p = p0) {
/*      */       Object result;
/*      */       
/* 2094 */       DefaultDeserializationContext ctxt = createDeserializationContext(p);
/* 2095 */       JsonToken t = _initForReading((DeserializationContext)ctxt, p);
/* 2096 */       if (t == JsonToken.VALUE_NULL) {
/* 2097 */         if (this._valueToUpdate == null) {
/* 2098 */           result = _findRootDeserializer((DeserializationContext)ctxt).getNullValue((DeserializationContext)ctxt);
/*      */         } else {
/* 2100 */           result = this._valueToUpdate;
/*      */         } 
/* 2102 */       } else if (t == JsonToken.END_ARRAY || t == JsonToken.END_OBJECT) {
/* 2103 */         result = this._valueToUpdate;
/*      */       } else {
/* 2105 */         result = ctxt.readRootValue(p, this._valueType, _findRootDeserializer((DeserializationContext)ctxt), this._valueToUpdate);
/*      */       } 
/*      */       
/* 2108 */       if (this._config.isEnabled(DeserializationFeature.FAIL_ON_TRAILING_TOKENS)) {
/* 2109 */         _verifyNoTrailingTokens(p, (DeserializationContext)ctxt, this._valueType);
/*      */       }
/* 2111 */       return result;
/*      */     } 
/*      */   }
/*      */   
/*      */   protected final JsonNode _bindAndCloseAsTree(JsonParser p0) throws IOException {
/* 2116 */     try (JsonParser p = p0) {
/* 2117 */       return _bindAsTree(p);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonNode _bindAsTree(JsonParser p) throws IOException {
/*      */     JsonNode resultNode;
/* 2125 */     if (this._valueToUpdate != null) {
/* 2126 */       return (JsonNode)_bind(p, this._valueToUpdate);
/*      */     }
/*      */ 
/*      */     
/* 2130 */     this._config.initialize(p);
/* 2131 */     if (this._schema != null) {
/* 2132 */       p.setSchema(this._schema);
/*      */     }
/*      */     
/* 2135 */     JsonToken t = p.currentToken();
/* 2136 */     if (t == null) {
/* 2137 */       t = p.nextToken();
/* 2138 */       if (t == null) {
/* 2139 */         return this._config.getNodeFactory().missingNode();
/*      */       }
/*      */     } 
/* 2142 */     DefaultDeserializationContext ctxt = createDeserializationContext(p);
/*      */ 
/*      */     
/* 2145 */     if (t == JsonToken.VALUE_NULL) {
/* 2146 */       NullNode nullNode = this._config.getNodeFactory().nullNode();
/*      */     } else {
/*      */       
/* 2149 */       resultNode = (JsonNode)ctxt.readRootValue(p, _jsonNodeType(), _findTreeDeserializer((DeserializationContext)ctxt), null);
/*      */     } 
/*      */     
/* 2152 */     p.clearCurrentToken();
/* 2153 */     if (this._config.isEnabled(DeserializationFeature.FAIL_ON_TRAILING_TOKENS)) {
/* 2154 */       _verifyNoTrailingTokens(p, (DeserializationContext)ctxt, _jsonNodeType());
/*      */     }
/* 2156 */     return resultNode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonNode _bindAsTreeOrNull(JsonParser p) throws IOException {
/*      */     JsonNode resultNode;
/* 2167 */     if (this._valueToUpdate != null) {
/* 2168 */       return (JsonNode)_bind(p, this._valueToUpdate);
/*      */     }
/*      */ 
/*      */     
/* 2172 */     this._config.initialize(p);
/* 2173 */     if (this._schema != null) {
/* 2174 */       p.setSchema(this._schema);
/*      */     }
/* 2176 */     JsonToken t = p.currentToken();
/* 2177 */     if (t == null) {
/* 2178 */       t = p.nextToken();
/* 2179 */       if (t == null) {
/* 2180 */         return null;
/*      */       }
/*      */     } 
/* 2183 */     DefaultDeserializationContext ctxt = createDeserializationContext(p);
/*      */     
/* 2185 */     if (t == JsonToken.VALUE_NULL) {
/* 2186 */       NullNode nullNode = this._config.getNodeFactory().nullNode();
/*      */     } else {
/*      */       
/* 2189 */       resultNode = (JsonNode)ctxt.readRootValue(p, _jsonNodeType(), _findTreeDeserializer((DeserializationContext)ctxt), null);
/*      */     } 
/*      */     
/* 2192 */     p.clearCurrentToken();
/* 2193 */     if (this._config.isEnabled(DeserializationFeature.FAIL_ON_TRAILING_TOKENS)) {
/* 2194 */       _verifyNoTrailingTokens(p, (DeserializationContext)ctxt, _jsonNodeType());
/*      */     }
/* 2196 */     return resultNode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <T> MappingIterator<T> _bindAndReadValues(JsonParser p) throws IOException {
/* 2204 */     DefaultDeserializationContext defaultDeserializationContext = createDeserializationContext(p);
/* 2205 */     _initForMultiRead((DeserializationContext)defaultDeserializationContext, p);
/* 2206 */     p.nextToken();
/* 2207 */     return _newIterator(p, (DeserializationContext)defaultDeserializationContext, _findRootDeserializer((DeserializationContext)defaultDeserializationContext), true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonParser _considerFilter(JsonParser p, boolean multiValue) {
/* 2216 */     return (this._filter == null || FilteringParserDelegate.class.isInstance(p)) ? p : (JsonParser)new FilteringParserDelegate(p, this._filter, TokenFilter.Inclusion.ONLY_INCLUDE_ALL, multiValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _verifyNoTrailingTokens(JsonParser p, DeserializationContext ctxt, JavaType bindType) throws IOException {
/* 2227 */     JsonToken t = p.nextToken();
/* 2228 */     if (t != null) {
/* 2229 */       Class<?> bt = ClassUtil.rawClass(bindType);
/* 2230 */       if (bt == null && 
/* 2231 */         this._valueToUpdate != null) {
/* 2232 */         bt = this._valueToUpdate.getClass();
/*      */       }
/*      */       
/* 2235 */       ctxt.reportTrailingTokens(bt, p, t);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object _detectBindAndClose(byte[] src, int offset, int length) throws IOException {
/* 2247 */     DataFormatReaders.Match match = this._dataFormatReaders.findFormat(src, offset, length);
/* 2248 */     if (!match.hasMatch()) {
/* 2249 */       _reportUnkownFormat(this._dataFormatReaders, match);
/*      */     }
/* 2251 */     JsonParser p = match.createParserWithMatch();
/* 2252 */     return match.getReader()._bindAndClose(p);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object _detectBindAndClose(DataFormatReaders.Match match, boolean forceClosing) throws IOException {
/* 2258 */     if (!match.hasMatch()) {
/* 2259 */       _reportUnkownFormat(this._dataFormatReaders, match);
/*      */     }
/* 2261 */     JsonParser p = match.createParserWithMatch();
/*      */ 
/*      */     
/* 2264 */     if (forceClosing) {
/* 2265 */       p.enable(JsonParser.Feature.AUTO_CLOSE_SOURCE);
/*      */     }
/*      */     
/* 2268 */     return match.getReader()._bindAndClose(p);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected <T> MappingIterator<T> _detectBindAndReadValues(DataFormatReaders.Match match, boolean forceClosing) throws IOException {
/* 2274 */     if (!match.hasMatch()) {
/* 2275 */       _reportUnkownFormat(this._dataFormatReaders, match);
/*      */     }
/* 2277 */     JsonParser p = match.createParserWithMatch();
/*      */ 
/*      */     
/* 2280 */     if (forceClosing) {
/* 2281 */       p.enable(JsonParser.Feature.AUTO_CLOSE_SOURCE);
/*      */     }
/*      */     
/* 2284 */     return match.getReader()._bindAndReadValues(p);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonNode _detectBindAndCloseAsTree(InputStream in) throws IOException {
/* 2289 */     DataFormatReaders.Match match = this._dataFormatReaders.findFormat(in);
/* 2290 */     if (!match.hasMatch()) {
/* 2291 */       _reportUnkownFormat(this._dataFormatReaders, match);
/*      */     }
/* 2293 */     JsonParser p = match.createParserWithMatch();
/* 2294 */     p.enable(JsonParser.Feature.AUTO_CLOSE_SOURCE);
/* 2295 */     return match.getReader()._bindAndCloseAsTree(p);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportUnkownFormat(DataFormatReaders detector, DataFormatReaders.Match match) throws IOException {
/* 2306 */     throw new JsonParseException(null, "Cannot detect format from input, does not look like any of detectable formats " + detector
/* 2307 */         .toString());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _verifySchemaType(FormatSchema schema) {
/* 2321 */     if (schema != null && 
/* 2322 */       !this._parserFactory.canUseSchema(schema)) {
/* 2323 */       throw new IllegalArgumentException("Cannot use FormatSchema of type " + schema.getClass().getName() + " for format " + this._parserFactory
/* 2324 */           .getFormatName());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected DefaultDeserializationContext createDeserializationContext(JsonParser p) {
/* 2335 */     return this._context.createInstance(this._config, p, this._injectableValues);
/*      */   }
/*      */ 
/*      */   
/*      */   protected DefaultDeserializationContext createDummyDeserializationContext() {
/* 2340 */     return this._context.createDummyInstance(this._config);
/*      */   }
/*      */   
/*      */   protected InputStream _inputStream(URL src) throws IOException {
/* 2344 */     return src.openStream();
/*      */   }
/*      */   
/*      */   protected InputStream _inputStream(File f) throws IOException {
/* 2348 */     return new FileInputStream(f);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportUndetectableSource(Object src) throws StreamReadException {
/* 2354 */     throw new JsonParseException(null, "Cannot use source of type " + src
/* 2355 */         .getClass().getName() + " with format auto-detection: must be byte- not char-based");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonDeserializer<Object> _findRootDeserializer(DeserializationContext ctxt) throws DatabindException {
/* 2370 */     if (this._rootDeserializer != null) {
/* 2371 */       return this._rootDeserializer;
/*      */     }
/*      */ 
/*      */     
/* 2375 */     JavaType t = this._valueType;
/* 2376 */     if (t == null) {
/* 2377 */       ctxt.reportBadDefinition((JavaType)null, "No value type configured for ObjectReader");
/*      */     }
/*      */ 
/*      */     
/* 2381 */     JsonDeserializer<Object> deser = this._rootDeserializers.get(t);
/* 2382 */     if (deser != null) {
/* 2383 */       return deser;
/*      */     }
/*      */     
/* 2386 */     deser = ctxt.findRootValueDeserializer(t);
/* 2387 */     if (deser == null) {
/* 2388 */       ctxt.reportBadDefinition(t, "Cannot find a deserializer for type " + t);
/*      */     }
/* 2390 */     this._rootDeserializers.put(t, deser);
/* 2391 */     return deser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonDeserializer<Object> _findTreeDeserializer(DeserializationContext ctxt) throws DatabindException {
/* 2400 */     JavaType nodeType = _jsonNodeType();
/* 2401 */     JsonDeserializer<Object> deser = this._rootDeserializers.get(nodeType);
/* 2402 */     if (deser == null) {
/*      */       
/* 2404 */       deser = ctxt.findRootValueDeserializer(nodeType);
/* 2405 */       if (deser == null) {
/* 2406 */         ctxt.reportBadDefinition(nodeType, "Cannot find a deserializer for type " + nodeType);
/*      */       }
/*      */       
/* 2409 */       this._rootDeserializers.put(nodeType, deser);
/*      */     } 
/* 2411 */     return deser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonDeserializer<Object> _prefetchRootDeserializer(JavaType valueType) {
/* 2421 */     if (valueType == null || !this._config.isEnabled(DeserializationFeature.EAGER_DESERIALIZER_FETCH)) {
/* 2422 */       return null;
/*      */     }
/*      */     
/* 2425 */     JsonDeserializer<Object> deser = this._rootDeserializers.get(valueType);
/* 2426 */     if (deser == null) {
/*      */       
/*      */       try {
/* 2429 */         DefaultDeserializationContext defaultDeserializationContext = createDummyDeserializationContext();
/* 2430 */         deser = defaultDeserializationContext.findRootValueDeserializer(valueType);
/* 2431 */         if (deser != null) {
/* 2432 */           this._rootDeserializers.put(valueType, deser);
/*      */         }
/* 2434 */         return deser;
/* 2435 */       } catch (JacksonException jacksonException) {}
/*      */     }
/*      */ 
/*      */     
/* 2439 */     return deser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JavaType _jsonNodeType() {
/* 2446 */     JavaType t = this._jsonNodeType;
/* 2447 */     if (t == null) {
/* 2448 */       t = getTypeFactory().constructType(JsonNode.class);
/* 2449 */       this._jsonNodeType = t;
/*      */     } 
/* 2451 */     return t;
/*      */   }
/*      */   
/*      */   protected final void _assertNotNull(String paramName, Object src) {
/* 2455 */     if (src == null)
/* 2456 */       throw new IllegalArgumentException(String.format("argument \"%s\" is null", new Object[] { paramName })); 
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\ObjectReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */