/*    */ package com.fasterxml.jackson.databind.deser.std;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.DeserializationContext;
/*    */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*    */ import com.fasterxml.jackson.databind.JsonMappingException;
/*    */ import java.nio.ByteBuffer;
/*    */ import java.util.HashSet;
/*    */ import java.util.UUID;
/*    */ import java.util.concurrent.atomic.AtomicBoolean;
/*    */ import java.util.concurrent.atomic.AtomicInteger;
/*    */ import java.util.concurrent.atomic.AtomicLong;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JdkDeserializers
/*    */ {
/* 17 */   private static final HashSet<String> _classNames = new HashSet<>();
/*    */   
/*    */   static {
/* 20 */     Class<?>[] types = new Class[] { UUID.class, AtomicBoolean.class, AtomicInteger.class, AtomicLong.class, StackTraceElement.class, ByteBuffer.class, Void.class };
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 29 */     for (Class<?> cls : types) _classNames.add(cls.getName()); 
/* 30 */     for (Class<?> cls : FromStringDeserializer.types()) _classNames.add(cls.getName());
/*    */   
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   public static JsonDeserializer<?> find(Class<?> rawType, String clsName) throws JsonMappingException {
/* 40 */     return find(null, rawType, clsName);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static JsonDeserializer<?> find(DeserializationContext ctxt, Class<?> rawType, String clsName) throws JsonMappingException {
/* 50 */     if (_classNames.contains(clsName)) {
/* 51 */       JsonDeserializer<?> d = FromStringDeserializer.findDeserializer(rawType);
/* 52 */       if (d != null) {
/* 53 */         return d;
/*    */       }
/* 55 */       if (rawType == UUID.class) {
/* 56 */         return new UUIDDeserializer();
/*    */       }
/* 58 */       if (rawType == StackTraceElement.class) {
/* 59 */         return StackTraceElementDeserializer.construct(ctxt);
/*    */       }
/* 61 */       if (rawType == AtomicBoolean.class) {
/* 62 */         return new AtomicBooleanDeserializer();
/*    */       }
/* 64 */       if (rawType == AtomicInteger.class) {
/* 65 */         return new AtomicIntegerDeserializer();
/*    */       }
/* 67 */       if (rawType == AtomicLong.class) {
/* 68 */         return new AtomicLongDeserializer();
/*    */       }
/* 70 */       if (rawType == ByteBuffer.class) {
/* 71 */         return new ByteBufferDeserializer();
/*    */       }
/* 73 */       if (rawType == Void.class) {
/* 74 */         return NullifyingDeserializer.instance;
/*    */       }
/*    */     } 
/* 77 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public static boolean hasDeserializerFor(Class<?> rawType) {
/* 82 */     return _classNames.contains(rawType.getName());
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\deser\std\JdkDeserializers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */