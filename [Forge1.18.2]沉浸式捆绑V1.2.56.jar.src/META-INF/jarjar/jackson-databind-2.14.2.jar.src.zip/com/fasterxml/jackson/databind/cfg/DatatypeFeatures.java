/*     */ package com.fasterxml.jackson.databind.cfg;
/*     */ 
/*     */ import com.fasterxml.jackson.core.util.VersionUtil;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DatatypeFeatures
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected static final int FEATURE_INDEX_ENUM = 0;
/*     */   protected static final int FEATURE_INDEX_JSON_NODE = 1;
/*     */   private final int _enabledFor1;
/*     */   private final int _enabledFor2;
/*     */   private final int _explicitFor1;
/*     */   private final int _explicitFor2;
/*     */   
/*     */   protected DatatypeFeatures(int enabledFor1, int explicitFor1, int enabledFor2, int explicitFor2) {
/*  26 */     this._enabledFor1 = enabledFor1;
/*  27 */     this._explicitFor1 = explicitFor1;
/*  28 */     this._enabledFor2 = enabledFor2;
/*  29 */     this._explicitFor2 = explicitFor2;
/*     */   }
/*     */   
/*     */   public static DatatypeFeatures defaultFeatures() {
/*  33 */     return DefaultHolder.getDefault();
/*     */   }
/*     */ 
/*     */   
/*     */   private DatatypeFeatures _with(int enabledFor1, int explicitFor1, int enabledFor2, int explicitFor2) {
/*  38 */     if (this._enabledFor1 == enabledFor1 && this._explicitFor1 == explicitFor1 && this._enabledFor2 == enabledFor2 && this._explicitFor2 == explicitFor2)
/*     */     {
/*  40 */       return this;
/*     */     }
/*  42 */     return new DatatypeFeatures(enabledFor1, explicitFor1, enabledFor2, explicitFor2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DatatypeFeatures with(DatatypeFeature f) {
/*  62 */     int mask = f.getMask();
/*  63 */     switch (f.featureIndex()) {
/*     */       case 0:
/*  65 */         return _with(this._enabledFor1 | mask, this._explicitFor1 | mask, this._enabledFor2, this._explicitFor2);
/*     */       
/*     */       case 1:
/*  68 */         return _with(this._enabledFor1, this._explicitFor1, this._enabledFor2 | mask, this._explicitFor2 | mask);
/*     */     } 
/*     */     
/*  71 */     VersionUtil.throwInternal();
/*  72 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DatatypeFeatures withFeatures(DatatypeFeature... features) {
/*  86 */     int mask = _calcMask(features);
/*  87 */     if (mask == 0) {
/*  88 */       return this;
/*     */     }
/*  90 */     switch (features[0].featureIndex()) {
/*     */       case 0:
/*  92 */         return _with(this._enabledFor1 | mask, this._explicitFor1 | mask, this._enabledFor2, this._explicitFor2);
/*     */       
/*     */       case 1:
/*  95 */         return _with(this._enabledFor1, this._explicitFor1, this._enabledFor2 | mask, this._explicitFor2 | mask);
/*     */     } 
/*     */     
/*  98 */     VersionUtil.throwInternal();
/*  99 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DatatypeFeatures without(DatatypeFeature f) {
/* 113 */     int mask = f.getMask();
/* 114 */     switch (f.featureIndex()) {
/*     */       case 0:
/* 116 */         return _with(this._enabledFor1 & (mask ^ 0xFFFFFFFF), this._explicitFor1 | mask, this._enabledFor2, this._explicitFor2);
/*     */       
/*     */       case 1:
/* 119 */         return _with(this._enabledFor1, this._explicitFor1, this._enabledFor2 & (mask ^ 0xFFFFFFFF), this._explicitFor2 | mask);
/*     */     } 
/*     */     
/* 122 */     VersionUtil.throwInternal();
/* 123 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DatatypeFeatures withoutFeatures(DatatypeFeature... features) {
/* 137 */     int mask = _calcMask(features);
/* 138 */     if (mask == 0) {
/* 139 */       return this;
/*     */     }
/* 141 */     switch (features[0].featureIndex()) {
/*     */       case 0:
/* 143 */         return _with(this._enabledFor1 & (mask ^ 0xFFFFFFFF), this._explicitFor1 | mask, this._enabledFor2, this._explicitFor2);
/*     */       
/*     */       case 1:
/* 146 */         return _with(this._enabledFor1, this._explicitFor1, this._enabledFor2 & (mask ^ 0xFFFFFFFF), this._explicitFor2 | mask);
/*     */     } 
/*     */     
/* 149 */     VersionUtil.throwInternal();
/* 150 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   private static final int _calcMask(DatatypeFeature... features) {
/* 155 */     int mask = 0;
/* 156 */     for (DatatypeFeature f : features) {
/* 157 */       mask |= f.getMask();
/*     */     }
/* 159 */     return mask;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled(DatatypeFeature f) {
/* 179 */     switch (f.featureIndex()) {
/*     */       case 0:
/* 181 */         return f.enabledIn(this._enabledFor1);
/*     */       case 1:
/* 183 */         return f.enabledIn(this._enabledFor2);
/*     */     } 
/* 185 */     VersionUtil.throwInternal();
/* 186 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isExplicitlySet(DatatypeFeature f) {
/* 200 */     switch (f.featureIndex()) {
/*     */       case 0:
/* 202 */         return f.enabledIn(this._explicitFor1);
/*     */       case 1:
/* 204 */         return f.enabledIn(this._explicitFor2);
/*     */     } 
/* 206 */     VersionUtil.throwInternal();
/* 207 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean getExplicitState(DatatypeFeature f) {
/* 222 */     switch (f.featureIndex()) {
/*     */       case 0:
/* 224 */         if (f.enabledIn(this._explicitFor1)) {
/* 225 */           return Boolean.valueOf(f.enabledIn(this._enabledFor1));
/*     */         }
/* 227 */         return null;
/*     */       case 1:
/* 229 */         if (f.enabledIn(this._explicitFor2)) {
/* 230 */           return Boolean.valueOf(f.enabledIn(this._enabledFor2));
/*     */         }
/* 232 */         return null;
/*     */     } 
/* 234 */     VersionUtil.throwInternal();
/* 235 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class DefaultHolder
/*     */   {
/* 253 */     private static final DatatypeFeatures DEFAULT_FEATURES = new DatatypeFeatures(
/* 254 */         collectDefaults(EnumFeature.values()), 0, 
/* 255 */         collectDefaults(JsonNodeFeature.values()), 0);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static <F extends Enum<F> & com.fasterxml.jackson.core.util.JacksonFeature> int collectDefaults(F[] features) {
/* 261 */       int flags = 0;
/* 262 */       for (F f : features) {
/* 263 */         if (f.enabledByDefault()) {
/* 264 */           flags |= f.getMask();
/*     */         }
/*     */       } 
/* 267 */       return flags;
/*     */     }
/*     */     
/*     */     public static DatatypeFeatures getDefault() {
/* 271 */       return DEFAULT_FEATURES;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\cfg\DatatypeFeatures.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */