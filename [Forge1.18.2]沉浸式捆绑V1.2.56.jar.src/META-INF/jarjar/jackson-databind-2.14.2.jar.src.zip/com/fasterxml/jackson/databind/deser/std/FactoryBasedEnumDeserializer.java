/*     */ package com.fasterxml.jackson.databind.deser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.deser.ContextualDeserializer;
/*     */ import com.fasterxml.jackson.databind.deser.SettableBeanProperty;
/*     */ import com.fasterxml.jackson.databind.deser.ValueInstantiator;
/*     */ import com.fasterxml.jackson.databind.deser.impl.PropertyBasedCreator;
/*     */ import com.fasterxml.jackson.databind.deser.impl.PropertyValueBuffer;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMethod;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*     */ import com.fasterxml.jackson.databind.type.LogicalType;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class FactoryBasedEnumDeserializer
/*     */   extends StdDeserializer<Object>
/*     */   implements ContextualDeserializer
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final JavaType _inputType;
/*     */   protected final AnnotatedMethod _factory;
/*     */   protected final JsonDeserializer<?> _deser;
/*     */   protected final ValueInstantiator _valueInstantiator;
/*     */   protected final SettableBeanProperty[] _creatorProps;
/*     */   protected final boolean _hasArgs;
/*     */   private transient PropertyBasedCreator _propCreator;
/*     */   
/*     */   public FactoryBasedEnumDeserializer(Class<?> cls, AnnotatedMethod f, JavaType paramType, ValueInstantiator valueInstantiator, SettableBeanProperty[] creatorProps) {
/*  51 */     super(cls);
/*  52 */     this._factory = f;
/*  53 */     this._hasArgs = true;
/*     */     
/*  55 */     this._inputType = (paramType.hasRawClass(String.class) || paramType.hasRawClass(CharSequence.class)) ? null : paramType;
/*     */     
/*  57 */     this._deser = null;
/*  58 */     this._valueInstantiator = valueInstantiator;
/*  59 */     this._creatorProps = creatorProps;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FactoryBasedEnumDeserializer(Class<?> cls, AnnotatedMethod f) {
/*  67 */     super(cls);
/*  68 */     this._factory = f;
/*  69 */     this._hasArgs = false;
/*  70 */     this._inputType = null;
/*  71 */     this._deser = null;
/*  72 */     this._valueInstantiator = null;
/*  73 */     this._creatorProps = null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected FactoryBasedEnumDeserializer(FactoryBasedEnumDeserializer base, JsonDeserializer<?> deser) {
/*  78 */     super(base._valueClass);
/*  79 */     this._inputType = base._inputType;
/*  80 */     this._factory = base._factory;
/*  81 */     this._hasArgs = base._hasArgs;
/*  82 */     this._valueInstantiator = base._valueInstantiator;
/*  83 */     this._creatorProps = base._creatorProps;
/*     */     
/*  85 */     this._deser = deser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonDeserializer<?> createContextual(DeserializationContext ctxt, BeanProperty property) throws JsonMappingException {
/*  96 */     if (this._deser == null && this._inputType != null && this._creatorProps == null) {
/*  97 */       return new FactoryBasedEnumDeserializer(this, ctxt
/*  98 */           .findContextualValueDeserializer(this._inputType, property));
/*     */     }
/* 100 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Boolean supportsUpdate(DeserializationConfig config) {
/* 105 */     return Boolean.FALSE;
/*     */   }
/*     */ 
/*     */   
/*     */   public LogicalType logicalType() {
/* 110 */     return LogicalType.Enum;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCachable() {
/* 115 */     return true;
/*     */   }
/*     */   public ValueInstantiator getValueInstantiator() {
/* 118 */     return this._valueInstantiator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/*     */     Object value;
/* 127 */     if (this._deser != null) {
/* 128 */       value = this._deser.deserialize(p, ctxt);
/*     */     
/*     */     }
/* 131 */     else if (this._hasArgs) {
/*     */ 
/*     */       
/* 134 */       if (this._creatorProps != null) {
/* 135 */         if (!p.isExpectedStartObjectToken()) {
/* 136 */           JavaType targetType = getValueType(ctxt);
/* 137 */           ctxt.reportInputMismatch(targetType, "Input mismatch reading Enum %s: properties-based `@JsonCreator` (%s) expects JSON Object (JsonToken.START_OBJECT), got JsonToken.%s", new Object[] {
/*     */                 
/* 139 */                 ClassUtil.getTypeDescription(targetType), this._factory, p.currentToken() });
/*     */         } 
/* 141 */         if (this._propCreator == null) {
/* 142 */           this._propCreator = PropertyBasedCreator.construct(ctxt, this._valueInstantiator, this._creatorProps, ctxt
/* 143 */               .isEnabled(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES));
/*     */         }
/* 145 */         p.nextToken();
/* 146 */         return deserializeEnumUsingPropertyBased(p, ctxt, this._propCreator);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 155 */       JsonToken t = p.currentToken();
/*     */       
/* 157 */       boolean unwrapping = (t == JsonToken.START_ARRAY && ctxt.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS));
/* 158 */       if (unwrapping) {
/* 159 */         t = p.nextToken();
/*     */       }
/* 161 */       if (t == null || !t.isScalarValue()) {
/*     */         
/* 163 */         value = "";
/* 164 */         p.skipChildren();
/*     */       } else {
/* 166 */         value = p.getValueAsString();
/*     */       } 
/* 168 */       if (unwrapping && 
/* 169 */         p.nextToken() != JsonToken.END_ARRAY) {
/* 170 */         handleMissingEndArrayForSingle(p, ctxt);
/*     */       }
/*     */     } else {
/*     */       
/* 174 */       p.skipChildren();
/*     */       try {
/* 176 */         return this._factory.call();
/* 177 */       } catch (Exception e) {
/* 178 */         Throwable t = ClassUtil.throwRootCauseIfIOE(e);
/* 179 */         return ctxt.handleInstantiationProblem(this._valueClass, null, t);
/*     */       } 
/*     */     } 
/*     */     try {
/* 183 */       return this._factory.callOnWith(this._valueClass, new Object[] { value });
/* 184 */     } catch (Exception e) {
/* 185 */       Throwable t = ClassUtil.throwRootCauseIfIOE(e);
/* 186 */       if (t instanceof IllegalArgumentException)
/*     */       {
/* 188 */         if (ctxt.isEnabled(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL)) {
/* 189 */           return null;
/*     */         }
/*     */       }
/*     */ 
/*     */       
/* 194 */       return ctxt.handleInstantiationProblem(this._valueClass, value, t);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Object deserializeWithType(JsonParser p, DeserializationContext ctxt, TypeDeserializer typeDeserializer) throws IOException {
/* 200 */     if (this._deser == null) {
/* 201 */       return deserialize(p, ctxt);
/*     */     }
/* 203 */     return typeDeserializer.deserializeTypedFromAny(p, ctxt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object deserializeEnumUsingPropertyBased(JsonParser p, DeserializationContext ctxt, PropertyBasedCreator creator) throws IOException {
/* 210 */     PropertyValueBuffer buffer = creator.startBuilding(p, ctxt, null);
/*     */     
/* 212 */     JsonToken t = p.currentToken();
/* 213 */     for (; t == JsonToken.FIELD_NAME; t = p.nextToken()) {
/* 214 */       String propName = p.currentName();
/* 215 */       p.nextToken();
/*     */       
/* 217 */       SettableBeanProperty creatorProp = creator.findCreatorProperty(propName);
/* 218 */       if (!buffer.readIdProperty(propName) || creatorProp != null)
/*     */       {
/*     */         
/* 221 */         if (creatorProp != null) {
/* 222 */           buffer.assignParameter(creatorProp, _deserializeWithErrorWrapping(p, ctxt, creatorProp));
/*     */         }
/*     */         else {
/*     */           
/* 226 */           p.skipChildren();
/*     */         }  } 
/* 228 */     }  return creator.build(ctxt, buffer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Object _deserializeWithErrorWrapping(JsonParser p, DeserializationContext ctxt, SettableBeanProperty prop) throws IOException {
/*     */     try {
/* 237 */       return prop.deserialize(p, ctxt);
/* 238 */     } catch (Exception e) {
/* 239 */       return wrapAndThrow(e, handledType(), prop.getName(), ctxt);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object wrapAndThrow(Throwable t, Object bean, String fieldName, DeserializationContext ctxt) throws IOException {
/* 246 */     throw JsonMappingException.wrapWithPath(throwOrReturnThrowable(t, ctxt), bean, fieldName);
/*     */   }
/*     */ 
/*     */   
/*     */   private Throwable throwOrReturnThrowable(Throwable t, DeserializationContext ctxt) throws IOException {
/* 251 */     t = ClassUtil.getRootCause(t);
/*     */     
/* 253 */     ClassUtil.throwIfError(t);
/* 254 */     boolean wrap = (ctxt == null || ctxt.isEnabled(DeserializationFeature.WRAP_EXCEPTIONS));
/*     */     
/* 256 */     if (t instanceof IOException) {
/* 257 */       if (!wrap || !(t instanceof com.fasterxml.jackson.core.JacksonException)) {
/* 258 */         throw (IOException)t;
/*     */       }
/* 260 */     } else if (!wrap) {
/* 261 */       ClassUtil.throwIfRTE(t);
/*     */     } 
/* 263 */     return t;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\deser\std\FactoryBasedEnumDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */