/*      */ package com.fasterxml.jackson.databind.introspect;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JacksonInject;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*      */ import com.fasterxml.jackson.databind.JavaType;
/*      */ import com.fasterxml.jackson.databind.MapperFeature;
/*      */ import com.fasterxml.jackson.databind.PropertyName;
/*      */ import com.fasterxml.jackson.databind.PropertyNamingStrategy;
/*      */ import com.fasterxml.jackson.databind.cfg.HandlerInstantiator;
/*      */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*      */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.TreeMap;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class POJOPropertiesCollector
/*      */ {
/*      */   protected final MapperConfig<?> _config;
/*      */   protected final AccessorNamingStrategy _accessorNaming;
/*      */   protected final boolean _forSerialization;
/*      */   protected final JavaType _type;
/*      */   protected final AnnotatedClass _classDef;
/*      */   protected final VisibilityChecker<?> _visibilityChecker;
/*      */   protected final AnnotationIntrospector _annotationIntrospector;
/*      */   protected final boolean _useAnnotations;
/*      */   protected boolean _collected;
/*      */   protected LinkedHashMap<String, POJOPropertyBuilder> _properties;
/*      */   protected LinkedList<POJOPropertyBuilder> _creatorProperties;
/*      */   protected Map<PropertyName, PropertyName> _fieldRenameMappings;
/*      */   protected LinkedList<AnnotatedMember> _anyGetters;
/*      */   protected LinkedList<AnnotatedMember> _anyGetterField;
/*      */   protected LinkedList<AnnotatedMethod> _anySetters;
/*      */   protected LinkedList<AnnotatedMember> _anySetterField;
/*      */   protected LinkedList<AnnotatedMember> _jsonKeyAccessors;
/*      */   protected LinkedList<AnnotatedMember> _jsonValueAccessors;
/*      */   protected HashSet<String> _ignoredPropertyNames;
/*      */   protected LinkedHashMap<Object, AnnotatedMember> _injectables;
/*      */   @Deprecated
/*      */   protected final boolean _stdBeanNaming;
/*      */   @Deprecated
/*  152 */   protected String _mutatorPrefix = "set";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected POJOPropertiesCollector(MapperConfig<?> config, boolean forSerialization, JavaType type, AnnotatedClass classDef, AccessorNamingStrategy accessorNaming) {
/*  168 */     this._config = config;
/*  169 */     this._forSerialization = forSerialization;
/*  170 */     this._type = type;
/*  171 */     this._classDef = classDef;
/*  172 */     if (config.isAnnotationProcessingEnabled()) {
/*  173 */       this._useAnnotations = true;
/*  174 */       this._annotationIntrospector = this._config.getAnnotationIntrospector();
/*      */     } else {
/*  176 */       this._useAnnotations = false;
/*  177 */       this._annotationIntrospector = AnnotationIntrospector.nopInstance();
/*      */     } 
/*  179 */     this._visibilityChecker = this._config.getDefaultVisibilityChecker(type.getRawClass(), classDef);
/*      */     
/*  181 */     this._accessorNaming = accessorNaming;
/*      */ 
/*      */     
/*  184 */     this._stdBeanNaming = config.isEnabled(MapperFeature.USE_STD_BEAN_NAMING);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected POJOPropertiesCollector(MapperConfig<?> config, boolean forSerialization, JavaType type, AnnotatedClass classDef, String mutatorPrefix) {
/*  195 */     this(config, forSerialization, type, classDef, 
/*  196 */         _accessorNaming(config, classDef, mutatorPrefix));
/*  197 */     this._mutatorPrefix = mutatorPrefix;
/*      */   }
/*      */ 
/*      */   
/*      */   private static AccessorNamingStrategy _accessorNaming(MapperConfig<?> config, AnnotatedClass classDef, String mutatorPrefix) {
/*  202 */     if (mutatorPrefix == null) {
/*  203 */       mutatorPrefix = "set";
/*      */     }
/*  205 */     return (new DefaultAccessorNamingStrategy.Provider())
/*  206 */       .withSetterPrefix(mutatorPrefix).forPOJO(config, classDef);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MapperConfig<?> getConfig() {
/*  216 */     return this._config;
/*      */   }
/*      */   
/*      */   public JavaType getType() {
/*  220 */     return this._type;
/*      */   }
/*      */   
/*      */   public AnnotatedClass getClassDef() {
/*  224 */     return this._classDef;
/*      */   }
/*      */   
/*      */   public AnnotationIntrospector getAnnotationIntrospector() {
/*  228 */     return this._annotationIntrospector;
/*      */   }
/*      */ 
/*      */   
/*      */   public List<BeanPropertyDefinition> getProperties() {
/*  233 */     Map<String, POJOPropertyBuilder> props = getPropertyMap();
/*  234 */     return new ArrayList<>(props.values());
/*      */   }
/*      */   
/*      */   public Map<Object, AnnotatedMember> getInjectables() {
/*  238 */     if (!this._collected) {
/*  239 */       collectAll();
/*      */     }
/*  241 */     return this._injectables;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotatedMember getJsonKeyAccessor() {
/*  248 */     if (!this._collected) {
/*  249 */       collectAll();
/*      */     }
/*      */     
/*  252 */     if (this._jsonKeyAccessors != null) {
/*  253 */       if (this._jsonKeyAccessors.size() > 1 && 
/*  254 */         !_resolveFieldVsGetter(this._jsonKeyAccessors)) {
/*  255 */         reportProblem("Multiple 'as-key' properties defined (%s vs %s)", new Object[] { this._jsonKeyAccessors
/*  256 */               .get(0), this._jsonKeyAccessors
/*  257 */               .get(1) });
/*      */       }
/*      */ 
/*      */       
/*  261 */       return this._jsonKeyAccessors.get(0);
/*      */     } 
/*  263 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotatedMember getJsonValueAccessor() {
/*  271 */     if (!this._collected) {
/*  272 */       collectAll();
/*      */     }
/*      */ 
/*      */     
/*  276 */     if (this._jsonValueAccessors != null) {
/*  277 */       if (this._jsonValueAccessors.size() > 1 && 
/*  278 */         !_resolveFieldVsGetter(this._jsonValueAccessors)) {
/*  279 */         reportProblem("Multiple 'as-value' properties defined (%s vs %s)", new Object[] { this._jsonValueAccessors
/*  280 */               .get(0), this._jsonValueAccessors
/*  281 */               .get(1) });
/*      */       }
/*      */ 
/*      */       
/*  285 */       return this._jsonValueAccessors.get(0);
/*      */     } 
/*  287 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public AnnotatedMember getAnyGetter() {
/*  298 */     return getAnyGetterMethod();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotatedMember getAnyGetterField() {
/*  306 */     if (!this._collected) {
/*  307 */       collectAll();
/*      */     }
/*  309 */     if (this._anyGetterField != null) {
/*  310 */       if (this._anyGetterField.size() > 1) {
/*  311 */         reportProblem("Multiple 'any-getter' fields defined (%s vs %s)", new Object[] { this._anyGetterField
/*  312 */               .get(0), this._anyGetterField.get(1) });
/*      */       }
/*  314 */       return this._anyGetterField.getFirst();
/*      */     } 
/*  316 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotatedMember getAnyGetterMethod() {
/*  324 */     if (!this._collected) {
/*  325 */       collectAll();
/*      */     }
/*  327 */     if (this._anyGetters != null) {
/*  328 */       if (this._anyGetters.size() > 1) {
/*  329 */         reportProblem("Multiple 'any-getter' methods defined (%s vs %s)", new Object[] { this._anyGetters
/*  330 */               .get(0), this._anyGetters.get(1) });
/*      */       }
/*  332 */       return this._anyGetters.getFirst();
/*      */     } 
/*  334 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public AnnotatedMember getAnySetterField() {
/*  339 */     if (!this._collected) {
/*  340 */       collectAll();
/*      */     }
/*  342 */     if (this._anySetterField != null) {
/*  343 */       if (this._anySetterField.size() > 1) {
/*  344 */         reportProblem("Multiple 'any-setter' fields defined (%s vs %s)", new Object[] { this._anySetterField
/*  345 */               .get(0), this._anySetterField.get(1) });
/*      */       }
/*  347 */       return this._anySetterField.getFirst();
/*      */     } 
/*  349 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public AnnotatedMethod getAnySetterMethod() {
/*  354 */     if (!this._collected) {
/*  355 */       collectAll();
/*      */     }
/*  357 */     if (this._anySetters != null) {
/*  358 */       if (this._anySetters.size() > 1) {
/*  359 */         reportProblem("Multiple 'any-setter' methods defined (%s vs %s)", new Object[] { this._anySetters
/*  360 */               .get(0), this._anySetters.get(1) });
/*      */       }
/*  362 */       return this._anySetters.getFirst();
/*      */     } 
/*  364 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<String> getIgnoredPropertyNames() {
/*  372 */     return this._ignoredPropertyNames;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectIdInfo getObjectIdInfo() {
/*  381 */     ObjectIdInfo info = this._annotationIntrospector.findObjectIdInfo(this._classDef);
/*  382 */     if (info != null) {
/*  383 */       info = this._annotationIntrospector.findObjectReferenceInfo(this._classDef, info);
/*      */     }
/*  385 */     return info;
/*      */   }
/*      */ 
/*      */   
/*      */   protected Map<String, POJOPropertyBuilder> getPropertyMap() {
/*  390 */     if (!this._collected) {
/*  391 */       collectAll();
/*      */     }
/*  393 */     return this._properties;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public AnnotatedMethod getJsonValueMethod() {
/*  398 */     AnnotatedMember m = getJsonValueAccessor();
/*  399 */     if (m instanceof AnnotatedMethod) {
/*  400 */       return (AnnotatedMethod)m;
/*      */     }
/*  402 */     return null;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public Class<?> findPOJOBuilderClass() {
/*  407 */     return this._annotationIntrospector.findPOJOBuilder(this._classDef);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void collectAll() {
/*  423 */     LinkedHashMap<String, POJOPropertyBuilder> props = new LinkedHashMap<>();
/*      */ 
/*      */     
/*  426 */     _addFields(props);
/*  427 */     _addMethods(props);
/*      */ 
/*      */     
/*  430 */     if (!this._classDef.isNonStaticInnerClass()) {
/*  431 */       _addCreators(props);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  436 */     _removeUnwantedProperties(props);
/*      */     
/*  438 */     _removeUnwantedAccessor(props);
/*      */ 
/*      */     
/*  441 */     _renameProperties(props);
/*      */ 
/*      */ 
/*      */     
/*  445 */     _addInjectables(props);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  450 */     for (POJOPropertyBuilder property : props.values()) {
/*  451 */       property.mergeAnnotations(this._forSerialization);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  457 */     PropertyNamingStrategy naming = _findNamingStrategy();
/*  458 */     if (naming != null) {
/*  459 */       _renameUsing(props, naming);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  464 */     for (POJOPropertyBuilder property : props.values()) {
/*  465 */       property.trimByVisibility();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  470 */     if (this._config.isEnabled(MapperFeature.USE_WRAPPER_NAME_AS_PROPERTY_NAME)) {
/*  471 */       _renameWithWrappers(props);
/*      */     }
/*      */ 
/*      */     
/*  475 */     _sortProperties(props);
/*  476 */     this._properties = props;
/*  477 */     this._collected = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _addFields(Map<String, POJOPropertyBuilder> props) {
/*  491 */     AnnotationIntrospector ai = this._annotationIntrospector;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  496 */     boolean pruneFinalFields = (!this._forSerialization && !this._config.isEnabled(MapperFeature.ALLOW_FINAL_FIELDS_AS_MUTATORS));
/*  497 */     boolean transientAsIgnoral = this._config.isEnabled(MapperFeature.PROPAGATE_TRANSIENT_MARKER);
/*      */     
/*  499 */     for (AnnotatedField f : this._classDef.fields()) {
/*      */       PropertyName pn;
/*  501 */       if (Boolean.TRUE.equals(ai.hasAsKey(this._config, f))) {
/*  502 */         if (this._jsonKeyAccessors == null) {
/*  503 */           this._jsonKeyAccessors = new LinkedList<>();
/*      */         }
/*  505 */         this._jsonKeyAccessors.add(f);
/*      */       } 
/*      */       
/*  508 */       if (Boolean.TRUE.equals(ai.hasAsValue(f))) {
/*  509 */         if (this._jsonValueAccessors == null) {
/*  510 */           this._jsonValueAccessors = new LinkedList<>();
/*      */         }
/*  512 */         this._jsonValueAccessors.add(f);
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*  517 */       boolean anyGetter = Boolean.TRUE.equals(ai.hasAnyGetter(f));
/*  518 */       boolean anySetter = Boolean.TRUE.equals(ai.hasAnySetter(f));
/*  519 */       if (anyGetter || anySetter) {
/*      */         
/*  521 */         if (anyGetter) {
/*  522 */           if (this._anyGetterField == null) {
/*  523 */             this._anyGetterField = new LinkedList<>();
/*      */           }
/*  525 */           this._anyGetterField.add(f);
/*      */         } 
/*      */         
/*  528 */         if (anySetter) {
/*  529 */           if (this._anySetterField == null) {
/*  530 */             this._anySetterField = new LinkedList<>();
/*      */           }
/*  532 */           this._anySetterField.add(f);
/*      */         } 
/*      */         continue;
/*      */       } 
/*  536 */       String implName = ai.findImplicitPropertyName(f);
/*  537 */       if (implName == null) {
/*  538 */         implName = f.getName();
/*      */       }
/*      */ 
/*      */       
/*  542 */       implName = this._accessorNaming.modifyFieldName(f, implName);
/*  543 */       if (implName == null) {
/*      */         continue;
/*      */       }
/*      */       
/*  547 */       PropertyName implNameP = _propNameFromSimple(implName);
/*      */ 
/*      */ 
/*      */       
/*  551 */       PropertyName rename = ai.findRenameByField(this._config, f, implNameP);
/*  552 */       if (rename != null && !rename.equals(implNameP)) {
/*  553 */         if (this._fieldRenameMappings == null) {
/*  554 */           this._fieldRenameMappings = new HashMap<>();
/*      */         }
/*  556 */         this._fieldRenameMappings.put(rename, implNameP);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  561 */       if (this._forSerialization) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  566 */         pn = ai.findNameForSerialization(f);
/*      */       } else {
/*  568 */         pn = ai.findNameForDeserialization(f);
/*      */       } 
/*  570 */       boolean hasName = (pn != null);
/*  571 */       boolean nameExplicit = hasName;
/*      */       
/*  573 */       if (nameExplicit && pn.isEmpty()) {
/*  574 */         pn = _propNameFromSimple(implName);
/*  575 */         nameExplicit = false;
/*      */       } 
/*      */       
/*  578 */       boolean visible = (pn != null);
/*  579 */       if (!visible) {
/*  580 */         visible = this._visibilityChecker.isFieldVisible(f);
/*      */       }
/*      */       
/*  583 */       boolean ignored = ai.hasIgnoreMarker(f);
/*      */ 
/*      */       
/*  586 */       if (f.isTransient())
/*      */       {
/*      */         
/*  589 */         if (!hasName) {
/*  590 */           visible = false;
/*  591 */           if (transientAsIgnoral) {
/*  592 */             ignored = true;
/*      */           }
/*      */         } 
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  601 */       if (pruneFinalFields && pn == null && !ignored && 
/*  602 */         Modifier.isFinal(f.getModifiers())) {
/*      */         continue;
/*      */       }
/*  605 */       _property(props, implName).addField(f, pn, nameExplicit, visible, ignored);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _addCreators(Map<String, POJOPropertyBuilder> props) {
/*  615 */     if (!this._useAnnotations) {
/*      */       return;
/*      */     }
/*  618 */     for (AnnotatedConstructor ctor : this._classDef.getConstructors()) {
/*  619 */       if (this._creatorProperties == null) {
/*  620 */         this._creatorProperties = new LinkedList<>();
/*      */       }
/*  622 */       for (int i = 0, len = ctor.getParameterCount(); i < len; i++) {
/*  623 */         _addCreatorParam(props, ctor.getParameter(i));
/*      */       }
/*      */     } 
/*  626 */     for (AnnotatedMethod factory : this._classDef.getFactoryMethods()) {
/*  627 */       if (this._creatorProperties == null) {
/*  628 */         this._creatorProperties = new LinkedList<>();
/*      */       }
/*  630 */       for (int i = 0, len = factory.getParameterCount(); i < len; i++) {
/*  631 */         _addCreatorParam(props, factory.getParameter(i));
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _addCreatorParam(Map<String, POJOPropertyBuilder> props, AnnotatedParameter param) {
/*  643 */     String impl = this._annotationIntrospector.findImplicitPropertyName(param);
/*  644 */     if (impl == null) {
/*  645 */       impl = "";
/*      */     }
/*  647 */     PropertyName pn = this._annotationIntrospector.findNameForDeserialization(param);
/*  648 */     boolean expl = (pn != null && !pn.isEmpty());
/*  649 */     if (!expl) {
/*  650 */       if (impl.isEmpty()) {
/*      */         return;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  656 */       JsonCreator.Mode creatorMode = this._annotationIntrospector.findCreatorAnnotation(this._config, param
/*  657 */           .getOwner());
/*  658 */       if (creatorMode == null || creatorMode == JsonCreator.Mode.DISABLED) {
/*      */         return;
/*      */       }
/*  661 */       pn = PropertyName.construct(impl);
/*      */     } 
/*      */ 
/*      */     
/*  665 */     impl = _checkRenameByField(impl);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  675 */     POJOPropertyBuilder prop = (expl && impl.isEmpty()) ? _property(props, pn) : _property(props, impl);
/*  676 */     prop.addCtor(param, pn, expl, true, false);
/*  677 */     this._creatorProperties.add(prop);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _addMethods(Map<String, POJOPropertyBuilder> props) {
/*  685 */     for (AnnotatedMethod m : this._classDef.memberMethods()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  691 */       int argCount = m.getParameterCount();
/*  692 */       if (argCount == 0) {
/*  693 */         _addGetterMethod(props, m, this._annotationIntrospector); continue;
/*  694 */       }  if (argCount == 1) {
/*  695 */         _addSetterMethod(props, m, this._annotationIntrospector); continue;
/*  696 */       }  if (argCount == 2 && 
/*  697 */         Boolean.TRUE.equals(this._annotationIntrospector.hasAnySetter(m))) {
/*  698 */         if (this._anySetters == null) {
/*  699 */           this._anySetters = new LinkedList<>();
/*      */         }
/*  701 */         this._anySetters.add(m);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _addGetterMethod(Map<String, POJOPropertyBuilder> props, AnnotatedMethod m, AnnotationIntrospector ai) {
/*      */     boolean visible;
/*  713 */     Class<?> rt = m.getRawReturnType();
/*  714 */     if (rt == void.class || (rt == Void.class && 
/*  715 */       !this._config.isEnabled(MapperFeature.ALLOW_VOID_VALUED_PROPERTIES))) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  722 */     if (Boolean.TRUE.equals(ai.hasAnyGetter(m))) {
/*  723 */       if (this._anyGetters == null) {
/*  724 */         this._anyGetters = new LinkedList<>();
/*      */       }
/*  726 */       this._anyGetters.add(m);
/*      */       
/*      */       return;
/*      */     } 
/*  730 */     if (Boolean.TRUE.equals(ai.hasAsKey(this._config, m))) {
/*  731 */       if (this._jsonKeyAccessors == null) {
/*  732 */         this._jsonKeyAccessors = new LinkedList<>();
/*      */       }
/*  734 */       this._jsonKeyAccessors.add(m);
/*      */       
/*      */       return;
/*      */     } 
/*  738 */     if (Boolean.TRUE.equals(ai.hasAsValue(m))) {
/*  739 */       if (this._jsonValueAccessors == null) {
/*  740 */         this._jsonValueAccessors = new LinkedList<>();
/*      */       }
/*  742 */       this._jsonValueAccessors.add(m);
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*  748 */     PropertyName pn = ai.findNameForSerialization(m);
/*  749 */     boolean nameExplicit = (pn != null);
/*      */     
/*  751 */     if (!nameExplicit) {
/*  752 */       implName = ai.findImplicitPropertyName(m);
/*  753 */       if (implName == null) {
/*  754 */         implName = this._accessorNaming.findNameForRegularGetter(m, m.getName());
/*      */       }
/*  756 */       if (implName == null) {
/*  757 */         implName = this._accessorNaming.findNameForIsGetter(m, m.getName());
/*  758 */         if (implName == null) {
/*      */           return;
/*      */         }
/*  761 */         visible = this._visibilityChecker.isIsGetterVisible(m);
/*      */       } else {
/*  763 */         visible = this._visibilityChecker.isGetterVisible(m);
/*      */       } 
/*      */     } else {
/*      */       
/*  767 */       implName = ai.findImplicitPropertyName(m);
/*  768 */       if (implName == null) {
/*  769 */         implName = this._accessorNaming.findNameForRegularGetter(m, m.getName());
/*  770 */         if (implName == null) {
/*  771 */           implName = this._accessorNaming.findNameForIsGetter(m, m.getName());
/*      */         }
/*      */       } 
/*      */       
/*  775 */       if (implName == null) {
/*  776 */         implName = m.getName();
/*      */       }
/*  778 */       if (pn.isEmpty()) {
/*      */         
/*  780 */         pn = _propNameFromSimple(implName);
/*  781 */         nameExplicit = false;
/*      */       } 
/*  783 */       visible = true;
/*      */     } 
/*      */     
/*  786 */     String implName = _checkRenameByField(implName);
/*  787 */     boolean ignore = ai.hasIgnoreMarker(m);
/*  788 */     _property(props, implName).addGetter(m, pn, nameExplicit, visible, ignore);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _addSetterMethod(Map<String, POJOPropertyBuilder> props, AnnotatedMethod m, AnnotationIntrospector ai) {
/*      */     boolean visible;
/*  796 */     PropertyName pn = ai.findNameForDeserialization(m);
/*  797 */     boolean nameExplicit = (pn != null);
/*  798 */     if (!nameExplicit) {
/*  799 */       implName = ai.findImplicitPropertyName(m);
/*  800 */       if (implName == null) {
/*  801 */         implName = this._accessorNaming.findNameForMutator(m, m.getName());
/*      */       }
/*  803 */       if (implName == null) {
/*      */         return;
/*      */       }
/*  806 */       visible = this._visibilityChecker.isSetterVisible(m);
/*      */     } else {
/*      */       
/*  809 */       implName = ai.findImplicitPropertyName(m);
/*  810 */       if (implName == null) {
/*  811 */         implName = this._accessorNaming.findNameForMutator(m, m.getName());
/*      */       }
/*      */       
/*  814 */       if (implName == null) {
/*  815 */         implName = m.getName();
/*      */       }
/*  817 */       if (pn.isEmpty()) {
/*      */         
/*  819 */         pn = _propNameFromSimple(implName);
/*  820 */         nameExplicit = false;
/*      */       } 
/*  822 */       visible = true;
/*      */     } 
/*      */     
/*  825 */     String implName = _checkRenameByField(implName);
/*  826 */     boolean ignore = ai.hasIgnoreMarker(m);
/*  827 */     _property(props, implName)
/*  828 */       .addSetter(m, pn, nameExplicit, visible, ignore);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _addInjectables(Map<String, POJOPropertyBuilder> props) {
/*  834 */     for (AnnotatedField f : this._classDef.fields()) {
/*  835 */       _doAddInjectable(this._annotationIntrospector.findInjectableValue(f), f);
/*      */     }
/*      */     
/*  838 */     for (AnnotatedMethod m : this._classDef.memberMethods()) {
/*      */       
/*  840 */       if (m.getParameterCount() != 1) {
/*      */         continue;
/*      */       }
/*  843 */       _doAddInjectable(this._annotationIntrospector.findInjectableValue(m), m);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void _doAddInjectable(JacksonInject.Value injectable, AnnotatedMember m) {
/*  849 */     if (injectable == null) {
/*      */       return;
/*      */     }
/*  852 */     Object id = injectable.getId();
/*  853 */     if (this._injectables == null) {
/*  854 */       this._injectables = new LinkedHashMap<>();
/*      */     }
/*  856 */     AnnotatedMember prev = this._injectables.put(id, m);
/*  857 */     if (prev != null)
/*      */     {
/*  859 */       if (prev.getClass() == m.getClass()) {
/*  860 */         String type = id.getClass().getName();
/*  861 */         throw new IllegalArgumentException("Duplicate injectable value with id '" + id + "' (of type " + type + ")");
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private PropertyName _propNameFromSimple(String simpleName) {
/*  868 */     return PropertyName.construct(simpleName, null);
/*      */   }
/*      */ 
/*      */   
/*      */   private String _checkRenameByField(String implName) {
/*  873 */     if (this._fieldRenameMappings != null) {
/*  874 */       PropertyName p = this._fieldRenameMappings.get(_propNameFromSimple(implName));
/*  875 */       if (p != null) {
/*  876 */         implName = p.getSimpleName();
/*  877 */         return implName;
/*      */       } 
/*      */     } 
/*      */     
/*  881 */     return implName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _removeUnwantedProperties(Map<String, POJOPropertyBuilder> props) {
/*  896 */     Iterator<POJOPropertyBuilder> it = props.values().iterator();
/*  897 */     while (it.hasNext()) {
/*  898 */       POJOPropertyBuilder prop = it.next();
/*      */ 
/*      */       
/*  901 */       if (!prop.anyVisible()) {
/*  902 */         it.remove();
/*      */         
/*      */         continue;
/*      */       } 
/*  906 */       if (prop.anyIgnorals()) {
/*      */ 
/*      */ 
/*      */         
/*  910 */         if (!prop.anyExplicitsWithoutIgnoral()) {
/*  911 */           it.remove();
/*  912 */           _collectIgnorals(prop.getName());
/*      */           
/*      */           continue;
/*      */         } 
/*  916 */         prop.removeIgnored();
/*  917 */         if (!prop.couldDeserialize()) {
/*  918 */           _collectIgnorals(prop.getName());
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _removeUnwantedAccessor(Map<String, POJOPropertyBuilder> props) {
/*  931 */     boolean inferMutators = this._config.isEnabled(MapperFeature.INFER_PROPERTY_MUTATORS);
/*  932 */     Iterator<POJOPropertyBuilder> it = props.values().iterator();
/*      */     
/*  934 */     while (it.hasNext()) {
/*  935 */       POJOPropertyBuilder prop = it.next();
/*      */ 
/*      */ 
/*      */       
/*  939 */       prop.removeNonVisible(inferMutators, this._forSerialization ? null : this);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _collectIgnorals(String name) {
/*  950 */     if (!this._forSerialization && name != null) {
/*  951 */       if (this._ignoredPropertyNames == null) {
/*  952 */         this._ignoredPropertyNames = new HashSet<>();
/*      */       }
/*  954 */       this._ignoredPropertyNames.add(name);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _renameProperties(Map<String, POJOPropertyBuilder> props) {
/*  967 */     Iterator<Map.Entry<String, POJOPropertyBuilder>> it = props.entrySet().iterator();
/*  968 */     LinkedList<POJOPropertyBuilder> renamed = null;
/*  969 */     while (it.hasNext()) {
/*  970 */       Map.Entry<String, POJOPropertyBuilder> entry = it.next();
/*  971 */       POJOPropertyBuilder prop = entry.getValue();
/*      */       
/*  973 */       Collection<PropertyName> l = prop.findExplicitNames();
/*      */ 
/*      */       
/*  976 */       if (l.isEmpty()) {
/*      */         continue;
/*      */       }
/*  979 */       it.remove();
/*  980 */       if (renamed == null) {
/*  981 */         renamed = new LinkedList<>();
/*      */       }
/*      */       
/*  984 */       if (l.size() == 1) {
/*  985 */         PropertyName n = l.iterator().next();
/*  986 */         renamed.add(prop.withName(n));
/*      */         
/*      */         continue;
/*      */       } 
/*  990 */       renamed.addAll(prop.explode(l));
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1006 */     if (renamed != null) {
/* 1007 */       for (POJOPropertyBuilder prop : renamed) {
/* 1008 */         String name = prop.getName();
/* 1009 */         POJOPropertyBuilder old = props.get(name);
/* 1010 */         if (old == null) {
/* 1011 */           props.put(name, prop);
/*      */         } else {
/* 1013 */           old.addAll(prop);
/*      */         } 
/*      */         
/* 1016 */         if (_replaceCreatorProperty(prop, this._creatorProperties))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1027 */           if (this._ignoredPropertyNames != null) {
/* 1028 */             this._ignoredPropertyNames.remove(name);
/*      */           }
/*      */         }
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _renameUsing(Map<String, POJOPropertyBuilder> propMap, PropertyNamingStrategy naming) {
/* 1038 */     POJOPropertyBuilder[] props = (POJOPropertyBuilder[])propMap.values().toArray((Object[])new POJOPropertyBuilder[propMap.size()]);
/* 1039 */     propMap.clear();
/* 1040 */     for (POJOPropertyBuilder prop : props) {
/* 1041 */       String simpleName; PropertyName fullName = prop.getFullName();
/* 1042 */       String rename = null;
/*      */ 
/*      */       
/* 1045 */       if (!prop.isExplicitlyNamed() || this._config.isEnabled(MapperFeature.ALLOW_EXPLICIT_PROPERTY_RENAMING)) {
/* 1046 */         if (this._forSerialization) {
/* 1047 */           if (prop.hasGetter()) {
/* 1048 */             rename = naming.nameForGetterMethod(this._config, prop.getGetter(), fullName.getSimpleName());
/* 1049 */           } else if (prop.hasField()) {
/* 1050 */             rename = naming.nameForField(this._config, prop.getField(), fullName.getSimpleName());
/*      */           }
/*      */         
/* 1053 */         } else if (prop.hasSetter()) {
/* 1054 */           rename = naming.nameForSetterMethod(this._config, prop.getSetterUnchecked(), fullName.getSimpleName());
/* 1055 */         } else if (prop.hasConstructorParameter()) {
/* 1056 */           rename = naming.nameForConstructorParameter(this._config, prop.getConstructorParameter(), fullName.getSimpleName());
/* 1057 */         } else if (prop.hasField()) {
/* 1058 */           rename = naming.nameForField(this._config, prop.getFieldUnchecked(), fullName.getSimpleName());
/* 1059 */         } else if (prop.hasGetter()) {
/*      */ 
/*      */           
/* 1062 */           rename = naming.nameForGetterMethod(this._config, prop.getGetterUnchecked(), fullName.getSimpleName());
/*      */         } 
/*      */       }
/*      */ 
/*      */       
/* 1067 */       if (rename != null && !fullName.hasSimpleName(rename)) {
/* 1068 */         prop = prop.withSimpleName(rename);
/* 1069 */         simpleName = rename;
/*      */       } else {
/* 1071 */         simpleName = fullName.getSimpleName();
/*      */       } 
/*      */       
/* 1074 */       POJOPropertyBuilder old = propMap.get(simpleName);
/* 1075 */       if (old == null) {
/* 1076 */         propMap.put(simpleName, prop);
/*      */       } else {
/* 1078 */         old.addAll(prop);
/*      */       } 
/*      */ 
/*      */       
/* 1082 */       _replaceCreatorProperty(prop, this._creatorProperties);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _renameWithWrappers(Map<String, POJOPropertyBuilder> props) {
/* 1090 */     Iterator<Map.Entry<String, POJOPropertyBuilder>> it = props.entrySet().iterator();
/* 1091 */     LinkedList<POJOPropertyBuilder> renamed = null;
/* 1092 */     while (it.hasNext()) {
/* 1093 */       Map.Entry<String, POJOPropertyBuilder> entry = it.next();
/* 1094 */       POJOPropertyBuilder prop = entry.getValue();
/* 1095 */       AnnotatedMember member = prop.getPrimaryMember();
/* 1096 */       if (member == null) {
/*      */         continue;
/*      */       }
/* 1099 */       PropertyName wrapperName = this._annotationIntrospector.findWrapperName(member);
/*      */ 
/*      */ 
/*      */       
/* 1103 */       if (wrapperName == null || !wrapperName.hasSimpleName()) {
/*      */         continue;
/*      */       }
/* 1106 */       if (!wrapperName.equals(prop.getFullName())) {
/* 1107 */         if (renamed == null) {
/* 1108 */           renamed = new LinkedList<>();
/*      */         }
/* 1110 */         prop = prop.withName(wrapperName);
/* 1111 */         renamed.add(prop);
/* 1112 */         it.remove();
/*      */       } 
/*      */     } 
/*      */     
/* 1116 */     if (renamed != null) {
/* 1117 */       for (POJOPropertyBuilder prop : renamed) {
/* 1118 */         String name = prop.getName();
/* 1119 */         POJOPropertyBuilder old = props.get(name);
/* 1120 */         if (old == null) {
/* 1121 */           props.put(name, prop); continue;
/*      */         } 
/* 1123 */         old.addAll(prop);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _sortProperties(Map<String, POJOPropertyBuilder> props) {
/*      */     Map<String, POJOPropertyBuilder> all;
/* 1142 */     AnnotationIntrospector intr = this._annotationIntrospector;
/* 1143 */     Boolean alpha = intr.findSerializationSortAlphabetically(this._classDef);
/*      */ 
/*      */     
/* 1146 */     boolean sortAlpha = (alpha == null) ? this._config.shouldSortPropertiesAlphabetically() : alpha.booleanValue();
/* 1147 */     boolean indexed = _anyIndexed(props.values());
/*      */     
/* 1149 */     String[] propertyOrder = intr.findSerializationPropertyOrder(this._classDef);
/*      */ 
/*      */     
/* 1152 */     if (!sortAlpha && !indexed && this._creatorProperties == null && propertyOrder == null) {
/*      */       return;
/*      */     }
/* 1155 */     int size = props.size();
/*      */ 
/*      */     
/* 1158 */     if (sortAlpha) {
/* 1159 */       all = new TreeMap<>();
/*      */     } else {
/* 1161 */       all = new LinkedHashMap<>(size + size);
/*      */     } 
/*      */     
/* 1164 */     for (POJOPropertyBuilder prop : props.values()) {
/* 1165 */       all.put(prop.getName(), prop);
/*      */     }
/* 1167 */     Map<String, POJOPropertyBuilder> ordered = new LinkedHashMap<>(size + size);
/*      */     
/* 1169 */     if (propertyOrder != null) {
/* 1170 */       for (String name : propertyOrder) {
/* 1171 */         POJOPropertyBuilder w = all.remove(name);
/* 1172 */         if (w == null) {
/* 1173 */           for (POJOPropertyBuilder prop : props.values()) {
/* 1174 */             if (name.equals(prop.getInternalName())) {
/* 1175 */               w = prop;
/*      */               
/* 1177 */               name = prop.getName();
/*      */               break;
/*      */             } 
/*      */           } 
/*      */         }
/* 1182 */         if (w != null) {
/* 1183 */           ordered.put(name, w);
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 1189 */     if (indexed) {
/* 1190 */       Map<Integer, POJOPropertyBuilder> byIndex = new TreeMap<>();
/* 1191 */       Iterator<Map.Entry<String, POJOPropertyBuilder>> it = all.entrySet().iterator();
/* 1192 */       while (it.hasNext()) {
/* 1193 */         Map.Entry<String, POJOPropertyBuilder> entry = it.next();
/* 1194 */         POJOPropertyBuilder prop = entry.getValue();
/* 1195 */         Integer index = prop.getMetadata().getIndex();
/* 1196 */         if (index != null) {
/* 1197 */           byIndex.put(index, prop);
/* 1198 */           it.remove();
/*      */         } 
/*      */       } 
/* 1201 */       for (POJOPropertyBuilder prop : byIndex.values()) {
/* 1202 */         ordered.put(prop.getName(), prop);
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1208 */     if (this._creatorProperties != null && (!sortAlpha || this._config
/* 1209 */       .isEnabled(MapperFeature.SORT_CREATOR_PROPERTIES_FIRST))) {
/*      */       Collection<POJOPropertyBuilder> cr;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1216 */       if (sortAlpha) {
/* 1217 */         TreeMap<String, POJOPropertyBuilder> sorted = new TreeMap<>();
/*      */         
/* 1219 */         for (POJOPropertyBuilder prop : this._creatorProperties) {
/* 1220 */           sorted.put(prop.getName(), prop);
/*      */         }
/* 1222 */         cr = sorted.values();
/*      */       } else {
/* 1224 */         cr = this._creatorProperties;
/*      */       } 
/* 1226 */       for (POJOPropertyBuilder prop : cr) {
/*      */ 
/*      */         
/* 1229 */         String name = prop.getName();
/*      */ 
/*      */         
/* 1232 */         if (all.containsKey(name)) {
/* 1233 */           ordered.put(name, prop);
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 1238 */     ordered.putAll(all);
/* 1239 */     props.clear();
/* 1240 */     props.putAll(ordered);
/*      */   }
/*      */   
/*      */   private boolean _anyIndexed(Collection<POJOPropertyBuilder> props) {
/* 1244 */     for (POJOPropertyBuilder prop : props) {
/* 1245 */       if (prop.getMetadata().hasIndex()) {
/* 1246 */         return true;
/*      */       }
/*      */     } 
/* 1249 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _resolveFieldVsGetter(List<AnnotatedMember> accessors) {
/*      */     while (true) {
/* 1272 */       AnnotatedMember acc1 = accessors.get(0);
/* 1273 */       AnnotatedMember acc2 = accessors.get(1);
/*      */       
/* 1275 */       if (acc1 instanceof AnnotatedField)
/* 1276 */       { if (acc2 instanceof AnnotatedMethod)
/*      */         
/* 1278 */         { accessors.remove(0);
/*      */ 
/*      */ 
/*      */           
/*      */            }
/*      */         
/*      */         else
/*      */         
/*      */         { 
/*      */ 
/*      */           
/* 1289 */           return false; }  } else if (acc1 instanceof AnnotatedMethod) { if (acc2 instanceof AnnotatedField) { accessors.remove(1); } else { return false; }  } else { return false; }
/* 1290 */        if (accessors.size() <= 1) {
/* 1291 */         return true;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void reportProblem(String msg, Object... args) {
/* 1301 */     if (args.length > 0) {
/* 1302 */       msg = String.format(msg, args);
/*      */     }
/* 1304 */     throw new IllegalArgumentException("Problem with definition of " + this._classDef + ": " + msg);
/*      */   }
/*      */ 
/*      */   
/*      */   protected POJOPropertyBuilder _property(Map<String, POJOPropertyBuilder> props, PropertyName name) {
/* 1309 */     String simpleName = name.getSimpleName();
/* 1310 */     POJOPropertyBuilder prop = props.get(simpleName);
/* 1311 */     if (prop == null) {
/* 1312 */       prop = new POJOPropertyBuilder(this._config, this._annotationIntrospector, this._forSerialization, name);
/*      */       
/* 1314 */       props.put(simpleName, prop);
/*      */     } 
/* 1316 */     return prop;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected POJOPropertyBuilder _property(Map<String, POJOPropertyBuilder> props, String implName) {
/* 1323 */     POJOPropertyBuilder prop = props.get(implName);
/* 1324 */     if (prop == null) {
/*      */       
/* 1326 */       prop = new POJOPropertyBuilder(this._config, this._annotationIntrospector, this._forSerialization, PropertyName.construct(implName));
/* 1327 */       props.put(implName, prop);
/*      */     } 
/* 1329 */     return prop;
/*      */   }
/*      */ 
/*      */   
/*      */   private PropertyNamingStrategy _findNamingStrategy() {
/* 1334 */     Object namingDef = this._annotationIntrospector.findNamingStrategy(this._classDef);
/* 1335 */     if (namingDef == null) {
/* 1336 */       return this._config.getPropertyNamingStrategy();
/*      */     }
/* 1338 */     if (namingDef instanceof PropertyNamingStrategy) {
/* 1339 */       return (PropertyNamingStrategy)namingDef;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1344 */     if (!(namingDef instanceof Class)) {
/* 1345 */       throw new IllegalStateException("AnnotationIntrospector returned PropertyNamingStrategy definition of type " + namingDef
/* 1346 */           .getClass().getName() + "; expected type PropertyNamingStrategy or Class<PropertyNamingStrategy> instead");
/*      */     }
/* 1348 */     Class<?> namingClass = (Class)namingDef;
/*      */     
/* 1350 */     if (namingClass == PropertyNamingStrategy.class) {
/* 1351 */       return null;
/*      */     }
/*      */     
/* 1354 */     if (!PropertyNamingStrategy.class.isAssignableFrom(namingClass)) {
/* 1355 */       throw new IllegalStateException("AnnotationIntrospector returned Class " + namingClass
/* 1356 */           .getName() + "; expected Class<PropertyNamingStrategy>");
/*      */     }
/* 1358 */     HandlerInstantiator hi = this._config.getHandlerInstantiator();
/* 1359 */     if (hi != null) {
/* 1360 */       PropertyNamingStrategy pns = hi.namingStrategyInstance(this._config, this._classDef, namingClass);
/* 1361 */       if (pns != null) {
/* 1362 */         return pns;
/*      */       }
/*      */     } 
/* 1365 */     return (PropertyNamingStrategy)ClassUtil.createInstance(namingClass, this._config
/* 1366 */         .canOverrideAccessModifiers());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   protected void _updateCreatorProperty(POJOPropertyBuilder prop, List<POJOPropertyBuilder> creatorProperties) {
/* 1371 */     _replaceCreatorProperty(prop, creatorProperties);
/*      */   }
/*      */   
/*      */   protected boolean _replaceCreatorProperty(POJOPropertyBuilder prop, List<POJOPropertyBuilder> creatorProperties) {
/* 1375 */     if (creatorProperties != null) {
/* 1376 */       String intName = prop.getInternalName();
/* 1377 */       for (int i = 0, len = creatorProperties.size(); i < len; i++) {
/* 1378 */         if (((POJOPropertyBuilder)creatorProperties.get(i)).getInternalName().equals(intName)) {
/* 1379 */           creatorProperties.set(i, prop);
/* 1380 */           return true;
/*      */         } 
/*      */       } 
/*      */     } 
/* 1384 */     return false;
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\introspect\POJOPropertiesCollector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */