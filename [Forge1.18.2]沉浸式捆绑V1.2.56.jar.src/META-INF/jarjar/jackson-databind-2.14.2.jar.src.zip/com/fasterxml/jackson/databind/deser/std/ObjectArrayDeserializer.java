/*     */ package com.fasterxml.jackson.databind.deser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.core.JacksonException;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.annotation.JacksonStdImpl;
/*     */ import com.fasterxml.jackson.databind.cfg.CoercionAction;
/*     */ import com.fasterxml.jackson.databind.cfg.CoercionInputShape;
/*     */ import com.fasterxml.jackson.databind.deser.ContextualDeserializer;
/*     */ import com.fasterxml.jackson.databind.deser.NullValueProvider;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*     */ import com.fasterxml.jackson.databind.type.ArrayType;
/*     */ import com.fasterxml.jackson.databind.type.LogicalType;
/*     */ import com.fasterxml.jackson.databind.util.AccessPattern;
/*     */ import com.fasterxml.jackson.databind.util.ObjectBuffer;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @JacksonStdImpl
/*     */ public class ObjectArrayDeserializer
/*     */   extends ContainerDeserializerBase<Object[]>
/*     */   implements ContextualDeserializer
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final boolean _untyped;
/*     */   protected final Class<?> _elementClass;
/*     */   protected JsonDeserializer<Object> _elementDeserializer;
/*     */   protected final TypeDeserializer _elementTypeDeserializer;
/*     */   protected final Object[] _emptyValue;
/*     */   
/*     */   public ObjectArrayDeserializer(JavaType arrayType0, JsonDeserializer<Object> elemDeser, TypeDeserializer elemTypeDeser) {
/*  72 */     super(arrayType0, (NullValueProvider)null, (Boolean)null);
/*  73 */     ArrayType arrayType = (ArrayType)arrayType0;
/*  74 */     this._elementClass = arrayType.getContentType().getRawClass();
/*  75 */     this._untyped = (this._elementClass == Object.class);
/*  76 */     this._elementDeserializer = elemDeser;
/*  77 */     this._elementTypeDeserializer = elemTypeDeser;
/*  78 */     this._emptyValue = arrayType.getEmptyArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ObjectArrayDeserializer(ObjectArrayDeserializer base, JsonDeserializer<Object> elemDeser, TypeDeserializer elemTypeDeser, NullValueProvider nuller, Boolean unwrapSingle) {
/*  85 */     super(base, nuller, unwrapSingle);
/*  86 */     this._elementClass = base._elementClass;
/*  87 */     this._untyped = base._untyped;
/*  88 */     this._emptyValue = base._emptyValue;
/*     */     
/*  90 */     this._elementDeserializer = elemDeser;
/*  91 */     this._elementTypeDeserializer = elemTypeDeser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectArrayDeserializer withDeserializer(TypeDeserializer elemTypeDeser, JsonDeserializer<?> elemDeser) {
/* 100 */     return withResolved(elemTypeDeser, elemDeser, this._nullProvider, this._unwrapSingle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectArrayDeserializer withResolved(TypeDeserializer elemTypeDeser, JsonDeserializer<?> elemDeser, NullValueProvider nuller, Boolean unwrapSingle) {
/* 111 */     if (Objects.equals(unwrapSingle, this._unwrapSingle) && nuller == this._nullProvider && elemDeser == this._elementDeserializer && elemTypeDeser == this._elementTypeDeserializer)
/*     */     {
/*     */       
/* 114 */       return this;
/*     */     }
/* 116 */     return new ObjectArrayDeserializer(this, (JsonDeserializer)elemDeser, elemTypeDeser, nuller, unwrapSingle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCachable() {
/* 125 */     return (this._elementDeserializer == null && this._elementTypeDeserializer == null);
/*     */   }
/*     */ 
/*     */   
/*     */   public LogicalType logicalType() {
/* 130 */     return LogicalType.Array;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonDeserializer<?> createContextual(DeserializationContext ctxt, BeanProperty property) throws JsonMappingException {
/* 137 */     JsonDeserializer<?> valueDeser = this._elementDeserializer;
/*     */ 
/*     */ 
/*     */     
/* 141 */     Boolean unwrapSingle = findFormatFeature(ctxt, property, this._containerType.getRawClass(), JsonFormat.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY);
/*     */ 
/*     */     
/* 144 */     valueDeser = findConvertingContentDeserializer(ctxt, property, valueDeser);
/* 145 */     JavaType vt = this._containerType.getContentType();
/* 146 */     if (valueDeser == null) {
/* 147 */       valueDeser = ctxt.findContextualValueDeserializer(vt, property);
/*     */     } else {
/* 149 */       valueDeser = ctxt.handleSecondaryContextualization(valueDeser, property, vt);
/*     */     } 
/* 151 */     TypeDeserializer elemTypeDeser = this._elementTypeDeserializer;
/* 152 */     if (elemTypeDeser != null) {
/* 153 */       elemTypeDeser = elemTypeDeser.forProperty(property);
/*     */     }
/* 155 */     NullValueProvider nuller = findContentNullProvider(ctxt, property, valueDeser);
/* 156 */     return withResolved(elemTypeDeser, valueDeser, nuller, unwrapSingle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonDeserializer<Object> getContentDeserializer() {
/* 167 */     return this._elementDeserializer;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public AccessPattern getEmptyAccessPattern() {
/* 173 */     return AccessPattern.CONSTANT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getEmptyValue(DeserializationContext ctxt) throws JsonMappingException {
/* 181 */     return this._emptyValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/*     */     Object[] result;
/* 195 */     if (!p.isExpectedStartArrayToken()) {
/* 196 */       return handleNonArray(p, ctxt);
/*     */     }
/*     */     
/* 199 */     ObjectBuffer buffer = ctxt.leaseObjectBuffer();
/* 200 */     Object[] chunk = buffer.resetAndStart();
/* 201 */     int ix = 0;
/*     */     
/* 203 */     TypeDeserializer typeDeser = this._elementTypeDeserializer;
/*     */     try {
/*     */       JsonToken t;
/* 206 */       while ((t = p.nextToken()) != JsonToken.END_ARRAY) {
/*     */         Object value;
/*     */ 
/*     */         
/* 210 */         if (t == JsonToken.VALUE_NULL) {
/* 211 */           if (this._skipNullValues) {
/*     */             continue;
/*     */           }
/* 214 */           value = this._nullProvider.getNullValue(ctxt);
/* 215 */         } else if (typeDeser == null) {
/* 216 */           value = this._elementDeserializer.deserialize(p, ctxt);
/*     */         } else {
/* 218 */           value = this._elementDeserializer.deserializeWithType(p, ctxt, typeDeser);
/*     */         } 
/* 220 */         if (ix >= chunk.length) {
/* 221 */           chunk = buffer.appendCompletedChunk(chunk);
/* 222 */           ix = 0;
/*     */         } 
/* 224 */         chunk[ix++] = value;
/*     */       } 
/* 226 */     } catch (Exception e) {
/* 227 */       throw JsonMappingException.wrapWithPath(e, chunk, buffer.bufferedSize() + ix);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 232 */     if (this._untyped) {
/* 233 */       result = buffer.completeAndClearBuffer(chunk, ix);
/*     */     } else {
/* 235 */       result = buffer.completeAndClearBuffer(chunk, ix, this._elementClass);
/*     */     } 
/* 237 */     ctxt.returnObjectBuffer(buffer);
/* 238 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] deserializeWithType(JsonParser p, DeserializationContext ctxt, TypeDeserializer typeDeserializer) throws IOException {
/* 248 */     return (Object[])typeDeserializer.deserializeTypedFromArray(p, ctxt);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] deserialize(JsonParser p, DeserializationContext ctxt, Object[] intoValue) throws IOException {
/*     */     Object[] result;
/* 255 */     if (!p.isExpectedStartArrayToken()) {
/* 256 */       Object[] arr = handleNonArray(p, ctxt);
/* 257 */       if (arr == null) {
/* 258 */         return intoValue;
/*     */       }
/* 260 */       int offset = intoValue.length;
/* 261 */       Object[] arrayOfObject1 = new Object[offset + arr.length];
/* 262 */       System.arraycopy(intoValue, 0, arrayOfObject1, 0, offset);
/* 263 */       System.arraycopy(arr, 0, arrayOfObject1, offset, arr.length);
/* 264 */       return arrayOfObject1;
/*     */     } 
/*     */     
/* 267 */     ObjectBuffer buffer = ctxt.leaseObjectBuffer();
/* 268 */     int ix = intoValue.length;
/* 269 */     Object[] chunk = buffer.resetAndStart(intoValue, ix);
/*     */     
/* 271 */     TypeDeserializer typeDeser = this._elementTypeDeserializer;
/*     */     try {
/*     */       JsonToken t;
/* 274 */       while ((t = p.nextToken()) != JsonToken.END_ARRAY) {
/*     */         Object value;
/*     */         
/* 277 */         if (t == JsonToken.VALUE_NULL) {
/* 278 */           if (this._skipNullValues) {
/*     */             continue;
/*     */           }
/* 281 */           value = this._nullProvider.getNullValue(ctxt);
/* 282 */         } else if (typeDeser == null) {
/* 283 */           value = this._elementDeserializer.deserialize(p, ctxt);
/*     */         } else {
/* 285 */           value = this._elementDeserializer.deserializeWithType(p, ctxt, typeDeser);
/*     */         } 
/* 287 */         if (ix >= chunk.length) {
/* 288 */           chunk = buffer.appendCompletedChunk(chunk);
/* 289 */           ix = 0;
/*     */         } 
/* 291 */         chunk[ix++] = value;
/*     */       } 
/* 293 */     } catch (Exception e) {
/* 294 */       throw JsonMappingException.wrapWithPath(e, chunk, buffer.bufferedSize() + ix);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 299 */     if (this._untyped) {
/* 300 */       result = buffer.completeAndClearBuffer(chunk, ix);
/*     */     } else {
/* 302 */       result = buffer.completeAndClearBuffer(chunk, ix, this._elementClass);
/*     */     } 
/* 304 */     ctxt.returnObjectBuffer(buffer);
/* 305 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Byte[] deserializeFromBase64(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 318 */     byte[] b = p.getBinaryValue(ctxt.getBase64Variant());
/*     */     
/* 320 */     Byte[] result = new Byte[b.length];
/* 321 */     for (int i = 0, len = b.length; i < len; i++) {
/* 322 */       result[i] = Byte.valueOf(b[i]);
/*     */     }
/* 324 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object[] handleNonArray(JsonParser p, DeserializationContext ctxt) throws IOException {
/*     */     Object value, result[];
/* 333 */     boolean canWrap = (this._unwrapSingle == Boolean.TRUE || (this._unwrapSingle == null && ctxt.isEnabled(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY)));
/* 334 */     if (!canWrap) {
/*     */       
/* 336 */       if (p.hasToken(JsonToken.VALUE_STRING)) {
/*     */ 
/*     */         
/* 339 */         if (this._elementClass == Byte.class) {
/* 340 */           return (Object[])deserializeFromBase64(p, ctxt);
/*     */         }
/*     */         
/* 343 */         return _deserializeFromString(p, ctxt);
/*     */       } 
/* 345 */       return (Object[])ctxt.handleUnexpectedToken(this._containerType, p);
/*     */     } 
/*     */ 
/*     */     
/* 349 */     if (p.hasToken(JsonToken.VALUE_NULL)) {
/*     */       
/* 351 */       if (this._skipNullValues) {
/* 352 */         return this._emptyValue;
/*     */       }
/* 354 */       value = this._nullProvider.getNullValue(ctxt);
/*     */     } else {
/* 356 */       if (p.hasToken(JsonToken.VALUE_STRING)) {
/* 357 */         String textValue = p.getText();
/*     */         
/* 359 */         if (textValue.isEmpty()) {
/* 360 */           CoercionAction act = ctxt.findCoercionAction(logicalType(), handledType(), CoercionInputShape.EmptyString);
/*     */           
/* 362 */           if (act != CoercionAction.Fail) {
/* 363 */             return (Object[])_deserializeFromEmptyString(p, ctxt, act, handledType(), "empty String (\"\")");
/*     */           }
/*     */         }
/* 366 */         else if (_isBlank(textValue)) {
/* 367 */           CoercionAction act = ctxt.findCoercionFromBlankString(logicalType(), handledType(), CoercionAction.Fail);
/*     */           
/* 369 */           if (act != CoercionAction.Fail) {
/* 370 */             return (Object[])_deserializeFromEmptyString(p, ctxt, act, handledType(), "blank String (all whitespace)");
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 377 */       if (this._elementTypeDeserializer == null) {
/* 378 */         value = this._elementDeserializer.deserialize(p, ctxt);
/*     */       } else {
/* 380 */         value = this._elementDeserializer.deserializeWithType(p, ctxt, this._elementTypeDeserializer);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 386 */     if (this._untyped) {
/* 387 */       result = new Object[1];
/*     */     } else {
/* 389 */       result = (Object[])Array.newInstance(this._elementClass, 1);
/*     */     } 
/* 391 */     result[0] = value;
/* 392 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\deser\std\ObjectArrayDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */