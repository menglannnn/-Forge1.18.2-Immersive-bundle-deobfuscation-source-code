/*     */ package com.fasterxml.jackson.databind.ser.impl;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.ser.BeanPropertyFilter;
/*     */ import com.fasterxml.jackson.databind.ser.FilterProvider;
/*     */ import com.fasterxml.jackson.databind.ser.PropertyFilter;
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleFilterProvider
/*     */   extends FilterProvider
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final Map<String, PropertyFilter> _filtersById;
/*     */   protected PropertyFilter _defaultFilter;
/*     */   protected boolean _cfgFailOnUnknownId = true;
/*     */   
/*     */   public SimpleFilterProvider() {
/*  50 */     this(new HashMap<>());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleFilterProvider(Map<String, ?> mapping) {
/*  63 */     for (Object ob : mapping.values()) {
/*  64 */       if (!(ob instanceof PropertyFilter)) {
/*  65 */         this._filtersById = _convert(mapping);
/*     */         return;
/*     */       } 
/*     */     } 
/*  69 */     this._filtersById = (Map)mapping;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final Map<String, PropertyFilter> _convert(Map<String, ?> filters) {
/*  75 */     HashMap<String, PropertyFilter> result = new HashMap<>();
/*  76 */     for (Map.Entry<String, ?> entry : filters.entrySet()) {
/*  77 */       Object f = entry.getValue();
/*  78 */       if (f instanceof PropertyFilter) {
/*  79 */         result.put(entry.getKey(), (PropertyFilter)f); continue;
/*  80 */       }  if (f instanceof BeanPropertyFilter) {
/*  81 */         result.put(entry.getKey(), _convert((BeanPropertyFilter)f)); continue;
/*     */       } 
/*  83 */       throw new IllegalArgumentException("Unrecognized filter type (" + f.getClass().getName() + ")");
/*     */     } 
/*     */     
/*  86 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private static final PropertyFilter _convert(BeanPropertyFilter f) {
/*  91 */     return SimpleBeanPropertyFilter.from(f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public SimpleFilterProvider setDefaultFilter(BeanPropertyFilter f) {
/* 105 */     this._defaultFilter = SimpleBeanPropertyFilter.from(f);
/* 106 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleFilterProvider setDefaultFilter(PropertyFilter f) {
/* 119 */     this._defaultFilter = f;
/* 120 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleFilterProvider setDefaultFilter(SimpleBeanPropertyFilter f) {
/* 128 */     this._defaultFilter = f;
/* 129 */     return this;
/*     */   }
/*     */   
/*     */   public PropertyFilter getDefaultFilter() {
/* 133 */     return this._defaultFilter;
/*     */   }
/*     */   
/*     */   public SimpleFilterProvider setFailOnUnknownId(boolean state) {
/* 137 */     this._cfgFailOnUnknownId = state;
/* 138 */     return this;
/*     */   }
/*     */   
/*     */   public boolean willFailOnUnknownId() {
/* 142 */     return this._cfgFailOnUnknownId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public SimpleFilterProvider addFilter(String id, BeanPropertyFilter filter) {
/* 150 */     this._filtersById.put(id, _convert(filter));
/* 151 */     return this;
/*     */   }
/*     */   
/*     */   public SimpleFilterProvider addFilter(String id, PropertyFilter filter) {
/* 155 */     this._filtersById.put(id, filter);
/* 156 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleFilterProvider addFilter(String id, SimpleBeanPropertyFilter filter) {
/* 163 */     this._filtersById.put(id, filter);
/* 164 */     return this;
/*     */   }
/*     */   
/*     */   public PropertyFilter removeFilter(String id) {
/* 168 */     return this._filtersById.remove(id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public BeanPropertyFilter findFilter(Object filterId) {
/* 181 */     throw new UnsupportedOperationException("Access to deprecated filters not supported");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertyFilter findPropertyFilter(Object filterId, Object valueToFilter) {
/* 187 */     PropertyFilter f = this._filtersById.get(filterId);
/* 188 */     if (f == null) {
/* 189 */       f = this._defaultFilter;
/* 190 */       if (f == null && this._cfgFailOnUnknownId) {
/* 191 */         throw new IllegalArgumentException("No filter configured with id '" + filterId + "' (type " + filterId
/* 192 */             .getClass().getName() + ")");
/*     */       }
/*     */     } 
/* 195 */     return f;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\ser\impl\SimpleFilterProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */