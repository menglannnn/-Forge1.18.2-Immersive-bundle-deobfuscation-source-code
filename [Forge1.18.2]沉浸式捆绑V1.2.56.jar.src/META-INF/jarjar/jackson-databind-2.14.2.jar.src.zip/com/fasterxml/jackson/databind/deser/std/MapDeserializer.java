/*     */ package com.fasterxml.jackson.databind.deser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
/*     */ import com.fasterxml.jackson.annotation.JsonIncludeProperties;
/*     */ import com.fasterxml.jackson.core.JacksonException;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.StreamReadCapability;
/*     */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.KeyDeserializer;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.annotation.JacksonStdImpl;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import com.fasterxml.jackson.databind.deser.ContextualDeserializer;
/*     */ import com.fasterxml.jackson.databind.deser.ContextualKeyDeserializer;
/*     */ import com.fasterxml.jackson.databind.deser.NullValueProvider;
/*     */ import com.fasterxml.jackson.databind.deser.ResolvableDeserializer;
/*     */ import com.fasterxml.jackson.databind.deser.SettableBeanProperty;
/*     */ import com.fasterxml.jackson.databind.deser.UnresolvedForwardReference;
/*     */ import com.fasterxml.jackson.databind.deser.ValueInstantiator;
/*     */ import com.fasterxml.jackson.databind.deser.impl.PropertyBasedCreator;
/*     */ import com.fasterxml.jackson.databind.deser.impl.PropertyValueBuffer;
/*     */ import com.fasterxml.jackson.databind.deser.impl.ReadableObjectId;
/*     */ import com.fasterxml.jackson.databind.introspect.Annotated;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*     */ import com.fasterxml.jackson.databind.type.LogicalType;
/*     */ import com.fasterxml.jackson.databind.util.ArrayBuilders;
/*     */ import com.fasterxml.jackson.databind.util.IgnorePropertiesUtil;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @JacksonStdImpl
/*     */ public class MapDeserializer
/*     */   extends ContainerDeserializerBase<Map<Object, Object>>
/*     */   implements ContextualDeserializer, ResolvableDeserializer
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final KeyDeserializer _keyDeserializer;
/*     */   protected boolean _standardStringKey;
/*     */   protected final JsonDeserializer<Object> _valueDeserializer;
/*     */   protected final TypeDeserializer _valueTypeDeserializer;
/*     */   protected final ValueInstantiator _valueInstantiator;
/*     */   protected JsonDeserializer<Object> _delegateDeserializer;
/*     */   protected PropertyBasedCreator _propertyBasedCreator;
/*     */   protected final boolean _hasDefaultCreator;
/*     */   protected Set<String> _ignorableProperties;
/*     */   protected Set<String> _includableProperties;
/*     */   protected IgnorePropertiesUtil.Checker _inclusionChecker;
/*     */   protected boolean _checkDupSquash;
/*     */   
/*     */   public MapDeserializer(JavaType mapType, ValueInstantiator valueInstantiator, KeyDeserializer keyDeser, JsonDeserializer<Object> valueDeser, TypeDeserializer valueTypeDeser) {
/* 123 */     super(mapType, (NullValueProvider)null, (Boolean)null);
/* 124 */     this._keyDeserializer = keyDeser;
/* 125 */     this._valueDeserializer = valueDeser;
/* 126 */     this._valueTypeDeserializer = valueTypeDeser;
/* 127 */     this._valueInstantiator = valueInstantiator;
/* 128 */     this._hasDefaultCreator = valueInstantiator.canCreateUsingDefault();
/* 129 */     this._delegateDeserializer = null;
/* 130 */     this._propertyBasedCreator = null;
/* 131 */     this._standardStringKey = _isStdKeyDeser(mapType, keyDeser);
/* 132 */     this._inclusionChecker = null;
/* 133 */     this._checkDupSquash = mapType.getContentType().hasRawClass(Object.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MapDeserializer(MapDeserializer src) {
/* 142 */     super(src);
/* 143 */     this._keyDeserializer = src._keyDeserializer;
/* 144 */     this._valueDeserializer = src._valueDeserializer;
/* 145 */     this._valueTypeDeserializer = src._valueTypeDeserializer;
/* 146 */     this._valueInstantiator = src._valueInstantiator;
/* 147 */     this._propertyBasedCreator = src._propertyBasedCreator;
/* 148 */     this._delegateDeserializer = src._delegateDeserializer;
/* 149 */     this._hasDefaultCreator = src._hasDefaultCreator;
/*     */     
/* 151 */     this._ignorableProperties = src._ignorableProperties;
/* 152 */     this._includableProperties = src._includableProperties;
/* 153 */     this._inclusionChecker = src._inclusionChecker;
/*     */     
/* 155 */     this._standardStringKey = src._standardStringKey;
/* 156 */     this._checkDupSquash = src._checkDupSquash;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MapDeserializer(MapDeserializer src, KeyDeserializer keyDeser, JsonDeserializer<Object> valueDeser, TypeDeserializer valueTypeDeser, NullValueProvider nuller, Set<String> ignorable) {
/* 165 */     this(src, keyDeser, valueDeser, valueTypeDeser, nuller, ignorable, (Set<String>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MapDeserializer(MapDeserializer src, KeyDeserializer keyDeser, JsonDeserializer<Object> valueDeser, TypeDeserializer valueTypeDeser, NullValueProvider nuller, Set<String> ignorable, Set<String> includable) {
/* 178 */     super(src, nuller, src._unwrapSingle);
/* 179 */     this._keyDeserializer = keyDeser;
/* 180 */     this._valueDeserializer = valueDeser;
/* 181 */     this._valueTypeDeserializer = valueTypeDeser;
/* 182 */     this._valueInstantiator = src._valueInstantiator;
/* 183 */     this._propertyBasedCreator = src._propertyBasedCreator;
/* 184 */     this._delegateDeserializer = src._delegateDeserializer;
/* 185 */     this._hasDefaultCreator = src._hasDefaultCreator;
/* 186 */     this._ignorableProperties = ignorable;
/* 187 */     this._includableProperties = includable;
/* 188 */     this._inclusionChecker = IgnorePropertiesUtil.buildCheckerIfNeeded(ignorable, includable);
/*     */     
/* 190 */     this._standardStringKey = _isStdKeyDeser(this._containerType, keyDeser);
/* 191 */     this._checkDupSquash = src._checkDupSquash;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MapDeserializer withResolved(KeyDeserializer keyDeser, TypeDeserializer valueTypeDeser, JsonDeserializer<?> valueDeser, NullValueProvider nuller, Set<String> ignorable) {
/* 203 */     return withResolved(keyDeser, valueTypeDeser, valueDeser, nuller, ignorable, this._includableProperties);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MapDeserializer withResolved(KeyDeserializer keyDeser, TypeDeserializer valueTypeDeser, JsonDeserializer<?> valueDeser, NullValueProvider nuller, Set<String> ignorable, Set<String> includable) {
/* 215 */     if (this._keyDeserializer == keyDeser && this._valueDeserializer == valueDeser && this._valueTypeDeserializer == valueTypeDeser && this._nullProvider == nuller && this._ignorableProperties == ignorable && this._includableProperties == includable)
/*     */     {
/*     */       
/* 218 */       return this;
/*     */     }
/* 220 */     return new MapDeserializer(this, keyDeser, (JsonDeserializer)valueDeser, valueTypeDeser, nuller, ignorable, includable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean _isStdKeyDeser(JavaType mapType, KeyDeserializer keyDeser) {
/* 231 */     if (keyDeser == null) {
/* 232 */       return true;
/*     */     }
/* 234 */     JavaType keyType = mapType.getKeyType();
/* 235 */     if (keyType == null) {
/* 236 */       return true;
/*     */     }
/* 238 */     Class<?> rawKeyType = keyType.getRawClass();
/* 239 */     return ((rawKeyType == String.class || rawKeyType == Object.class) && 
/* 240 */       isDefaultKeyDeserializer(keyDeser));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setIgnorableProperties(String[] ignorable) {
/* 248 */     this
/* 249 */       ._ignorableProperties = (ignorable == null || ignorable.length == 0) ? null : ArrayBuilders.arrayToSet((Object[])ignorable);
/* 250 */     this._inclusionChecker = IgnorePropertiesUtil.buildCheckerIfNeeded(this._ignorableProperties, this._includableProperties);
/*     */   }
/*     */   
/*     */   public void setIgnorableProperties(Set<String> ignorable) {
/* 254 */     this._ignorableProperties = (ignorable == null || ignorable.isEmpty()) ? null : ignorable;
/*     */     
/* 256 */     this._inclusionChecker = IgnorePropertiesUtil.buildCheckerIfNeeded(this._ignorableProperties, this._includableProperties);
/*     */   }
/*     */   
/*     */   public void setIncludableProperties(Set<String> includable) {
/* 260 */     this._includableProperties = includable;
/* 261 */     this._inclusionChecker = IgnorePropertiesUtil.buildCheckerIfNeeded(this._ignorableProperties, this._includableProperties);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resolve(DeserializationContext ctxt) throws JsonMappingException {
/* 274 */     if (this._valueInstantiator.canCreateUsingDelegate()) {
/* 275 */       JavaType delegateType = this._valueInstantiator.getDelegateType(ctxt.getConfig());
/* 276 */       if (delegateType == null) {
/* 277 */         ctxt.reportBadDefinition(this._containerType, String.format("Invalid delegate-creator definition for %s: value instantiator (%s) returned true for 'canCreateUsingDelegate()', but null for 'getDelegateType()'", new Object[] { this._containerType, this._valueInstantiator
/*     */ 
/*     */                 
/* 280 */                 .getClass().getName() }));
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 285 */       this._delegateDeserializer = findDeserializer(ctxt, delegateType, null);
/* 286 */     } else if (this._valueInstantiator.canCreateUsingArrayDelegate()) {
/* 287 */       JavaType delegateType = this._valueInstantiator.getArrayDelegateType(ctxt.getConfig());
/* 288 */       if (delegateType == null) {
/* 289 */         ctxt.reportBadDefinition(this._containerType, String.format("Invalid delegate-creator definition for %s: value instantiator (%s) returned true for 'canCreateUsingArrayDelegate()', but null for 'getArrayDelegateType()'", new Object[] { this._containerType, this._valueInstantiator
/*     */ 
/*     */                 
/* 292 */                 .getClass().getName() }));
/*     */       }
/* 294 */       this._delegateDeserializer = findDeserializer(ctxt, delegateType, null);
/*     */     } 
/* 296 */     if (this._valueInstantiator.canCreateFromObjectWith()) {
/* 297 */       SettableBeanProperty[] creatorProps = this._valueInstantiator.getFromObjectArguments(ctxt.getConfig());
/* 298 */       this._propertyBasedCreator = PropertyBasedCreator.construct(ctxt, this._valueInstantiator, creatorProps, ctxt
/* 299 */           .isEnabled(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES));
/*     */     } 
/* 301 */     this._standardStringKey = _isStdKeyDeser(this._containerType, this._keyDeserializer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonDeserializer<?> createContextual(DeserializationContext ctxt, BeanProperty property) throws JsonMappingException {
/* 312 */     KeyDeserializer keyDeser = this._keyDeserializer;
/* 313 */     if (keyDeser == null) {
/* 314 */       keyDeser = ctxt.findKeyDeserializer(this._containerType.getKeyType(), property);
/*     */     }
/* 316 */     else if (keyDeser instanceof ContextualKeyDeserializer) {
/* 317 */       keyDeser = ((ContextualKeyDeserializer)keyDeser).createContextual(ctxt, property);
/*     */     } 
/*     */ 
/*     */     
/* 321 */     JsonDeserializer<?> valueDeser = this._valueDeserializer;
/*     */     
/* 323 */     if (property != null) {
/* 324 */       valueDeser = findConvertingContentDeserializer(ctxt, property, valueDeser);
/*     */     }
/* 326 */     JavaType vt = this._containerType.getContentType();
/* 327 */     if (valueDeser == null) {
/* 328 */       valueDeser = ctxt.findContextualValueDeserializer(vt, property);
/*     */     } else {
/* 330 */       valueDeser = ctxt.handleSecondaryContextualization(valueDeser, property, vt);
/*     */     } 
/* 332 */     TypeDeserializer vtd = this._valueTypeDeserializer;
/* 333 */     if (vtd != null) {
/* 334 */       vtd = vtd.forProperty(property);
/*     */     }
/* 336 */     Set<String> ignored = this._ignorableProperties;
/* 337 */     Set<String> included = this._includableProperties;
/* 338 */     AnnotationIntrospector intr = ctxt.getAnnotationIntrospector();
/* 339 */     if (_neitherNull(intr, property)) {
/* 340 */       AnnotatedMember member = property.getMember();
/* 341 */       if (member != null) {
/* 342 */         DeserializationConfig config = ctxt.getConfig();
/* 343 */         JsonIgnoreProperties.Value ignorals = intr.findPropertyIgnoralByName((MapperConfig)config, (Annotated)member);
/* 344 */         if (ignorals != null) {
/* 345 */           Set<String> ignoresToAdd = ignorals.findIgnoredForDeserialization();
/* 346 */           if (!ignoresToAdd.isEmpty()) {
/* 347 */             ignored = (ignored == null) ? new HashSet<>() : new HashSet<>(ignored);
/* 348 */             for (String str : ignoresToAdd) {
/* 349 */               ignored.add(str);
/*     */             }
/*     */           } 
/*     */         } 
/* 353 */         JsonIncludeProperties.Value inclusions = intr.findPropertyInclusionByName((MapperConfig)config, (Annotated)member);
/* 354 */         if (inclusions != null) {
/* 355 */           Set<String> includedToAdd = inclusions.getIncluded();
/* 356 */           if (includedToAdd != null) {
/* 357 */             Set<String> newIncluded = new HashSet<>();
/* 358 */             if (included == null) {
/* 359 */               newIncluded = new HashSet<>(includedToAdd);
/*     */             } else {
/* 361 */               for (String str : includedToAdd) {
/* 362 */                 if (included.contains(str)) {
/* 363 */                   newIncluded.add(str);
/*     */                 }
/*     */               } 
/*     */             } 
/* 367 */             included = newIncluded;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 372 */     return withResolved(keyDeser, vtd, valueDeser, 
/* 373 */         findContentNullProvider(ctxt, property, valueDeser), ignored, included);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonDeserializer<Object> getContentDeserializer() {
/* 384 */     return this._valueDeserializer;
/*     */   }
/*     */ 
/*     */   
/*     */   public ValueInstantiator getValueInstantiator() {
/* 389 */     return this._valueInstantiator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCachable() {
/* 415 */     return (this._valueDeserializer == null && this._keyDeserializer == null && this._valueTypeDeserializer == null && this._ignorableProperties == null && this._includableProperties == null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LogicalType logicalType() {
/* 424 */     return LogicalType.Map;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<Object, Object> deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/*     */     Map<Object, Object> result;
/* 431 */     if (this._propertyBasedCreator != null) {
/* 432 */       return _deserializeUsingCreator(p, ctxt);
/*     */     }
/* 434 */     if (this._delegateDeserializer != null) {
/* 435 */       return (Map<Object, Object>)this._valueInstantiator.createUsingDelegate(ctxt, this._delegateDeserializer
/* 436 */           .deserialize(p, ctxt));
/*     */     }
/* 438 */     if (!this._hasDefaultCreator) {
/* 439 */       return (Map<Object, Object>)ctxt.handleMissingInstantiator(getMapClass(), 
/* 440 */           getValueInstantiator(), p, "no default constructor found", new Object[0]);
/*     */     }
/*     */     
/* 443 */     switch (p.currentTokenId()) {
/*     */       case 1:
/*     */       case 2:
/*     */       case 5:
/* 447 */         result = (Map<Object, Object>)this._valueInstantiator.createUsingDefault(ctxt);
/* 448 */         if (this._standardStringKey) {
/* 449 */           return _readAndBindStringKeyMap(p, ctxt, result);
/*     */         }
/* 451 */         return _readAndBind(p, ctxt, result);
/*     */       
/*     */       case 6:
/* 454 */         return _deserializeFromString(p, ctxt);
/*     */       
/*     */       case 3:
/* 457 */         return _deserializeFromArray(p, ctxt);
/*     */     } 
/*     */     
/* 460 */     return (Map<Object, Object>)ctxt.handleUnexpectedToken(getValueType(ctxt), p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<Object, Object> deserialize(JsonParser p, DeserializationContext ctxt, Map<Object, Object> result) throws IOException {
/* 470 */     p.setCurrentValue(result);
/*     */ 
/*     */     
/* 473 */     JsonToken t = p.currentToken();
/* 474 */     if (t != JsonToken.START_OBJECT && t != JsonToken.FIELD_NAME) {
/* 475 */       return (Map<Object, Object>)ctxt.handleUnexpectedToken(getMapClass(), p);
/*     */     }
/*     */     
/* 478 */     if (this._standardStringKey) {
/* 479 */       _readAndUpdateStringKeyMap(p, ctxt, result);
/* 480 */       return result;
/*     */     } 
/* 482 */     _readAndUpdate(p, ctxt, result);
/* 483 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserializeWithType(JsonParser p, DeserializationContext ctxt, TypeDeserializer typeDeserializer) throws IOException {
/* 492 */     return typeDeserializer.deserializeTypedFromObject(p, ctxt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Class<?> getMapClass() {
/* 502 */     return this._containerType.getRawClass();
/*     */   } public JavaType getValueType() {
/* 504 */     return this._containerType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Map<Object, Object> _readAndBind(JsonParser p, DeserializationContext ctxt, Map<Object, Object> result) throws IOException {
/* 515 */     KeyDeserializer keyDes = this._keyDeserializer;
/* 516 */     JsonDeserializer<Object> valueDes = this._valueDeserializer;
/* 517 */     TypeDeserializer typeDeser = this._valueTypeDeserializer;
/*     */     
/* 519 */     MapReferringAccumulator referringAccumulator = null;
/* 520 */     boolean useObjectId = (valueDes.getObjectIdReader() != null);
/* 521 */     if (useObjectId) {
/* 522 */       referringAccumulator = new MapReferringAccumulator(this._containerType.getContentType().getRawClass(), result);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 527 */     if (p.isExpectedStartObjectToken()) {
/* 528 */       str = p.nextFieldName();
/*     */     } else {
/* 530 */       JsonToken t = p.currentToken();
/* 531 */       if (t != JsonToken.FIELD_NAME) {
/* 532 */         if (t == JsonToken.END_OBJECT) {
/* 533 */           return result;
/*     */         }
/* 535 */         ctxt.reportWrongTokenException(this, JsonToken.FIELD_NAME, null, new Object[0]);
/*     */       } 
/* 537 */       str = p.currentName();
/*     */     } 
/*     */     String str;
/* 540 */     for (; str != null; str = p.nextFieldName()) {
/* 541 */       Object key = keyDes.deserializeKey(str, ctxt);
/*     */       
/* 543 */       JsonToken t = p.nextToken();
/* 544 */       if (this._inclusionChecker != null && this._inclusionChecker.shouldIgnore(str)) {
/* 545 */         p.skipChildren();
/*     */         
/*     */         continue;
/*     */       } 
/*     */       try {
/*     */         Object value;
/* 551 */         if (t == JsonToken.VALUE_NULL) {
/* 552 */           if (this._skipNullValues) {
/*     */             continue;
/*     */           }
/* 555 */           value = this._nullProvider.getNullValue(ctxt);
/* 556 */         } else if (typeDeser == null) {
/* 557 */           value = valueDes.deserialize(p, ctxt);
/*     */         } else {
/* 559 */           value = valueDes.deserializeWithType(p, ctxt, typeDeser);
/*     */         } 
/* 561 */         if (useObjectId) {
/* 562 */           referringAccumulator.put(key, value);
/*     */         } else {
/* 564 */           Object oldValue = result.put(key, value);
/* 565 */           if (oldValue != null) {
/* 566 */             _squashDups(ctxt, result, key, oldValue, value);
/*     */           }
/*     */         } 
/* 569 */       } catch (UnresolvedForwardReference reference) {
/* 570 */         handleUnresolvedReference(ctxt, referringAccumulator, key, reference);
/* 571 */       } catch (Exception e) {
/* 572 */         wrapAndThrow(ctxt, e, result, str);
/*     */       }  continue;
/*     */     } 
/* 575 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Map<Object, Object> _readAndBindStringKeyMap(JsonParser p, DeserializationContext ctxt, Map<Object, Object> result) throws IOException {
/* 586 */     JsonDeserializer<Object> valueDes = this._valueDeserializer;
/* 587 */     TypeDeserializer typeDeser = this._valueTypeDeserializer;
/* 588 */     MapReferringAccumulator referringAccumulator = null;
/* 589 */     boolean useObjectId = (valueDes.getObjectIdReader() != null);
/* 590 */     if (useObjectId) {
/* 591 */       referringAccumulator = new MapReferringAccumulator(this._containerType.getContentType().getRawClass(), result);
/*     */     }
/*     */ 
/*     */     
/* 595 */     if (p.isExpectedStartObjectToken()) {
/* 596 */       str = p.nextFieldName();
/*     */     } else {
/* 598 */       JsonToken t = p.currentToken();
/* 599 */       if (t == JsonToken.END_OBJECT) {
/* 600 */         return result;
/*     */       }
/* 602 */       if (t != JsonToken.FIELD_NAME) {
/* 603 */         ctxt.reportWrongTokenException(this, JsonToken.FIELD_NAME, null, new Object[0]);
/*     */       }
/* 605 */       str = p.currentName();
/*     */     } 
/*     */     String str;
/* 608 */     for (; str != null; str = p.nextFieldName()) {
/* 609 */       JsonToken t = p.nextToken();
/* 610 */       if (this._inclusionChecker != null && this._inclusionChecker.shouldIgnore(str)) {
/* 611 */         p.skipChildren();
/*     */         
/*     */         continue;
/*     */       } 
/*     */       try {
/*     */         Object value;
/* 617 */         if (t == JsonToken.VALUE_NULL) {
/* 618 */           if (this._skipNullValues) {
/*     */             continue;
/*     */           }
/* 621 */           value = this._nullProvider.getNullValue(ctxt);
/* 622 */         } else if (typeDeser == null) {
/* 623 */           value = valueDes.deserialize(p, ctxt);
/*     */         } else {
/* 625 */           value = valueDes.deserializeWithType(p, ctxt, typeDeser);
/*     */         } 
/* 627 */         if (useObjectId) {
/* 628 */           referringAccumulator.put(str, value);
/*     */         } else {
/* 630 */           Object oldValue = result.put(str, value);
/* 631 */           if (oldValue != null) {
/* 632 */             _squashDups(ctxt, result, str, oldValue, value);
/*     */           }
/*     */         } 
/* 635 */       } catch (UnresolvedForwardReference reference) {
/* 636 */         handleUnresolvedReference(ctxt, referringAccumulator, str, reference);
/* 637 */       } catch (Exception e) {
/* 638 */         wrapAndThrow(ctxt, e, result, str);
/*     */       } 
/*     */       
/*     */       continue;
/*     */     } 
/* 643 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<Object, Object> _deserializeUsingCreator(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 649 */     PropertyBasedCreator creator = this._propertyBasedCreator;
/*     */     
/* 651 */     PropertyValueBuffer buffer = creator.startBuilding(p, ctxt, null);
/*     */     
/* 653 */     JsonDeserializer<Object> valueDes = this._valueDeserializer;
/* 654 */     TypeDeserializer typeDeser = this._valueTypeDeserializer;
/*     */ 
/*     */     
/* 657 */     if (p.isExpectedStartObjectToken()) {
/* 658 */       str = p.nextFieldName();
/* 659 */     } else if (p.hasToken(JsonToken.FIELD_NAME)) {
/* 660 */       str = p.currentName();
/*     */     } else {
/* 662 */       str = null;
/*     */     } 
/*     */     String str;
/* 665 */     for (; str != null; str = p.nextFieldName()) {
/* 666 */       Object value; JsonToken t = p.nextToken();
/* 667 */       if (this._inclusionChecker != null && this._inclusionChecker.shouldIgnore(str)) {
/* 668 */         p.skipChildren();
/*     */         
/*     */         continue;
/*     */       } 
/* 672 */       SettableBeanProperty prop = creator.findCreatorProperty(str);
/* 673 */       if (prop != null) {
/*     */         
/* 675 */         if (buffer.assignParameter(prop, prop.deserialize(p, ctxt))) {
/* 676 */           Map<Object, Object> result; p.nextToken();
/*     */           
/*     */           try {
/* 679 */             result = (Map<Object, Object>)creator.build(ctxt, buffer);
/* 680 */           } catch (Exception e) {
/* 681 */             return (Map<Object, Object>)wrapAndThrow(ctxt, e, this._containerType.getRawClass(), str);
/*     */           } 
/* 683 */           return _readAndBind(p, ctxt, result);
/*     */         } 
/*     */         
/*     */         continue;
/*     */       } 
/* 688 */       Object actualKey = this._keyDeserializer.deserializeKey(str, ctxt);
/*     */ 
/*     */       
/*     */       try {
/* 692 */         if (t == JsonToken.VALUE_NULL) {
/* 693 */           if (this._skipNullValues) {
/*     */             continue;
/*     */           }
/* 696 */           value = this._nullProvider.getNullValue(ctxt);
/* 697 */         } else if (typeDeser == null) {
/* 698 */           value = valueDes.deserialize(p, ctxt);
/*     */         } else {
/* 700 */           value = valueDes.deserializeWithType(p, ctxt, typeDeser);
/*     */         } 
/* 702 */       } catch (Exception e) {
/* 703 */         wrapAndThrow(ctxt, e, this._containerType.getRawClass(), str);
/* 704 */         return null;
/*     */       } 
/* 706 */       buffer.bufferMapProperty(actualKey, value);
/*     */       
/*     */       continue;
/*     */     } 
/*     */     try {
/* 711 */       return (Map<Object, Object>)creator.build(ctxt, buffer);
/* 712 */     } catch (Exception e) {
/* 713 */       wrapAndThrow(ctxt, e, this._containerType.getRawClass(), str);
/* 714 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void _readAndUpdate(JsonParser p, DeserializationContext ctxt, Map<Object, Object> result) throws IOException {
/* 730 */     KeyDeserializer keyDes = this._keyDeserializer;
/* 731 */     JsonDeserializer<Object> valueDes = this._valueDeserializer;
/* 732 */     TypeDeserializer typeDeser = this._valueTypeDeserializer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 738 */     if (p.isExpectedStartObjectToken()) {
/* 739 */       keyStr = p.nextFieldName();
/*     */     } else {
/* 741 */       JsonToken t = p.currentToken();
/* 742 */       if (t == JsonToken.END_OBJECT) {
/*     */         return;
/*     */       }
/* 745 */       if (t != JsonToken.FIELD_NAME) {
/* 746 */         ctxt.reportWrongTokenException(this, JsonToken.FIELD_NAME, null, new Object[0]);
/*     */       }
/* 748 */       keyStr = p.currentName();
/*     */     } 
/*     */     String keyStr;
/* 751 */     for (; keyStr != null; keyStr = p.nextFieldName()) {
/* 752 */       Object key = keyDes.deserializeKey(keyStr, ctxt);
/*     */       
/* 754 */       JsonToken t = p.nextToken();
/* 755 */       if (this._inclusionChecker != null && this._inclusionChecker.shouldIgnore(keyStr)) {
/* 756 */         p.skipChildren();
/*     */       } else {
/*     */ 
/*     */         
/*     */         try {
/* 761 */           if (t == JsonToken.VALUE_NULL) {
/* 762 */             if (!this._skipNullValues)
/*     */             {
/*     */               
/* 765 */               result.put(key, this._nullProvider.getNullValue(ctxt));
/*     */             }
/*     */           } else {
/* 768 */             Object value, old = result.get(key);
/*     */             
/* 770 */             if (old != null) {
/* 771 */               if (typeDeser == null) {
/* 772 */                 value = valueDes.deserialize(p, ctxt, old);
/*     */               } else {
/* 774 */                 value = valueDes.deserializeWithType(p, ctxt, typeDeser, old);
/*     */               } 
/* 776 */             } else if (typeDeser == null) {
/* 777 */               value = valueDes.deserialize(p, ctxt);
/*     */             } else {
/* 779 */               value = valueDes.deserializeWithType(p, ctxt, typeDeser);
/*     */             } 
/* 781 */             if (value != old)
/* 782 */               result.put(key, value); 
/*     */           } 
/* 784 */         } catch (Exception e) {
/* 785 */           wrapAndThrow(ctxt, e, result, keyStr);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void _readAndUpdateStringKeyMap(JsonParser p, DeserializationContext ctxt, Map<Object, Object> result) throws IOException {
/* 800 */     JsonDeserializer<Object> valueDes = this._valueDeserializer;
/* 801 */     TypeDeserializer typeDeser = this._valueTypeDeserializer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 807 */     if (p.isExpectedStartObjectToken()) {
/* 808 */       key = p.nextFieldName();
/*     */     } else {
/* 810 */       JsonToken t = p.currentToken();
/* 811 */       if (t == JsonToken.END_OBJECT) {
/*     */         return;
/*     */       }
/* 814 */       if (t != JsonToken.FIELD_NAME) {
/* 815 */         ctxt.reportWrongTokenException(this, JsonToken.FIELD_NAME, null, new Object[0]);
/*     */       }
/* 817 */       key = p.currentName();
/*     */     } 
/*     */     String key;
/* 820 */     for (; key != null; key = p.nextFieldName()) {
/* 821 */       JsonToken t = p.nextToken();
/* 822 */       if (this._inclusionChecker != null && this._inclusionChecker.shouldIgnore(key)) {
/* 823 */         p.skipChildren();
/*     */       } else {
/*     */ 
/*     */         
/*     */         try {
/* 828 */           if (t == JsonToken.VALUE_NULL) {
/* 829 */             if (!this._skipNullValues)
/*     */             {
/*     */               
/* 832 */               result.put(key, this._nullProvider.getNullValue(ctxt));
/*     */             }
/*     */           } else {
/* 835 */             Object value, old = result.get(key);
/*     */             
/* 837 */             if (old != null) {
/* 838 */               if (typeDeser == null) {
/* 839 */                 value = valueDes.deserialize(p, ctxt, old);
/*     */               } else {
/* 841 */                 value = valueDes.deserializeWithType(p, ctxt, typeDeser, old);
/*     */               } 
/* 843 */             } else if (typeDeser == null) {
/* 844 */               value = valueDes.deserialize(p, ctxt);
/*     */             } else {
/* 846 */               value = valueDes.deserializeWithType(p, ctxt, typeDeser);
/*     */             } 
/* 848 */             if (value != old)
/* 849 */               result.put(key, value); 
/*     */           } 
/* 851 */         } catch (Exception e) {
/* 852 */           wrapAndThrow(ctxt, e, result, key);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _squashDups(DeserializationContext ctxt, Map<Object, Object> result, Object key, Object oldValue, Object newValue) {
/* 865 */     if (this._checkDupSquash && ctxt.isEnabled(StreamReadCapability.DUPLICATE_PROPERTIES)) {
/* 866 */       if (oldValue instanceof List) {
/* 867 */         ((List<Object>)oldValue).add(newValue);
/* 868 */         result.put(key, oldValue);
/*     */       } else {
/* 870 */         ArrayList<Object> l = new ArrayList();
/* 871 */         l.add(oldValue);
/* 872 */         l.add(newValue);
/* 873 */         result.put(key, l);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void handleUnresolvedReference(DeserializationContext ctxt, MapReferringAccumulator accumulator, Object key, UnresolvedForwardReference reference) throws JsonMappingException {
/* 889 */     if (accumulator == null) {
/* 890 */       ctxt.reportInputMismatch(this, "Unresolved forward reference but no identity info: " + reference, new Object[0]);
/*     */     }
/*     */     
/* 893 */     ReadableObjectId.Referring referring = accumulator.handleUnresolvedReference(reference, key);
/* 894 */     reference.getRoid().appendReferring(referring);
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class MapReferringAccumulator
/*     */   {
/*     */     private final Class<?> _valueType;
/*     */     
/*     */     private Map<Object, Object> _result;
/* 903 */     private List<MapDeserializer.MapReferring> _accumulator = new ArrayList<>();
/*     */     
/*     */     public MapReferringAccumulator(Class<?> valueType, Map<Object, Object> result) {
/* 906 */       this._valueType = valueType;
/* 907 */       this._result = result;
/*     */     }
/*     */ 
/*     */     
/*     */     public void put(Object key, Object value) {
/* 912 */       if (this._accumulator.isEmpty()) {
/* 913 */         this._result.put(key, value);
/*     */       } else {
/* 915 */         MapDeserializer.MapReferring ref = this._accumulator.get(this._accumulator.size() - 1);
/* 916 */         ref.next.put(key, value);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public ReadableObjectId.Referring handleUnresolvedReference(UnresolvedForwardReference reference, Object key) {
/* 922 */       MapDeserializer.MapReferring id = new MapDeserializer.MapReferring(this, reference, this._valueType, key);
/* 923 */       this._accumulator.add(id);
/* 924 */       return id;
/*     */     }
/*     */ 
/*     */     
/*     */     public void resolveForwardReference(Object id, Object value) throws IOException {
/* 929 */       Iterator<MapDeserializer.MapReferring> iterator = this._accumulator.iterator();
/*     */ 
/*     */ 
/*     */       
/* 933 */       Map<Object, Object> previous = this._result;
/* 934 */       while (iterator.hasNext()) {
/* 935 */         MapDeserializer.MapReferring ref = iterator.next();
/* 936 */         if (ref.hasId(id)) {
/* 937 */           iterator.remove();
/* 938 */           previous.put(ref.key, value);
/* 939 */           previous.putAll(ref.next);
/*     */           return;
/*     */         } 
/* 942 */         previous = ref.next;
/*     */       } 
/*     */       
/* 945 */       throw new IllegalArgumentException("Trying to resolve a forward reference with id [" + id + "] that wasn't previously seen as unresolved.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class MapReferring
/*     */     extends ReadableObjectId.Referring
/*     */   {
/*     */     private final MapDeserializer.MapReferringAccumulator _parent;
/*     */ 
/*     */     
/* 958 */     public final Map<Object, Object> next = new LinkedHashMap<>();
/*     */     
/*     */     public final Object key;
/*     */ 
/*     */     
/*     */     MapReferring(MapDeserializer.MapReferringAccumulator parent, UnresolvedForwardReference ref, Class<?> valueType, Object key) {
/* 964 */       super(ref, valueType);
/* 965 */       this._parent = parent;
/* 966 */       this.key = key;
/*     */     }
/*     */ 
/*     */     
/*     */     public void handleResolvedForwardReference(Object id, Object value) throws IOException {
/* 971 */       this._parent.resolveForwardReference(id, value);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\deser\std\MapDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */