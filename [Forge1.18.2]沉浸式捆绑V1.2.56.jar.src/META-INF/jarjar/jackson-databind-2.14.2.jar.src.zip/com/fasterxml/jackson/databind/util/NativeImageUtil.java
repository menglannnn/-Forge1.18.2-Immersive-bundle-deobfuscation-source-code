/*    */ package com.fasterxml.jackson.databind.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NativeImageUtil
/*    */ {
/* 15 */   private static final boolean RUNNING_IN_SVM = (System.getProperty("org.graalvm.nativeimage.imagecode") != null);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static boolean isRunningInNativeImage() {
/* 26 */     return (RUNNING_IN_SVM && "runtime".equals(System.getProperty("org.graalvm.nativeimage.imagecode")));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean isUnsupportedFeatureError(Throwable e) {
/* 33 */     if (!isRunningInNativeImage()) {
/* 34 */       return false;
/*    */     }
/* 36 */     if (e instanceof java.lang.reflect.InvocationTargetException) {
/* 37 */       e = e.getCause();
/*    */     }
/* 39 */     return e.getClass().getName().equals("com.oracle.svm.core.jdk.UnsupportedFeatureError");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean needsReflectionConfiguration(Class<?> cl) {
/* 47 */     if (!isRunningInNativeImage()) {
/* 48 */       return false;
/*    */     }
/*    */     
/* 51 */     return (((cl.getDeclaredFields()).length == 0 || ClassUtil.isRecordType(cl)) && (cl
/* 52 */       .getDeclaredMethods()).length == 0 && (cl
/* 53 */       .getDeclaredConstructors()).length == 0);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databin\\util\NativeImageUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */