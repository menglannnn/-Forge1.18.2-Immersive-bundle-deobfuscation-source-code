/*     */ package com.fasterxml.jackson.databind.node;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.JsonSerializable;
/*     */ import com.fasterxml.jackson.databind.ObjectReader;
/*     */ import com.fasterxml.jackson.databind.ObjectWriter;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.json.JsonMapper;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class InternalNodeMapper
/*     */ {
/*  22 */   private static final JsonMapper JSON_MAPPER = new JsonMapper();
/*     */   
/*  24 */   private static final ObjectWriter STD_WRITER = JSON_MAPPER.writer();
/*  25 */   private static final ObjectWriter PRETTY_WRITER = JSON_MAPPER.writer()
/*  26 */     .withDefaultPrettyPrinter();
/*     */   
/*  28 */   private static final ObjectReader NODE_READER = JSON_MAPPER.readerFor(JsonNode.class);
/*     */ 
/*     */ 
/*     */   
/*     */   public static String nodeToString(BaseJsonNode n) {
/*     */     try {
/*  34 */       return STD_WRITER.writeValueAsString(_wrapper(n));
/*  35 */     } catch (IOException e) {
/*  36 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static String nodeToPrettyString(BaseJsonNode n) {
/*     */     try {
/*  42 */       return PRETTY_WRITER.writeValueAsString(_wrapper(n));
/*  43 */     } catch (IOException e) {
/*  44 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] valueToBytes(Object value) throws IOException {
/*  51 */     return JSON_MAPPER.writeValueAsBytes(value);
/*     */   }
/*     */   
/*     */   public static JsonNode bytesToNode(byte[] json) throws IOException {
/*  55 */     return (JsonNode)NODE_READER.readValue(json);
/*     */   }
/*     */   
/*     */   private static JsonSerializable _wrapper(BaseJsonNode root) {
/*  59 */     return (JsonSerializable)new WrapperForSerializer(root);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static class WrapperForSerializer
/*     */     extends JsonSerializable.Base
/*     */   {
/*     */     protected final BaseJsonNode _root;
/*     */ 
/*     */ 
/*     */     
/*     */     protected SerializerProvider _context;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public WrapperForSerializer(BaseJsonNode root) {
/*  79 */       this._root = root;
/*     */     }
/*     */ 
/*     */     
/*     */     public void serialize(JsonGenerator g, SerializerProvider ctxt) throws IOException {
/*  84 */       this._context = ctxt;
/*  85 */       _serializeNonRecursive(g, this._root);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void serializeWithType(JsonGenerator g, SerializerProvider ctxt, TypeSerializer typeSer) throws IOException {
/*  93 */       serialize(g, ctxt);
/*     */     }
/*     */ 
/*     */     
/*     */     protected void _serializeNonRecursive(JsonGenerator g, JsonNode node) throws IOException {
/*  98 */       if (node instanceof ObjectNode) {
/*  99 */         g.writeStartObject(this, node.size());
/* 100 */         _serializeNonRecursive(g, new InternalNodeMapper.IteratorStack(), node.fields());
/* 101 */       } else if (node instanceof ArrayNode) {
/* 102 */         g.writeStartArray(this, node.size());
/* 103 */         _serializeNonRecursive(g, new InternalNodeMapper.IteratorStack(), node.elements());
/*     */       } else {
/* 105 */         node.serialize(g, this._context);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void _serializeNonRecursive(JsonGenerator g, InternalNodeMapper.IteratorStack stack, Iterator<?> rootIterator) throws IOException {
/* 113 */       Iterator<?> currIt = rootIterator;
/*     */       
/*     */       do {
/* 116 */         while (currIt.hasNext()) {
/*     */           JsonNode value;
/*     */ 
/*     */           
/* 120 */           Object elem = currIt.next();
/* 121 */           if (elem instanceof Map.Entry) {
/*     */             
/* 123 */             Map.Entry<String, JsonNode> en = (Map.Entry<String, JsonNode>)elem;
/* 124 */             g.writeFieldName(en.getKey());
/* 125 */             value = en.getValue();
/*     */           } else {
/* 127 */             value = (JsonNode)elem;
/*     */           } 
/* 129 */           if (value instanceof ObjectNode) {
/* 130 */             stack.push(currIt);
/* 131 */             currIt = value.fields();
/* 132 */             g.writeStartObject(value, value.size()); continue;
/* 133 */           }  if (value instanceof ArrayNode) {
/* 134 */             stack.push(currIt);
/* 135 */             currIt = value.elements();
/* 136 */             g.writeStartArray(value, value.size()); continue;
/*     */           } 
/* 138 */           value.serialize(g, this._context);
/*     */         } 
/*     */         
/* 141 */         if (g.getOutputContext().inArray()) {
/* 142 */           g.writeEndArray();
/*     */         } else {
/* 144 */           g.writeEndObject();
/*     */         } 
/* 146 */         currIt = stack.popOrNull();
/* 147 */       } while (currIt != null);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class IteratorStack
/*     */   {
/*     */     private Iterator<?>[] _stack;
/*     */ 
/*     */ 
/*     */     
/*     */     private int _top;
/*     */ 
/*     */     
/*     */     private int _end;
/*     */ 
/*     */ 
/*     */     
/*     */     public void push(Iterator<?> it) {
/* 168 */       if (this._top < this._end) {
/* 169 */         this._stack[this._top++] = it;
/*     */         return;
/*     */       } 
/* 172 */       if (this._stack == null) {
/* 173 */         this._end = 10;
/* 174 */         this._stack = (Iterator<?>[])new Iterator[this._end];
/*     */       } else {
/*     */         
/* 177 */         this._end += Math.min(4000, Math.max(20, this._end >> 1));
/* 178 */         this._stack = (Iterator<?>[])Arrays.<Iterator>copyOf((Iterator[])this._stack, this._end);
/*     */       } 
/* 180 */       this._stack[this._top++] = it;
/*     */     }
/*     */     
/*     */     public Iterator<?> popOrNull() {
/* 184 */       if (this._top == 0) {
/* 185 */         return null;
/*     */       }
/*     */ 
/*     */       
/* 189 */       return this._stack[--this._top];
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\node\InternalNodeMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */