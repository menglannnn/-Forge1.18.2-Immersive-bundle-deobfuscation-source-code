/*     */ package com.fasterxml.jackson.databind.deser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JacksonException;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StackTraceElementDeserializer
/*     */   extends StdScalarDeserializer<StackTraceElement>
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final JsonDeserializer<?> _adapterDeserializer;
/*     */   
/*     */   @Deprecated
/*     */   public StackTraceElementDeserializer() {
/*  22 */     this((JsonDeserializer<?>)null);
/*     */   }
/*     */ 
/*     */   
/*     */   protected StackTraceElementDeserializer(JsonDeserializer<?> ad) {
/*  27 */     super(StackTraceElement.class);
/*  28 */     this._adapterDeserializer = ad;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JsonDeserializer<?> construct(DeserializationContext ctxt) throws JsonMappingException {
/*  36 */     if (ctxt == null) {
/*  37 */       return new StackTraceElementDeserializer();
/*     */     }
/*  39 */     JsonDeserializer<?> adapterDeser = ctxt.findNonContextualValueDeserializer(ctxt.constructType(Adapter.class));
/*  40 */     return new StackTraceElementDeserializer(adapterDeser);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public StackTraceElement deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  46 */     JsonToken t = p.currentToken();
/*     */ 
/*     */     
/*  49 */     if (t == JsonToken.START_OBJECT || t == JsonToken.FIELD_NAME) {
/*     */       Adapter adapted;
/*     */       
/*  52 */       if (this._adapterDeserializer == null) {
/*  53 */         adapted = (Adapter)ctxt.readValue(p, Adapter.class);
/*     */       } else {
/*  55 */         adapted = (Adapter)this._adapterDeserializer.deserialize(p, ctxt);
/*     */       } 
/*  57 */       return constructValue(ctxt, adapted);
/*  58 */     }  if (t == JsonToken.START_ARRAY && ctxt.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS)) {
/*  59 */       p.nextToken();
/*  60 */       StackTraceElement value = deserialize(p, ctxt);
/*  61 */       if (p.nextToken() != JsonToken.END_ARRAY) {
/*  62 */         handleMissingEndArrayForSingle(p, ctxt);
/*     */       }
/*  64 */       return value;
/*     */     } 
/*  66 */     return (StackTraceElement)ctxt.handleUnexpectedToken(this._valueClass, p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected StackTraceElement constructValue(DeserializationContext ctxt, Adapter adapted) {
/*  75 */     return constructValue(ctxt, adapted.className, adapted.methodName, adapted.fileName, adapted.lineNumber, adapted.moduleName, adapted.moduleVersion, adapted.classLoaderName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected StackTraceElement constructValue(DeserializationContext ctxt, String className, String methodName, String fileName, int lineNumber, String moduleName, String moduleVersion) {
/*  85 */     return constructValue(ctxt, className, methodName, fileName, lineNumber, moduleName, moduleVersion, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected StackTraceElement constructValue(DeserializationContext ctxt, String className, String methodName, String fileName, int lineNumber, String moduleName, String moduleVersion, String classLoaderName) {
/* 100 */     return new StackTraceElement(className, methodName, fileName, lineNumber);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Adapter
/*     */   {
/*     */     public String classLoaderName;
/*     */     
/*     */     public String declaringClass;
/*     */     
/* 111 */     public String className = "";
/*     */     public String format;
/* 113 */     public String fileName = ""; public String methodName = "";
/* 114 */     public int lineNumber = -1;
/*     */     public String moduleName;
/*     */     public String moduleVersion;
/*     */     public boolean nativeMethod;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\deser\std\StackTraceElementDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */