/*     */ package com.fasterxml.jackson.databind.deser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.StreamReadCapability;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.annotation.JacksonStdImpl;
/*     */ import com.fasterxml.jackson.databind.deser.ContextualDeserializer;
/*     */ import com.fasterxml.jackson.databind.deser.ResolvableDeserializer;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*     */ import com.fasterxml.jackson.databind.type.LogicalType;
/*     */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import com.fasterxml.jackson.databind.util.ObjectBuffer;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ @JacksonStdImpl
/*     */ public class UntypedObjectDeserializer
/*     */   extends StdDeserializer<Object>
/*     */   implements ResolvableDeserializer, ContextualDeserializer
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  35 */   protected static final Object[] NO_OBJECTS = new Object[0];
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonDeserializer<Object> _mapDeserializer;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonDeserializer<Object> _listDeserializer;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonDeserializer<Object> _stringDeserializer;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonDeserializer<Object> _numberDeserializer;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JavaType _listType;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JavaType _mapType;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean _nonMerging;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public UntypedObjectDeserializer() {
/*  77 */     this((JavaType)null, (JavaType)null);
/*     */   }
/*     */   
/*     */   public UntypedObjectDeserializer(JavaType listType, JavaType mapType) {
/*  81 */     super(Object.class);
/*  82 */     this._listType = listType;
/*  83 */     this._mapType = mapType;
/*  84 */     this._nonMerging = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UntypedObjectDeserializer(UntypedObjectDeserializer base, JsonDeserializer<?> mapDeser, JsonDeserializer<?> listDeser, JsonDeserializer<?> stringDeser, JsonDeserializer<?> numberDeser) {
/*  92 */     super(Object.class);
/*  93 */     this._mapDeserializer = (JsonDeserializer)mapDeser;
/*  94 */     this._listDeserializer = (JsonDeserializer)listDeser;
/*  95 */     this._stringDeserializer = (JsonDeserializer)stringDeser;
/*  96 */     this._numberDeserializer = (JsonDeserializer)numberDeser;
/*  97 */     this._listType = base._listType;
/*  98 */     this._mapType = base._mapType;
/*  99 */     this._nonMerging = base._nonMerging;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected UntypedObjectDeserializer(UntypedObjectDeserializer base, boolean nonMerging) {
/* 108 */     super(Object.class);
/* 109 */     this._mapDeserializer = base._mapDeserializer;
/* 110 */     this._listDeserializer = base._listDeserializer;
/* 111 */     this._stringDeserializer = base._stringDeserializer;
/* 112 */     this._numberDeserializer = base._numberDeserializer;
/* 113 */     this._listType = base._listType;
/* 114 */     this._mapType = base._mapType;
/* 115 */     this._nonMerging = nonMerging;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resolve(DeserializationContext ctxt) throws JsonMappingException {
/* 133 */     JavaType obType = ctxt.constructType(Object.class);
/* 134 */     JavaType stringType = ctxt.constructType(String.class);
/* 135 */     TypeFactory tf = ctxt.getTypeFactory();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 147 */     if (this._listType == null) {
/* 148 */       this._listDeserializer = _clearIfStdImpl(_findCustomDeser(ctxt, (JavaType)tf.constructCollectionType(List.class, obType)));
/*     */     } else {
/*     */       
/* 151 */       this._listDeserializer = _findCustomDeser(ctxt, this._listType);
/*     */     } 
/* 153 */     if (this._mapType == null) {
/* 154 */       this._mapDeserializer = _clearIfStdImpl(_findCustomDeser(ctxt, (JavaType)tf.constructMapType(Map.class, stringType, obType)));
/*     */     } else {
/*     */       
/* 157 */       this._mapDeserializer = _findCustomDeser(ctxt, this._mapType);
/*     */     } 
/* 159 */     this._stringDeserializer = _clearIfStdImpl(_findCustomDeser(ctxt, stringType));
/* 160 */     this._numberDeserializer = _clearIfStdImpl(_findCustomDeser(ctxt, tf.constructType(Number.class)));
/*     */ 
/*     */ 
/*     */     
/* 164 */     JavaType unknown = TypeFactory.unknownType();
/* 165 */     this._mapDeserializer = ctxt.handleSecondaryContextualization(this._mapDeserializer, null, unknown);
/* 166 */     this._listDeserializer = ctxt.handleSecondaryContextualization(this._listDeserializer, null, unknown);
/* 167 */     this._stringDeserializer = ctxt.handleSecondaryContextualization(this._stringDeserializer, null, unknown);
/* 168 */     this._numberDeserializer = ctxt.handleSecondaryContextualization(this._numberDeserializer, null, unknown);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonDeserializer<Object> _findCustomDeser(DeserializationContext ctxt, JavaType type) throws JsonMappingException {
/* 176 */     return ctxt.findNonContextualValueDeserializer(type);
/*     */   }
/*     */   
/*     */   protected JsonDeserializer<Object> _clearIfStdImpl(JsonDeserializer<Object> deser) {
/* 180 */     return ClassUtil.isJacksonStdImpl(deser) ? null : deser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonDeserializer<?> createContextual(DeserializationContext ctxt, BeanProperty property) throws JsonMappingException {
/* 193 */     boolean preventMerge = (property == null && Boolean.FALSE.equals(ctxt.getConfig().getDefaultMergeable(Object.class)));
/*     */ 
/*     */     
/* 196 */     if (this._stringDeserializer == null && this._numberDeserializer == null && this._mapDeserializer == null && this._listDeserializer == null && 
/*     */       
/* 198 */       getClass() == UntypedObjectDeserializer.class) {
/* 199 */       return UntypedObjectDeserializerNR.instance(preventMerge);
/*     */     }
/*     */     
/* 202 */     if (preventMerge != this._nonMerging) {
/* 203 */       return new UntypedObjectDeserializer(this, preventMerge);
/*     */     }
/*     */     
/* 206 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCachable() {
/* 224 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public LogicalType logicalType() {
/* 229 */     return LogicalType.Untyped;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean supportsUpdate(DeserializationConfig config) {
/* 235 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 241 */     switch (p.currentTokenId()) {
/*     */ 
/*     */       
/*     */       case 1:
/*     */       case 2:
/*     */       case 5:
/* 247 */         if (this._mapDeserializer != null) {
/* 248 */           return this._mapDeserializer.deserialize(p, ctxt);
/*     */         }
/* 250 */         return mapObject(p, ctxt);
/*     */       case 3:
/* 252 */         if (ctxt.isEnabled(DeserializationFeature.USE_JAVA_ARRAY_FOR_JSON_ARRAY)) {
/* 253 */           return mapArrayToArray(p, ctxt);
/*     */         }
/* 255 */         if (this._listDeserializer != null) {
/* 256 */           return this._listDeserializer.deserialize(p, ctxt);
/*     */         }
/* 258 */         return mapArray(p, ctxt);
/*     */       case 12:
/* 260 */         return p.getEmbeddedObject();
/*     */       case 6:
/* 262 */         if (this._stringDeserializer != null) {
/* 263 */           return this._stringDeserializer.deserialize(p, ctxt);
/*     */         }
/* 265 */         return p.getText();
/*     */       
/*     */       case 7:
/* 268 */         if (this._numberDeserializer != null) {
/* 269 */           return this._numberDeserializer.deserialize(p, ctxt);
/*     */         }
/*     */ 
/*     */         
/* 273 */         if (ctxt.hasSomeOfFeatures(F_MASK_INT_COERCIONS)) {
/* 274 */           return _coerceIntegral(p, ctxt);
/*     */         }
/* 276 */         return p.getNumberValue();
/*     */       
/*     */       case 8:
/* 279 */         if (this._numberDeserializer != null) {
/* 280 */           return this._numberDeserializer.deserialize(p, ctxt);
/*     */         }
/*     */         
/* 283 */         if (ctxt.isEnabled(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS)) {
/* 284 */           return p.getDecimalValue();
/*     */         }
/*     */         
/* 287 */         return p.getNumberValue();
/*     */       
/*     */       case 9:
/* 290 */         return Boolean.TRUE;
/*     */       case 10:
/* 292 */         return Boolean.FALSE;
/*     */       
/*     */       case 11:
/* 295 */         return null;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 300 */     return ctxt.handleUnexpectedToken(Object.class, p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserializeWithType(JsonParser p, DeserializationContext ctxt, TypeDeserializer typeDeserializer) throws IOException {
/* 307 */     switch (p.currentTokenId()) {
/*     */ 
/*     */       
/*     */       case 1:
/*     */       case 3:
/*     */       case 5:
/* 313 */         return typeDeserializer.deserializeTypedFromAny(p, ctxt);
/*     */       
/*     */       case 12:
/* 316 */         return p.getEmbeddedObject();
/*     */ 
/*     */ 
/*     */       
/*     */       case 6:
/* 321 */         if (this._stringDeserializer != null) {
/* 322 */           return this._stringDeserializer.deserialize(p, ctxt);
/*     */         }
/* 324 */         return p.getText();
/*     */       
/*     */       case 7:
/* 327 */         if (this._numberDeserializer != null) {
/* 328 */           return this._numberDeserializer.deserialize(p, ctxt);
/*     */         }
/*     */         
/* 331 */         if (ctxt.hasSomeOfFeatures(F_MASK_INT_COERCIONS)) {
/* 332 */           return _coerceIntegral(p, ctxt);
/*     */         }
/* 334 */         return p.getNumberValue();
/*     */       
/*     */       case 8:
/* 337 */         if (this._numberDeserializer != null) {
/* 338 */           return this._numberDeserializer.deserialize(p, ctxt);
/*     */         }
/* 340 */         if (ctxt.isEnabled(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS)) {
/* 341 */           return p.getDecimalValue();
/*     */         }
/* 343 */         return p.getNumberValue();
/*     */       
/*     */       case 9:
/* 346 */         return Boolean.TRUE;
/*     */       case 10:
/* 348 */         return Boolean.FALSE;
/*     */       
/*     */       case 11:
/* 351 */         return null;
/*     */     } 
/*     */     
/* 354 */     return ctxt.handleUnexpectedToken(Object.class, p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserialize(JsonParser p, DeserializationContext ctxt, Object intoValue) throws IOException {
/* 362 */     if (this._nonMerging) {
/* 363 */       return deserialize(p, ctxt);
/*     */     }
/*     */     
/* 366 */     switch (p.currentTokenId()) {
/*     */ 
/*     */       
/*     */       case 1:
/*     */       case 2:
/*     */       case 5:
/* 372 */         if (this._mapDeserializer != null) {
/* 373 */           return this._mapDeserializer.deserialize(p, ctxt, intoValue);
/*     */         }
/* 375 */         if (intoValue instanceof Map) {
/* 376 */           return mapObject(p, ctxt, (Map<Object, Object>)intoValue);
/*     */         }
/* 378 */         return mapObject(p, ctxt);
/*     */       case 3:
/* 380 */         if (this._listDeserializer != null) {
/* 381 */           return this._listDeserializer.deserialize(p, ctxt, intoValue);
/*     */         }
/* 383 */         if (intoValue instanceof Collection) {
/* 384 */           return mapArray(p, ctxt, (Collection<Object>)intoValue);
/*     */         }
/* 386 */         if (ctxt.isEnabled(DeserializationFeature.USE_JAVA_ARRAY_FOR_JSON_ARRAY)) {
/* 387 */           return mapArrayToArray(p, ctxt);
/*     */         }
/* 389 */         return mapArray(p, ctxt);
/*     */       case 12:
/* 391 */         return p.getEmbeddedObject();
/*     */       case 6:
/* 393 */         if (this._stringDeserializer != null) {
/* 394 */           return this._stringDeserializer.deserialize(p, ctxt, intoValue);
/*     */         }
/* 396 */         return p.getText();
/*     */       
/*     */       case 7:
/* 399 */         if (this._numberDeserializer != null) {
/* 400 */           return this._numberDeserializer.deserialize(p, ctxt, intoValue);
/*     */         }
/* 402 */         if (ctxt.hasSomeOfFeatures(F_MASK_INT_COERCIONS)) {
/* 403 */           return _coerceIntegral(p, ctxt);
/*     */         }
/* 405 */         return p.getNumberValue();
/*     */       
/*     */       case 8:
/* 408 */         if (this._numberDeserializer != null) {
/* 409 */           return this._numberDeserializer.deserialize(p, ctxt, intoValue);
/*     */         }
/* 411 */         if (ctxt.isEnabled(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS)) {
/* 412 */           return p.getDecimalValue();
/*     */         }
/* 414 */         return p.getNumberValue();
/*     */       case 9:
/* 416 */         return Boolean.TRUE;
/*     */       case 10:
/* 418 */         return Boolean.FALSE;
/*     */ 
/*     */       
/*     */       case 11:
/* 422 */         return null;
/*     */     } 
/*     */ 
/*     */     
/* 426 */     return deserialize(p, ctxt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object mapArray(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 441 */     if (p.nextToken() == JsonToken.END_ARRAY) {
/* 442 */       return new ArrayList(2);
/*     */     }
/* 444 */     Object value = deserialize(p, ctxt);
/* 445 */     if (p.nextToken() == JsonToken.END_ARRAY) {
/* 446 */       ArrayList<Object> l = new ArrayList(2);
/* 447 */       l.add(value);
/* 448 */       return l;
/*     */     } 
/* 450 */     Object value2 = deserialize(p, ctxt);
/* 451 */     if (p.nextToken() == JsonToken.END_ARRAY) {
/* 452 */       ArrayList<Object> l = new ArrayList(2);
/* 453 */       l.add(value);
/* 454 */       l.add(value2);
/* 455 */       return l;
/*     */     } 
/* 457 */     ObjectBuffer buffer = ctxt.leaseObjectBuffer();
/* 458 */     Object[] values = buffer.resetAndStart();
/* 459 */     int ptr = 0;
/* 460 */     values[ptr++] = value;
/* 461 */     values[ptr++] = value2;
/* 462 */     int totalSize = ptr;
/*     */     do {
/* 464 */       value = deserialize(p, ctxt);
/* 465 */       totalSize++;
/* 466 */       if (ptr >= values.length) {
/* 467 */         values = buffer.appendCompletedChunk(values);
/* 468 */         ptr = 0;
/*     */       } 
/* 470 */       values[ptr++] = value;
/* 471 */     } while (p.nextToken() != JsonToken.END_ARRAY);
/*     */     
/* 473 */     ArrayList<Object> result = new ArrayList(totalSize);
/* 474 */     buffer.completeAndClearBuffer(values, ptr, result);
/* 475 */     ctxt.returnObjectBuffer(buffer);
/* 476 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object mapArray(JsonParser p, DeserializationContext ctxt, Collection<Object> result) throws IOException {
/* 484 */     while (p.nextToken() != JsonToken.END_ARRAY) {
/* 485 */       result.add(deserialize(p, ctxt));
/*     */     }
/* 487 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object mapObject(JsonParser p, DeserializationContext ctxt) throws IOException {
/*     */     String key1;
/* 496 */     JsonToken t = p.currentToken();
/*     */     
/* 498 */     if (t == JsonToken.START_OBJECT) {
/* 499 */       key1 = p.nextFieldName();
/* 500 */     } else if (t == JsonToken.FIELD_NAME) {
/* 501 */       key1 = p.currentName();
/*     */     } else {
/* 503 */       if (t != JsonToken.END_OBJECT) {
/* 504 */         return ctxt.handleUnexpectedToken(handledType(), p);
/*     */       }
/* 506 */       key1 = null;
/*     */     } 
/* 508 */     if (key1 == null)
/*     */     {
/* 510 */       return new LinkedHashMap<>(2);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 515 */     p.nextToken();
/* 516 */     Object value1 = deserialize(p, ctxt);
/* 517 */     String key2 = p.nextFieldName();
/* 518 */     if (key2 == null) {
/*     */       
/* 520 */       LinkedHashMap<String, Object> linkedHashMap = new LinkedHashMap<>(2);
/* 521 */       linkedHashMap.put(key1, value1);
/* 522 */       return linkedHashMap;
/*     */     } 
/* 524 */     p.nextToken();
/* 525 */     Object value2 = deserialize(p, ctxt);
/*     */     
/* 527 */     String key = p.nextFieldName();
/* 528 */     if (key == null) {
/* 529 */       LinkedHashMap<String, Object> linkedHashMap = new LinkedHashMap<>(4);
/* 530 */       linkedHashMap.put(key1, value1);
/* 531 */       if (linkedHashMap.put(key2, value2) != null)
/*     */       {
/* 533 */         return _mapObjectWithDups(p, ctxt, linkedHashMap, key1, value1, value2, key);
/*     */       }
/* 535 */       return linkedHashMap;
/*     */     } 
/*     */     
/* 538 */     LinkedHashMap<String, Object> result = new LinkedHashMap<>();
/* 539 */     result.put(key1, value1);
/* 540 */     if (result.put(key2, value2) != null)
/*     */     {
/* 542 */       return _mapObjectWithDups(p, ctxt, result, key1, value1, value2, key);
/*     */     }
/*     */     
/*     */     while (true) {
/* 546 */       p.nextToken();
/* 547 */       Object newValue = deserialize(p, ctxt);
/* 548 */       Object oldValue = result.put(key, newValue);
/* 549 */       if (oldValue != null) {
/* 550 */         return _mapObjectWithDups(p, ctxt, result, key, oldValue, newValue, p
/* 551 */             .nextFieldName());
/*     */       }
/* 553 */       if ((key = p.nextFieldName()) == null) {
/* 554 */         return result;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object _mapObjectWithDups(JsonParser p, DeserializationContext ctxt, Map<String, Object> result, String key, Object oldValue, Object newValue, String nextKey) throws IOException {
/* 562 */     boolean squashDups = ctxt.isEnabled(StreamReadCapability.DUPLICATE_PROPERTIES);
/*     */     
/* 564 */     if (squashDups) {
/* 565 */       _squashDups(result, key, oldValue, newValue);
/*     */     }
/*     */     
/* 568 */     while (nextKey != null) {
/* 569 */       p.nextToken();
/* 570 */       newValue = deserialize(p, ctxt);
/* 571 */       oldValue = result.put(nextKey, newValue);
/* 572 */       if (oldValue != null && squashDups) {
/* 573 */         _squashDups(result, key, oldValue, newValue);
/*     */       }
/* 575 */       nextKey = p.nextFieldName();
/*     */     } 
/*     */     
/* 578 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void _squashDups(Map<String, Object> result, String key, Object oldValue, Object newValue) {
/* 585 */     if (oldValue instanceof List) {
/* 586 */       ((List<Object>)oldValue).add(newValue);
/* 587 */       result.put(key, oldValue);
/*     */     } else {
/* 589 */       ArrayList<Object> l = new ArrayList();
/* 590 */       l.add(oldValue);
/* 591 */       l.add(newValue);
/* 592 */       result.put(key, l);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object[] mapArrayToArray(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 602 */     if (p.nextToken() == JsonToken.END_ARRAY) {
/* 603 */       return NO_OBJECTS;
/*     */     }
/* 605 */     ObjectBuffer buffer = ctxt.leaseObjectBuffer();
/* 606 */     Object[] values = buffer.resetAndStart();
/* 607 */     int ptr = 0;
/*     */     while (true) {
/* 609 */       Object value = deserialize(p, ctxt);
/* 610 */       if (ptr >= values.length) {
/* 611 */         values = buffer.appendCompletedChunk(values);
/* 612 */         ptr = 0;
/*     */       } 
/* 614 */       values[ptr++] = value;
/* 615 */       if (p.nextToken() == JsonToken.END_ARRAY) {
/* 616 */         Object[] result = buffer.completeAndClearBuffer(values, ptr);
/* 617 */         ctxt.returnObjectBuffer(buffer);
/* 618 */         return result;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   protected Object mapObject(JsonParser p, DeserializationContext ctxt, Map<Object, Object> m) throws IOException {
/* 624 */     JsonToken t = p.currentToken();
/* 625 */     if (t == JsonToken.START_OBJECT) {
/* 626 */       t = p.nextToken();
/*     */     }
/* 628 */     if (t == JsonToken.END_OBJECT) {
/* 629 */       return m;
/*     */     }
/*     */     
/* 632 */     String key = p.currentName(); while (true) {
/*     */       Object newV;
/* 634 */       p.nextToken();
/*     */       
/* 636 */       Object old = m.get(key);
/*     */ 
/*     */       
/* 639 */       if (old != null) {
/* 640 */         newV = deserialize(p, ctxt, old);
/*     */       } else {
/* 642 */         newV = deserialize(p, ctxt);
/*     */       } 
/* 644 */       if (newV != old) {
/* 645 */         m.put(key, newV);
/*     */       }
/* 647 */       if ((key = p.nextFieldName()) == null) {
/* 648 */         return m;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JacksonStdImpl
/*     */   @Deprecated
/*     */   public static class Vanilla
/*     */     extends StdDeserializer<Object>
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 668 */     public static final Vanilla std = new Vanilla();
/*     */     
/*     */     protected final boolean _nonMerging;
/*     */     
/*     */     public Vanilla() {
/* 673 */       this(false);
/*     */     }
/*     */     protected Vanilla(boolean nonMerging) {
/* 676 */       super(Object.class);
/* 677 */       this._nonMerging = nonMerging;
/*     */     }
/*     */     
/*     */     public static Vanilla instance(boolean nonMerging) {
/* 681 */       if (nonMerging) {
/* 682 */         return new Vanilla(true);
/*     */       }
/* 684 */       return std;
/*     */     }
/*     */ 
/*     */     
/*     */     public LogicalType logicalType() {
/* 689 */       return LogicalType.Untyped;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Boolean supportsUpdate(DeserializationConfig config) {
/* 696 */       return this._nonMerging ? Boolean.FALSE : null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/*     */       JsonToken t;
/* 702 */       switch (p.currentTokenId()) {
/*     */         
/*     */         case 1:
/* 705 */           t = p.nextToken();
/* 706 */           if (t == JsonToken.END_OBJECT) {
/* 707 */             return new LinkedHashMap<>(2);
/*     */           }
/*     */         
/*     */         case 5:
/* 711 */           return mapObject(p, ctxt);
/*     */         
/*     */         case 3:
/* 714 */           t = p.nextToken();
/* 715 */           if (t == JsonToken.END_ARRAY) {
/* 716 */             if (ctxt.isEnabled(DeserializationFeature.USE_JAVA_ARRAY_FOR_JSON_ARRAY)) {
/* 717 */               return UntypedObjectDeserializer.NO_OBJECTS;
/*     */             }
/* 719 */             return new ArrayList(2);
/*     */           } 
/*     */           
/* 722 */           if (ctxt.isEnabled(DeserializationFeature.USE_JAVA_ARRAY_FOR_JSON_ARRAY)) {
/* 723 */             return mapArrayToArray(p, ctxt);
/*     */           }
/* 725 */           return mapArray(p, ctxt);
/*     */         case 12:
/* 727 */           return p.getEmbeddedObject();
/*     */         case 6:
/* 729 */           return p.getText();
/*     */         
/*     */         case 7:
/* 732 */           if (ctxt.hasSomeOfFeatures(F_MASK_INT_COERCIONS)) {
/* 733 */             return _coerceIntegral(p, ctxt);
/*     */           }
/* 735 */           return p.getNumberValue();
/*     */         
/*     */         case 8:
/* 738 */           if (ctxt.isEnabled(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS)) {
/* 739 */             return p.getDecimalValue();
/*     */           }
/* 741 */           return p.getNumberValue();
/*     */         
/*     */         case 9:
/* 744 */           return Boolean.TRUE;
/*     */         case 10:
/* 746 */           return Boolean.FALSE;
/*     */ 
/*     */ 
/*     */         
/*     */         case 2:
/* 751 */           return new LinkedHashMap<>(2);
/*     */         
/*     */         case 11:
/* 754 */           return null;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 759 */       return ctxt.handleUnexpectedToken(Object.class, p);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Object deserializeWithType(JsonParser p, DeserializationContext ctxt, TypeDeserializer typeDeserializer) throws IOException {
/* 765 */       switch (p.currentTokenId()) {
/*     */         case 1:
/*     */         case 3:
/*     */         case 5:
/* 769 */           return typeDeserializer.deserializeTypedFromAny(p, ctxt);
/*     */         
/*     */         case 6:
/* 772 */           return p.getText();
/*     */         
/*     */         case 7:
/* 775 */           if (ctxt.isEnabled(DeserializationFeature.USE_BIG_INTEGER_FOR_INTS)) {
/* 776 */             return p.getBigIntegerValue();
/*     */           }
/* 778 */           return p.getNumberValue();
/*     */         
/*     */         case 8:
/* 781 */           if (ctxt.isEnabled(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS)) {
/* 782 */             return p.getDecimalValue();
/*     */           }
/* 784 */           return p.getNumberValue();
/*     */         
/*     */         case 9:
/* 787 */           return Boolean.TRUE;
/*     */         case 10:
/* 789 */           return Boolean.FALSE;
/*     */         case 12:
/* 791 */           return p.getEmbeddedObject();
/*     */         
/*     */         case 11:
/* 794 */           return null;
/*     */       } 
/*     */       
/* 797 */       return ctxt.handleUnexpectedToken(Object.class, p);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Object deserialize(JsonParser p, DeserializationContext ctxt, Object intoValue) throws IOException {
/*     */       JsonToken t;
/* 805 */       if (this._nonMerging) {
/* 806 */         return deserialize(p, ctxt);
/*     */       }
/* 808 */       switch (p.currentTokenId()) {
/*     */         case 2:
/*     */         case 4:
/* 811 */           return intoValue;
/*     */         
/*     */         case 1:
/* 814 */           t = p.nextToken();
/* 815 */           if (t == JsonToken.END_OBJECT) {
/* 816 */             return intoValue;
/*     */           }
/*     */         
/*     */         case 5:
/* 820 */           if (intoValue instanceof Map) {
/* 821 */             Map<Object, Object> m = (Map<Object, Object>)intoValue;
/*     */             
/* 823 */             String key = p.currentName(); while (true) {
/*     */               Object newV;
/* 825 */               p.nextToken();
/*     */               
/* 827 */               Object old = m.get(key);
/*     */               
/* 829 */               if (old != null) {
/* 830 */                 newV = deserialize(p, ctxt, old);
/*     */               } else {
/* 832 */                 newV = deserialize(p, ctxt);
/*     */               } 
/* 834 */               if (newV != old) {
/* 835 */                 m.put(key, newV);
/*     */               }
/* 837 */               if ((key = p.nextFieldName()) == null)
/* 838 */                 return intoValue; 
/*     */             } 
/*     */           } 
/*     */           break;
/*     */         case 3:
/* 843 */           t = p.nextToken();
/* 844 */           if (t == JsonToken.END_ARRAY) {
/* 845 */             return intoValue;
/*     */           }
/*     */ 
/*     */           
/* 849 */           if (intoValue instanceof Collection) {
/* 850 */             Collection<Object> c = (Collection<Object>)intoValue;
/*     */             
/*     */             while (true) {
/* 853 */               c.add(deserialize(p, ctxt));
/* 854 */               if (p.nextToken() == JsonToken.END_ARRAY) {
/* 855 */                 return intoValue;
/*     */               }
/*     */             } 
/*     */           } 
/*     */           break;
/*     */       } 
/*     */       
/* 862 */       return deserialize(p, ctxt);
/*     */     }
/*     */ 
/*     */     
/*     */     protected Object mapArray(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 867 */       Object value = deserialize(p, ctxt);
/* 868 */       if (p.nextToken() == JsonToken.END_ARRAY) {
/* 869 */         ArrayList<Object> l = new ArrayList(2);
/* 870 */         l.add(value);
/* 871 */         return l;
/*     */       } 
/* 873 */       ObjectBuffer buffer = ctxt.leaseObjectBuffer();
/* 874 */       Object[] values = buffer.resetAndStart();
/* 875 */       int ptr = 0;
/* 876 */       values[ptr++] = value;
/* 877 */       int totalSize = ptr;
/*     */       do {
/* 879 */         value = deserialize(p, ctxt);
/* 880 */         totalSize++;
/* 881 */         if (ptr >= values.length) {
/* 882 */           values = buffer.appendCompletedChunk(values);
/* 883 */           ptr = 0;
/*     */         } 
/* 885 */         values[ptr++] = value;
/* 886 */       } while (p.nextToken() != JsonToken.END_ARRAY);
/*     */       
/* 888 */       ArrayList<Object> result = new ArrayList(totalSize);
/* 889 */       buffer.completeAndClearBuffer(values, ptr, result);
/* 890 */       ctxt.returnObjectBuffer(buffer);
/* 891 */       return result;
/*     */     }
/*     */     
/*     */     protected Object[] mapArrayToArray(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 895 */       ObjectBuffer buffer = ctxt.leaseObjectBuffer();
/* 896 */       Object[] values = buffer.resetAndStart();
/* 897 */       int ptr = 0;
/*     */       while (true) {
/* 899 */         Object value = deserialize(p, ctxt);
/* 900 */         if (ptr >= values.length) {
/* 901 */           values = buffer.appendCompletedChunk(values);
/* 902 */           ptr = 0;
/*     */         } 
/* 904 */         values[ptr++] = value;
/* 905 */         if (p.nextToken() == JsonToken.END_ARRAY) {
/* 906 */           Object[] result = buffer.completeAndClearBuffer(values, ptr);
/* 907 */           ctxt.returnObjectBuffer(buffer);
/* 908 */           return result;
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     protected Object mapObject(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 915 */       String key1 = p.currentName();
/* 916 */       p.nextToken();
/* 917 */       Object value1 = deserialize(p, ctxt);
/*     */       
/* 919 */       String key = p.nextFieldName();
/* 920 */       if (key == null) {
/* 921 */         LinkedHashMap<String, Object> linkedHashMap = new LinkedHashMap<>(2);
/* 922 */         linkedHashMap.put(key1, value1);
/* 923 */         return linkedHashMap;
/*     */       } 
/*     */       
/* 926 */       LinkedHashMap<String, Object> result = new LinkedHashMap<>();
/* 927 */       result.put(key1, value1);
/*     */       while (true) {
/* 929 */         p.nextToken();
/* 930 */         Object newValue = deserialize(p, ctxt);
/* 931 */         Object oldValue = result.put(key, newValue);
/* 932 */         if (oldValue != null) {
/* 933 */           return _mapObjectWithDups(p, ctxt, result, key, oldValue, newValue, p
/* 934 */               .nextFieldName());
/*     */         }
/* 936 */         if ((key = p.nextFieldName()) == null) {
/* 937 */           return result;
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected Object _mapObjectWithDups(JsonParser p, DeserializationContext ctxt, Map<String, Object> result, String initialKey, Object oldValue, Object newValue, String nextKey) throws IOException {
/* 946 */       boolean squashDups = ctxt.isEnabled(StreamReadCapability.DUPLICATE_PROPERTIES);
/*     */       
/* 948 */       if (squashDups) {
/* 949 */         _squashDups(result, initialKey, oldValue, newValue);
/*     */       }
/*     */       
/* 952 */       while (nextKey != null) {
/* 953 */         p.nextToken();
/* 954 */         newValue = deserialize(p, ctxt);
/* 955 */         oldValue = result.put(nextKey, newValue);
/* 956 */         if (oldValue != null && squashDups) {
/* 957 */           _squashDups(result, nextKey, oldValue, newValue);
/*     */         }
/* 959 */         nextKey = p.nextFieldName();
/*     */       } 
/*     */       
/* 962 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void _squashDups(Map<String, Object> result, String key, Object oldValue, Object newValue) {
/* 970 */       if (oldValue instanceof List) {
/* 971 */         ((List<Object>)oldValue).add(newValue);
/* 972 */         result.put(key, oldValue);
/*     */       } else {
/* 974 */         ArrayList<Object> l = new ArrayList();
/* 975 */         l.add(oldValue);
/* 976 */         l.add(newValue);
/* 977 */         result.put(key, l);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\deser\std\UntypedObjectDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */