/*    */ package com.fasterxml.jackson.databind.cfg;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum CoercionAction
/*    */ {
/* 21 */   Fail,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 26 */   TryConvert,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 31 */   AsNull,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 40 */   AsEmpty;
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\cfg\CoercionAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */