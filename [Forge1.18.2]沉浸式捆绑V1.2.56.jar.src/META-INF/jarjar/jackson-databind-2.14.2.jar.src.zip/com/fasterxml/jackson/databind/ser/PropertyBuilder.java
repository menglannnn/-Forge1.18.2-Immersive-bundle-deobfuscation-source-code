/*     */ package com.fasterxml.jackson.databind.ser;
/*     */ import com.fasterxml.jackson.annotation.JsonInclude;
/*     */ import com.fasterxml.jackson.databind.BeanDescription;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.SerializationConfig;
/*     */ import com.fasterxml.jackson.databind.SerializationFeature;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*     */ import com.fasterxml.jackson.databind.introspect.Annotated;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*     */ import com.fasterxml.jackson.databind.introspect.BeanPropertyDefinition;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ 
/*     */ public class PropertyBuilder {
/*  18 */   private static final Object NO_DEFAULT_MARKER = Boolean.FALSE;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final SerializationConfig _config;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final BeanDescription _beanDesc;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final AnnotationIntrospector _annotationIntrospector;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object _defaultBean;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final JsonInclude.Value _defaultInclusion;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean _useRealPropertyDefaults;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertyBuilder(SerializationConfig config, BeanDescription beanDesc) {
/*  54 */     this._config = config;
/*  55 */     this._beanDesc = beanDesc;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  66 */     JsonInclude.Value inclPerType = JsonInclude.Value.merge(beanDesc
/*  67 */         .findPropertyInclusion(JsonInclude.Value.empty()), config
/*  68 */         .getDefaultPropertyInclusion(beanDesc.getBeanClass(), 
/*  69 */           JsonInclude.Value.empty()));
/*  70 */     this._defaultInclusion = JsonInclude.Value.merge(config.getDefaultPropertyInclusion(), inclPerType);
/*     */     
/*  72 */     this._useRealPropertyDefaults = (inclPerType.getValueInclusion() == JsonInclude.Include.NON_DEFAULT);
/*  73 */     this._annotationIntrospector = this._config.getAnnotationIntrospector();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Annotations getClassAnnotations() {
/*  83 */     return this._beanDesc.getClassAnnotations();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BeanPropertyWriter buildWriter(SerializerProvider prov, BeanPropertyDefinition propDef, JavaType declaredType, JsonSerializer<?> ser, TypeSerializer typeSer, TypeSerializer contentTypeSer, AnnotatedMember am, boolean defaultUseStaticTyping) throws JsonMappingException {
/*     */     JavaType serializationType;
/*     */     Object defaultBean;
/*     */     SerializationFeature emptyJsonArrays;
/*     */     try {
/* 100 */       serializationType = findSerializationType((Annotated)am, defaultUseStaticTyping, declaredType);
/* 101 */     } catch (JsonMappingException e) {
/* 102 */       if (propDef == null) {
/* 103 */         return (BeanPropertyWriter)prov.reportBadDefinition(declaredType, ClassUtil.exceptionMessage((Throwable)e));
/*     */       }
/* 105 */       return (BeanPropertyWriter)prov.reportBadPropertyDefinition(this._beanDesc, propDef, ClassUtil.exceptionMessage((Throwable)e), new Object[0]);
/*     */     } 
/*     */ 
/*     */     
/* 109 */     if (contentTypeSer != null) {
/*     */ 
/*     */ 
/*     */       
/* 113 */       if (serializationType == null)
/*     */       {
/* 115 */         serializationType = declaredType;
/*     */       }
/* 117 */       JavaType ct = serializationType.getContentType();
/*     */       
/* 119 */       if (ct == null) {
/* 120 */         prov.reportBadPropertyDefinition(this._beanDesc, propDef, "serialization type " + serializationType + " has no content", new Object[0]);
/*     */       }
/*     */       
/* 123 */       serializationType = serializationType.withContentTypeHandler(contentTypeSer);
/* 124 */       ct = serializationType.getContentType();
/*     */     } 
/*     */     
/* 127 */     Object valueToSuppress = null;
/* 128 */     boolean suppressNulls = false;
/*     */ 
/*     */     
/* 131 */     JavaType actualType = (serializationType == null) ? declaredType : serializationType;
/*     */ 
/*     */     
/* 134 */     AnnotatedMember accessor = propDef.getAccessor();
/* 135 */     if (accessor == null)
/*     */     {
/* 137 */       return (BeanPropertyWriter)prov.reportBadPropertyDefinition(this._beanDesc, propDef, "could not determine property type", new Object[0]);
/*     */     }
/*     */     
/* 140 */     Class<?> rawPropertyType = accessor.getRawType();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 145 */     JsonInclude.Value inclV = this._config.getDefaultInclusion(actualType.getRawClass(), rawPropertyType, this._defaultInclusion);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 150 */     inclV = inclV.withOverrides(propDef.findInclusion());
/*     */     
/* 152 */     JsonInclude.Include inclusion = inclV.getValueInclusion();
/* 153 */     if (inclusion == JsonInclude.Include.USE_DEFAULTS) {
/* 154 */       inclusion = JsonInclude.Include.ALWAYS;
/*     */     }
/* 156 */     switch (inclusion) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case NON_DEFAULT:
/* 169 */         if (this._useRealPropertyDefaults && (defaultBean = getDefaultBean()) != null) {
/*     */           
/* 171 */           if (prov.isEnabled(MapperFeature.CAN_OVERRIDE_ACCESS_MODIFIERS)) {
/* 172 */             am.fixAccess(this._config.isEnabled(MapperFeature.OVERRIDE_PUBLIC_ACCESS_MODIFIERS));
/*     */           }
/*     */           try {
/* 175 */             valueToSuppress = am.getValue(defaultBean);
/* 176 */           } catch (Exception e) {
/* 177 */             _throwWrapped(e, propDef.getName(), defaultBean);
/*     */           } 
/*     */         } else {
/* 180 */           valueToSuppress = BeanUtil.getDefaultValue(actualType);
/* 181 */           suppressNulls = true;
/*     */         } 
/* 183 */         if (valueToSuppress == null) {
/* 184 */           suppressNulls = true; break;
/*     */         } 
/* 186 */         if (valueToSuppress.getClass().isArray()) {
/* 187 */           valueToSuppress = ArrayBuilders.getArrayComparator(valueToSuppress);
/*     */         }
/*     */         break;
/*     */ 
/*     */       
/*     */       case NON_ABSENT:
/* 193 */         suppressNulls = true;
/*     */         
/* 195 */         if (actualType.isReferenceType()) {
/* 196 */           valueToSuppress = BeanPropertyWriter.MARKER_FOR_EMPTY;
/*     */         }
/*     */         break;
/*     */       
/*     */       case NON_EMPTY:
/* 201 */         suppressNulls = true;
/*     */         
/* 203 */         valueToSuppress = BeanPropertyWriter.MARKER_FOR_EMPTY;
/*     */         break;
/*     */       case CUSTOM:
/* 206 */         valueToSuppress = prov.includeFilterInstance(propDef, inclV.getValueFilter());
/*     */         break;
/*     */       case NON_NULL:
/* 209 */         suppressNulls = true;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       default:
/* 215 */         emptyJsonArrays = SerializationFeature.WRITE_EMPTY_JSON_ARRAYS;
/* 216 */         if (actualType.isContainerType() && !this._config.isEnabled(emptyJsonArrays)) {
/* 217 */           valueToSuppress = BeanPropertyWriter.MARKER_FOR_EMPTY;
/*     */         }
/*     */         break;
/*     */     } 
/* 221 */     Class<?>[] views = propDef.findViews();
/* 222 */     if (views == null) {
/* 223 */       views = this._beanDesc.findDefaultViews();
/*     */     }
/* 225 */     BeanPropertyWriter bpw = _constructPropertyWriter(propDef, am, this._beanDesc
/* 226 */         .getClassAnnotations(), declaredType, ser, typeSer, serializationType, suppressNulls, valueToSuppress, views);
/*     */ 
/*     */ 
/*     */     
/* 230 */     Object serDef = this._annotationIntrospector.findNullSerializer((Annotated)am);
/* 231 */     if (serDef != null) {
/* 232 */       bpw.assignNullSerializer(prov.serializerInstance((Annotated)am, serDef));
/*     */     }
/*     */     
/* 235 */     NameTransformer unwrapper = this._annotationIntrospector.findUnwrappingNameTransformer(am);
/* 236 */     if (unwrapper != null) {
/* 237 */       bpw = bpw.unwrappingWriter(unwrapper);
/*     */     }
/* 239 */     return bpw;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BeanPropertyWriter _constructPropertyWriter(BeanPropertyDefinition propDef, AnnotatedMember member, Annotations contextAnnotations, JavaType declaredType, JsonSerializer<?> ser, TypeSerializer typeSer, JavaType serType, boolean suppressNulls, Object suppressableValue, Class<?>[] includeInViews) throws JsonMappingException {
/* 256 */     return new BeanPropertyWriter(propDef, member, contextAnnotations, declaredType, ser, typeSer, serType, suppressNulls, suppressableValue, includeInViews);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JavaType findSerializationType(Annotated a, boolean useStaticTyping, JavaType declaredType) throws JsonMappingException {
/* 276 */     JavaType secondary = this._annotationIntrospector.refineSerializationType((MapperConfig)this._config, a, declaredType);
/*     */ 
/*     */ 
/*     */     
/* 280 */     if (secondary != declaredType) {
/* 281 */       Class<?> serClass = secondary.getRawClass();
/*     */       
/* 283 */       Class<?> rawDeclared = declaredType.getRawClass();
/* 284 */       if (!serClass.isAssignableFrom(rawDeclared))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 293 */         if (!rawDeclared.isAssignableFrom(serClass)) {
/* 294 */           throw new IllegalArgumentException("Illegal concrete-type annotation for method '" + a.getName() + "': class " + serClass.getName() + " not a super-type of (declared) class " + rawDeclared.getName());
/*     */         }
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 301 */       useStaticTyping = true;
/* 302 */       declaredType = secondary;
/*     */     } 
/*     */     
/* 305 */     JsonSerialize.Typing typing = this._annotationIntrospector.findSerializationTyping(a);
/* 306 */     if (typing != null && typing != JsonSerialize.Typing.DEFAULT_TYPING) {
/* 307 */       useStaticTyping = (typing == JsonSerialize.Typing.STATIC);
/*     */     }
/* 309 */     if (useStaticTyping)
/*     */     {
/* 311 */       return declaredType.withStaticTyping();
/*     */     }
/*     */     
/* 314 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object getDefaultBean() {
/* 325 */     Object def = this._defaultBean;
/* 326 */     if (def == null) {
/*     */ 
/*     */ 
/*     */       
/* 330 */       def = this._beanDesc.instantiateBean(this._config.canOverrideAccessModifiers());
/* 331 */       if (def == null)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 339 */         def = NO_DEFAULT_MARKER;
/*     */       }
/* 341 */       this._defaultBean = def;
/*     */     } 
/* 343 */     return (def == NO_DEFAULT_MARKER) ? null : this._defaultBean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected Object getPropertyDefaultValue(String name, AnnotatedMember member, JavaType type) {
/* 365 */     Object defaultBean = getDefaultBean();
/* 366 */     if (defaultBean == null) {
/* 367 */       return getDefaultValue(type);
/*     */     }
/*     */     try {
/* 370 */       return member.getValue(defaultBean);
/* 371 */     } catch (Exception e) {
/* 372 */       return _throwWrapped(e, name, defaultBean);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected Object getDefaultValue(JavaType type) {
/* 381 */     return BeanUtil.getDefaultValue(type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object _throwWrapped(Exception e, String propName, Object defaultBean) {
/* 392 */     Throwable t = e;
/* 393 */     while (t.getCause() != null) {
/* 394 */       t = t.getCause();
/*     */     }
/* 396 */     ClassUtil.throwIfError(t);
/* 397 */     ClassUtil.throwIfRTE(t);
/* 398 */     throw new IllegalArgumentException("Failed to get property '" + propName + "' of default " + defaultBean.getClass().getName() + " instance");
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\ser\PropertyBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */