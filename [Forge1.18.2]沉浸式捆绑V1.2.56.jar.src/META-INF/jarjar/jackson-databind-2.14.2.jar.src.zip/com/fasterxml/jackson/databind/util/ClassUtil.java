/*      */ package com.fasterxml.jackson.databind.util;
/*      */ import com.fasterxml.jackson.core.JsonGenerator;
/*      */ import com.fasterxml.jackson.databind.JavaType;
/*      */ import java.io.Closeable;
/*      */ import java.io.IOException;
/*      */ import java.lang.annotation.Annotation;
/*      */ import java.lang.reflect.AccessibleObject;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.Member;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.EnumMap;
/*      */ import java.util.EnumSet;
/*      */ import java.util.List;
/*      */ 
/*      */ public final class ClassUtil {
/*   20 */   private static final Class<?> CLS_OBJECT = Object.class;
/*      */   
/*   22 */   private static final Annotation[] NO_ANNOTATIONS = new Annotation[0];
/*   23 */   private static final Ctor[] NO_CTORS = new Ctor[0];
/*      */   
/*   25 */   private static final Iterator<?> EMPTY_ITERATOR = Collections.emptyIterator();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Iterator<T> emptyIterator() {
/*   38 */     return (Iterator)EMPTY_ITERATOR;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<JavaType> findSuperTypes(JavaType type, Class<?> endBefore, boolean addClassItself) {
/*   63 */     if (type == null || type.hasRawClass(endBefore) || type.hasRawClass(Object.class)) {
/*   64 */       return Collections.emptyList();
/*      */     }
/*   66 */     List<JavaType> result = new ArrayList<>(8);
/*   67 */     _addSuperTypes(type, endBefore, result, addClassItself);
/*   68 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<Class<?>> findRawSuperTypes(Class<?> cls, Class<?> endBefore, boolean addClassItself) {
/*   75 */     if (cls == null || cls == endBefore || cls == Object.class) {
/*   76 */       return Collections.emptyList();
/*      */     }
/*   78 */     List<Class<?>> result = new ArrayList<>(8);
/*   79 */     _addRawSuperTypes(cls, endBefore, result, addClassItself);
/*   80 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<Class<?>> findSuperClasses(Class<?> cls, Class<?> endBefore, boolean addClassItself) {
/*   95 */     List<Class<?>> result = new ArrayList<>(8);
/*   96 */     if (cls != null && cls != endBefore) {
/*   97 */       if (addClassItself) {
/*   98 */         result.add(cls);
/*      */       }
/*  100 */       while ((cls = cls.getSuperclass()) != null && 
/*  101 */         cls != endBefore)
/*      */       {
/*      */         
/*  104 */         result.add(cls);
/*      */       }
/*      */     } 
/*  107 */     return result;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public static List<Class<?>> findSuperTypes(Class<?> cls, Class<?> endBefore) {
/*  112 */     return findSuperTypes(cls, endBefore, new ArrayList<>(8));
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public static List<Class<?>> findSuperTypes(Class<?> cls, Class<?> endBefore, List<Class<?>> result) {
/*  117 */     _addRawSuperTypes(cls, endBefore, result, false);
/*  118 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static void _addSuperTypes(JavaType type, Class<?> endBefore, Collection<JavaType> result, boolean addClassItself) {
/*  124 */     if (type == null) {
/*      */       return;
/*      */     }
/*  127 */     Class<?> cls = type.getRawClass();
/*  128 */     if (cls == endBefore || cls == Object.class)
/*  129 */       return;  if (addClassItself) {
/*  130 */       if (result.contains(type)) {
/*      */         return;
/*      */       }
/*  133 */       result.add(type);
/*      */     } 
/*  135 */     for (JavaType intCls : type.getInterfaces()) {
/*  136 */       _addSuperTypes(intCls, endBefore, result, true);
/*      */     }
/*  138 */     _addSuperTypes(type.getSuperClass(), endBefore, result, true);
/*      */   }
/*      */   
/*      */   private static void _addRawSuperTypes(Class<?> cls, Class<?> endBefore, Collection<Class<?>> result, boolean addClassItself) {
/*  142 */     if (cls == endBefore || cls == null || cls == Object.class)
/*  143 */       return;  if (addClassItself) {
/*  144 */       if (result.contains(cls)) {
/*      */         return;
/*      */       }
/*  147 */       result.add(cls);
/*      */     } 
/*  149 */     for (Class<?> intCls : _interfaces(cls)) {
/*  150 */       _addRawSuperTypes(intCls, endBefore, result, true);
/*      */     }
/*  152 */     _addRawSuperTypes(cls.getSuperclass(), endBefore, result, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String canBeABeanType(Class<?> type) {
/*  168 */     if (type.isAnnotation()) {
/*  169 */       return "annotation";
/*      */     }
/*  171 */     if (type.isArray()) {
/*  172 */       return "array";
/*      */     }
/*  174 */     if (Enum.class.isAssignableFrom(type)) {
/*  175 */       return "enum";
/*      */     }
/*  177 */     if (type.isPrimitive()) {
/*  178 */       return "primitive";
/*      */     }
/*      */ 
/*      */     
/*  182 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String isLocalType(Class<?> type, boolean allowNonStatic) {
/*      */     
/*  192 */     try { boolean isStatic = Modifier.isStatic(type.getModifiers());
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  197 */       if (!isStatic && hasEnclosingMethod(type)) {
/*  198 */         return "local/anonymous";
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  204 */       if (!allowNonStatic && 
/*  205 */         !isStatic && getEnclosingClass(type) != null) {
/*  206 */         return "non-static member class";
/*      */       
/*      */       } }
/*      */     
/*  210 */     catch (SecurityException securityException) {  }
/*  211 */     catch (NullPointerException nullPointerException) {}
/*  212 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Class<?> getOuterClass(Class<?> type) {
/*  221 */     if (!Modifier.isStatic(type.getModifiers())) {
/*      */       
/*      */       try {
/*  224 */         if (hasEnclosingMethod(type)) {
/*  225 */           return null;
/*      */         }
/*  227 */         return getEnclosingClass(type);
/*  228 */       } catch (SecurityException securityException) {}
/*      */     }
/*  230 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isProxyType(Class<?> type) {
/*  247 */     String name = type.getName();
/*      */     
/*  249 */     if (name.startsWith("net.sf.cglib.proxy.") || name
/*  250 */       .startsWith("org.hibernate.proxy.")) {
/*  251 */       return true;
/*      */     }
/*      */     
/*  254 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isConcrete(Class<?> type) {
/*  263 */     int mod = type.getModifiers();
/*  264 */     return ((mod & 0x600) == 0);
/*      */   }
/*      */ 
/*      */   
/*      */   public static boolean isConcrete(Member member) {
/*  269 */     int mod = member.getModifiers();
/*  270 */     return ((mod & 0x600) == 0);
/*      */   }
/*      */ 
/*      */   
/*      */   public static boolean isCollectionMapOrArray(Class<?> type) {
/*  275 */     if (type.isArray()) return true; 
/*  276 */     if (Collection.class.isAssignableFrom(type)) return true; 
/*  277 */     if (Map.class.isAssignableFrom(type)) return true; 
/*  278 */     return false;
/*      */   }
/*      */   
/*      */   public static boolean isBogusClass(Class<?> cls) {
/*  282 */     return (cls == Void.class || cls == void.class || cls == NoClass.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isRecordType(Class<?> cls) {
/*  292 */     Class<?> parent = cls.getSuperclass();
/*  293 */     return (parent != null && "java.lang.Record".equals(parent.getName()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isObjectOrPrimitive(Class<?> cls) {
/*  300 */     return (cls == CLS_OBJECT || cls.isPrimitive());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean hasClass(Object inst, Class<?> raw) {
/*  309 */     return (inst != null && inst.getClass() == raw);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void verifyMustOverride(Class<?> expType, Object instance, String method) {
/*  318 */     if (instance.getClass() != expType) {
/*  319 */       throw new IllegalStateException(String.format("Sub-class %s (of class %s) must override method '%s'", new Object[] { instance
/*      */               
/*  321 */               .getClass().getName(), expType.getName(), method }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static boolean hasGetterSignature(Method m) {
/*  338 */     if (Modifier.isStatic(m.getModifiers())) {
/*  339 */       return false;
/*      */     }
/*      */     
/*  342 */     Class<?>[] pts = m.getParameterTypes();
/*  343 */     if (pts != null && pts.length != 0) {
/*  344 */       return false;
/*      */     }
/*      */     
/*  347 */     if (void.class == m.getReturnType()) {
/*  348 */       return false;
/*      */     }
/*      */     
/*  351 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Throwable throwIfError(Throwable t) {
/*  367 */     if (t instanceof Error) {
/*  368 */       throw (Error)t;
/*      */     }
/*  370 */     return t;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Throwable throwIfRTE(Throwable t) {
/*  380 */     if (t instanceof RuntimeException) {
/*  381 */       throw (RuntimeException)t;
/*      */     }
/*  383 */     return t;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Throwable throwIfIOE(Throwable t) throws IOException {
/*  393 */     if (t instanceof IOException) {
/*  394 */       throw (IOException)t;
/*      */     }
/*  396 */     return t;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Throwable getRootCause(Throwable t) {
/*  411 */     while (t.getCause() != null) {
/*  412 */       t = t.getCause();
/*      */     }
/*  414 */     return t;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Throwable throwRootCauseIfIOE(Throwable t) throws IOException {
/*  425 */     return throwIfIOE(getRootCause(t));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void throwAsIAE(Throwable t) {
/*  433 */     throwAsIAE(t, t.getMessage());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void throwAsIAE(Throwable t, String msg) {
/*  443 */     throwIfRTE(t);
/*  444 */     throwIfError(t);
/*  445 */     throw new IllegalArgumentException(msg, t);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T throwAsMappingException(DeserializationContext ctxt, IOException e0) throws JsonMappingException {
/*  453 */     if (e0 instanceof JsonMappingException) {
/*  454 */       throw (JsonMappingException)e0;
/*      */     }
/*  456 */     throw JsonMappingException.from(ctxt, e0.getMessage())
/*  457 */       .withCause(e0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void unwrapAndThrowAsIAE(Throwable t) {
/*  467 */     throwAsIAE(getRootCause(t));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void unwrapAndThrowAsIAE(Throwable t, String msg) {
/*  477 */     throwAsIAE(getRootCause(t), msg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void closeOnFailAndThrowAsIOE(JsonGenerator g, Exception fail) throws IOException {
/*  494 */     g.disable(JsonGenerator.Feature.AUTO_CLOSE_JSON_CONTENT);
/*      */     try {
/*  496 */       g.close();
/*  497 */     } catch (Exception e) {
/*  498 */       fail.addSuppressed(e);
/*      */     } 
/*  500 */     throwIfIOE(fail);
/*  501 */     throwIfRTE(fail);
/*  502 */     throw new RuntimeException(fail);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void closeOnFailAndThrowAsIOE(JsonGenerator g, Closeable toClose, Exception fail) throws IOException {
/*  518 */     if (g != null) {
/*  519 */       g.disable(JsonGenerator.Feature.AUTO_CLOSE_JSON_CONTENT);
/*      */       try {
/*  521 */         g.close();
/*  522 */       } catch (Exception e) {
/*  523 */         fail.addSuppressed(e);
/*      */       } 
/*      */     } 
/*  526 */     if (toClose != null) {
/*      */       try {
/*  528 */         toClose.close();
/*  529 */       } catch (Exception e) {
/*  530 */         fail.addSuppressed(e);
/*      */       } 
/*      */     }
/*  533 */     throwIfIOE(fail);
/*  534 */     throwIfRTE(fail);
/*  535 */     throw new RuntimeException(fail);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T createInstance(Class<T> cls, boolean canFixAccess) throws IllegalArgumentException {
/*  560 */     Constructor<T> ctor = findConstructor(cls, canFixAccess);
/*  561 */     if (ctor == null) {
/*  562 */       throw new IllegalArgumentException("Class " + cls.getName() + " has no default (no arg) constructor");
/*      */     }
/*      */     try {
/*  565 */       return ctor.newInstance(new Object[0]);
/*  566 */     } catch (Exception e) {
/*  567 */       unwrapAndThrowAsIAE(e, "Failed to instantiate class " + cls.getName() + ", problem: " + e.getMessage());
/*  568 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Constructor<T> findConstructor(Class<T> cls, boolean forceAccess) throws IllegalArgumentException {
/*      */     try {
/*  576 */       Constructor<T> ctor = cls.getDeclaredConstructor(new Class[0]);
/*  577 */       if (forceAccess) {
/*  578 */         checkAndFixAccess(ctor, forceAccess);
/*      */       
/*      */       }
/*  581 */       else if (!Modifier.isPublic(ctor.getModifiers())) {
/*  582 */         throw new IllegalArgumentException("Default constructor for " + cls.getName() + " is not accessible (non-public?): not allowed to try modify access via Reflection: cannot instantiate type");
/*      */       } 
/*      */       
/*  585 */       return ctor;
/*  586 */     } catch (NoSuchMethodException noSuchMethodException) {
/*      */     
/*  588 */     } catch (Exception e) {
/*  589 */       unwrapAndThrowAsIAE(e, "Failed to find default constructor of class " + cls.getName() + ", problem: " + e.getMessage());
/*      */     } 
/*  591 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Class<?> classOf(Object inst) {
/*  604 */     if (inst == null) {
/*  605 */       return null;
/*      */     }
/*  607 */     return inst.getClass();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Class<?> rawClass(JavaType t) {
/*  614 */     if (t == null) {
/*  615 */       return null;
/*      */     }
/*  617 */     return t.getRawClass();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T nonNull(T valueOrNull, T defaultValue) {
/*  624 */     return (valueOrNull == null) ? defaultValue : valueOrNull;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String nullOrToString(Object value) {
/*  631 */     if (value == null) {
/*  632 */       return null;
/*      */     }
/*  634 */     return value.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String nonNullString(String str) {
/*  641 */     if (str == null) {
/*  642 */       return "";
/*      */     }
/*  644 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String quotedOr(Object str, String forNull) {
/*  654 */     if (str == null) {
/*  655 */       return forNull;
/*      */     }
/*  657 */     return String.format("\"%s\"", new Object[] { str });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getClassDescription(Object classOrInstance) {
/*  673 */     if (classOrInstance == null) {
/*  674 */       return "unknown";
/*      */     }
/*      */     
/*  677 */     Class<?> cls = (classOrInstance instanceof Class) ? (Class)classOrInstance : classOrInstance.getClass();
/*  678 */     return nameOf(cls);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getTypeDescription(JavaType fullType) {
/*  694 */     if (fullType == null) {
/*  695 */       return "[null]";
/*      */     }
/*  697 */     StringBuilder sb = (new StringBuilder(80)).append('`');
/*  698 */     sb.append(fullType.toCanonical());
/*  699 */     return sb.append('`').toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String classNameOf(Object inst) {
/*  710 */     if (inst == null) {
/*  711 */       return "[null]";
/*      */     }
/*  713 */     Class<?> raw = (inst instanceof Class) ? (Class)inst : inst.getClass();
/*  714 */     return nameOf(raw);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String nameOf(Class<?> cls) {
/*  724 */     if (cls == null) {
/*  725 */       return "[null]";
/*      */     }
/*  727 */     int index = 0;
/*  728 */     while (cls.isArray()) {
/*  729 */       index++;
/*  730 */       cls = cls.getComponentType();
/*      */     } 
/*  732 */     String base = cls.isPrimitive() ? cls.getSimpleName() : cls.getName();
/*  733 */     if (index > 0) {
/*  734 */       StringBuilder sb = new StringBuilder(base);
/*      */       while (true) {
/*  736 */         sb.append("[]");
/*  737 */         if (--index <= 0)
/*  738 */         { base = sb.toString(); break; } 
/*      */       } 
/*  740 */     }  return backticked(base);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String nameOf(Named named) {
/*  753 */     if (named == null) {
/*  754 */       return "[null]";
/*      */     }
/*  756 */     return apostrophed(named.getName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String name(String name) {
/*  766 */     if (name == null) {
/*  767 */       return "[null]";
/*      */     }
/*  769 */     return apostrophed(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String name(PropertyName name) {
/*  779 */     if (name == null) {
/*  780 */       return "[null]";
/*      */     }
/*      */     
/*  783 */     return apostrophed(name.getSimpleName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String backticked(String text) {
/*  798 */     if (text == null) {
/*  799 */       return "[null]";
/*      */     }
/*  801 */     return (new StringBuilder(text.length() + 2)).append('`').append(text).append('`').toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String apostrophed(String text) {
/*  810 */     if (text == null) {
/*  811 */       return "[null]";
/*      */     }
/*  813 */     return (new StringBuilder(text.length() + 2)).append('\'').append(text).append('\'').toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String exceptionMessage(Throwable t) {
/*  827 */     if (t instanceof JacksonException) {
/*  828 */       return ((JacksonException)t).getOriginalMessage();
/*      */     }
/*  830 */     if (t instanceof java.lang.reflect.InvocationTargetException && t.getCause() != null) {
/*  831 */       return t.getCause().getMessage();
/*      */     }
/*  833 */     return t.getMessage();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object defaultValue(Class<?> cls) {
/*  848 */     if (cls == int.class) {
/*  849 */       return Integer.valueOf(0);
/*      */     }
/*  851 */     if (cls == long.class) {
/*  852 */       return Long.valueOf(0L);
/*      */     }
/*  854 */     if (cls == boolean.class) {
/*  855 */       return Boolean.FALSE;
/*      */     }
/*  857 */     if (cls == double.class) {
/*  858 */       return Double.valueOf(0.0D);
/*      */     }
/*  860 */     if (cls == float.class) {
/*  861 */       return Float.valueOf(0.0F);
/*      */     }
/*  863 */     if (cls == byte.class) {
/*  864 */       return Byte.valueOf((byte)0);
/*      */     }
/*  866 */     if (cls == short.class) {
/*  867 */       return Short.valueOf((short)0);
/*      */     }
/*  869 */     if (cls == char.class) {
/*  870 */       return Character.valueOf(false);
/*      */     }
/*  872 */     throw new IllegalArgumentException("Class " + cls.getName() + " is not a primitive type");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Class<?> wrapperType(Class<?> primitiveType) {
/*  883 */     if (primitiveType == int.class) {
/*  884 */       return Integer.class;
/*      */     }
/*  886 */     if (primitiveType == long.class) {
/*  887 */       return Long.class;
/*      */     }
/*  889 */     if (primitiveType == boolean.class) {
/*  890 */       return Boolean.class;
/*      */     }
/*  892 */     if (primitiveType == double.class) {
/*  893 */       return Double.class;
/*      */     }
/*  895 */     if (primitiveType == float.class) {
/*  896 */       return Float.class;
/*      */     }
/*  898 */     if (primitiveType == byte.class) {
/*  899 */       return Byte.class;
/*      */     }
/*  901 */     if (primitiveType == short.class) {
/*  902 */       return Short.class;
/*      */     }
/*  904 */     if (primitiveType == char.class) {
/*  905 */       return Character.class;
/*      */     }
/*  907 */     throw new IllegalArgumentException("Class " + primitiveType.getName() + " is not a primitive type");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Class<?> primitiveType(Class<?> type) {
/*  918 */     if (type.isPrimitive()) {
/*  919 */       return type;
/*      */     }
/*      */     
/*  922 */     if (type == Integer.class) {
/*  923 */       return int.class;
/*      */     }
/*  925 */     if (type == Long.class) {
/*  926 */       return long.class;
/*      */     }
/*  928 */     if (type == Boolean.class) {
/*  929 */       return boolean.class;
/*      */     }
/*  931 */     if (type == Double.class) {
/*  932 */       return double.class;
/*      */     }
/*  934 */     if (type == Float.class) {
/*  935 */       return float.class;
/*      */     }
/*  937 */     if (type == Byte.class) {
/*  938 */       return byte.class;
/*      */     }
/*  940 */     if (type == Short.class) {
/*  941 */       return short.class;
/*      */     }
/*  943 */     if (type == Character.class) {
/*  944 */       return char.class;
/*      */     }
/*  946 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static void checkAndFixAccess(Member member) {
/*  965 */     checkAndFixAccess(member, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkAndFixAccess(Member member, boolean evenIfAlreadyPublic) {
/*  983 */     AccessibleObject ao = (AccessibleObject)member;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  991 */       Class<?> declaringClass = member.getDeclaringClass();
/*      */       
/*  993 */       boolean isPublic = (Modifier.isPublic(member.getModifiers()) && Modifier.isPublic(declaringClass.getModifiers()));
/*  994 */       if (!isPublic || (evenIfAlreadyPublic && !isJDKClass(declaringClass))) {
/*  995 */         ao.setAccessible(true);
/*      */       }
/*  997 */     } catch (SecurityException se) {
/*      */ 
/*      */       
/* 1000 */       if (!ao.isAccessible()) {
/* 1001 */         Class<?> declClass = member.getDeclaringClass();
/* 1002 */         throw new IllegalArgumentException("Cannot access " + member + " (from class " + declClass.getName() + "; failed to set access: " + se.getMessage());
/*      */       }
/*      */     
/*      */     }
/* 1006 */     catch (RuntimeException se) {
/* 1007 */       if ("InaccessibleObjectException".equals(se.getClass().getSimpleName())) {
/* 1008 */         throw new IllegalArgumentException(String.format("Failed to call `setAccess()` on %s '%s' (of class %s) due to `%s`, problem: %s", new Object[] { member
/*      */                 
/* 1010 */                 .getClass().getSimpleName(), member.getName(), 
/* 1011 */                 nameOf(member.getDeclaringClass()), se
/* 1012 */                 .getClass().getName(), se.getMessage() }), se);
/*      */       }
/*      */       
/* 1015 */       throw se;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isEnumType(Class<?> rawType) {
/* 1032 */     return Enum.class.isAssignableFrom(rawType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Class<? extends Enum<?>> findEnumType(EnumSet<?> s) {
/* 1044 */     if (!s.isEmpty()) {
/* 1045 */       return findEnumType(s.iterator().next());
/*      */     }
/*      */     
/* 1048 */     return EnumTypeLocator.instance.enumTypeFor(s);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Class<? extends Enum<?>> findEnumType(EnumMap<?, ?> m) {
/* 1059 */     if (!m.isEmpty()) {
/* 1060 */       return findEnumType(m.keySet().iterator().next());
/*      */     }
/*      */     
/* 1063 */     return EnumTypeLocator.instance.enumTypeFor(m);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Class<? extends Enum<?>> findEnumType(Enum<?> en) {
/* 1075 */     return (Class)en.getDeclaringClass();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Class<? extends Enum<?>> findEnumType(Class<?> cls) {
/* 1088 */     if (cls.getSuperclass() != Enum.class) {
/* 1089 */       cls = cls.getSuperclass();
/*      */     }
/* 1091 */     return (Class)cls;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Annotation> Enum<?> findFirstAnnotatedEnumValue(Class<Enum<?>> enumClass, Class<T> annotationClass) {
/* 1107 */     Field[] fields = enumClass.getDeclaredFields();
/* 1108 */     for (Field field : fields) {
/* 1109 */       if (field.isEnumConstant()) {
/* 1110 */         Annotation defaultValueAnnotation = field.getAnnotation(annotationClass);
/* 1111 */         if (defaultValueAnnotation != null) {
/* 1112 */           String name = field.getName();
/* 1113 */           for (Enum<?> enumValue : (Enum[])enumClass.getEnumConstants()) {
/* 1114 */             if (name.equals(enumValue.name())) {
/* 1115 */               return enumValue;
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/* 1121 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isJacksonStdImpl(Object impl) {
/* 1141 */     return (impl == null || isJacksonStdImpl(impl.getClass()));
/*      */   }
/*      */   
/*      */   public static boolean isJacksonStdImpl(Class<?> implClass) {
/* 1145 */     return (implClass.getAnnotation(JacksonStdImpl.class) != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isJDKClass(Class<?> rawType) {
/* 1162 */     String clsName = rawType.getName();
/* 1163 */     return (clsName.startsWith("java.") || clsName.startsWith("javax."));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isNonStaticInnerClass(Class<?> cls) {
/* 1176 */     return (!Modifier.isStatic(cls.getModifiers()) && 
/* 1177 */       getEnclosingClass(cls) != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static String getPackageName(Class<?> cls) {
/* 1187 */     Package pkg = cls.getPackage();
/* 1188 */     return (pkg == null) ? null : pkg.getName();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean hasEnclosingMethod(Class<?> cls) {
/* 1195 */     return (!isObjectOrPrimitive(cls) && cls.getEnclosingMethod() != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Field[] getDeclaredFields(Class<?> cls) {
/* 1203 */     return cls.getDeclaredFields();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Method[] getDeclaredMethods(Class<?> cls) {
/* 1211 */     return cls.getDeclaredMethods();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Annotation[] findClassAnnotations(Class<?> cls) {
/* 1218 */     if (isObjectOrPrimitive(cls)) {
/* 1219 */       return NO_ANNOTATIONS;
/*      */     }
/* 1221 */     return cls.getDeclaredAnnotations();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Method[] getClassMethods(Class<?> cls) {
/*      */     try {
/* 1234 */       return cls.getDeclaredMethods();
/* 1235 */     } catch (NoClassDefFoundError ex) {
/*      */       Class<?> contextClass;
/*      */       
/* 1238 */       ClassLoader loader = Thread.currentThread().getContextClassLoader();
/* 1239 */       if (loader == null)
/*      */       {
/* 1241 */         return _failGetClassMethods(cls, ex);
/*      */       }
/*      */       
/*      */       try {
/* 1245 */         contextClass = loader.loadClass(cls.getName());
/* 1246 */       } catch (ClassNotFoundException e) {
/* 1247 */         ex.addSuppressed(e);
/* 1248 */         return _failGetClassMethods(cls, ex);
/*      */       } 
/*      */       try {
/* 1251 */         return contextClass.getDeclaredMethods();
/* 1252 */       } catch (Throwable t) {
/* 1253 */         return _failGetClassMethods(cls, t);
/*      */       } 
/* 1255 */     } catch (Throwable t) {
/* 1256 */       return _failGetClassMethods(cls, t);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Method[] _failGetClassMethods(Class<?> cls, Throwable rootCause) throws IllegalArgumentException {
/* 1264 */     throw new IllegalArgumentException(String.format("Failed on call to `getDeclaredMethods()` on class `%s`, problem: (%s) %s", new Object[] { cls
/*      */             
/* 1266 */             .getName(), rootCause.getClass().getName(), rootCause.getMessage() }), rootCause);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ctor[] getConstructors(Class<?> cls) {
/* 1276 */     if (cls.isInterface() || isObjectOrPrimitive(cls)) {
/* 1277 */       return NO_CTORS;
/*      */     }
/* 1279 */     Constructor[] arrayOfConstructor = (Constructor[])cls.getDeclaredConstructors();
/* 1280 */     int len = arrayOfConstructor.length;
/* 1281 */     Ctor[] result = new Ctor[len];
/* 1282 */     for (int i = 0; i < len; i++) {
/* 1283 */       result[i] = new Ctor(arrayOfConstructor[i]);
/*      */     }
/* 1285 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Class<?> getDeclaringClass(Class<?> cls) {
/* 1295 */     return isObjectOrPrimitive(cls) ? null : cls.getDeclaringClass();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Type getGenericSuperclass(Class<?> cls) {
/* 1302 */     return cls.getGenericSuperclass();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Type[] getGenericInterfaces(Class<?> cls) {
/* 1309 */     return cls.getGenericInterfaces();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Class<?> getEnclosingClass(Class<?> cls) {
/* 1317 */     return isObjectOrPrimitive(cls) ? null : cls.getEnclosingClass();
/*      */   }
/*      */   
/*      */   private static Class<?>[] _interfaces(Class<?> cls) {
/* 1321 */     return cls.getInterfaces();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class EnumTypeLocator
/*      */   {
/* 1336 */     static final EnumTypeLocator instance = new EnumTypeLocator();
/*      */     
/*      */     private final Field enumSetTypeField;
/*      */     
/*      */     private final Field enumMapTypeField;
/*      */     
/*      */     private final String failForEnumSet;
/*      */     
/*      */     private final String failForEnumMap;
/*      */ 
/*      */     
/*      */     private EnumTypeLocator() {
/* 1348 */       Field f = null;
/* 1349 */       String msg = null;
/*      */       
/*      */       try {
/* 1352 */         f = locateField(EnumSet.class, "elementType", Class.class);
/* 1353 */       } catch (Exception e) {
/* 1354 */         msg = e.toString();
/*      */       } 
/* 1356 */       this.enumSetTypeField = f;
/* 1357 */       this.failForEnumSet = msg;
/*      */       
/* 1359 */       f = null;
/* 1360 */       msg = null;
/*      */       try {
/* 1362 */         f = locateField(EnumMap.class, "keyType", Class.class);
/* 1363 */       } catch (Exception e) {
/* 1364 */         msg = e.toString();
/*      */       } 
/* 1366 */       this.enumMapTypeField = f;
/* 1367 */       this.failForEnumMap = msg;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Class<? extends Enum<?>> enumTypeFor(EnumSet<?> set) {
/* 1373 */       if (this.enumSetTypeField != null) {
/* 1374 */         return (Class<? extends Enum<?>>)get(set, this.enumSetTypeField);
/*      */       }
/* 1376 */       throw new IllegalStateException("Cannot figure out type parameter for `EnumSet` (odd JDK platform?), problem: " + this.failForEnumSet);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Class<? extends Enum<?>> enumTypeFor(EnumMap<?, ?> set) {
/* 1383 */       if (this.enumMapTypeField != null) {
/* 1384 */         return (Class<? extends Enum<?>>)get(set, this.enumMapTypeField);
/*      */       }
/* 1386 */       throw new IllegalStateException("Cannot figure out type parameter for `EnumMap` (odd JDK platform?), problem: " + this.failForEnumMap);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private Object get(Object bean, Field field) {
/*      */       try {
/* 1393 */         return field.get(bean);
/* 1394 */       } catch (Exception e) {
/* 1395 */         throw new IllegalArgumentException(e);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static Field locateField(Class<?> fromClass, String expectedName, Class<?> type) throws Exception {
/* 1403 */       Field[] fields = fromClass.getDeclaredFields(); Field[] arrayOfField1; int i; byte b;
/* 1404 */       for (arrayOfField1 = fields, i = arrayOfField1.length, b = 0; b < i; ) { Field f = arrayOfField1[b];
/* 1405 */         if (!expectedName.equals(f.getName()) || f.getType() != type) {
/*      */           b++; continue;
/*      */         } 
/* 1408 */         f.setAccessible(true);
/* 1409 */         return f; }
/*      */ 
/*      */       
/* 1412 */       throw new IllegalStateException(String.format("No field named '%s' in class '%s'", new Object[] { expectedName, fromClass
/* 1413 */               .getName() }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final class Ctor
/*      */   {
/*      */     public final Constructor<?> _ctor;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private transient Annotation[] _annotations;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private transient Annotation[][] _paramAnnotations;
/*      */ 
/*      */ 
/*      */     
/* 1437 */     private int _paramCount = -1;
/*      */     
/*      */     public Ctor(Constructor<?> ctor) {
/* 1440 */       this._ctor = ctor;
/*      */     }
/*      */     
/*      */     public Constructor<?> getConstructor() {
/* 1444 */       return this._ctor;
/*      */     }
/*      */     
/*      */     public int getParamCount() {
/* 1448 */       int c = this._paramCount;
/* 1449 */       if (c < 0) {
/* 1450 */         c = this._ctor.getParameterCount();
/* 1451 */         this._paramCount = c;
/*      */       } 
/* 1453 */       return c;
/*      */     }
/*      */     
/*      */     public Class<?> getDeclaringClass() {
/* 1457 */       return this._ctor.getDeclaringClass();
/*      */     }
/*      */     
/*      */     public Annotation[] getDeclaredAnnotations() {
/* 1461 */       Annotation[] result = this._annotations;
/* 1462 */       if (result == null) {
/* 1463 */         result = this._ctor.getDeclaredAnnotations();
/* 1464 */         this._annotations = result;
/*      */       } 
/* 1466 */       return result;
/*      */     }
/*      */     
/*      */     public Annotation[][] getParameterAnnotations() {
/* 1470 */       Annotation[][] result = this._paramAnnotations;
/* 1471 */       if (result == null) {
/* 1472 */         result = this._ctor.getParameterAnnotations();
/* 1473 */         this._paramAnnotations = result;
/*      */       } 
/* 1475 */       return result;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databin\\util\ClassUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */