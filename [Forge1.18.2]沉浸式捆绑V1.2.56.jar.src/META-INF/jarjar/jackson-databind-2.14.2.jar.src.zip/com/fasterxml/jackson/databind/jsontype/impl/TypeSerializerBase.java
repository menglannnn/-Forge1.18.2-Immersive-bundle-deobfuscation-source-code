/*     */ package com.fasterxml.jackson.databind.jsontype.impl;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonTypeInfo;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.type.WritableTypeId;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeIdResolver;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TypeSerializerBase
/*     */   extends TypeSerializer
/*     */ {
/*     */   protected final TypeIdResolver _idResolver;
/*     */   protected final BeanProperty _property;
/*     */   
/*     */   protected TypeSerializerBase(TypeIdResolver idRes, BeanProperty property) {
/*  22 */     this._idResolver = idRes;
/*  23 */     this._property = property;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract JsonTypeInfo.As getTypeInclusion();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPropertyName() {
/*  36 */     return null;
/*     */   }
/*     */   public TypeIdResolver getTypeIdResolver() {
/*  39 */     return this._idResolver;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public WritableTypeId writeTypePrefix(JsonGenerator g, WritableTypeId idMetadata) throws IOException {
/*  45 */     _generateTypeId(idMetadata);
/*     */ 
/*     */ 
/*     */     
/*  49 */     if (idMetadata.id == null) {
/*  50 */       return null;
/*     */     }
/*  52 */     return g.writeTypePrefix(idMetadata);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WritableTypeId writeTypeSuffix(JsonGenerator g, WritableTypeId idMetadata) throws IOException {
/*  60 */     if (idMetadata == null) {
/*  61 */       return null;
/*     */     }
/*  63 */     return g.writeTypeSuffix(idMetadata);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _generateTypeId(WritableTypeId idMetadata) {
/*  72 */     Object id = idMetadata.id;
/*  73 */     if (id == null) {
/*  74 */       Object value = idMetadata.forValue;
/*  75 */       Class<?> typeForId = idMetadata.forValueType;
/*  76 */       if (typeForId == null) {
/*  77 */         id = idFromValue(value);
/*     */       } else {
/*  79 */         id = idFromValueAndType(value, typeForId);
/*     */       } 
/*  81 */       idMetadata.id = id;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String idFromValue(Object value) {
/*  92 */     String id = this._idResolver.idFromValue(value);
/*  93 */     if (id == null) {
/*  94 */       handleMissingId(value);
/*     */     }
/*  96 */     return id;
/*     */   }
/*     */   
/*     */   protected String idFromValueAndType(Object value, Class<?> type) {
/* 100 */     String id = this._idResolver.idFromValueAndType(value, type);
/* 101 */     if (id == null) {
/* 102 */       handleMissingId(value);
/*     */     }
/* 104 */     return id;
/*     */   }
/*     */   
/*     */   protected void handleMissingId(Object value) {}
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\jsontype\impl\TypeSerializerBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */