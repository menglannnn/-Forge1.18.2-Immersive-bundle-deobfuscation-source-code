/*     */ package com.fasterxml.jackson.databind.node;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.util.RawValue;
/*     */ import java.io.Serializable;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JsonNodeFactory
/*     */   implements Serializable, JsonNodeCreator
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected static final int MAX_ELEMENT_INDEX_FOR_INSERT = 9999;
/*     */   private final boolean _cfgBigDecimalExact;
/*  31 */   private static final JsonNodeFactory decimalsNormalized = new JsonNodeFactory(false);
/*     */   
/*  33 */   private static final JsonNodeFactory decimalsAsIs = new JsonNodeFactory(true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  41 */   public static final JsonNodeFactory instance = decimalsNormalized;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonNodeFactory(boolean bigDecimalExact) {
/*  70 */     this._cfgBigDecimalExact = bigDecimalExact;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonNodeFactory() {
/*  81 */     this(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JsonNodeFactory withExactBigDecimals(boolean bigDecimalExact) {
/*  93 */     return bigDecimalExact ? decimalsAsIs : decimalsNormalized;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxElementIndexForInsert() {
/* 106 */     return 9999;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BooleanNode booleanNode(boolean v) {
/* 121 */     return v ? BooleanNode.getTrue() : BooleanNode.getFalse();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NullNode nullNode() {
/* 129 */     return NullNode.getInstance();
/*     */   }
/*     */   public JsonNode missingNode() {
/* 132 */     return MissingNode.getInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NumericNode numberNode(byte v) {
/* 146 */     return IntNode.valueOf(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValueNode numberNode(Byte value) {
/* 156 */     return (value == null) ? nullNode() : IntNode.valueOf(value.intValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NumericNode numberNode(short v) {
/* 164 */     return ShortNode.valueOf(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValueNode numberNode(Short value) {
/* 174 */     return (value == null) ? nullNode() : ShortNode.valueOf(value.shortValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NumericNode numberNode(int v) {
/* 182 */     return IntNode.valueOf(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValueNode numberNode(Integer value) {
/* 192 */     return (value == null) ? nullNode() : IntNode.valueOf(value.intValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NumericNode numberNode(long v) {
/* 201 */     return LongNode.valueOf(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValueNode numberNode(Long v) {
/* 211 */     if (v == null) {
/* 212 */       return nullNode();
/*     */     }
/* 214 */     return LongNode.valueOf(v.longValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValueNode numberNode(BigInteger v) {
/* 223 */     if (v == null) {
/* 224 */       return nullNode();
/*     */     }
/* 226 */     return BigIntegerNode.valueOf(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NumericNode numberNode(float v) {
/* 234 */     return FloatNode.valueOf(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValueNode numberNode(Float value) {
/* 244 */     return (value == null) ? nullNode() : FloatNode.valueOf(value.floatValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NumericNode numberNode(double v) {
/* 252 */     return DoubleNode.valueOf(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValueNode numberNode(Double value) {
/* 262 */     return (value == null) ? nullNode() : DoubleNode.valueOf(value.doubleValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValueNode numberNode(BigDecimal v) {
/* 278 */     if (v == null) {
/* 279 */       return nullNode();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 285 */     if (this._cfgBigDecimalExact) {
/* 286 */       return DecimalNode.valueOf(v);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 299 */     if (v.signum() == 0) {
/* 300 */       return DecimalNode.ZERO;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 306 */       v = v.stripTrailingZeros();
/* 307 */     } catch (ArithmeticException arithmeticException) {}
/*     */ 
/*     */ 
/*     */     
/* 311 */     return DecimalNode.valueOf(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TextNode textNode(String text) {
/* 325 */     return TextNode.valueOf(text);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BinaryNode binaryNode(byte[] data) {
/* 333 */     return BinaryNode.valueOf(data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BinaryNode binaryNode(byte[] data, int offset, int length) {
/* 342 */     return BinaryNode.valueOf(data, offset, length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayNode arrayNode() {
/* 355 */     return new ArrayNode(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayNode arrayNode(int capacity) {
/* 363 */     return new ArrayNode(this, capacity);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectNode objectNode() {
/* 369 */     return new ObjectNode(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValueNode pojoNode(Object pojo) {
/* 378 */     return new POJONode(pojo);
/*     */   }
/*     */   
/*     */   public ValueNode rawValueNode(RawValue value) {
/* 382 */     return new POJONode(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean _inIntRange(long l) {
/* 393 */     int i = (int)l;
/* 394 */     long l2 = i;
/* 395 */     return (l2 == l);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\node\JsonNodeFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */