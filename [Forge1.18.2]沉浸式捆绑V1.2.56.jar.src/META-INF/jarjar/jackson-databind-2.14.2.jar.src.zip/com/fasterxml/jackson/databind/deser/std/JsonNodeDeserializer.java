/*     */ package com.fasterxml.jackson.databind.deser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JacksonException;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*     */ import com.fasterxml.jackson.databind.node.ArrayNode;
/*     */ import com.fasterxml.jackson.databind.node.ContainerNode;
/*     */ import com.fasterxml.jackson.databind.node.JsonNodeFactory;
/*     */ import com.fasterxml.jackson.databind.node.ObjectNode;
/*     */ import com.fasterxml.jackson.databind.type.LogicalType;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JsonNodeDeserializer
/*     */   extends BaseNodeDeserializer<JsonNode>
/*     */ {
/*  31 */   private static final JsonNodeDeserializer instance = new JsonNodeDeserializer();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonNodeDeserializer() {
/*  37 */     super(JsonNode.class, null);
/*     */   }
/*     */ 
/*     */   
/*     */   protected JsonNodeDeserializer(JsonNodeDeserializer base, boolean mergeArrays, boolean mergeObjects) {
/*  42 */     super(base, mergeArrays, mergeObjects);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonDeserializer<?> _createWithMerge(boolean mergeArrays, boolean mergeObjects) {
/*  48 */     return new JsonNodeDeserializer(this, mergeArrays, mergeObjects);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JsonDeserializer<? extends JsonNode> getDeserializer(Class<?> nodeClass) {
/*  56 */     if (nodeClass == ObjectNode.class) {
/*  57 */       return ObjectDeserializer.getInstance();
/*     */     }
/*  59 */     if (nodeClass == ArrayNode.class) {
/*  60 */       return ArrayDeserializer.getInstance();
/*     */     }
/*     */     
/*  63 */     return instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonNode getNullValue(DeserializationContext ctxt) {
/*  74 */     return (JsonNode)ctxt.getNodeFactory().nullNode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getAbsentValue(DeserializationContext ctxt) {
/*  83 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonNode deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  94 */     BaseNodeDeserializer.ContainerStack stack = new BaseNodeDeserializer.ContainerStack();
/*  95 */     JsonNodeFactory nodeF = ctxt.getNodeFactory();
/*  96 */     switch (p.currentTokenId()) {
/*     */       case 1:
/*  98 */         return (JsonNode)_deserializeContainerNoRecursion(p, ctxt, nodeF, stack, (ContainerNode<?>)nodeF.objectNode());
/*     */       case 2:
/* 100 */         return (JsonNode)nodeF.objectNode();
/*     */       case 3:
/* 102 */         return (JsonNode)_deserializeContainerNoRecursion(p, ctxt, nodeF, stack, (ContainerNode<?>)nodeF.arrayNode());
/*     */       case 5:
/* 104 */         return (JsonNode)_deserializeObjectAtName(p, ctxt, nodeF, stack);
/*     */     } 
/*     */     
/* 107 */     return _deserializeAnyScalar(p, ctxt);
/*     */   }
/*     */ 
/*     */   
/*     */   public Boolean supportsUpdate(DeserializationConfig config) {
/* 112 */     return this._supportsUpdates;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class ObjectDeserializer
/*     */     extends BaseNodeDeserializer<ObjectNode>
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 129 */     protected static final ObjectDeserializer _instance = new ObjectDeserializer();
/*     */     protected ObjectDeserializer() {
/* 131 */       super(ObjectNode.class, Boolean.valueOf(true));
/*     */     } public static ObjectDeserializer getInstance() {
/* 133 */       return _instance;
/*     */     }
/*     */     
/*     */     protected ObjectDeserializer(ObjectDeserializer base, boolean mergeArrays, boolean mergeObjects) {
/* 137 */       super(base, mergeArrays, mergeObjects);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected JsonDeserializer<?> _createWithMerge(boolean mergeArrays, boolean mergeObjects) {
/* 143 */       return new ObjectDeserializer(this, mergeArrays, mergeObjects);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public ObjectNode deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 149 */       JsonNodeFactory nodeF = ctxt.getNodeFactory();
/* 150 */       if (p.isExpectedStartObjectToken()) {
/* 151 */         ObjectNode root = nodeF.objectNode();
/* 152 */         _deserializeContainerNoRecursion(p, ctxt, nodeF, new BaseNodeDeserializer.ContainerStack(), (ContainerNode<?>)root);
/* 153 */         return root;
/*     */       } 
/* 155 */       if (p.hasToken(JsonToken.FIELD_NAME)) {
/* 156 */         return _deserializeObjectAtName(p, ctxt, nodeF, new BaseNodeDeserializer.ContainerStack());
/*     */       }
/*     */ 
/*     */       
/* 160 */       if (p.hasToken(JsonToken.END_OBJECT)) {
/* 161 */         return nodeF.objectNode();
/*     */       }
/* 163 */       return (ObjectNode)ctxt.handleUnexpectedToken(ObjectNode.class, p);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ObjectNode deserialize(JsonParser p, DeserializationContext ctxt, ObjectNode node) throws IOException {
/* 175 */       if (p.isExpectedStartObjectToken() || p.hasToken(JsonToken.FIELD_NAME)) {
/* 176 */         return (ObjectNode)updateObject(p, ctxt, node, new BaseNodeDeserializer.ContainerStack());
/*     */       }
/*     */       
/* 179 */       return (ObjectNode)ctxt.handleUnexpectedToken(ObjectNode.class, p);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class ArrayDeserializer
/*     */     extends BaseNodeDeserializer<ArrayNode>
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     
/* 191 */     protected static final ArrayDeserializer _instance = new ArrayDeserializer();
/*     */     protected ArrayDeserializer() {
/* 193 */       super(ArrayNode.class, Boolean.valueOf(true));
/*     */     } public static ArrayDeserializer getInstance() {
/* 195 */       return _instance;
/*     */     }
/*     */     
/*     */     protected ArrayDeserializer(ArrayDeserializer base, boolean mergeArrays, boolean mergeObjects) {
/* 199 */       super(base, mergeArrays, mergeObjects);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected JsonDeserializer<?> _createWithMerge(boolean mergeArrays, boolean mergeObjects) {
/* 205 */       return new ArrayDeserializer(this, mergeArrays, mergeObjects);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public ArrayNode deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 211 */       if (p.isExpectedStartArrayToken()) {
/* 212 */         JsonNodeFactory nodeF = ctxt.getNodeFactory();
/* 213 */         ArrayNode arrayNode = nodeF.arrayNode();
/* 214 */         _deserializeContainerNoRecursion(p, ctxt, nodeF, new BaseNodeDeserializer.ContainerStack(), (ContainerNode<?>)arrayNode);
/*     */         
/* 216 */         return arrayNode;
/*     */       } 
/* 218 */       return (ArrayNode)ctxt.handleUnexpectedToken(ArrayNode.class, p);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ArrayNode deserialize(JsonParser p, DeserializationContext ctxt, ArrayNode arrayNode) throws IOException {
/* 228 */       if (p.isExpectedStartArrayToken()) {
/* 229 */         _deserializeContainerNoRecursion(p, ctxt, ctxt.getNodeFactory(), new BaseNodeDeserializer.ContainerStack(), (ContainerNode<?>)arrayNode);
/*     */         
/* 231 */         return arrayNode;
/*     */       } 
/* 233 */       return (ArrayNode)ctxt.handleUnexpectedToken(ArrayNode.class, p);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\deser\std\JsonNodeDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */