/*     */ package com.fasterxml.jackson.databind.deser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.deser.BeanDeserializer;
/*     */ import com.fasterxml.jackson.databind.deser.BeanDeserializerBase;
/*     */ import com.fasterxml.jackson.databind.deser.SettableBeanProperty;
/*     */ import com.fasterxml.jackson.databind.util.NameTransformer;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ThrowableDeserializer
/*     */   extends BeanDeserializer
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected static final String PROP_NAME_MESSAGE = "message";
/*     */   protected static final String PROP_NAME_SUPPRESSED = "suppressed";
/*     */   protected static final String PROP_NAME_LOCALIZED_MESSAGE = "localizedMessage";
/*     */   
/*     */   @Deprecated
/*     */   public ThrowableDeserializer(BeanDeserializer baseDeserializer) {
/*  34 */     super((BeanDeserializerBase)baseDeserializer);
/*     */     
/*  36 */     this._vanillaProcessing = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ThrowableDeserializer construct(DeserializationContext ctxt, BeanDeserializer baseDeserializer) {
/*  50 */     return new ThrowableDeserializer(baseDeserializer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ThrowableDeserializer(BeanDeserializer src, NameTransformer unwrapper) {
/*  58 */     super((BeanDeserializerBase)src, unwrapper);
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonDeserializer<Object> unwrappingDeserializer(NameTransformer unwrapper) {
/*  63 */     if (getClass() != ThrowableDeserializer.class) {
/*  64 */       return (JsonDeserializer<Object>)this;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  69 */     return (JsonDeserializer<Object>)new ThrowableDeserializer(this, unwrapper);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserializeFromObject(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  82 */     if (this._propertyBasedCreator != null) {
/*  83 */       return _deserializeUsingPropertyBased(p, ctxt);
/*     */     }
/*  85 */     if (this._delegateDeserializer != null) {
/*  86 */       return this._valueInstantiator.createUsingDelegate(ctxt, this._delegateDeserializer
/*  87 */           .deserialize(p, ctxt));
/*     */     }
/*  89 */     if (this._beanType.isAbstract()) {
/*  90 */       return ctxt.handleMissingInstantiator(handledType(), getValueInstantiator(), p, "abstract type (need to add/enable type information?)", new Object[0]);
/*     */     }
/*     */     
/*  93 */     boolean hasStringCreator = this._valueInstantiator.canCreateFromString();
/*  94 */     boolean hasDefaultCtor = this._valueInstantiator.canCreateUsingDefault();
/*     */     
/*  96 */     if (!hasStringCreator && !hasDefaultCtor) {
/*  97 */       return ctxt.handleMissingInstantiator(handledType(), getValueInstantiator(), p, "Throwable needs a default constructor, a single-String-arg constructor; or explicit @JsonCreator", new Object[0]);
/*     */     }
/*     */ 
/*     */     
/* 101 */     Throwable throwable = null;
/* 102 */     Object[] pending = null;
/* 103 */     Throwable[] suppressed = null;
/* 104 */     int pendingIx = 0;
/*     */     
/* 106 */     for (; !p.hasToken(JsonToken.END_OBJECT); p.nextToken()) {
/* 107 */       String propName = p.currentName();
/* 108 */       SettableBeanProperty prop = this._beanProperties.find(propName);
/* 109 */       p.nextToken();
/*     */       
/* 111 */       if (prop != null) {
/* 112 */         if (throwable != null) {
/* 113 */           prop.deserializeAndSet(p, ctxt, throwable);
/*     */         }
/*     */         else {
/*     */           
/* 117 */           if (pending == null) {
/* 118 */             int len = this._beanProperties.size();
/* 119 */             pending = new Object[len + len];
/*     */           } 
/* 121 */           pending[pendingIx++] = prop;
/* 122 */           pending[pendingIx++] = prop.deserialize(p, ctxt);
/*     */ 
/*     */ 
/*     */         
/*     */         }
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 131 */       else if ("message".equalsIgnoreCase(propName) && 
/* 132 */         hasStringCreator) {
/* 133 */         throwable = (Throwable)this._valueInstantiator.createFromString(ctxt, p.getValueAsString());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 140 */       else if (this._ignorableProps != null && this._ignorableProps.contains(propName)) {
/* 141 */         p.skipChildren();
/*     */       
/*     */       }
/* 144 */       else if ("suppressed".equalsIgnoreCase(propName)) {
/* 145 */         suppressed = (Throwable[])ctxt.readValue(p, Throwable[].class);
/*     */       
/*     */       }
/* 148 */       else if ("localizedMessage".equalsIgnoreCase(propName)) {
/* 149 */         p.skipChildren();
/*     */       
/*     */       }
/* 152 */       else if (this._anySetter != null) {
/* 153 */         this._anySetter.deserializeAndSet(p, ctxt, throwable, propName);
/*     */ 
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */ 
/*     */         
/* 161 */         handleUnknownProperty(p, ctxt, throwable, propName);
/*     */       } 
/*     */     } 
/* 164 */     if (throwable == null)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 171 */       if (hasStringCreator) {
/* 172 */         throwable = (Throwable)this._valueInstantiator.createFromString(ctxt, null);
/*     */       } else {
/* 174 */         throwable = (Throwable)this._valueInstantiator.createUsingDefault(ctxt);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 179 */     if (pending != null) {
/* 180 */       for (int i = 0, len = pendingIx; i < len; i += 2) {
/* 181 */         SettableBeanProperty prop = (SettableBeanProperty)pending[i];
/* 182 */         prop.set(throwable, pending[i + 1]);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 187 */     if (suppressed != null) {
/* 188 */       for (Throwable s : suppressed) {
/* 189 */         throwable.addSuppressed(s);
/*     */       }
/*     */     }
/*     */     
/* 193 */     return throwable;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\deser\std\ThrowableDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */