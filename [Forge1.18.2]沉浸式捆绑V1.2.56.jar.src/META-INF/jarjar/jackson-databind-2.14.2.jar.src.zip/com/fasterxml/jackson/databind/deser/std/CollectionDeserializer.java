/*     */ package com.fasterxml.jackson.databind.deser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.core.JacksonException;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.annotation.JacksonStdImpl;
/*     */ import com.fasterxml.jackson.databind.cfg.CoercionAction;
/*     */ import com.fasterxml.jackson.databind.cfg.CoercionInputShape;
/*     */ import com.fasterxml.jackson.databind.deser.ContextualDeserializer;
/*     */ import com.fasterxml.jackson.databind.deser.NullValueProvider;
/*     */ import com.fasterxml.jackson.databind.deser.UnresolvedForwardReference;
/*     */ import com.fasterxml.jackson.databind.deser.ValueInstantiator;
/*     */ import com.fasterxml.jackson.databind.deser.impl.ReadableObjectId;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*     */ import com.fasterxml.jackson.databind.type.LogicalType;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @JacksonStdImpl
/*     */ public class CollectionDeserializer
/*     */   extends ContainerDeserializerBase<Collection<Object>>
/*     */   implements ContextualDeserializer
/*     */ {
/*     */   private static final long serialVersionUID = -1L;
/*     */   protected final JsonDeserializer<Object> _valueDeserializer;
/*     */   protected final TypeDeserializer _valueTypeDeserializer;
/*     */   protected final ValueInstantiator _valueInstantiator;
/*     */   protected final JsonDeserializer<Object> _delegateDeserializer;
/*     */   
/*     */   public CollectionDeserializer(JavaType collectionType, JsonDeserializer<Object> valueDeser, TypeDeserializer valueTypeDeser, ValueInstantiator valueInstantiator) {
/*  74 */     this(collectionType, valueDeser, valueTypeDeser, valueInstantiator, (JsonDeserializer<Object>)null, (NullValueProvider)null, (Boolean)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected CollectionDeserializer(JavaType collectionType, JsonDeserializer<Object> valueDeser, TypeDeserializer valueTypeDeser, ValueInstantiator valueInstantiator, JsonDeserializer<Object> delegateDeser, NullValueProvider nuller, Boolean unwrapSingle) {
/*  87 */     super(collectionType, nuller, unwrapSingle);
/*  88 */     this._valueDeserializer = valueDeser;
/*  89 */     this._valueTypeDeserializer = valueTypeDeser;
/*  90 */     this._valueInstantiator = valueInstantiator;
/*  91 */     this._delegateDeserializer = delegateDeser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected CollectionDeserializer(CollectionDeserializer src) {
/* 100 */     super(src);
/* 101 */     this._valueDeserializer = src._valueDeserializer;
/* 102 */     this._valueTypeDeserializer = src._valueTypeDeserializer;
/* 103 */     this._valueInstantiator = src._valueInstantiator;
/* 104 */     this._delegateDeserializer = src._delegateDeserializer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected CollectionDeserializer withResolved(JsonDeserializer<?> dd, JsonDeserializer<?> vd, TypeDeserializer vtd, NullValueProvider nuller, Boolean unwrapSingle) {
/* 117 */     return new CollectionDeserializer(this._containerType, (JsonDeserializer)vd, vtd, this._valueInstantiator, (JsonDeserializer)dd, nuller, unwrapSingle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCachable() {
/* 127 */     return (this._valueDeserializer == null && this._valueTypeDeserializer == null && this._delegateDeserializer == null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LogicalType logicalType() {
/* 135 */     return LogicalType.Collection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CollectionDeserializer createContextual(DeserializationContext ctxt, BeanProperty property) throws JsonMappingException {
/* 154 */     JsonDeserializer<Object> delegateDeser = null;
/* 155 */     if (this._valueInstantiator != null) {
/* 156 */       if (this._valueInstantiator.canCreateUsingDelegate()) {
/* 157 */         JavaType delegateType = this._valueInstantiator.getDelegateType(ctxt.getConfig());
/* 158 */         if (delegateType == null) {
/* 159 */           ctxt.reportBadDefinition(this._containerType, String.format("Invalid delegate-creator definition for %s: value instantiator (%s) returned true for 'canCreateUsingDelegate()', but null for 'getDelegateType()'", new Object[] { this._containerType, this._valueInstantiator
/*     */ 
/*     */                   
/* 162 */                   .getClass().getName() }));
/*     */         }
/* 164 */         delegateDeser = findDeserializer(ctxt, delegateType, property);
/* 165 */       } else if (this._valueInstantiator.canCreateUsingArrayDelegate()) {
/* 166 */         JavaType delegateType = this._valueInstantiator.getArrayDelegateType(ctxt.getConfig());
/* 167 */         if (delegateType == null) {
/* 168 */           ctxt.reportBadDefinition(this._containerType, String.format("Invalid delegate-creator definition for %s: value instantiator (%s) returned true for 'canCreateUsingArrayDelegate()', but null for 'getArrayDelegateType()'", new Object[] { this._containerType, this._valueInstantiator
/*     */ 
/*     */                   
/* 171 */                   .getClass().getName() }));
/*     */         }
/* 173 */         delegateDeser = findDeserializer(ctxt, delegateType, property);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 179 */     Boolean unwrapSingle = findFormatFeature(ctxt, property, Collection.class, JsonFormat.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY);
/*     */ 
/*     */     
/* 182 */     JsonDeserializer<?> valueDeser = this._valueDeserializer;
/*     */ 
/*     */     
/* 185 */     valueDeser = findConvertingContentDeserializer(ctxt, property, valueDeser);
/* 186 */     JavaType vt = this._containerType.getContentType();
/* 187 */     if (valueDeser == null) {
/* 188 */       valueDeser = ctxt.findContextualValueDeserializer(vt, property);
/*     */     } else {
/* 190 */       valueDeser = ctxt.handleSecondaryContextualization(valueDeser, property, vt);
/*     */     } 
/*     */     
/* 193 */     TypeDeserializer valueTypeDeser = this._valueTypeDeserializer;
/* 194 */     if (valueTypeDeser != null) {
/* 195 */       valueTypeDeser = valueTypeDeser.forProperty(property);
/*     */     }
/* 197 */     NullValueProvider nuller = findContentNullProvider(ctxt, property, valueDeser);
/* 198 */     if (!Objects.equals(unwrapSingle, this._unwrapSingle) || nuller != this._nullProvider || delegateDeser != this._delegateDeserializer || valueDeser != this._valueDeserializer || valueTypeDeser != this._valueTypeDeserializer)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 204 */       return withResolved(delegateDeser, valueDeser, valueTypeDeser, nuller, unwrapSingle);
/*     */     }
/*     */     
/* 207 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonDeserializer<Object> getContentDeserializer() {
/* 218 */     return this._valueDeserializer;
/*     */   }
/*     */ 
/*     */   
/*     */   public ValueInstantiator getValueInstantiator() {
/* 223 */     return this._valueInstantiator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<Object> deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 237 */     if (this._delegateDeserializer != null) {
/* 238 */       return (Collection<Object>)this._valueInstantiator.createUsingDelegate(ctxt, this._delegateDeserializer
/* 239 */           .deserialize(p, ctxt));
/*     */     }
/*     */ 
/*     */     
/* 243 */     if (p.isExpectedStartArrayToken()) {
/* 244 */       return _deserializeFromArray(p, ctxt, createDefaultInstance(ctxt));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 249 */     if (p.hasToken(JsonToken.VALUE_STRING)) {
/* 250 */       return _deserializeFromString(p, ctxt, p.getText());
/*     */     }
/* 252 */     return handleNonArray(p, ctxt, createDefaultInstance(ctxt));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Collection<Object> createDefaultInstance(DeserializationContext ctxt) throws IOException {
/* 262 */     return (Collection<Object>)this._valueInstantiator.createUsingDefault(ctxt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<Object> deserialize(JsonParser p, DeserializationContext ctxt, Collection<Object> result) throws IOException {
/* 271 */     if (p.isExpectedStartArrayToken()) {
/* 272 */       return _deserializeFromArray(p, ctxt, result);
/*     */     }
/* 274 */     return handleNonArray(p, ctxt, result);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserializeWithType(JsonParser p, DeserializationContext ctxt, TypeDeserializer typeDeserializer) throws IOException {
/* 283 */     return typeDeserializer.deserializeTypedFromArray(p, ctxt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Collection<Object> _deserializeFromString(JsonParser p, DeserializationContext ctxt, String value) throws IOException {
/* 296 */     Class<?> rawTargetType = handledType();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 305 */     if (value.isEmpty()) {
/* 306 */       CoercionAction act = ctxt.findCoercionAction(logicalType(), rawTargetType, CoercionInputShape.EmptyString);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 311 */       if (act != null && act != CoercionAction.Fail) {
/* 312 */         return (Collection<Object>)_deserializeFromEmptyString(p, ctxt, act, rawTargetType, "empty String (\"\")");
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */     
/*     */     }
/* 320 */     else if (_isBlank(value)) {
/* 321 */       CoercionAction act = ctxt.findCoercionFromBlankString(logicalType(), rawTargetType, CoercionAction.Fail);
/*     */       
/* 323 */       if (act != CoercionAction.Fail) {
/* 324 */         return (Collection<Object>)_deserializeFromEmptyString(p, ctxt, act, rawTargetType, "blank String (all whitespace)");
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 330 */     return handleNonArray(p, ctxt, createDefaultInstance(ctxt));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Collection<Object> _deserializeFromArray(JsonParser p, DeserializationContext ctxt, Collection<Object> result) throws IOException {
/* 341 */     p.setCurrentValue(result);
/*     */     
/* 343 */     JsonDeserializer<Object> valueDes = this._valueDeserializer;
/*     */     
/* 345 */     if (valueDes.getObjectIdReader() != null) {
/* 346 */       return _deserializeWithObjectId(p, ctxt, result);
/*     */     }
/* 348 */     TypeDeserializer typeDeser = this._valueTypeDeserializer;
/*     */     JsonToken t;
/* 350 */     while ((t = p.nextToken()) != JsonToken.END_ARRAY) {
/*     */       try {
/*     */         Object value;
/* 353 */         if (t == JsonToken.VALUE_NULL) {
/* 354 */           if (this._skipNullValues) {
/*     */             continue;
/*     */           }
/* 357 */           value = this._nullProvider.getNullValue(ctxt);
/* 358 */         } else if (typeDeser == null) {
/* 359 */           value = valueDes.deserialize(p, ctxt);
/*     */         } else {
/* 361 */           value = valueDes.deserializeWithType(p, ctxt, typeDeser);
/*     */         } 
/* 363 */         result.add(value);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 370 */       catch (Exception e) {
/* 371 */         boolean wrap = (ctxt == null || ctxt.isEnabled(DeserializationFeature.WRAP_EXCEPTIONS));
/* 372 */         if (!wrap) {
/* 373 */           ClassUtil.throwIfRTE(e);
/*     */         }
/* 375 */         throw JsonMappingException.wrapWithPath(e, result, result.size());
/*     */       } 
/*     */     } 
/* 378 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Collection<Object> handleNonArray(JsonParser p, DeserializationContext ctxt, Collection<Object> result) throws IOException {
/*     */     Object value;
/* 394 */     boolean canWrap = (this._unwrapSingle == Boolean.TRUE || (this._unwrapSingle == null && ctxt.isEnabled(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY)));
/* 395 */     if (!canWrap) {
/* 396 */       return (Collection<Object>)ctxt.handleUnexpectedToken(this._containerType, p);
/*     */     }
/* 398 */     JsonDeserializer<Object> valueDes = this._valueDeserializer;
/* 399 */     TypeDeserializer typeDeser = this._valueTypeDeserializer;
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 404 */       if (p.hasToken(JsonToken.VALUE_NULL)) {
/*     */         
/* 406 */         if (this._skipNullValues) {
/* 407 */           return result;
/*     */         }
/* 409 */         value = this._nullProvider.getNullValue(ctxt);
/* 410 */       } else if (typeDeser == null) {
/* 411 */         value = valueDes.deserialize(p, ctxt);
/*     */       } else {
/* 413 */         value = valueDes.deserializeWithType(p, ctxt, typeDeser);
/*     */       } 
/* 415 */     } catch (Exception e) {
/* 416 */       boolean wrap = ctxt.isEnabled(DeserializationFeature.WRAP_EXCEPTIONS);
/* 417 */       if (!wrap) {
/* 418 */         ClassUtil.throwIfRTE(e);
/*     */       }
/*     */       
/* 421 */       throw JsonMappingException.wrapWithPath(e, Object.class, result.size());
/*     */     } 
/* 423 */     result.add(value);
/* 424 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Collection<Object> _deserializeWithObjectId(JsonParser p, DeserializationContext ctxt, Collection<Object> result) throws IOException {
/* 432 */     if (!p.isExpectedStartArrayToken()) {
/* 433 */       return handleNonArray(p, ctxt, result);
/*     */     }
/*     */     
/* 436 */     p.setCurrentValue(result);
/*     */     
/* 438 */     JsonDeserializer<Object> valueDes = this._valueDeserializer;
/* 439 */     TypeDeserializer typeDeser = this._valueTypeDeserializer;
/*     */     
/* 441 */     CollectionReferringAccumulator referringAccumulator = new CollectionReferringAccumulator(this._containerType.getContentType().getRawClass(), result);
/*     */     
/*     */     JsonToken t;
/* 444 */     while ((t = p.nextToken()) != JsonToken.END_ARRAY) {
/*     */       try {
/*     */         Object value;
/* 447 */         if (t == JsonToken.VALUE_NULL) {
/* 448 */           if (this._skipNullValues) {
/*     */             continue;
/*     */           }
/* 451 */           value = this._nullProvider.getNullValue(ctxt);
/* 452 */         } else if (typeDeser == null) {
/* 453 */           value = valueDes.deserialize(p, ctxt);
/*     */         } else {
/* 455 */           value = valueDes.deserializeWithType(p, ctxt, typeDeser);
/*     */         } 
/* 457 */         referringAccumulator.add(value);
/* 458 */       } catch (UnresolvedForwardReference reference) {
/* 459 */         ReadableObjectId.Referring ref = referringAccumulator.handleUnresolvedReference(reference);
/* 460 */         reference.getRoid().appendReferring(ref);
/* 461 */       } catch (Exception e) {
/* 462 */         boolean wrap = (ctxt == null || ctxt.isEnabled(DeserializationFeature.WRAP_EXCEPTIONS));
/* 463 */         if (!wrap) {
/* 464 */           ClassUtil.throwIfRTE(e);
/*     */         }
/* 466 */         throw JsonMappingException.wrapWithPath(e, result, result.size());
/*     */       } 
/*     */     } 
/* 469 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class CollectionReferringAccumulator
/*     */   {
/*     */     private final Class<?> _elementType;
/*     */ 
/*     */     
/*     */     private final Collection<Object> _result;
/*     */ 
/*     */     
/* 483 */     private List<CollectionDeserializer.CollectionReferring> _accumulator = new ArrayList<>();
/*     */     
/*     */     public CollectionReferringAccumulator(Class<?> elementType, Collection<Object> result) {
/* 486 */       this._elementType = elementType;
/* 487 */       this._result = result;
/*     */     }
/*     */ 
/*     */     
/*     */     public void add(Object value) {
/* 492 */       if (this._accumulator.isEmpty()) {
/* 493 */         this._result.add(value);
/*     */       } else {
/* 495 */         CollectionDeserializer.CollectionReferring ref = this._accumulator.get(this._accumulator.size() - 1);
/* 496 */         ref.next.add(value);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public ReadableObjectId.Referring handleUnresolvedReference(UnresolvedForwardReference reference) {
/* 502 */       CollectionDeserializer.CollectionReferring id = new CollectionDeserializer.CollectionReferring(this, reference, this._elementType);
/* 503 */       this._accumulator.add(id);
/* 504 */       return id;
/*     */     }
/*     */ 
/*     */     
/*     */     public void resolveForwardReference(Object id, Object value) throws IOException {
/* 509 */       Iterator<CollectionDeserializer.CollectionReferring> iterator = this._accumulator.iterator();
/*     */ 
/*     */ 
/*     */       
/* 513 */       Collection<Object> previous = this._result;
/* 514 */       while (iterator.hasNext()) {
/* 515 */         CollectionDeserializer.CollectionReferring ref = iterator.next();
/* 516 */         if (ref.hasId(id)) {
/* 517 */           iterator.remove();
/* 518 */           previous.add(value);
/* 519 */           previous.addAll(ref.next);
/*     */           return;
/*     */         } 
/* 522 */         previous = ref.next;
/*     */       } 
/*     */       
/* 525 */       throw new IllegalArgumentException("Trying to resolve a forward reference with id [" + id + "] that wasn't previously seen as unresolved.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class CollectionReferring
/*     */     extends ReadableObjectId.Referring
/*     */   {
/*     */     private final CollectionDeserializer.CollectionReferringAccumulator _parent;
/*     */ 
/*     */     
/* 537 */     public final List<Object> next = new ArrayList();
/*     */ 
/*     */ 
/*     */     
/*     */     CollectionReferring(CollectionDeserializer.CollectionReferringAccumulator parent, UnresolvedForwardReference reference, Class<?> contentType) {
/* 542 */       super(reference, contentType);
/* 543 */       this._parent = parent;
/*     */     }
/*     */ 
/*     */     
/*     */     public void handleResolvedForwardReference(Object id, Object value) throws IOException {
/* 548 */       this._parent.resolveForwardReference(id, value);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\deser\std\CollectionDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */