/*    */ package com.fasterxml.jackson.databind.deser.std;
/*    */ 
/*    */ import com.fasterxml.jackson.core.JacksonException;
/*    */ import com.fasterxml.jackson.core.JsonParser;
/*    */ import com.fasterxml.jackson.core.JsonToken;
/*    */ import com.fasterxml.jackson.databind.DeserializationContext;
/*    */ import com.fasterxml.jackson.databind.JsonMappingException;
/*    */ import com.fasterxml.jackson.databind.annotation.JacksonStdImpl;
/*    */ import com.fasterxml.jackson.databind.deser.NullValueProvider;
/*    */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*    */ import com.fasterxml.jackson.databind.type.LogicalType;
/*    */ import java.io.IOException;
/*    */ 
/*    */ @JacksonStdImpl
/*    */ public class StringDeserializer
/*    */   extends StdScalarDeserializer<String>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/* 19 */   public static final StringDeserializer instance = new StringDeserializer();
/*    */   public StringDeserializer() {
/* 21 */     super(String.class);
/*    */   }
/*    */   
/*    */   public LogicalType logicalType() {
/* 25 */     return LogicalType.Textual;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isCachable() {
/* 30 */     return true;
/*    */   }
/*    */   
/*    */   public Object getEmptyValue(DeserializationContext ctxt) throws JsonMappingException {
/* 34 */     return "";
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 41 */     if (p.hasToken(JsonToken.VALUE_STRING)) {
/* 42 */       return p.getText();
/*    */     }
/*    */     
/* 45 */     if (p.hasToken(JsonToken.START_ARRAY)) {
/* 46 */       return _deserializeFromArray(p, ctxt);
/*    */     }
/* 48 */     return _parseString(p, ctxt, (NullValueProvider)this);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String deserializeWithType(JsonParser p, DeserializationContext ctxt, TypeDeserializer typeDeserializer) throws IOException {
/* 56 */     return deserialize(p, ctxt);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\deser\std\StringDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */