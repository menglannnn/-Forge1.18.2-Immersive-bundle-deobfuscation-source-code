/*     */ package com.fasterxml.jackson.databind.type;
/*     */ 
/*     */ import com.fasterxml.jackson.core.type.ResolvedType;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import java.lang.reflect.TypeVariable;
/*     */ import java.util.Collection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CollectionLikeType
/*     */   extends TypeBase
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final JavaType _elementType;
/*     */   
/*     */   protected CollectionLikeType(Class<?> collT, TypeBindings bindings, JavaType superClass, JavaType[] superInts, JavaType elemT, Object valueHandler, Object typeHandler, boolean asStatic) {
/*  34 */     super(collT, bindings, superClass, superInts, elemT
/*  35 */         .hashCode(), valueHandler, typeHandler, asStatic);
/*  36 */     this._elementType = elemT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected CollectionLikeType(TypeBase base, JavaType elemT) {
/*  44 */     super(base);
/*  45 */     this._elementType = elemT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CollectionLikeType construct(Class<?> rawType, TypeBindings bindings, JavaType superClass, JavaType[] superInts, JavaType elemT) {
/*  53 */     return new CollectionLikeType(rawType, bindings, superClass, superInts, elemT, null, null, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static CollectionLikeType construct(Class<?> rawType, JavaType elemT) {
/*     */     TypeBindings bindings;
/*  65 */     TypeVariable[] arrayOfTypeVariable = (TypeVariable[])rawType.getTypeParameters();
/*     */     
/*  67 */     if (arrayOfTypeVariable == null || arrayOfTypeVariable.length != 1) {
/*  68 */       bindings = TypeBindings.emptyBindings();
/*     */     } else {
/*  70 */       bindings = TypeBindings.create(rawType, elemT);
/*     */     } 
/*  72 */     return new CollectionLikeType(rawType, bindings, 
/*  73 */         _bogusSuperClass(rawType), null, elemT, null, null, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CollectionLikeType upgradeFrom(JavaType baseType, JavaType elementType) {
/*  86 */     if (baseType instanceof TypeBase) {
/*  87 */       return new CollectionLikeType((TypeBase)baseType, elementType);
/*     */     }
/*  89 */     throw new IllegalArgumentException("Cannot upgrade from an instance of " + baseType.getClass());
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected JavaType _narrow(Class<?> subclass) {
/*  95 */     return new CollectionLikeType(subclass, this._bindings, this._superClass, this._superInterfaces, this._elementType, this._valueHandler, this._typeHandler, this._asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaType withContentType(JavaType contentType) {
/* 102 */     if (this._elementType == contentType) {
/* 103 */       return this;
/*     */     }
/* 105 */     return new CollectionLikeType(this._class, this._bindings, this._superClass, this._superInterfaces, contentType, this._valueHandler, this._typeHandler, this._asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CollectionLikeType withTypeHandler(Object h) {
/* 111 */     return new CollectionLikeType(this._class, this._bindings, this._superClass, this._superInterfaces, this._elementType, this._valueHandler, h, this._asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CollectionLikeType withContentTypeHandler(Object h) {
/* 118 */     return new CollectionLikeType(this._class, this._bindings, this._superClass, this._superInterfaces, this._elementType
/* 119 */         .withTypeHandler(h), this._valueHandler, this._typeHandler, this._asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CollectionLikeType withValueHandler(Object h) {
/* 125 */     return new CollectionLikeType(this._class, this._bindings, this._superClass, this._superInterfaces, this._elementType, h, this._typeHandler, this._asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CollectionLikeType withContentValueHandler(Object h) {
/* 131 */     return new CollectionLikeType(this._class, this._bindings, this._superClass, this._superInterfaces, this._elementType
/* 132 */         .withValueHandler(h), this._valueHandler, this._typeHandler, this._asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaType withHandlersFrom(JavaType src) {
/* 138 */     JavaType type = super.withHandlersFrom(src);
/* 139 */     JavaType srcCt = src.getContentType();
/* 140 */     if (srcCt != null) {
/* 141 */       JavaType ct = this._elementType.withHandlersFrom(srcCt);
/* 142 */       if (ct != this._elementType) {
/* 143 */         type = type.withContentType(ct);
/*     */       }
/*     */     } 
/* 146 */     return type;
/*     */   }
/*     */ 
/*     */   
/*     */   public CollectionLikeType withStaticTyping() {
/* 151 */     if (this._asStatic) {
/* 152 */       return this;
/*     */     }
/* 154 */     return new CollectionLikeType(this._class, this._bindings, this._superClass, this._superInterfaces, this._elementType
/* 155 */         .withStaticTyping(), this._valueHandler, this._typeHandler, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaType refine(Class<?> rawType, TypeBindings bindings, JavaType superClass, JavaType[] superInterfaces) {
/* 162 */     return new CollectionLikeType(rawType, bindings, superClass, superInterfaces, this._elementType, this._valueHandler, this._typeHandler, this._asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isContainerType() {
/* 174 */     return true;
/*     */   }
/*     */   public boolean isCollectionLikeType() {
/* 177 */     return true;
/*     */   }
/*     */   public JavaType getContentType() {
/* 180 */     return this._elementType;
/*     */   }
/*     */   
/*     */   public Object getContentValueHandler() {
/* 184 */     return this._elementType.getValueHandler();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getContentTypeHandler() {
/* 189 */     return this._elementType.getTypeHandler();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasHandlers() {
/* 194 */     return (super.hasHandlers() || this._elementType.hasHandlers());
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuilder getErasedSignature(StringBuilder sb) {
/* 199 */     return _classSignature(this._class, sb, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuilder getGenericSignature(StringBuilder sb) {
/* 204 */     _classSignature(this._class, sb, false);
/* 205 */     sb.append('<');
/* 206 */     this._elementType.getGenericSignature(sb);
/* 207 */     sb.append(">;");
/* 208 */     return sb;
/*     */   }
/*     */ 
/*     */   
/*     */   protected String buildCanonicalName() {
/* 213 */     StringBuilder sb = new StringBuilder();
/* 214 */     sb.append(this._class.getName());
/*     */ 
/*     */     
/* 217 */     if (this._elementType != null && _hasNTypeParameters(1)) {
/* 218 */       sb.append('<');
/* 219 */       sb.append(this._elementType.toCanonical());
/* 220 */       sb.append('>');
/*     */     } 
/* 222 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public boolean isTrueCollectionType() {
/* 241 */     return Collection.class.isAssignableFrom(this._class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 253 */     if (o == this) return true; 
/* 254 */     if (o == null) return false; 
/* 255 */     if (o.getClass() != getClass()) return false;
/*     */     
/* 257 */     CollectionLikeType other = (CollectionLikeType)o;
/* 258 */     return (this._class == other._class && this._elementType.equals(other._elementType));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 264 */     return "[collection-like type; class " + this._class.getName() + ", contains " + this._elementType + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\type\CollectionLikeType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */