/*     */ package com.fasterxml.jackson.databind.deser.impl;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonLocation;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.deser.ValueInstantiator;
/*     */ import com.fasterxml.jackson.databind.deser.std.JsonLocationInstantiator;
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JDKValueInstantiators
/*     */ {
/*     */   public static ValueInstantiator findStdValueInstantiator(DeserializationConfig config, Class<?> raw) {
/*  25 */     if (raw == JsonLocation.class) {
/*  26 */       return (ValueInstantiator)new JsonLocationInstantiator();
/*     */     }
/*     */ 
/*     */     
/*  30 */     if (Collection.class.isAssignableFrom(raw)) {
/*  31 */       if (raw == ArrayList.class) {
/*  32 */         return (ValueInstantiator)ArrayListInstantiator.INSTANCE;
/*     */       }
/*  34 */       if (Collections.EMPTY_SET.getClass() == raw) {
/*  35 */         return (ValueInstantiator)new ConstantValueInstantiator(Collections.EMPTY_SET);
/*     */       }
/*  37 */       if (Collections.EMPTY_LIST.getClass() == raw) {
/*  38 */         return (ValueInstantiator)new ConstantValueInstantiator(Collections.EMPTY_LIST);
/*     */       }
/*  40 */     } else if (Map.class.isAssignableFrom(raw)) {
/*  41 */       if (raw == LinkedHashMap.class) {
/*  42 */         return (ValueInstantiator)LinkedHashMapInstantiator.INSTANCE;
/*     */       }
/*  44 */       if (raw == HashMap.class) {
/*  45 */         return (ValueInstantiator)HashMapInstantiator.INSTANCE;
/*     */       }
/*  47 */       if (Collections.EMPTY_MAP.getClass() == raw) {
/*  48 */         return (ValueInstantiator)new ConstantValueInstantiator(Collections.EMPTY_MAP);
/*     */       }
/*     */     } 
/*  51 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private static class ArrayListInstantiator
/*     */     extends ValueInstantiator.Base
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 2L;
/*  60 */     public static final ArrayListInstantiator INSTANCE = new ArrayListInstantiator();
/*     */     public ArrayListInstantiator() {
/*  62 */       super(ArrayList.class);
/*     */     }
/*     */     
/*     */     public boolean canInstantiate() {
/*  66 */       return true;
/*     */     }
/*     */     public boolean canCreateUsingDefault() {
/*  69 */       return true;
/*     */     }
/*     */     
/*     */     public Object createUsingDefault(DeserializationContext ctxt) throws IOException {
/*  73 */       return new ArrayList();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class HashMapInstantiator
/*     */     extends ValueInstantiator.Base
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 2L;
/*  83 */     public static final HashMapInstantiator INSTANCE = new HashMapInstantiator();
/*     */     
/*     */     public HashMapInstantiator() {
/*  86 */       super(HashMap.class);
/*     */     }
/*     */     
/*     */     public boolean canInstantiate() {
/*  90 */       return true;
/*     */     }
/*     */     public boolean canCreateUsingDefault() {
/*  93 */       return true;
/*     */     }
/*     */     
/*     */     public Object createUsingDefault(DeserializationContext ctxt) throws IOException {
/*  97 */       return new HashMap<>();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class LinkedHashMapInstantiator
/*     */     extends ValueInstantiator.Base
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 2L;
/* 107 */     public static final LinkedHashMapInstantiator INSTANCE = new LinkedHashMapInstantiator();
/*     */     
/*     */     public LinkedHashMapInstantiator() {
/* 110 */       super(LinkedHashMap.class);
/*     */     }
/*     */     
/*     */     public boolean canInstantiate() {
/* 114 */       return true;
/*     */     }
/*     */     public boolean canCreateUsingDefault() {
/* 117 */       return true;
/*     */     }
/*     */     
/*     */     public Object createUsingDefault(DeserializationContext ctxt) throws IOException {
/* 121 */       return new LinkedHashMap<>();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class ConstantValueInstantiator
/*     */     extends ValueInstantiator.Base
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 2L;
/*     */     protected final Object _value;
/*     */     
/*     */     public ConstantValueInstantiator(Object value) {
/* 134 */       super(value.getClass());
/* 135 */       this._value = value;
/*     */     }
/*     */     
/*     */     public boolean canInstantiate() {
/* 139 */       return true;
/*     */     }
/*     */     public boolean canCreateUsingDefault() {
/* 142 */       return true;
/*     */     }
/*     */     
/*     */     public Object createUsingDefault(DeserializationContext ctxt) throws IOException {
/* 146 */       return this._value;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\deser\impl\JDKValueInstantiators.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */