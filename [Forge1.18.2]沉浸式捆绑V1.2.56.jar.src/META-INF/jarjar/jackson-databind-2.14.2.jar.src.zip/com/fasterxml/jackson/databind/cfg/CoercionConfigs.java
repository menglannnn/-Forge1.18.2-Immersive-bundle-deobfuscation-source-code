/*     */ package com.fasterxml.jackson.databind.cfg;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.type.LogicalType;
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CoercionConfigs
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  19 */   private static final int TARGET_TYPE_COUNT = (LogicalType.values()).length;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected CoercionAction _defaultAction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final MutableCoercionConfig _defaultCoercions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MutableCoercionConfig[] _perTypeCoercions;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Map<Class<?>, MutableCoercionConfig> _perClassCoercions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CoercionConfigs() {
/*  49 */     this(CoercionAction.TryConvert, new MutableCoercionConfig(), null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected CoercionConfigs(CoercionAction defaultAction, MutableCoercionConfig defaultCoercions, MutableCoercionConfig[] perTypeCoercions, Map<Class<?>, MutableCoercionConfig> perClassCoercions) {
/*  58 */     this._defaultCoercions = defaultCoercions;
/*  59 */     this._defaultAction = defaultAction;
/*  60 */     this._perTypeCoercions = perTypeCoercions;
/*  61 */     this._perClassCoercions = perClassCoercions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CoercionConfigs copy() {
/*     */     MutableCoercionConfig[] newPerType;
/*     */     Map<Class<?>, MutableCoercionConfig> newPerClass;
/*  74 */     if (this._perTypeCoercions == null) {
/*  75 */       newPerType = null;
/*     */     } else {
/*  77 */       int size = this._perTypeCoercions.length;
/*  78 */       newPerType = new MutableCoercionConfig[size];
/*  79 */       for (int i = 0; i < size; i++) {
/*  80 */         newPerType[i] = _copy(this._perTypeCoercions[i]);
/*     */       }
/*     */     } 
/*     */     
/*  84 */     if (this._perClassCoercions == null) {
/*  85 */       newPerClass = null;
/*     */     } else {
/*  87 */       newPerClass = new HashMap<>();
/*  88 */       for (Map.Entry<Class<?>, MutableCoercionConfig> entry : this._perClassCoercions.entrySet()) {
/*  89 */         newPerClass.put(entry.getKey(), ((MutableCoercionConfig)entry.getValue()).copy());
/*     */       }
/*     */     } 
/*  92 */     return new CoercionConfigs(this._defaultAction, this._defaultCoercions.copy(), newPerType, newPerClass);
/*     */   }
/*     */ 
/*     */   
/*     */   private static MutableCoercionConfig _copy(MutableCoercionConfig src) {
/*  97 */     if (src == null) {
/*  98 */       return null;
/*     */     }
/* 100 */     return src.copy();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MutableCoercionConfig defaultCoercions() {
/* 110 */     return this._defaultCoercions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MutableCoercionConfig findOrCreateCoercion(LogicalType type) {
/* 120 */     if (this._perTypeCoercions == null) {
/* 121 */       this._perTypeCoercions = new MutableCoercionConfig[TARGET_TYPE_COUNT];
/*     */     }
/* 123 */     MutableCoercionConfig config = this._perTypeCoercions[type.ordinal()];
/* 124 */     if (config == null) {
/* 125 */       this._perTypeCoercions[type.ordinal()] = config = new MutableCoercionConfig();
/*     */     }
/* 127 */     return config;
/*     */   }
/*     */   
/*     */   public MutableCoercionConfig findOrCreateCoercion(Class<?> type) {
/* 131 */     if (this._perClassCoercions == null) {
/* 132 */       this._perClassCoercions = new HashMap<>();
/*     */     }
/* 134 */     MutableCoercionConfig config = this._perClassCoercions.get(type);
/* 135 */     if (config == null) {
/* 136 */       config = new MutableCoercionConfig();
/* 137 */       this._perClassCoercions.put(type, config);
/*     */     } 
/* 139 */     return config;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CoercionAction findCoercion(DeserializationConfig config, LogicalType targetType, Class<?> targetClass, CoercionInputShape inputShape) {
/* 166 */     if (this._perClassCoercions != null && targetClass != null) {
/* 167 */       MutableCoercionConfig cc = this._perClassCoercions.get(targetClass);
/* 168 */       if (cc != null) {
/* 169 */         CoercionAction coercionAction = cc.findAction(inputShape);
/* 170 */         if (coercionAction != null) {
/* 171 */           return coercionAction;
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 177 */     if (this._perTypeCoercions != null && targetType != null) {
/* 178 */       MutableCoercionConfig cc = this._perTypeCoercions[targetType.ordinal()];
/* 179 */       if (cc != null) {
/* 180 */         CoercionAction coercionAction = cc.findAction(inputShape);
/* 181 */         if (coercionAction != null) {
/* 182 */           return coercionAction;
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 188 */     CoercionAction act = this._defaultCoercions.findAction(inputShape);
/* 189 */     if (act != null) {
/* 190 */       return act;
/*     */     }
/*     */ 
/*     */     
/* 194 */     switch (inputShape) {
/*     */       
/*     */       case EmptyArray:
/* 197 */         return config.isEnabled(DeserializationFeature.ACCEPT_EMPTY_ARRAY_AS_NULL_OBJECT) ? CoercionAction.AsNull : CoercionAction.Fail;
/*     */       
/*     */       case Float:
/* 200 */         if (targetType == LogicalType.Integer)
/*     */         {
/* 202 */           return config.isEnabled(DeserializationFeature.ACCEPT_FLOAT_AS_INT) ? CoercionAction.TryConvert : CoercionAction.Fail;
/*     */         }
/*     */         break;
/*     */       
/*     */       case Integer:
/* 207 */         if (targetType == LogicalType.Enum && 
/* 208 */           config.isEnabled(DeserializationFeature.FAIL_ON_NUMBERS_FOR_ENUMS)) {
/* 209 */           return CoercionAction.Fail;
/*     */         }
/*     */         break;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 218 */     boolean baseScalar = _isScalarType(targetType);
/*     */     
/* 220 */     if (baseScalar && 
/*     */       
/* 222 */       !config.isEnabled(MapperFeature.ALLOW_COERCION_OF_SCALARS) && (targetType != LogicalType.Float || inputShape != CoercionInputShape.Integer))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 228 */       return CoercionAction.Fail;
/*     */     }
/*     */     
/* 231 */     if (inputShape == CoercionInputShape.EmptyString) {
/*     */ 
/*     */       
/* 234 */       if (baseScalar || config
/*     */         
/* 236 */         .isEnabled(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT)) {
/* 237 */         return CoercionAction.AsNull;
/*     */       }
/*     */ 
/*     */       
/* 241 */       if (targetType == LogicalType.OtherScalar) {
/* 242 */         return CoercionAction.TryConvert;
/*     */       }
/*     */       
/* 245 */       return CoercionAction.Fail;
/*     */     } 
/*     */ 
/*     */     
/* 249 */     return this._defaultAction;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CoercionAction findCoercionFromBlankString(DeserializationConfig config, LogicalType targetType, Class<?> targetClass, CoercionAction actionIfBlankNotAllowed) {
/* 272 */     Boolean acceptBlankAsEmpty = null;
/* 273 */     CoercionAction action = null;
/*     */ 
/*     */     
/* 276 */     if (this._perClassCoercions != null && targetClass != null) {
/* 277 */       MutableCoercionConfig cc = this._perClassCoercions.get(targetClass);
/* 278 */       if (cc != null) {
/* 279 */         acceptBlankAsEmpty = cc.getAcceptBlankAsEmpty();
/* 280 */         action = cc.findAction(CoercionInputShape.EmptyString);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 285 */     if (this._perTypeCoercions != null && targetType != null) {
/* 286 */       MutableCoercionConfig cc = this._perTypeCoercions[targetType.ordinal()];
/* 287 */       if (cc != null) {
/* 288 */         if (acceptBlankAsEmpty == null) {
/* 289 */           acceptBlankAsEmpty = cc.getAcceptBlankAsEmpty();
/*     */         }
/* 291 */         if (action == null) {
/* 292 */           action = cc.findAction(CoercionInputShape.EmptyString);
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 298 */     if (acceptBlankAsEmpty == null) {
/* 299 */       acceptBlankAsEmpty = this._defaultCoercions.getAcceptBlankAsEmpty();
/*     */     }
/* 301 */     if (action == null) {
/* 302 */       action = this._defaultCoercions.findAction(CoercionInputShape.EmptyString);
/*     */     }
/*     */ 
/*     */     
/* 306 */     if (Boolean.FALSE.equals(acceptBlankAsEmpty)) {
/* 307 */       return actionIfBlankNotAllowed;
/*     */     }
/*     */     
/* 310 */     if (action != null) {
/* 311 */       return action;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 316 */     if (_isScalarType(targetType)) {
/* 317 */       return CoercionAction.AsNull;
/*     */     }
/*     */ 
/*     */     
/* 321 */     if (config.isEnabled(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT)) {
/* 322 */       return CoercionAction.AsNull;
/*     */     }
/*     */ 
/*     */     
/* 326 */     return actionIfBlankNotAllowed;
/*     */   }
/*     */   
/*     */   protected boolean _isScalarType(LogicalType targetType) {
/* 330 */     return (targetType == LogicalType.Float || targetType == LogicalType.Integer || targetType == LogicalType.Boolean || targetType == LogicalType.DateTime);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\cfg\CoercionConfigs.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */