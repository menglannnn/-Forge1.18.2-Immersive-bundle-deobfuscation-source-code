/*     */ package com.fasterxml.jackson.databind.ser;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
/*     */ import com.fasterxml.jackson.annotation.JsonIncludeProperties;
/*     */ import com.fasterxml.jackson.annotation.JsonTypeInfo;
/*     */ import com.fasterxml.jackson.annotation.ObjectIdGenerator;
/*     */ import com.fasterxml.jackson.annotation.ObjectIdGenerators;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.TokenStreamFactory;
/*     */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*     */ import com.fasterxml.jackson.databind.BeanDescription;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.DatabindContext;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.ObjectMapper;
/*     */ import com.fasterxml.jackson.databind.ObjectReader;
/*     */ import com.fasterxml.jackson.databind.ObjectWriter;
/*     */ import com.fasterxml.jackson.databind.PropertyMetadata;
/*     */ import com.fasterxml.jackson.databind.PropertyName;
/*     */ import com.fasterxml.jackson.databind.SerializationConfig;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import com.fasterxml.jackson.databind.cfg.SerializerFactoryConfig;
/*     */ import com.fasterxml.jackson.databind.introspect.Annotated;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedClass;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*     */ import com.fasterxml.jackson.databind.introspect.BeanPropertyDefinition;
/*     */ import com.fasterxml.jackson.databind.introspect.ObjectIdInfo;
/*     */ import com.fasterxml.jackson.databind.jsontype.NamedType;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeResolverBuilder;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*     */ import com.fasterxml.jackson.databind.ser.impl.FilteredBeanPropertyWriter;
/*     */ import com.fasterxml.jackson.databind.ser.impl.ObjectIdWriter;
/*     */ import com.fasterxml.jackson.databind.ser.impl.PropertyBasedObjectIdGenerator;
/*     */ import com.fasterxml.jackson.databind.ser.impl.UnsupportedTypeSerializer;
/*     */ import com.fasterxml.jackson.databind.ser.std.MapSerializer;
/*     */ import com.fasterxml.jackson.databind.ser.std.StdDelegatingSerializer;
/*     */ import com.fasterxml.jackson.databind.ser.std.ToEmptyObjectSerializer;
/*     */ import com.fasterxml.jackson.databind.type.ReferenceType;
/*     */ import com.fasterxml.jackson.databind.util.BeanUtil;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import com.fasterxml.jackson.databind.util.Converter;
/*     */ import com.fasterxml.jackson.databind.util.IgnorePropertiesUtil;
/*     */ import com.fasterxml.jackson.databind.util.NativeImageUtil;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BeanSerializerFactory
/*     */   extends BasicSerializerFactory
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  73 */   public static final BeanSerializerFactory instance = new BeanSerializerFactory(null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BeanSerializerFactory(SerializerFactoryConfig config) {
/*  86 */     super(config);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializerFactory withConfig(SerializerFactoryConfig config) {
/*  98 */     if (this._factoryConfig == config) {
/*  99 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 107 */     if (getClass() != BeanSerializerFactory.class) {
/* 108 */       throw new IllegalStateException("Subtype of BeanSerializerFactory (" + getClass().getName() + ") has not properly overridden method 'withAdditionalSerializers': cannot instantiate subtype with additional serializer definitions");
/*     */     }
/*     */ 
/*     */     
/* 112 */     return new BeanSerializerFactory(config);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Iterable<Serializers> customSerializers() {
/* 117 */     return this._factoryConfig.serializers();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonSerializer<Object> createSerializer(SerializerProvider prov, JavaType origType) throws JsonMappingException {
/*     */     boolean staticTyping;
/*     */     JavaType type;
/* 143 */     SerializationConfig config = prov.getConfig();
/* 144 */     BeanDescription beanDesc = config.introspect(origType);
/* 145 */     JsonSerializer<?> ser = findSerializerFromAnnotation(prov, (Annotated)beanDesc.getClassInfo());
/* 146 */     if (ser != null) {
/* 147 */       return (JsonSerializer)ser;
/*     */     }
/*     */ 
/*     */     
/* 151 */     AnnotationIntrospector intr = config.getAnnotationIntrospector();
/*     */ 
/*     */     
/* 154 */     if (intr == null) {
/* 155 */       type = origType;
/*     */     } else {
/*     */       try {
/* 158 */         type = intr.refineSerializationType((MapperConfig)config, (Annotated)beanDesc.getClassInfo(), origType);
/* 159 */       } catch (JsonMappingException e) {
/* 160 */         return (JsonSerializer<Object>)prov.reportBadTypeDefinition(beanDesc, e.getMessage(), new Object[0]);
/*     */       } 
/*     */     } 
/* 163 */     if (type == origType) {
/* 164 */       staticTyping = false;
/*     */     } else {
/* 166 */       staticTyping = true;
/* 167 */       if (!type.hasRawClass(origType.getRawClass())) {
/* 168 */         beanDesc = config.introspect(type);
/*     */       }
/*     */     } 
/*     */     
/* 172 */     Converter<Object, Object> conv = beanDesc.findSerializationConverter();
/* 173 */     if (conv == null) {
/* 174 */       return (JsonSerializer)_createSerializer2(prov, type, beanDesc, staticTyping);
/*     */     }
/* 176 */     JavaType delegateType = conv.getOutputType(prov.getTypeFactory());
/*     */ 
/*     */     
/* 179 */     if (!delegateType.hasRawClass(type.getRawClass())) {
/* 180 */       beanDesc = config.introspect(delegateType);
/*     */       
/* 182 */       ser = findSerializerFromAnnotation(prov, (Annotated)beanDesc.getClassInfo());
/*     */     } 
/*     */     
/* 185 */     if (ser == null && !delegateType.isJavaLangObject()) {
/* 186 */       ser = _createSerializer2(prov, delegateType, beanDesc, true);
/*     */     }
/* 188 */     return (JsonSerializer<Object>)new StdDelegatingSerializer(conv, delegateType, ser);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonSerializer<?> _createSerializer2(SerializerProvider prov, JavaType type, BeanDescription beanDesc, boolean staticTyping) throws JsonMappingException {
/* 195 */     JsonSerializer<?> ser = null;
/* 196 */     SerializationConfig config = prov.getConfig();
/*     */ 
/*     */ 
/*     */     
/* 200 */     if (type.isContainerType()) {
/* 201 */       if (!staticTyping) {
/* 202 */         staticTyping = usesStaticTyping(config, beanDesc, null);
/*     */       }
/*     */       
/* 205 */       ser = buildContainerSerializer(prov, type, beanDesc, staticTyping);
/*     */       
/* 207 */       if (ser != null) {
/* 208 */         return ser;
/*     */       }
/*     */     } else {
/* 211 */       if (type.isReferenceType()) {
/* 212 */         ser = findReferenceSerializer(prov, (ReferenceType)type, beanDesc, staticTyping);
/*     */       } else {
/*     */         
/* 215 */         for (Serializers serializers : customSerializers()) {
/* 216 */           ser = serializers.findSerializer(config, type, beanDesc);
/* 217 */           if (ser != null) {
/*     */             break;
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 224 */       if (ser == null) {
/* 225 */         ser = findSerializerByAnnotations(prov, type, beanDesc);
/*     */       }
/*     */     } 
/*     */     
/* 229 */     if (ser == null) {
/*     */ 
/*     */ 
/*     */       
/* 233 */       ser = findSerializerByLookup(type, config, beanDesc, staticTyping);
/* 234 */       if (ser == null) {
/* 235 */         ser = findSerializerByPrimaryType(prov, type, beanDesc, staticTyping);
/* 236 */         if (ser == null) {
/*     */ 
/*     */ 
/*     */           
/* 240 */           ser = findBeanOrAddOnSerializer(prov, type, beanDesc, staticTyping);
/*     */ 
/*     */ 
/*     */           
/* 244 */           if (ser == null) {
/* 245 */             ser = prov.getUnknownTypeSerializer(beanDesc.getBeanClass());
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 250 */     if (ser != null)
/*     */     {
/* 252 */       if (this._factoryConfig.hasSerializerModifiers()) {
/* 253 */         for (BeanSerializerModifier mod : this._factoryConfig.serializerModifiers()) {
/* 254 */           ser = mod.modifySerializer(config, beanDesc, ser);
/*     */         }
/*     */       }
/*     */     }
/* 258 */     return ser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public JsonSerializer<Object> findBeanSerializer(SerializerProvider prov, JavaType type, BeanDescription beanDesc) throws JsonMappingException {
/* 273 */     return findBeanOrAddOnSerializer(prov, type, beanDesc, prov.isEnabled(MapperFeature.USE_STATIC_TYPING));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonSerializer<Object> findBeanOrAddOnSerializer(SerializerProvider prov, JavaType type, BeanDescription beanDesc, boolean staticTyping) throws JsonMappingException {
/* 288 */     if (!isPotentialBeanType(type.getRawClass()))
/*     */     {
/*     */       
/* 291 */       if (!ClassUtil.isEnumType(type.getRawClass())) {
/* 292 */         return null;
/*     */       }
/*     */     }
/* 295 */     return constructBeanOrAddOnSerializer(prov, type, beanDesc, staticTyping);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeSerializer findPropertyTypeSerializer(JavaType baseType, SerializationConfig config, AnnotatedMember accessor) throws JsonMappingException {
/*     */     TypeSerializer typeSer;
/* 312 */     AnnotationIntrospector ai = config.getAnnotationIntrospector();
/* 313 */     TypeResolverBuilder<?> b = ai.findPropertyTypeResolver((MapperConfig)config, accessor, baseType);
/*     */ 
/*     */ 
/*     */     
/* 317 */     if (b == null) {
/* 318 */       typeSer = createTypeSerializer(config, baseType);
/*     */     } else {
/* 320 */       Collection<NamedType> subtypes = config.getSubtypeResolver().collectAndResolveSubtypesByClass((MapperConfig)config, accessor, baseType);
/*     */       
/* 322 */       typeSer = b.buildTypeSerializer(config, baseType, subtypes);
/*     */     } 
/* 324 */     return typeSer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeSerializer findPropertyContentTypeSerializer(JavaType containerType, SerializationConfig config, AnnotatedMember accessor) throws JsonMappingException {
/*     */     TypeSerializer typeSer;
/* 341 */     JavaType contentType = containerType.getContentType();
/* 342 */     AnnotationIntrospector ai = config.getAnnotationIntrospector();
/* 343 */     TypeResolverBuilder<?> b = ai.findPropertyContentTypeResolver((MapperConfig)config, accessor, containerType);
/*     */ 
/*     */ 
/*     */     
/* 347 */     if (b == null) {
/* 348 */       typeSer = createTypeSerializer(config, contentType);
/*     */     } else {
/* 350 */       Collection<NamedType> subtypes = config.getSubtypeResolver().collectAndResolveSubtypesByClass((MapperConfig)config, accessor, contentType);
/*     */       
/* 352 */       typeSer = b.buildTypeSerializer(config, contentType, subtypes);
/*     */     } 
/* 354 */     return typeSer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected JsonSerializer<Object> constructBeanSerializer(SerializerProvider prov, BeanDescription beanDesc) throws JsonMappingException {
/* 368 */     return constructBeanOrAddOnSerializer(prov, beanDesc.getType(), beanDesc, prov.isEnabled(MapperFeature.USE_STATIC_TYPING));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonSerializer<Object> constructBeanOrAddOnSerializer(SerializerProvider prov, JavaType type, BeanDescription beanDesc, boolean staticTyping) throws JsonMappingException {
/* 384 */     if (beanDesc.getBeanClass() == Object.class) {
/* 385 */       return prov.getUnknownTypeSerializer(Object.class);
/*     */     }
/*     */     
/* 388 */     JsonSerializer<?> ser = _findUnsupportedTypeSerializer(prov, type, beanDesc);
/* 389 */     if (ser != null) {
/* 390 */       return (JsonSerializer)ser;
/*     */     }
/*     */ 
/*     */     
/* 394 */     if (_isUnserializableJacksonType(prov, type)) {
/* 395 */       return (JsonSerializer<Object>)new ToEmptyObjectSerializer(type);
/*     */     }
/* 397 */     SerializationConfig config = prov.getConfig();
/* 398 */     BeanSerializerBuilder builder = constructBeanSerializerBuilder(beanDesc);
/* 399 */     builder.setConfig(config);
/*     */ 
/*     */     
/* 402 */     List<BeanPropertyWriter> props = findBeanProperties(prov, beanDesc, builder);
/* 403 */     if (props == null) {
/* 404 */       props = new ArrayList<>();
/*     */     } else {
/* 406 */       props = removeOverlappingTypeIds(prov, beanDesc, builder, props);
/*     */     } 
/*     */ 
/*     */     
/* 410 */     prov.getAnnotationIntrospector().findAndAddVirtualProperties((MapperConfig)config, beanDesc.getClassInfo(), props);
/*     */ 
/*     */     
/* 413 */     if (this._factoryConfig.hasSerializerModifiers()) {
/* 414 */       for (BeanSerializerModifier mod : this._factoryConfig.serializerModifiers()) {
/* 415 */         props = mod.changeProperties(config, beanDesc, props);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 423 */     props = filterUnwantedJDKProperties(config, beanDesc, props);
/* 424 */     props = filterBeanProperties(config, beanDesc, props);
/*     */ 
/*     */     
/* 427 */     if (this._factoryConfig.hasSerializerModifiers()) {
/* 428 */       for (BeanSerializerModifier mod : this._factoryConfig.serializerModifiers()) {
/* 429 */         props = mod.orderProperties(config, beanDesc, props);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 436 */     builder.setObjectIdWriter(constructObjectIdHandler(prov, beanDesc, props));
/*     */     
/* 438 */     builder.setProperties(props);
/* 439 */     builder.setFilterId(findFilterId(config, beanDesc));
/*     */     
/* 441 */     AnnotatedMember anyGetter = beanDesc.findAnyGetter();
/* 442 */     if (anyGetter != null) {
/* 443 */       MapSerializer mapSerializer; JavaType anyType = anyGetter.getType();
/*     */       
/* 445 */       JavaType valueType = anyType.getContentType();
/* 446 */       TypeSerializer typeSer = createTypeSerializer(config, valueType);
/*     */ 
/*     */       
/* 449 */       JsonSerializer<?> anySer = findSerializerFromAnnotation(prov, (Annotated)anyGetter);
/* 450 */       if (anySer == null)
/*     */       {
/* 452 */         mapSerializer = MapSerializer.construct((Set)null, anyType, config
/* 453 */             .isEnabled(MapperFeature.USE_STATIC_TYPING), typeSer, null, null, null);
/*     */       }
/*     */ 
/*     */       
/* 457 */       PropertyName name = PropertyName.construct(anyGetter.getName());
/* 458 */       BeanProperty.Std anyProp = new BeanProperty.Std(name, valueType, null, anyGetter, PropertyMetadata.STD_OPTIONAL);
/*     */       
/* 460 */       builder.setAnyGetter(new AnyGetterWriter((BeanProperty)anyProp, anyGetter, (JsonSerializer<?>)mapSerializer));
/*     */     } 
/*     */     
/* 463 */     processViews(config, builder);
/*     */ 
/*     */     
/* 466 */     if (this._factoryConfig.hasSerializerModifiers()) {
/* 467 */       for (BeanSerializerModifier mod : this._factoryConfig.serializerModifiers()) {
/* 468 */         builder = mod.updateBuilder(config, beanDesc, builder);
/*     */       }
/*     */     }
/*     */     
/*     */     try {
/* 473 */       ser = builder.build();
/* 474 */     } catch (RuntimeException e) {
/* 475 */       return (JsonSerializer<Object>)prov.reportBadTypeDefinition(beanDesc, "Failed to construct BeanSerializer for %s: (%s) %s", new Object[] { beanDesc
/* 476 */             .getType(), e.getClass().getName(), e.getMessage() });
/*     */     } 
/* 478 */     if (ser == null) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 483 */       if (type.isRecordType() && !NativeImageUtil.needsReflectionConfiguration(type.getRawClass())) {
/* 484 */         return (JsonSerializer<Object>)builder.createDummy();
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 489 */       ser = findSerializerByAddonType(config, type, beanDesc, staticTyping);
/* 490 */       if (ser == null)
/*     */       {
/*     */ 
/*     */         
/* 494 */         if (beanDesc.hasKnownClassAnnotations()) {
/* 495 */           return (JsonSerializer<Object>)builder.createDummy();
/*     */         }
/*     */       }
/*     */     } 
/* 499 */     return (JsonSerializer)ser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ObjectIdWriter constructObjectIdHandler(SerializerProvider prov, BeanDescription beanDesc, List<BeanPropertyWriter> props) throws JsonMappingException {
/* 506 */     ObjectIdInfo objectIdInfo = beanDesc.getObjectIdInfo();
/* 507 */     if (objectIdInfo == null) {
/* 508 */       return null;
/*     */     }
/*     */     
/* 511 */     Class<?> implClass = objectIdInfo.getGeneratorType();
/*     */ 
/*     */     
/* 514 */     if (implClass == ObjectIdGenerators.PropertyGenerator.class) {
/* 515 */       String propName = objectIdInfo.getPropertyName().getSimpleName();
/* 516 */       BeanPropertyWriter idProp = null;
/*     */       
/* 518 */       for (int i = 0, len = props.size();; i++) {
/* 519 */         if (i == len)
/* 520 */           throw new IllegalArgumentException(String.format("Invalid Object Id definition for %s: cannot find property with name %s", new Object[] {
/*     */                   
/* 522 */                   ClassUtil.getTypeDescription(beanDesc.getType()), ClassUtil.name(propName)
/*     */                 })); 
/* 524 */         BeanPropertyWriter prop = props.get(i);
/* 525 */         if (propName.equals(prop.getName())) {
/* 526 */           idProp = prop;
/*     */ 
/*     */           
/* 529 */           if (i > 0) {
/* 530 */             props.remove(i);
/* 531 */             props.add(0, idProp);
/*     */           } 
/*     */           break;
/*     */         } 
/*     */       } 
/* 536 */       JavaType javaType = idProp.getType();
/* 537 */       PropertyBasedObjectIdGenerator propertyBasedObjectIdGenerator = new PropertyBasedObjectIdGenerator(objectIdInfo, idProp);
/*     */       
/* 539 */       return ObjectIdWriter.construct(javaType, (PropertyName)null, (ObjectIdGenerator)propertyBasedObjectIdGenerator, objectIdInfo.getAlwaysAsId());
/*     */     } 
/*     */ 
/*     */     
/* 543 */     JavaType type = prov.constructType(implClass);
/*     */     
/* 545 */     JavaType idType = prov.getTypeFactory().findTypeParameters(type, ObjectIdGenerator.class)[0];
/* 546 */     ObjectIdGenerator<?> gen = prov.objectIdGeneratorInstance((Annotated)beanDesc.getClassInfo(), objectIdInfo);
/* 547 */     return ObjectIdWriter.construct(idType, objectIdInfo.getPropertyName(), gen, objectIdInfo
/* 548 */         .getAlwaysAsId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BeanPropertyWriter constructFilteredBeanWriter(BeanPropertyWriter writer, Class<?>[] inViews) {
/* 559 */     return FilteredBeanPropertyWriter.constructViewBased(writer, inViews);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected PropertyBuilder constructPropertyBuilder(SerializationConfig config, BeanDescription beanDesc) {
/* 565 */     return new PropertyBuilder(config, beanDesc);
/*     */   }
/*     */   
/*     */   protected BeanSerializerBuilder constructBeanSerializerBuilder(BeanDescription beanDesc) {
/* 569 */     return new BeanSerializerBuilder(beanDesc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isPotentialBeanType(Class<?> type) {
/* 588 */     return (ClassUtil.canBeABeanType(type) == null && !ClassUtil.isProxyType(type));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<BeanPropertyWriter> findBeanProperties(SerializerProvider prov, BeanDescription beanDesc, BeanSerializerBuilder builder) throws JsonMappingException {
/* 599 */     List<BeanPropertyDefinition> properties = beanDesc.findProperties();
/* 600 */     SerializationConfig config = prov.getConfig();
/*     */ 
/*     */     
/* 603 */     removeIgnorableTypes(config, beanDesc, properties);
/*     */ 
/*     */     
/* 606 */     if (config.isEnabled(MapperFeature.REQUIRE_SETTERS_FOR_GETTERS)) {
/* 607 */       removeSetterlessGetters(config, beanDesc, properties);
/*     */     }
/*     */ 
/*     */     
/* 611 */     if (properties.isEmpty()) {
/* 612 */       return null;
/*     */     }
/*     */     
/* 615 */     boolean staticTyping = usesStaticTyping(config, beanDesc, null);
/* 616 */     PropertyBuilder pb = constructPropertyBuilder(config, beanDesc);
/*     */     
/* 618 */     ArrayList<BeanPropertyWriter> result = new ArrayList<>(properties.size());
/* 619 */     for (BeanPropertyDefinition property : properties) {
/* 620 */       AnnotatedMember accessor = property.getAccessor();
/*     */       
/* 622 */       if (property.isTypeId()) {
/* 623 */         if (accessor != null) {
/* 624 */           builder.setTypeId(accessor);
/*     */         }
/*     */         
/*     */         continue;
/*     */       } 
/* 629 */       AnnotationIntrospector.ReferenceProperty refType = property.findReferenceType();
/* 630 */       if (refType != null && refType.isBackReference()) {
/*     */         continue;
/*     */       }
/* 633 */       if (accessor instanceof com.fasterxml.jackson.databind.introspect.AnnotatedMethod) {
/* 634 */         result.add(_constructWriter(prov, property, pb, staticTyping, accessor)); continue;
/*     */       } 
/* 636 */       result.add(_constructWriter(prov, property, pb, staticTyping, accessor));
/*     */     } 
/*     */     
/* 639 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<BeanPropertyWriter> filterBeanProperties(SerializationConfig config, BeanDescription beanDesc, List<BeanPropertyWriter> props) {
/* 659 */     JsonIgnoreProperties.Value ignorals = config.getDefaultPropertyIgnorals(beanDesc.getBeanClass(), beanDesc
/* 660 */         .getClassInfo());
/* 661 */     Set<String> ignored = null;
/* 662 */     if (ignorals != null) {
/* 663 */       ignored = ignorals.findIgnoredForSerialization();
/*     */     }
/* 665 */     JsonIncludeProperties.Value inclusions = config.getDefaultPropertyInclusions(beanDesc.getBeanClass(), beanDesc
/* 666 */         .getClassInfo());
/* 667 */     Set<String> included = null;
/* 668 */     if (inclusions != null) {
/* 669 */       included = inclusions.getIncluded();
/*     */     }
/* 671 */     if (included != null || (ignored != null && !ignored.isEmpty())) {
/* 672 */       Iterator<BeanPropertyWriter> it = props.iterator();
/* 673 */       while (it.hasNext()) {
/* 674 */         if (IgnorePropertiesUtil.shouldIgnore(((BeanPropertyWriter)it.next()).getName(), ignored, included)) {
/* 675 */           it.remove();
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 680 */     return props;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<BeanPropertyWriter> filterUnwantedJDKProperties(SerializationConfig config, BeanDescription beanDesc, List<BeanPropertyWriter> props) {
/* 696 */     if (beanDesc.getType().isTypeOrSubTypeOf(CharSequence.class))
/*     */     {
/* 698 */       if (props.size() == 1) {
/* 699 */         BeanPropertyWriter prop = props.get(0);
/*     */ 
/*     */ 
/*     */         
/* 703 */         AnnotatedMember m = prop.getMember();
/* 704 */         if (m instanceof com.fasterxml.jackson.databind.introspect.AnnotatedMethod && "isEmpty"
/* 705 */           .equals(m.getName()) && m
/* 706 */           .getDeclaringClass() == CharSequence.class) {
/* 707 */           props.remove(0);
/*     */         }
/*     */       } 
/*     */     }
/* 711 */     return props;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void processViews(SerializationConfig config, BeanSerializerBuilder builder) {
/* 726 */     List<BeanPropertyWriter> props = builder.getProperties();
/* 727 */     boolean includeByDefault = config.isEnabled(MapperFeature.DEFAULT_VIEW_INCLUSION);
/* 728 */     int propCount = props.size();
/* 729 */     int viewsFound = 0;
/* 730 */     BeanPropertyWriter[] filtered = new BeanPropertyWriter[propCount];
/*     */     
/* 732 */     for (int i = 0; i < propCount; i++) {
/* 733 */       BeanPropertyWriter bpw = props.get(i);
/* 734 */       Class<?>[] views = bpw.getViews();
/* 735 */       if (views == null || views.length == 0) {
/*     */ 
/*     */         
/* 738 */         if (includeByDefault) {
/* 739 */           filtered[i] = bpw;
/*     */         }
/*     */       } else {
/* 742 */         viewsFound++;
/* 743 */         filtered[i] = constructFilteredBeanWriter(bpw, views);
/*     */       } 
/*     */     } 
/*     */     
/* 747 */     if (includeByDefault && viewsFound == 0) {
/*     */       return;
/*     */     }
/* 750 */     builder.setFilteredProperties(filtered);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void removeIgnorableTypes(SerializationConfig config, BeanDescription beanDesc, List<BeanPropertyDefinition> properties) {
/* 762 */     AnnotationIntrospector intr = config.getAnnotationIntrospector();
/* 763 */     HashMap<Class<?>, Boolean> ignores = new HashMap<>();
/* 764 */     Iterator<BeanPropertyDefinition> it = properties.iterator();
/* 765 */     while (it.hasNext()) {
/* 766 */       BeanPropertyDefinition property = it.next();
/* 767 */       AnnotatedMember accessor = property.getAccessor();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 772 */       if (accessor == null) {
/* 773 */         it.remove();
/*     */         continue;
/*     */       } 
/* 776 */       Class<?> type = property.getRawPrimaryType();
/* 777 */       Boolean result = ignores.get(type);
/* 778 */       if (result == null) {
/*     */         
/* 780 */         result = config.getConfigOverride(type).getIsIgnoredType();
/* 781 */         if (result == null) {
/* 782 */           BeanDescription desc = config.introspectClassAnnotations(type);
/* 783 */           AnnotatedClass ac = desc.getClassInfo();
/* 784 */           result = intr.isIgnorableType(ac);
/*     */           
/* 786 */           if (result == null) {
/* 787 */             result = Boolean.FALSE;
/*     */           }
/*     */         } 
/* 790 */         ignores.put(type, result);
/*     */       } 
/*     */       
/* 793 */       if (result.booleanValue()) {
/* 794 */         it.remove();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void removeSetterlessGetters(SerializationConfig config, BeanDescription beanDesc, List<BeanPropertyDefinition> properties) {
/* 805 */     Iterator<BeanPropertyDefinition> it = properties.iterator();
/* 806 */     while (it.hasNext()) {
/* 807 */       BeanPropertyDefinition property = it.next();
/*     */ 
/*     */       
/* 810 */       if (!property.couldDeserialize() && !property.isExplicitlyIncluded()) {
/* 811 */         it.remove();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<BeanPropertyWriter> removeOverlappingTypeIds(SerializerProvider prov, BeanDescription beanDesc, BeanSerializerBuilder builder, List<BeanPropertyWriter> props) {
/* 826 */     for (int i = 0, end = props.size(); i < end; i++) {
/* 827 */       BeanPropertyWriter bpw = props.get(i);
/* 828 */       TypeSerializer td = bpw.getTypeSerializer();
/* 829 */       if (td != null && td.getTypeInclusion() == JsonTypeInfo.As.EXTERNAL_PROPERTY) {
/*     */ 
/*     */         
/* 832 */         String n = td.getPropertyName();
/* 833 */         PropertyName typePropName = PropertyName.construct(n);
/*     */         
/* 835 */         for (BeanPropertyWriter w2 : props) {
/* 836 */           if (w2 != bpw && w2.wouldConflictWithName(typePropName)) {
/* 837 */             bpw.assignTypeSerializer(null); break;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 842 */     return props;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BeanPropertyWriter _constructWriter(SerializerProvider prov, BeanPropertyDefinition propDef, PropertyBuilder pb, boolean staticTyping, AnnotatedMember accessor) throws JsonMappingException {
/* 860 */     PropertyName name = propDef.getFullName();
/* 861 */     JavaType type = accessor.getType();
/*     */     
/* 863 */     BeanProperty.Std property = new BeanProperty.Std(name, type, propDef.getWrapperName(), accessor, propDef.getMetadata());
/*     */ 
/*     */     
/* 866 */     JsonSerializer<?> annotatedSerializer = findSerializerFromAnnotation(prov, (Annotated)accessor);
/*     */ 
/*     */ 
/*     */     
/* 870 */     if (annotatedSerializer instanceof ResolvableSerializer) {
/* 871 */       ((ResolvableSerializer)annotatedSerializer).resolve(prov);
/*     */     }
/*     */     
/* 874 */     annotatedSerializer = prov.handlePrimaryContextualization(annotatedSerializer, (BeanProperty)property);
/*     */     
/* 876 */     TypeSerializer contentTypeSer = null;
/*     */     
/* 878 */     if (type.isContainerType() || type.isReferenceType()) {
/* 879 */       contentTypeSer = findPropertyContentTypeSerializer(type, prov.getConfig(), accessor);
/*     */     }
/*     */     
/* 882 */     TypeSerializer typeSer = findPropertyTypeSerializer(type, prov.getConfig(), accessor);
/* 883 */     return pb.buildWriter(prov, propDef, type, annotatedSerializer, typeSer, contentTypeSer, accessor, staticTyping);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonSerializer<?> _findUnsupportedTypeSerializer(SerializerProvider ctxt, JavaType type, BeanDescription beanDesc) throws JsonMappingException {
/* 893 */     String errorMsg = BeanUtil.checkUnsupportedType(type);
/* 894 */     if (errorMsg != null)
/*     */     {
/*     */       
/* 897 */       if (ctxt.getConfig().findMixInClassFor(type.getRawClass()) == null) {
/* 898 */         return (JsonSerializer<?>)new UnsupportedTypeSerializer(type, errorMsg);
/*     */       }
/*     */     }
/* 901 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean _isUnserializableJacksonType(SerializerProvider ctxt, JavaType type) {
/* 912 */     Class<?> raw = type.getRawClass();
/* 913 */     return (ObjectMapper.class.isAssignableFrom(raw) || ObjectReader.class
/* 914 */       .isAssignableFrom(raw) || ObjectWriter.class
/* 915 */       .isAssignableFrom(raw) || DatabindContext.class
/* 916 */       .isAssignableFrom(raw) || TokenStreamFactory.class
/* 917 */       .isAssignableFrom(raw) || JsonParser.class
/* 918 */       .isAssignableFrom(raw) || JsonGenerator.class
/* 919 */       .isAssignableFrom(raw));
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\ser\BeanSerializerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */