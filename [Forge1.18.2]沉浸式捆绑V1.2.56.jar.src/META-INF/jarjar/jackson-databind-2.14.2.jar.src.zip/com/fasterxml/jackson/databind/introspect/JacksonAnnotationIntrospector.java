/*      */ package com.fasterxml.jackson.databind.introspect;
/*      */ import com.fasterxml.jackson.annotation.JacksonInject;
/*      */ import com.fasterxml.jackson.annotation.JsonAlias;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonFormat;
/*      */ import com.fasterxml.jackson.annotation.JsonIdentityInfo;
/*      */ import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
/*      */ import com.fasterxml.jackson.annotation.JsonInclude;
/*      */ import com.fasterxml.jackson.annotation.JsonIncludeProperties;
/*      */ import com.fasterxml.jackson.annotation.JsonManagedReference;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.annotation.JsonPropertyOrder;
/*      */ import com.fasterxml.jackson.annotation.JsonSetter;
/*      */ import com.fasterxml.jackson.annotation.JsonSubTypes;
/*      */ import com.fasterxml.jackson.annotation.JsonTypeInfo;
/*      */ import com.fasterxml.jackson.annotation.JsonUnwrapped;
/*      */ import com.fasterxml.jackson.annotation.JsonValue;
/*      */ import com.fasterxml.jackson.databind.JavaType;
/*      */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*      */ import com.fasterxml.jackson.databind.JsonSerializer;
/*      */ import com.fasterxml.jackson.databind.PropertyMetadata;
/*      */ import com.fasterxml.jackson.databind.PropertyName;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonAppend;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*      */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*      */ import com.fasterxml.jackson.databind.jsontype.NamedType;
/*      */ import com.fasterxml.jackson.databind.jsontype.TypeResolverBuilder;
/*      */ import com.fasterxml.jackson.databind.ser.BeanPropertyWriter;
/*      */ import com.fasterxml.jackson.databind.type.MapLikeType;
/*      */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*      */ import java.lang.reflect.Field;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ 
/*      */ public class JacksonAnnotationIntrospector extends AnnotationIntrospector implements Serializable {
/*   37 */   private static final Class<? extends Annotation>[] ANNOTATIONS_TO_INFER_SER = new Class[] { JsonSerialize.class, JsonView.class, JsonFormat.class, JsonTypeInfo.class, JsonRawValue.class, JsonUnwrapped.class, JsonBackReference.class, JsonManagedReference.class };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final long serialVersionUID = 1L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   50 */   private static final Class<? extends Annotation>[] ANNOTATIONS_TO_INFER_DESER = new Class[] { JsonDeserialize.class, JsonView.class, JsonFormat.class, JsonTypeInfo.class, JsonUnwrapped.class, JsonBackReference.class, JsonManagedReference.class, JsonMerge.class };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final Java7Support _java7Helper;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static {
/*   66 */     Java7Support x = null;
/*      */     try {
/*   68 */       x = Java7Support.instance();
/*   69 */     } catch (Throwable throwable) {}
/*   70 */     _java7Helper = x;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   82 */   protected transient LRUMap<Class<?>, Boolean> _annotationsInside = new LRUMap(48, 48);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _cfgConstructorPropertiesImpliesCreator = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Version version() {
/*  110 */     return PackageVersion.VERSION;
/*      */   }
/*      */   
/*      */   protected Object readResolve() {
/*  114 */     if (this._annotationsInside == null) {
/*  115 */       this._annotationsInside = new LRUMap(48, 48);
/*      */     }
/*  117 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JacksonAnnotationIntrospector setConstructorPropertiesImpliesCreator(boolean b) {
/*  138 */     this._cfgConstructorPropertiesImpliesCreator = b;
/*  139 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isAnnotationBundle(Annotation ann) {
/*  158 */     Class<?> type = ann.annotationType();
/*  159 */     Boolean b = (Boolean)this._annotationsInside.get(type);
/*  160 */     if (b == null) {
/*  161 */       b = Boolean.valueOf((type.getAnnotation(JacksonAnnotationsInside.class) != null));
/*  162 */       this._annotationsInside.putIfAbsent(type, b);
/*      */     } 
/*  164 */     return b.booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public String findEnumValue(Enum<?> value) {
/*      */     try {
/*  186 */       Field f = value.getDeclaringClass().getField(value.name());
/*  187 */       if (f != null) {
/*  188 */         JsonProperty prop = f.<JsonProperty>getAnnotation(JsonProperty.class);
/*  189 */         if (prop != null) {
/*  190 */           String n = prop.value();
/*  191 */           if (n != null && !n.isEmpty()) {
/*  192 */             return n;
/*      */           }
/*      */         } 
/*      */       } 
/*  196 */     } catch (SecurityException securityException) {
/*      */     
/*  198 */     } catch (NoSuchFieldException noSuchFieldException) {}
/*      */ 
/*      */     
/*  201 */     return value.name();
/*      */   }
/*      */ 
/*      */   
/*      */   public String[] findEnumValues(Class<?> enumType, Enum<?>[] enumValues, String[] names) {
/*  206 */     HashMap<String, String> expl = null;
/*  207 */     for (Field f : enumType.getDeclaredFields()) {
/*  208 */       if (f.isEnumConstant()) {
/*      */ 
/*      */         
/*  211 */         JsonProperty prop = f.<JsonProperty>getAnnotation(JsonProperty.class);
/*  212 */         if (prop != null) {
/*      */ 
/*      */           
/*  215 */           String n = prop.value();
/*  216 */           if (!n.isEmpty())
/*      */           
/*      */           { 
/*  219 */             if (expl == null) {
/*  220 */               expl = new HashMap<>();
/*      */             }
/*  222 */             expl.put(f.getName(), n); } 
/*      */         } 
/*      */       } 
/*  225 */     }  if (expl != null) {
/*  226 */       for (int i = 0, end = enumValues.length; i < end; i++) {
/*  227 */         String defName = enumValues[i].name();
/*  228 */         String explValue = expl.get(defName);
/*  229 */         if (explValue != null) {
/*  230 */           names[i] = explValue;
/*      */         }
/*      */       } 
/*      */     }
/*  234 */     return names;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void findEnumAliases(Class<?> enumType, Enum<?>[] enumValues, String[][] aliasList) {
/*  242 */     for (Field f : enumType.getDeclaredFields()) {
/*  243 */       if (f.isEnumConstant()) {
/*  244 */         JsonAlias aliasAnnotation = f.<JsonAlias>getAnnotation(JsonAlias.class);
/*  245 */         if (aliasAnnotation != null) {
/*  246 */           String[] aliases = aliasAnnotation.value();
/*  247 */           if (aliases.length != 0) {
/*  248 */             String name = f.getName();
/*      */             
/*  250 */             for (int i = 0, end = enumValues.length; i < end; i++) {
/*  251 */               if (name.equals(enumValues[i].name())) {
/*  252 */                 aliasList[i] = aliases;
/*      */               }
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Enum<?> findDefaultEnumValue(Class<Enum<?>> enumCls) {
/*  272 */     return ClassUtil.findFirstAnnotatedEnumValue(enumCls, JsonEnumDefaultValue.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PropertyName findRootName(AnnotatedClass ac) {
/*  284 */     JsonRootName ann = (JsonRootName)_findAnnotation(ac, JsonRootName.class);
/*  285 */     if (ann == null) {
/*  286 */       return null;
/*      */     }
/*  288 */     String ns = ann.namespace();
/*  289 */     if (ns != null && ns.isEmpty()) {
/*  290 */       ns = null;
/*      */     }
/*  292 */     return PropertyName.construct(ann.value(), ns);
/*      */   }
/*      */ 
/*      */   
/*      */   public Boolean isIgnorableType(AnnotatedClass ac) {
/*  297 */     JsonIgnoreType ignore = (JsonIgnoreType)_findAnnotation(ac, JsonIgnoreType.class);
/*  298 */     return (ignore == null) ? null : Boolean.valueOf(ignore.value());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonIgnoreProperties.Value findPropertyIgnoralByName(MapperConfig<?> config, Annotated a) {
/*  304 */     JsonIgnoreProperties v = (JsonIgnoreProperties)_findAnnotation(a, JsonIgnoreProperties.class);
/*  305 */     if (v == null) {
/*  306 */       return JsonIgnoreProperties.Value.empty();
/*      */     }
/*  308 */     return JsonIgnoreProperties.Value.from(v);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonIgnoreProperties.Value findPropertyIgnorals(Annotated ac) {
/*  315 */     return findPropertyIgnoralByName((MapperConfig<?>)null, ac);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonIncludeProperties.Value findPropertyInclusionByName(MapperConfig<?> config, Annotated a) {
/*  321 */     JsonIncludeProperties v = (JsonIncludeProperties)_findAnnotation(a, JsonIncludeProperties.class);
/*  322 */     if (v == null) {
/*  323 */       return JsonIncludeProperties.Value.all();
/*      */     }
/*  325 */     return JsonIncludeProperties.Value.from(v);
/*      */   }
/*      */ 
/*      */   
/*      */   public Object findFilterId(Annotated a) {
/*  330 */     JsonFilter ann = (JsonFilter)_findAnnotation(a, JsonFilter.class);
/*  331 */     if (ann != null) {
/*  332 */       String id = ann.value();
/*      */       
/*  334 */       if (!id.isEmpty()) {
/*  335 */         return id;
/*      */       }
/*      */     } 
/*  338 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Object findNamingStrategy(AnnotatedClass ac) {
/*  344 */     JsonNaming ann = (JsonNaming)_findAnnotation(ac, JsonNaming.class);
/*  345 */     return (ann == null) ? null : ann.value();
/*      */   }
/*      */ 
/*      */   
/*      */   public String findClassDescription(AnnotatedClass ac) {
/*  350 */     JsonClassDescription ann = (JsonClassDescription)_findAnnotation(ac, JsonClassDescription.class);
/*  351 */     return (ann == null) ? null : ann.value();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public VisibilityChecker<?> findAutoDetectVisibility(AnnotatedClass ac, VisibilityChecker<?> checker) {
/*  364 */     JsonAutoDetect ann = (JsonAutoDetect)_findAnnotation(ac, JsonAutoDetect.class);
/*  365 */     return (ann == null) ? checker : (VisibilityChecker<?>)checker.with(ann);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String findImplicitPropertyName(AnnotatedMember m) {
/*  376 */     PropertyName n = _findConstructorName(m);
/*  377 */     return (n == null) ? null : n.getSimpleName();
/*      */   }
/*      */ 
/*      */   
/*      */   public List<PropertyName> findPropertyAliases(Annotated m) {
/*  382 */     JsonAlias ann = (JsonAlias)_findAnnotation(m, JsonAlias.class);
/*  383 */     if (ann == null) {
/*  384 */       return null;
/*      */     }
/*  386 */     String[] strs = ann.value();
/*  387 */     int len = strs.length;
/*  388 */     if (len == 0) {
/*  389 */       return Collections.emptyList();
/*      */     }
/*  391 */     List<PropertyName> result = new ArrayList<>(len);
/*  392 */     for (int i = 0; i < len; i++) {
/*  393 */       result.add(PropertyName.construct(strs[i]));
/*      */     }
/*  395 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean hasIgnoreMarker(AnnotatedMember m) {
/*  400 */     return _isIgnorable(m);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Boolean hasRequiredMarker(AnnotatedMember m) {
/*  406 */     JsonProperty ann = (JsonProperty)_findAnnotation(m, JsonProperty.class);
/*  407 */     if (ann != null) {
/*  408 */       return Boolean.valueOf(ann.required());
/*      */     }
/*  410 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public JsonProperty.Access findPropertyAccess(Annotated m) {
/*  415 */     JsonProperty ann = (JsonProperty)_findAnnotation(m, JsonProperty.class);
/*  416 */     if (ann != null) {
/*  417 */       return ann.access();
/*      */     }
/*  419 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public String findPropertyDescription(Annotated ann) {
/*  424 */     JsonPropertyDescription desc = (JsonPropertyDescription)_findAnnotation(ann, JsonPropertyDescription.class);
/*  425 */     return (desc == null) ? null : desc.value();
/*      */   }
/*      */ 
/*      */   
/*      */   public Integer findPropertyIndex(Annotated ann) {
/*  430 */     JsonProperty prop = (JsonProperty)_findAnnotation(ann, JsonProperty.class);
/*  431 */     if (prop != null) {
/*  432 */       int ix = prop.index();
/*  433 */       if (ix != -1) {
/*  434 */         return Integer.valueOf(ix);
/*      */       }
/*      */     } 
/*  437 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public String findPropertyDefaultValue(Annotated ann) {
/*  442 */     JsonProperty prop = (JsonProperty)_findAnnotation(ann, JsonProperty.class);
/*  443 */     if (prop == null) {
/*  444 */       return null;
/*      */     }
/*  446 */     String str = prop.defaultValue();
/*      */     
/*  448 */     return str.isEmpty() ? null : str;
/*      */   }
/*      */ 
/*      */   
/*      */   public JsonFormat.Value findFormat(Annotated ann) {
/*  453 */     JsonFormat f = (JsonFormat)_findAnnotation(ann, JsonFormat.class);
/*      */ 
/*      */     
/*  456 */     return (f == null) ? null : JsonFormat.Value.from(f);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationIntrospector.ReferenceProperty findReferenceType(AnnotatedMember member) {
/*  462 */     JsonManagedReference ref1 = (JsonManagedReference)_findAnnotation(member, JsonManagedReference.class);
/*  463 */     if (ref1 != null) {
/*  464 */       return AnnotationIntrospector.ReferenceProperty.managed(ref1.value());
/*      */     }
/*  466 */     JsonBackReference ref2 = (JsonBackReference)_findAnnotation(member, JsonBackReference.class);
/*  467 */     if (ref2 != null) {
/*  468 */       return AnnotationIntrospector.ReferenceProperty.back(ref2.value());
/*      */     }
/*  470 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public NameTransformer findUnwrappingNameTransformer(AnnotatedMember member) {
/*  476 */     JsonUnwrapped ann = (JsonUnwrapped)_findAnnotation(member, JsonUnwrapped.class);
/*      */ 
/*      */     
/*  479 */     if (ann == null || !ann.enabled()) {
/*  480 */       return null;
/*      */     }
/*  482 */     String prefix = ann.prefix();
/*  483 */     String suffix = ann.suffix();
/*  484 */     return NameTransformer.simpleTransformer(prefix, suffix);
/*      */   }
/*      */ 
/*      */   
/*      */   public JacksonInject.Value findInjectableValue(AnnotatedMember m) {
/*  489 */     JacksonInject ann = (JacksonInject)_findAnnotation(m, JacksonInject.class);
/*  490 */     if (ann == null) {
/*  491 */       return null;
/*      */     }
/*      */     
/*  494 */     JacksonInject.Value v = JacksonInject.Value.from(ann);
/*  495 */     if (!v.hasId()) {
/*      */       Object id;
/*      */       
/*  498 */       if (!(m instanceof AnnotatedMethod)) {
/*  499 */         id = m.getRawType().getName();
/*      */       } else {
/*  501 */         AnnotatedMethod am = (AnnotatedMethod)m;
/*  502 */         if (am.getParameterCount() == 0) {
/*  503 */           id = m.getRawType().getName();
/*      */         } else {
/*  505 */           id = am.getRawParameterType(0).getName();
/*      */         } 
/*      */       } 
/*  508 */       v = v.withId(id);
/*      */     } 
/*  510 */     return v;
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Object findInjectableValueId(AnnotatedMember m) {
/*  516 */     JacksonInject.Value v = findInjectableValue(m);
/*  517 */     return (v == null) ? null : v.getId();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Class<?>[] findViews(Annotated a) {
/*  523 */     JsonView ann = (JsonView)_findAnnotation(a, JsonView.class);
/*  524 */     return (ann == null) ? null : ann.value();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotatedMethod resolveSetterConflict(MapperConfig<?> config, AnnotatedMethod setter1, AnnotatedMethod setter2) {
/*  545 */     Class<?> cls1 = setter1.getRawParameterType(0);
/*  546 */     Class<?> cls2 = setter2.getRawParameterType(0);
/*      */ 
/*      */ 
/*      */     
/*  550 */     if (cls1.isPrimitive()) {
/*  551 */       if (!cls2.isPrimitive()) {
/*  552 */         return setter1;
/*      */       }
/*      */       
/*  555 */       return null;
/*  556 */     }  if (cls2.isPrimitive()) {
/*  557 */       return setter2;
/*      */     }
/*      */     
/*  560 */     if (cls1 == String.class) {
/*  561 */       if (cls2 != String.class) {
/*  562 */         return setter1;
/*      */       }
/*  564 */     } else if (cls2 == String.class) {
/*  565 */       return setter2;
/*      */     } 
/*      */     
/*  568 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PropertyName findRenameByField(MapperConfig<?> config, AnnotatedField f, PropertyName implName) {
/*  575 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeResolverBuilder<?> findTypeResolver(MapperConfig<?> config, AnnotatedClass ac, JavaType baseType) {
/*  588 */     return _findTypeResolver(config, ac, baseType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeResolverBuilder<?> findPropertyTypeResolver(MapperConfig<?> config, AnnotatedMember am, JavaType baseType) {
/*  599 */     if (baseType.isContainerType() || baseType.isReferenceType()) {
/*  600 */       return null;
/*      */     }
/*      */     
/*  603 */     return _findTypeResolver(config, am, baseType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeResolverBuilder<?> findPropertyContentTypeResolver(MapperConfig<?> config, AnnotatedMember am, JavaType containerType) {
/*  612 */     if (containerType.getContentType() == null) {
/*  613 */       throw new IllegalArgumentException("Must call method with a container or reference type (got " + containerType + ")");
/*      */     }
/*  615 */     return _findTypeResolver(config, am, containerType);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<NamedType> findSubtypes(Annotated a) {
/*  621 */     JsonSubTypes t = (JsonSubTypes)_findAnnotation(a, JsonSubTypes.class);
/*  622 */     if (t == null) return null; 
/*  623 */     JsonSubTypes.Type[] types = t.value();
/*      */ 
/*      */ 
/*      */     
/*  627 */     if (t.failOnRepeatedNames()) {
/*  628 */       return findSubtypesCheckRepeatedNames(a.getName(), types);
/*      */     }
/*  630 */     ArrayList<NamedType> result = new ArrayList<>(types.length);
/*  631 */     for (JsonSubTypes.Type type : types) {
/*  632 */       result.add(new NamedType(type.value(), type.name()));
/*      */       
/*  634 */       for (String name : type.names()) {
/*  635 */         result.add(new NamedType(type.value(), name));
/*      */       }
/*      */     } 
/*  638 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private List<NamedType> findSubtypesCheckRepeatedNames(String annotatedTypeName, JsonSubTypes.Type[] types) {
/*  645 */     ArrayList<NamedType> result = new ArrayList<>(types.length);
/*  646 */     Set<String> seenNames = new HashSet<>();
/*  647 */     for (JsonSubTypes.Type type : types) {
/*  648 */       String typeName = type.name();
/*  649 */       if (!typeName.isEmpty() && seenNames.contains(typeName)) {
/*  650 */         throw new IllegalArgumentException("Annotated type [" + annotatedTypeName + "] got repeated subtype name [" + typeName + "]");
/*      */       }
/*  652 */       seenNames.add(typeName);
/*      */       
/*  654 */       result.add(new NamedType(type.value(), typeName));
/*      */ 
/*      */       
/*  657 */       for (String altName : type.names()) {
/*  658 */         if (!altName.isEmpty() && seenNames.contains(altName)) {
/*  659 */           throw new IllegalArgumentException("Annotated type [" + annotatedTypeName + "] got repeated subtype name [" + altName + "]");
/*      */         }
/*  661 */         seenNames.add(altName);
/*      */         
/*  663 */         result.add(new NamedType(type.value(), altName));
/*      */       } 
/*      */     } 
/*      */     
/*  667 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String findTypeName(AnnotatedClass ac) {
/*  673 */     JsonTypeName tn = (JsonTypeName)_findAnnotation(ac, JsonTypeName.class);
/*  674 */     return (tn == null) ? null : tn.value();
/*      */   }
/*      */ 
/*      */   
/*      */   public Boolean isTypeId(AnnotatedMember member) {
/*  679 */     return Boolean.valueOf(_hasAnnotation(member, JsonTypeId.class));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectIdInfo findObjectIdInfo(Annotated ann) {
/*  690 */     JsonIdentityInfo info = (JsonIdentityInfo)_findAnnotation(ann, JsonIdentityInfo.class);
/*  691 */     if (info == null || info.generator() == ObjectIdGenerators.None.class) {
/*  692 */       return null;
/*      */     }
/*      */     
/*  695 */     PropertyName name = PropertyName.construct(info.property());
/*  696 */     return new ObjectIdInfo(name, info.scope(), info.generator(), info.resolver());
/*      */   }
/*      */ 
/*      */   
/*      */   public ObjectIdInfo findObjectReferenceInfo(Annotated ann, ObjectIdInfo objectIdInfo) {
/*  701 */     JsonIdentityReference ref = (JsonIdentityReference)_findAnnotation(ann, JsonIdentityReference.class);
/*  702 */     if (ref == null) {
/*  703 */       return objectIdInfo;
/*      */     }
/*  705 */     if (objectIdInfo == null) {
/*  706 */       objectIdInfo = ObjectIdInfo.empty();
/*      */     }
/*  708 */     return objectIdInfo.withAlwaysAsId(ref.alwaysAsId());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object findSerializer(Annotated a) {
/*  720 */     JsonSerialize ann = (JsonSerialize)_findAnnotation(a, JsonSerialize.class);
/*  721 */     if (ann != null) {
/*      */       
/*  723 */       Class<? extends JsonSerializer> serClass = ann.using();
/*  724 */       if (serClass != JsonSerializer.None.class) {
/*  725 */         return serClass;
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  733 */     JsonRawValue annRaw = (JsonRawValue)_findAnnotation(a, JsonRawValue.class);
/*  734 */     if (annRaw != null && annRaw.value()) {
/*      */       
/*  736 */       Class<?> cls = a.getRawType();
/*  737 */       return new RawSerializer(cls);
/*      */     } 
/*  739 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Object findKeySerializer(Annotated a) {
/*  745 */     JsonSerialize ann = (JsonSerialize)_findAnnotation(a, JsonSerialize.class);
/*  746 */     if (ann != null) {
/*      */       
/*  748 */       Class<? extends JsonSerializer> serClass = ann.keyUsing();
/*  749 */       if (serClass != JsonSerializer.None.class) {
/*  750 */         return serClass;
/*      */       }
/*      */     } 
/*  753 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Object findContentSerializer(Annotated a) {
/*  759 */     JsonSerialize ann = (JsonSerialize)_findAnnotation(a, JsonSerialize.class);
/*  760 */     if (ann != null) {
/*      */       
/*  762 */       Class<? extends JsonSerializer> serClass = ann.contentUsing();
/*  763 */       if (serClass != JsonSerializer.None.class) {
/*  764 */         return serClass;
/*      */       }
/*      */     } 
/*  767 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Object findNullSerializer(Annotated a) {
/*  773 */     JsonSerialize ann = (JsonSerialize)_findAnnotation(a, JsonSerialize.class);
/*  774 */     if (ann != null) {
/*      */       
/*  776 */       Class<? extends JsonSerializer> serClass = ann.nullsUsing();
/*  777 */       if (serClass != JsonSerializer.None.class) {
/*  778 */         return serClass;
/*      */       }
/*      */     } 
/*  781 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonInclude.Value findPropertyInclusion(Annotated a) {
/*  787 */     JsonInclude inc = (JsonInclude)_findAnnotation(a, JsonInclude.class);
/*  788 */     JsonInclude.Value value = (inc == null) ? JsonInclude.Value.empty() : JsonInclude.Value.from(inc);
/*      */ 
/*      */     
/*  791 */     if (value.getValueInclusion() == JsonInclude.Include.USE_DEFAULTS) {
/*  792 */       value = _refinePropertyInclusion(a, value);
/*      */     }
/*  794 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   private JsonInclude.Value _refinePropertyInclusion(Annotated a, JsonInclude.Value value) {
/*  799 */     JsonSerialize ann = (JsonSerialize)_findAnnotation(a, JsonSerialize.class);
/*  800 */     if (ann != null) {
/*  801 */       switch (ann.include()) {
/*      */         case ALWAYS:
/*  803 */           return value.withValueInclusion(JsonInclude.Include.ALWAYS);
/*      */         case NON_NULL:
/*  805 */           return value.withValueInclusion(JsonInclude.Include.NON_NULL);
/*      */         case NON_DEFAULT:
/*  807 */           return value.withValueInclusion(JsonInclude.Include.NON_DEFAULT);
/*      */         case NON_EMPTY:
/*  809 */           return value.withValueInclusion(JsonInclude.Include.NON_EMPTY);
/*      */       } 
/*      */ 
/*      */     
/*      */     }
/*  814 */     return value;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonSerialize.Typing findSerializationTyping(Annotated a) {
/*  820 */     JsonSerialize ann = (JsonSerialize)_findAnnotation(a, JsonSerialize.class);
/*  821 */     return (ann == null) ? null : ann.typing();
/*      */   }
/*      */ 
/*      */   
/*      */   public Object findSerializationConverter(Annotated a) {
/*  826 */     JsonSerialize ann = (JsonSerialize)_findAnnotation(a, JsonSerialize.class);
/*  827 */     return (ann == null) ? null : _classIfExplicit(ann.converter(), Converter.None.class);
/*      */   }
/*      */ 
/*      */   
/*      */   public Object findSerializationContentConverter(AnnotatedMember a) {
/*  832 */     JsonSerialize ann = (JsonSerialize)_findAnnotation(a, JsonSerialize.class);
/*  833 */     return (ann == null) ? null : _classIfExplicit(ann.contentConverter(), Converter.None.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType refineSerializationType(MapperConfig<?> config, Annotated a, JavaType baseType) throws JsonMappingException {
/*      */     MapLikeType mapLikeType;
/*  847 */     JavaType javaType1, type = baseType;
/*  848 */     TypeFactory tf = config.getTypeFactory();
/*      */     
/*  850 */     JsonSerialize jsonSer = (JsonSerialize)_findAnnotation(a, JsonSerialize.class);
/*      */ 
/*      */ 
/*      */     
/*  854 */     Class<?> serClass = (jsonSer == null) ? null : _classIfExplicit(jsonSer.as());
/*  855 */     if (serClass != null) {
/*  856 */       if (type.hasRawClass(serClass)) {
/*      */ 
/*      */         
/*  859 */         type = type.withStaticTyping();
/*      */       } else {
/*  861 */         Class<?> currRaw = type.getRawClass();
/*      */ 
/*      */         
/*      */         try {
/*  865 */           if (serClass.isAssignableFrom(currRaw)) {
/*  866 */             type = tf.constructGeneralizedType(type, serClass);
/*  867 */           } else if (currRaw.isAssignableFrom(serClass)) {
/*  868 */             type = tf.constructSpecializedType(type, serClass);
/*  869 */           } else if (_primitiveAndWrapper(currRaw, serClass)) {
/*      */             
/*  871 */             type = type.withStaticTyping();
/*      */           } else {
/*  873 */             throw _databindException(
/*  874 */                 String.format("Cannot refine serialization type %s into %s; types not related", new Object[] {
/*  875 */                     type, serClass.getName() }));
/*      */           } 
/*  877 */         } catch (IllegalArgumentException iae) {
/*  878 */           throw _databindException(iae, 
/*  879 */               String.format("Failed to widen type %s with annotation (value %s), from '%s': %s", new Object[] {
/*  880 */                   type, serClass.getName(), a.getName(), iae.getMessage()
/*      */                 }));
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*  887 */     if (type.isMapLikeType()) {
/*  888 */       JavaType keyType = type.getKeyType();
/*  889 */       Class<?> keyClass = (jsonSer == null) ? null : _classIfExplicit(jsonSer.keyAs());
/*  890 */       if (keyClass != null) {
/*  891 */         if (keyType.hasRawClass(keyClass)) {
/*  892 */           keyType = keyType.withStaticTyping();
/*      */         } else {
/*  894 */           Class<?> currRaw = keyType.getRawClass();
/*      */ 
/*      */ 
/*      */           
/*      */           try {
/*  899 */             if (keyClass.isAssignableFrom(currRaw)) {
/*  900 */               keyType = tf.constructGeneralizedType(keyType, keyClass);
/*  901 */             } else if (currRaw.isAssignableFrom(keyClass)) {
/*  902 */               keyType = tf.constructSpecializedType(keyType, keyClass);
/*  903 */             } else if (_primitiveAndWrapper(currRaw, keyClass)) {
/*      */               
/*  905 */               keyType = keyType.withStaticTyping();
/*      */             } else {
/*  907 */               throw _databindException(
/*  908 */                   String.format("Cannot refine serialization key type %s into %s; types not related", new Object[] {
/*  909 */                       keyType, keyClass.getName() }));
/*      */             } 
/*  911 */           } catch (IllegalArgumentException iae) {
/*  912 */             throw _databindException(iae, 
/*  913 */                 String.format("Failed to widen key type of %s with concrete-type annotation (value %s), from '%s': %s", new Object[] {
/*  914 */                     type, keyClass.getName(), a.getName(), iae.getMessage() }));
/*      */           } 
/*      */         } 
/*  917 */         mapLikeType = ((MapLikeType)type).withKeyType(keyType);
/*      */       } 
/*      */     } 
/*      */     
/*  921 */     JavaType contentType = mapLikeType.getContentType();
/*  922 */     if (contentType != null) {
/*      */       
/*  924 */       Class<?> contentClass = (jsonSer == null) ? null : _classIfExplicit(jsonSer.contentAs());
/*  925 */       if (contentClass != null) {
/*  926 */         if (contentType.hasRawClass(contentClass)) {
/*  927 */           contentType = contentType.withStaticTyping();
/*      */         
/*      */         }
/*      */         else {
/*      */           
/*  932 */           Class<?> currRaw = contentType.getRawClass();
/*      */           try {
/*  934 */             if (contentClass.isAssignableFrom(currRaw)) {
/*  935 */               contentType = tf.constructGeneralizedType(contentType, contentClass);
/*  936 */             } else if (currRaw.isAssignableFrom(contentClass)) {
/*  937 */               contentType = tf.constructSpecializedType(contentType, contentClass);
/*  938 */             } else if (_primitiveAndWrapper(currRaw, contentClass)) {
/*      */               
/*  940 */               contentType = contentType.withStaticTyping();
/*      */             } else {
/*  942 */               throw _databindException(
/*  943 */                   String.format("Cannot refine serialization content type %s into %s; types not related", new Object[] {
/*  944 */                       contentType, contentClass.getName() }));
/*      */             } 
/*  946 */           } catch (IllegalArgumentException iae) {
/*  947 */             throw _databindException(iae, 
/*  948 */                 String.format("Internal error: failed to refine value type of %s with concrete-type annotation (value %s), from '%s': %s", new Object[] {
/*  949 */                     mapLikeType, contentClass.getName(), a.getName(), iae.getMessage() }));
/*      */           } 
/*      */         } 
/*  952 */         javaType1 = mapLikeType.withContentType(contentType);
/*      */       } 
/*      */     } 
/*  955 */     return javaType1;
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Class<?> findSerializationType(Annotated am) {
/*  961 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Class<?> findSerializationKeyType(Annotated am, JavaType baseType) {
/*  967 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Class<?> findSerializationContentType(Annotated am, JavaType baseType) {
/*  973 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] findSerializationPropertyOrder(AnnotatedClass ac) {
/*  984 */     JsonPropertyOrder order = (JsonPropertyOrder)_findAnnotation(ac, JsonPropertyOrder.class);
/*  985 */     return (order == null) ? null : order.value();
/*      */   }
/*      */ 
/*      */   
/*      */   public Boolean findSerializationSortAlphabetically(Annotated ann) {
/*  990 */     return _findSortAlpha(ann);
/*      */   }
/*      */   
/*      */   private final Boolean _findSortAlpha(Annotated ann) {
/*  994 */     JsonPropertyOrder order = (JsonPropertyOrder)_findAnnotation(ann, JsonPropertyOrder.class);
/*      */ 
/*      */     
/*  997 */     if (order != null && order.alphabetic()) {
/*  998 */       return Boolean.TRUE;
/*      */     }
/* 1000 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void findAndAddVirtualProperties(MapperConfig<?> config, AnnotatedClass ac, List<BeanPropertyWriter> properties) {
/* 1006 */     JsonAppend ann = (JsonAppend)_findAnnotation(ac, JsonAppend.class);
/* 1007 */     if (ann == null) {
/*      */       return;
/*      */     }
/* 1010 */     boolean prepend = ann.prepend();
/* 1011 */     JavaType propType = null;
/*      */ 
/*      */     
/* 1014 */     JsonAppend.Attr[] attrs = ann.attrs();
/* 1015 */     for (int i = 0, len = attrs.length; i < len; i++) {
/* 1016 */       if (propType == null) {
/* 1017 */         propType = config.constructType(Object.class);
/*      */       }
/* 1019 */       BeanPropertyWriter bpw = _constructVirtualProperty(attrs[i], config, ac, propType);
/*      */       
/* 1021 */       if (prepend) {
/* 1022 */         properties.add(i, bpw);
/*      */       } else {
/* 1024 */         properties.add(bpw);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1029 */     JsonAppend.Prop[] props = ann.props();
/* 1030 */     for (int j = 0, k = props.length; j < k; j++) {
/* 1031 */       BeanPropertyWriter bpw = _constructVirtualProperty(props[j], config, ac);
/*      */       
/* 1033 */       if (prepend) {
/* 1034 */         properties.add(j, bpw);
/*      */       } else {
/* 1036 */         properties.add(bpw);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected BeanPropertyWriter _constructVirtualProperty(JsonAppend.Attr attr, MapperConfig<?> config, AnnotatedClass ac, JavaType type) {
/* 1044 */     PropertyMetadata metadata = attr.required() ? PropertyMetadata.STD_REQUIRED : PropertyMetadata.STD_OPTIONAL;
/*      */ 
/*      */     
/* 1047 */     String attrName = attr.value();
/*      */ 
/*      */     
/* 1050 */     PropertyName propName = _propertyName(attr.propName(), attr.propNamespace());
/* 1051 */     if (!propName.hasSimpleName()) {
/* 1052 */       propName = PropertyName.construct(attrName);
/*      */     }
/*      */     
/* 1055 */     AnnotatedMember member = new VirtualAnnotatedMember(ac, ac.getRawType(), attrName, type);
/*      */ 
/*      */     
/* 1058 */     SimpleBeanPropertyDefinition propDef = SimpleBeanPropertyDefinition.construct(config, member, propName, metadata, attr
/* 1059 */         .include());
/*      */     
/* 1061 */     return (BeanPropertyWriter)AttributePropertyWriter.construct(attrName, (BeanPropertyDefinition)propDef, ac
/* 1062 */         .getAnnotations(), type);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected BeanPropertyWriter _constructVirtualProperty(JsonAppend.Prop prop, MapperConfig<?> config, AnnotatedClass ac) {
/* 1068 */     PropertyMetadata metadata = prop.required() ? PropertyMetadata.STD_REQUIRED : PropertyMetadata.STD_OPTIONAL;
/*      */     
/* 1070 */     PropertyName propName = _propertyName(prop.name(), prop.namespace());
/* 1071 */     JavaType type = config.constructType(prop.type());
/*      */ 
/*      */     
/* 1074 */     AnnotatedMember member = new VirtualAnnotatedMember(ac, ac.getRawType(), propName.getSimpleName(), type);
/*      */     
/* 1076 */     SimpleBeanPropertyDefinition propDef = SimpleBeanPropertyDefinition.construct(config, member, propName, metadata, prop
/* 1077 */         .include());
/*      */     
/* 1079 */     Class<?> implClass = prop.value();
/*      */     
/* 1081 */     HandlerInstantiator hi = config.getHandlerInstantiator();
/*      */     
/* 1083 */     VirtualBeanPropertyWriter bpw = (hi == null) ? null : hi.virtualPropertyWriterInstance(config, implClass);
/* 1084 */     if (bpw == null) {
/* 1085 */       bpw = (VirtualBeanPropertyWriter)ClassUtil.createInstance(implClass, config
/* 1086 */           .canOverrideAccessModifiers());
/*      */     }
/*      */ 
/*      */     
/* 1090 */     return (BeanPropertyWriter)bpw.withConfig(config, ac, (BeanPropertyDefinition)propDef, type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PropertyName findNameForSerialization(Annotated a) {
/* 1102 */     boolean useDefault = false;
/* 1103 */     JsonGetter jg = (JsonGetter)_findAnnotation(a, JsonGetter.class);
/* 1104 */     if (jg != null) {
/* 1105 */       String s = jg.value();
/*      */       
/* 1107 */       if (!s.isEmpty()) {
/* 1108 */         return PropertyName.construct(s);
/*      */       }
/* 1110 */       useDefault = true;
/*      */     } 
/* 1112 */     JsonProperty pann = (JsonProperty)_findAnnotation(a, JsonProperty.class);
/* 1113 */     if (pann != null) {
/*      */       
/* 1115 */       String ns = pann.namespace();
/* 1116 */       if (ns != null && ns.isEmpty()) {
/* 1117 */         ns = null;
/*      */       }
/* 1119 */       return PropertyName.construct(pann.value(), ns);
/*      */     } 
/* 1121 */     if (useDefault || _hasOneOf(a, (Class[])ANNOTATIONS_TO_INFER_SER)) {
/* 1122 */       return PropertyName.USE_DEFAULT;
/*      */     }
/* 1124 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public Boolean hasAsKey(MapperConfig<?> config, Annotated a) {
/* 1129 */     JsonKey ann = (JsonKey)_findAnnotation(a, JsonKey.class);
/* 1130 */     if (ann == null) {
/* 1131 */       return null;
/*      */     }
/* 1133 */     return Boolean.valueOf(ann.value());
/*      */   }
/*      */ 
/*      */   
/*      */   public Boolean hasAsValue(Annotated a) {
/* 1138 */     JsonValue ann = (JsonValue)_findAnnotation(a, JsonValue.class);
/* 1139 */     if (ann == null) {
/* 1140 */       return null;
/*      */     }
/* 1142 */     return Boolean.valueOf(ann.value());
/*      */   }
/*      */ 
/*      */   
/*      */   public Boolean hasAnyGetter(Annotated a) {
/* 1147 */     JsonAnyGetter ann = (JsonAnyGetter)_findAnnotation(a, JsonAnyGetter.class);
/* 1148 */     if (ann == null) {
/* 1149 */       return null;
/*      */     }
/* 1151 */     return Boolean.valueOf(ann.enabled());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public boolean hasAnyGetterAnnotation(AnnotatedMethod am) {
/* 1158 */     return _hasAnnotation(am, JsonAnyGetter.class);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public boolean hasAsValueAnnotation(AnnotatedMethod am) {
/* 1164 */     JsonValue ann = (JsonValue)_findAnnotation(am, JsonValue.class);
/*      */     
/* 1166 */     return (ann != null && ann.value());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object findDeserializer(Annotated a) {
/* 1178 */     JsonDeserialize ann = (JsonDeserialize)_findAnnotation(a, JsonDeserialize.class);
/* 1179 */     if (ann != null) {
/*      */       
/* 1181 */       Class<? extends JsonDeserializer> deserClass = ann.using();
/* 1182 */       if (deserClass != JsonDeserializer.None.class) {
/* 1183 */         return deserClass;
/*      */       }
/*      */     } 
/* 1186 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Object findKeyDeserializer(Annotated a) {
/* 1192 */     JsonDeserialize ann = (JsonDeserialize)_findAnnotation(a, JsonDeserialize.class);
/* 1193 */     if (ann != null) {
/* 1194 */       Class<? extends KeyDeserializer> deserClass = ann.keyUsing();
/* 1195 */       if (deserClass != KeyDeserializer.None.class) {
/* 1196 */         return deserClass;
/*      */       }
/*      */     } 
/* 1199 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Object findContentDeserializer(Annotated a) {
/* 1205 */     JsonDeserialize ann = (JsonDeserialize)_findAnnotation(a, JsonDeserialize.class);
/* 1206 */     if (ann != null) {
/*      */       
/* 1208 */       Class<? extends JsonDeserializer> deserClass = ann.contentUsing();
/* 1209 */       if (deserClass != JsonDeserializer.None.class) {
/* 1210 */         return deserClass;
/*      */       }
/*      */     } 
/* 1213 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Object findDeserializationConverter(Annotated a) {
/* 1219 */     JsonDeserialize ann = (JsonDeserialize)_findAnnotation(a, JsonDeserialize.class);
/* 1220 */     return (ann == null) ? null : _classIfExplicit(ann.converter(), Converter.None.class);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Object findDeserializationContentConverter(AnnotatedMember a) {
/* 1226 */     JsonDeserialize ann = (JsonDeserialize)_findAnnotation(a, JsonDeserialize.class);
/* 1227 */     return (ann == null) ? null : _classIfExplicit(ann.contentConverter(), Converter.None.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType refineDeserializationType(MapperConfig<?> config, Annotated a, JavaType baseType) throws JsonMappingException {
/*      */     MapLikeType mapLikeType;
/* 1240 */     JavaType javaType1, type = baseType;
/* 1241 */     TypeFactory tf = config.getTypeFactory();
/*      */     
/* 1243 */     JsonDeserialize jsonDeser = (JsonDeserialize)_findAnnotation(a, JsonDeserialize.class);
/*      */ 
/*      */     
/* 1246 */     Class<?> valueClass = (jsonDeser == null) ? null : _classIfExplicit(jsonDeser.as());
/* 1247 */     if (valueClass != null && !type.hasRawClass(valueClass) && 
/* 1248 */       !_primitiveAndWrapper(type, valueClass)) {
/*      */       try {
/* 1250 */         type = tf.constructSpecializedType(type, valueClass);
/* 1251 */       } catch (IllegalArgumentException iae) {
/* 1252 */         throw _databindException(iae, 
/* 1253 */             String.format("Failed to narrow type %s with annotation (value %s), from '%s': %s", new Object[] {
/* 1254 */                 type, valueClass.getName(), a.getName(), iae.getMessage()
/*      */               }));
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 1260 */     if (type.isMapLikeType()) {
/* 1261 */       JavaType keyType = type.getKeyType();
/* 1262 */       Class<?> keyClass = (jsonDeser == null) ? null : _classIfExplicit(jsonDeser.keyAs());
/* 1263 */       if (keyClass != null && 
/* 1264 */         !_primitiveAndWrapper(keyType, keyClass))
/*      */         try {
/* 1266 */           keyType = tf.constructSpecializedType(keyType, keyClass);
/* 1267 */           mapLikeType = ((MapLikeType)type).withKeyType(keyType);
/* 1268 */         } catch (IllegalArgumentException iae) {
/* 1269 */           throw _databindException(iae, 
/* 1270 */               String.format("Failed to narrow key type of %s with concrete-type annotation (value %s), from '%s': %s", new Object[] {
/* 1271 */                   mapLikeType, keyClass.getName(), a.getName(), iae.getMessage()
/*      */                 }));
/*      */         }  
/*      */     } 
/* 1275 */     JavaType contentType = mapLikeType.getContentType();
/* 1276 */     if (contentType != null) {
/*      */       
/* 1278 */       Class<?> contentClass = (jsonDeser == null) ? null : _classIfExplicit(jsonDeser.contentAs());
/* 1279 */       if (contentClass != null && 
/* 1280 */         !_primitiveAndWrapper(contentType, contentClass))
/*      */         try {
/* 1282 */           contentType = tf.constructSpecializedType(contentType, contentClass);
/* 1283 */           javaType1 = mapLikeType.withContentType(contentType);
/* 1284 */         } catch (IllegalArgumentException iae) {
/* 1285 */           throw _databindException(iae, 
/* 1286 */               String.format("Failed to narrow value type of %s with concrete-type annotation (value %s), from '%s': %s", new Object[] {
/* 1287 */                   javaType1, contentClass.getName(), a.getName(), iae.getMessage()
/*      */                 }));
/*      */         }  
/*      */     } 
/* 1291 */     return javaType1;
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Class<?> findDeserializationContentType(Annotated am, JavaType baseContentType) {
/* 1297 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Class<?> findDeserializationType(Annotated am, JavaType baseType) {
/* 1303 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Class<?> findDeserializationKeyType(Annotated am, JavaType baseKeyType) {
/* 1309 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object findValueInstantiator(AnnotatedClass ac) {
/* 1321 */     JsonValueInstantiator ann = (JsonValueInstantiator)_findAnnotation(ac, JsonValueInstantiator.class);
/*      */     
/* 1323 */     return (ann == null) ? null : ann.value();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Class<?> findPOJOBuilder(AnnotatedClass ac) {
/* 1329 */     JsonDeserialize ann = (JsonDeserialize)_findAnnotation(ac, JsonDeserialize.class);
/* 1330 */     return (ann == null) ? null : _classIfExplicit(ann.builder());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonPOJOBuilder.Value findPOJOBuilderConfig(AnnotatedClass ac) {
/* 1336 */     JsonPOJOBuilder ann = (JsonPOJOBuilder)_findAnnotation(ac, JsonPOJOBuilder.class);
/* 1337 */     return (ann == null) ? null : new JsonPOJOBuilder.Value(ann);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PropertyName findNameForDeserialization(Annotated a) {
/* 1351 */     boolean useDefault = false;
/* 1352 */     JsonSetter js = (JsonSetter)_findAnnotation(a, JsonSetter.class);
/* 1353 */     if (js != null) {
/* 1354 */       String s = js.value();
/*      */       
/* 1356 */       if (s.isEmpty()) {
/* 1357 */         useDefault = true;
/*      */       } else {
/* 1359 */         return PropertyName.construct(s);
/*      */       } 
/*      */     } 
/* 1362 */     JsonProperty pann = (JsonProperty)_findAnnotation(a, JsonProperty.class);
/* 1363 */     if (pann != null) {
/*      */       
/* 1365 */       String ns = pann.namespace();
/* 1366 */       if (ns != null && ns.isEmpty()) {
/* 1367 */         ns = null;
/*      */       }
/* 1369 */       return PropertyName.construct(pann.value(), ns);
/*      */     } 
/* 1371 */     if (useDefault || _hasOneOf(a, (Class[])ANNOTATIONS_TO_INFER_DESER)) {
/* 1372 */       return PropertyName.USE_DEFAULT;
/*      */     }
/* 1374 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public Boolean hasAnySetter(Annotated a) {
/* 1379 */     JsonAnySetter ann = (JsonAnySetter)_findAnnotation(a, JsonAnySetter.class);
/* 1380 */     return (ann == null) ? null : Boolean.valueOf(ann.enabled());
/*      */   }
/*      */ 
/*      */   
/*      */   public JsonSetter.Value findSetterInfo(Annotated a) {
/* 1385 */     return JsonSetter.Value.from((JsonSetter)_findAnnotation(a, JsonSetter.class));
/*      */   }
/*      */ 
/*      */   
/*      */   public Boolean findMergeInfo(Annotated a) {
/* 1390 */     JsonMerge ann = (JsonMerge)_findAnnotation(a, JsonMerge.class);
/* 1391 */     return (ann == null) ? null : ann.value().asBoolean();
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public boolean hasAnySetterAnnotation(AnnotatedMethod am) {
/* 1397 */     return _hasAnnotation(am, JsonAnySetter.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public boolean hasCreatorAnnotation(Annotated a) {
/* 1407 */     JsonCreator ann = (JsonCreator)_findAnnotation(a, JsonCreator.class);
/* 1408 */     if (ann != null) {
/* 1409 */       return (ann.mode() != JsonCreator.Mode.DISABLED);
/*      */     }
/*      */ 
/*      */     
/* 1413 */     if (this._cfgConstructorPropertiesImpliesCreator && 
/* 1414 */       a instanceof AnnotatedConstructor && 
/* 1415 */       _java7Helper != null) {
/* 1416 */       Boolean b = _java7Helper.hasCreatorAnnotation(a);
/* 1417 */       if (b != null) {
/* 1418 */         return b.booleanValue();
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1423 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonCreator.Mode findCreatorBinding(Annotated a) {
/* 1429 */     JsonCreator ann = (JsonCreator)_findAnnotation(a, JsonCreator.class);
/* 1430 */     return (ann == null) ? null : ann.mode();
/*      */   }
/*      */ 
/*      */   
/*      */   public JsonCreator.Mode findCreatorAnnotation(MapperConfig<?> config, Annotated a) {
/* 1435 */     JsonCreator ann = (JsonCreator)_findAnnotation(a, JsonCreator.class);
/* 1436 */     if (ann != null) {
/* 1437 */       return ann.mode();
/*      */     }
/* 1439 */     if (this._cfgConstructorPropertiesImpliesCreator && config
/* 1440 */       .isEnabled(MapperFeature.INFER_CREATOR_FROM_CONSTRUCTOR_PROPERTIES))
/*      */     {
/* 1442 */       if (a instanceof AnnotatedConstructor && 
/* 1443 */         _java7Helper != null) {
/* 1444 */         Boolean b = _java7Helper.hasCreatorAnnotation(a);
/* 1445 */         if (b != null && b.booleanValue())
/*      */         {
/*      */           
/* 1448 */           return JsonCreator.Mode.PROPERTIES;
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/* 1453 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _isIgnorable(Annotated a) {
/* 1464 */     JsonIgnore ann = (JsonIgnore)_findAnnotation(a, JsonIgnore.class);
/* 1465 */     if (ann != null) {
/* 1466 */       return ann.value();
/*      */     }
/* 1468 */     if (_java7Helper != null) {
/* 1469 */       Boolean b = _java7Helper.findTransient(a);
/* 1470 */       if (b != null) {
/* 1471 */         return b.booleanValue();
/*      */       }
/*      */     } 
/* 1474 */     return false;
/*      */   }
/*      */   
/*      */   protected Class<?> _classIfExplicit(Class<?> cls) {
/* 1478 */     if (cls == null || ClassUtil.isBogusClass(cls)) {
/* 1479 */       return null;
/*      */     }
/* 1481 */     return cls;
/*      */   }
/*      */   
/*      */   protected Class<?> _classIfExplicit(Class<?> cls, Class<?> implicit) {
/* 1485 */     cls = _classIfExplicit(cls);
/* 1486 */     return (cls == null || cls == implicit) ? null : cls;
/*      */   }
/*      */   
/*      */   protected PropertyName _propertyName(String localName, String namespace) {
/* 1490 */     if (localName.isEmpty()) {
/* 1491 */       return PropertyName.USE_DEFAULT;
/*      */     }
/* 1493 */     if (namespace == null || namespace.isEmpty()) {
/* 1494 */       return PropertyName.construct(localName);
/*      */     }
/* 1496 */     return PropertyName.construct(localName, namespace);
/*      */   }
/*      */ 
/*      */   
/*      */   protected PropertyName _findConstructorName(Annotated a) {
/* 1501 */     if (a instanceof AnnotatedParameter) {
/* 1502 */       AnnotatedParameter p = (AnnotatedParameter)a;
/* 1503 */       AnnotatedWithParams ctor = p.getOwner();
/*      */       
/* 1505 */       if (ctor != null && 
/* 1506 */         _java7Helper != null) {
/* 1507 */         PropertyName name = _java7Helper.findConstructorName(p);
/* 1508 */         if (name != null) {
/* 1509 */           return name;
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 1514 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected TypeResolverBuilder<?> _findTypeResolver(MapperConfig<?> config, Annotated ann, JavaType baseType) {
/*      */     StdTypeResolverBuilder stdTypeResolverBuilder;
/* 1527 */     JsonTypeInfo info = (JsonTypeInfo)_findAnnotation(ann, JsonTypeInfo.class);
/* 1528 */     JsonTypeResolver resAnn = (JsonTypeResolver)_findAnnotation(ann, JsonTypeResolver.class);
/*      */     
/* 1530 */     if (resAnn != null) {
/* 1531 */       if (info == null) {
/* 1532 */         return null;
/*      */       }
/*      */ 
/*      */       
/* 1536 */       TypeResolverBuilder<?> b = config.typeResolverBuilderInstance(ann, resAnn.value());
/*      */     } else {
/* 1538 */       if (info == null) {
/* 1539 */         return null;
/*      */       }
/*      */       
/* 1542 */       if (info.use() == JsonTypeInfo.Id.NONE) {
/* 1543 */         return (TypeResolverBuilder<?>)_constructNoTypeResolverBuilder();
/*      */       }
/* 1545 */       stdTypeResolverBuilder = _constructStdTypeResolverBuilder();
/*      */     } 
/*      */     
/* 1548 */     JsonTypeIdResolver idResInfo = (JsonTypeIdResolver)_findAnnotation(ann, JsonTypeIdResolver.class);
/*      */     
/* 1550 */     TypeIdResolver idRes = (idResInfo == null) ? null : config.typeIdResolverInstance(ann, idResInfo.value());
/* 1551 */     if (idRes != null) {
/* 1552 */       idRes.init(baseType);
/*      */     }
/* 1554 */     TypeResolverBuilder<?> typeResolverBuilder = stdTypeResolverBuilder.init(info.use(), idRes);
/*      */ 
/*      */ 
/*      */     
/* 1558 */     JsonTypeInfo.As inclusion = info.include();
/* 1559 */     if (inclusion == JsonTypeInfo.As.EXTERNAL_PROPERTY && ann instanceof AnnotatedClass) {
/* 1560 */       inclusion = JsonTypeInfo.As.PROPERTY;
/*      */     }
/* 1562 */     typeResolverBuilder = typeResolverBuilder.inclusion(inclusion);
/* 1563 */     typeResolverBuilder = typeResolverBuilder.typeProperty(info.property());
/* 1564 */     Class<?> defaultImpl = info.defaultImpl();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1570 */     if (defaultImpl != JsonTypeInfo.None.class && !defaultImpl.isAnnotation()) {
/* 1571 */       typeResolverBuilder = typeResolverBuilder.defaultImpl(defaultImpl);
/*      */     }
/* 1573 */     typeResolverBuilder = typeResolverBuilder.typeIdVisibility(info.visible());
/* 1574 */     return typeResolverBuilder;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected StdTypeResolverBuilder _constructStdTypeResolverBuilder() {
/* 1582 */     return new StdTypeResolverBuilder();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected StdTypeResolverBuilder _constructNoTypeResolverBuilder() {
/* 1590 */     return StdTypeResolverBuilder.noTypeInfoBuilder();
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean _primitiveAndWrapper(Class<?> baseType, Class<?> refinement) {
/* 1595 */     if (baseType.isPrimitive()) {
/* 1596 */       return (baseType == ClassUtil.primitiveType(refinement));
/*      */     }
/* 1598 */     if (refinement.isPrimitive()) {
/* 1599 */       return (refinement == ClassUtil.primitiveType(baseType));
/*      */     }
/* 1601 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean _primitiveAndWrapper(JavaType baseType, Class<?> refinement) {
/* 1606 */     if (baseType.isPrimitive()) {
/* 1607 */       return baseType.hasRawClass(ClassUtil.primitiveType(refinement));
/*      */     }
/* 1609 */     if (refinement.isPrimitive()) {
/* 1610 */       return (refinement == ClassUtil.primitiveType(baseType.getRawClass()));
/*      */     }
/* 1612 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private JsonMappingException _databindException(String msg) {
/* 1617 */     return new JsonMappingException(null, msg);
/*      */   }
/*      */ 
/*      */   
/*      */   private JsonMappingException _databindException(Throwable t, String msg) {
/* 1622 */     return new JsonMappingException(null, msg, t);
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\introspect\JacksonAnnotationIntrospector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */