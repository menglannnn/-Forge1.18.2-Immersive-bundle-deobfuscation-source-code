/*     */ package com.fasterxml.jackson.databind.jdk14;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*     */ import com.fasterxml.jackson.databind.BeanDescription;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import com.fasterxml.jackson.databind.introspect.Annotated;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedConstructor;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import com.fasterxml.jackson.databind.util.NativeImageUtil;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JDK14Util
/*     */ {
/*     */   public static String[] getRecordFieldNames(Class<?> recordType) {
/*  28 */     return RecordAccessor.instance().getRecordFieldNames(recordType);
/*     */   }
/*     */ 
/*     */   
/*     */   public static AnnotatedConstructor findRecordConstructor(DeserializationContext ctxt, BeanDescription beanDesc, List<String> names) {
/*  33 */     return (new CreatorLocator(ctxt, beanDesc))
/*  34 */       .locate(names);
/*     */   }
/*     */   
/*     */   static class RecordAccessor
/*     */   {
/*     */     private final Method RECORD_GET_RECORD_COMPONENTS;
/*     */     private final Method RECORD_COMPONENT_GET_NAME;
/*     */     private final Method RECORD_COMPONENT_GET_TYPE;
/*     */     private static final RecordAccessor INSTANCE;
/*     */     private static final RuntimeException PROBLEM;
/*     */     
/*     */     static {
/*  46 */       RuntimeException prob = null;
/*  47 */       RecordAccessor inst = null;
/*     */       try {
/*  49 */         inst = new RecordAccessor();
/*  50 */       } catch (RuntimeException e) {
/*  51 */         prob = e;
/*     */       } 
/*  53 */       INSTANCE = inst;
/*  54 */       PROBLEM = prob;
/*     */     }
/*     */     
/*     */     private RecordAccessor() throws RuntimeException {
/*     */       try {
/*  59 */         this.RECORD_GET_RECORD_COMPONENTS = Class.class.getMethod("getRecordComponents", new Class[0]);
/*  60 */         Class<?> c = Class.forName("java.lang.reflect.RecordComponent");
/*  61 */         this.RECORD_COMPONENT_GET_NAME = c.getMethod("getName", new Class[0]);
/*  62 */         this.RECORD_COMPONENT_GET_TYPE = c.getMethod("getType", new Class[0]);
/*  63 */       } catch (Exception e) {
/*  64 */         throw new RuntimeException(String.format("Failed to access Methods needed to support `java.lang.Record`: (%s) %s", new Object[] { e
/*     */                 
/*  66 */                 .getClass().getName(), e.getMessage() }), e);
/*     */       } 
/*     */     }
/*     */     
/*     */     public static RecordAccessor instance() {
/*  71 */       if (PROBLEM != null) {
/*  72 */         throw PROBLEM;
/*     */       }
/*  74 */       return INSTANCE;
/*     */     }
/*     */ 
/*     */     
/*     */     public String[] getRecordFieldNames(Class<?> recordType) throws IllegalArgumentException {
/*  79 */       Object[] components = recordComponents(recordType);
/*  80 */       if (components == null)
/*     */       {
/*  82 */         return null;
/*     */       }
/*  84 */       String[] names = new String[components.length];
/*  85 */       for (int i = 0; i < components.length; i++) {
/*     */         try {
/*  87 */           names[i] = (String)this.RECORD_COMPONENT_GET_NAME.invoke(components[i], new Object[0]);
/*  88 */         } catch (Exception e) {
/*  89 */           throw new IllegalArgumentException(String.format("Failed to access name of field #%d (of %d) of Record type %s", new Object[] {
/*     */                   
/*  91 */                   Integer.valueOf(i), Integer.valueOf(components.length), ClassUtil.nameOf(recordType) }), e);
/*     */         } 
/*     */       } 
/*  94 */       return names;
/*     */     }
/*     */ 
/*     */     
/*     */     public JDK14Util.RawTypeName[] getRecordFields(Class<?> recordType) throws IllegalArgumentException {
/*  99 */       Object[] components = recordComponents(recordType);
/* 100 */       if (components == null)
/*     */       {
/* 102 */         return null;
/*     */       }
/* 104 */       JDK14Util.RawTypeName[] results = new JDK14Util.RawTypeName[components.length];
/* 105 */       for (int i = 0; i < components.length; i++) {
/*     */         String name; Class<?> type;
/*     */         try {
/* 108 */           name = (String)this.RECORD_COMPONENT_GET_NAME.invoke(components[i], new Object[0]);
/* 109 */         } catch (Exception e) {
/* 110 */           throw new IllegalArgumentException(String.format("Failed to access name of field #%d (of %d) of Record type %s", new Object[] {
/*     */                   
/* 112 */                   Integer.valueOf(i), Integer.valueOf(components.length), ClassUtil.nameOf(recordType)
/*     */                 }), e);
/*     */         } 
/*     */         try {
/* 116 */           type = (Class)this.RECORD_COMPONENT_GET_TYPE.invoke(components[i], new Object[0]);
/* 117 */         } catch (Exception e) {
/* 118 */           throw new IllegalArgumentException(String.format("Failed to access type of field #%d (of %d) of Record type %s", new Object[] {
/*     */                   
/* 120 */                   Integer.valueOf(i), Integer.valueOf(components.length), ClassUtil.nameOf(recordType) }), e);
/*     */         } 
/* 122 */         results[i] = new JDK14Util.RawTypeName(type, name);
/*     */       } 
/* 124 */       return results;
/*     */     }
/*     */ 
/*     */     
/*     */     protected Object[] recordComponents(Class<?> recordType) throws IllegalArgumentException {
/*     */       try {
/* 130 */         return (Object[])this.RECORD_GET_RECORD_COMPONENTS.invoke(recordType, new Object[0]);
/* 131 */       } catch (Exception e) {
/* 132 */         if (NativeImageUtil.isUnsupportedFeatureError(e)) {
/* 133 */           return null;
/*     */         }
/* 135 */         throw new IllegalArgumentException("Failed to access RecordComponents of type " + 
/* 136 */             ClassUtil.nameOf(recordType));
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   static class RawTypeName
/*     */   {
/*     */     public final Class<?> rawType;
/*     */     public final String name;
/*     */     
/*     */     public RawTypeName(Class<?> rt, String n) {
/* 147 */       this.rawType = rt;
/* 148 */       this.name = n;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static class CreatorLocator
/*     */   {
/*     */     protected final BeanDescription _beanDesc;
/*     */     protected final DeserializationConfig _config;
/*     */     protected final AnnotationIntrospector _intr;
/*     */     protected final List<AnnotatedConstructor> _constructors;
/*     */     protected final AnnotatedConstructor _primaryConstructor;
/*     */     protected final JDK14Util.RawTypeName[] _recordFields;
/*     */     
/*     */     CreatorLocator(DeserializationContext ctxt, BeanDescription beanDesc) {
/* 163 */       this._beanDesc = beanDesc;
/*     */       
/* 165 */       this._intr = ctxt.getAnnotationIntrospector();
/* 166 */       this._config = ctxt.getConfig();
/*     */       
/* 168 */       this._recordFields = JDK14Util.RecordAccessor.instance().getRecordFields(beanDesc.getBeanClass());
/* 169 */       if (this._recordFields == null) {
/*     */         
/* 171 */         this._constructors = beanDesc.getConstructors();
/* 172 */         this._primaryConstructor = null;
/*     */       } else {
/* 174 */         int argCount = this._recordFields.length;
/*     */ 
/*     */ 
/*     */         
/* 178 */         AnnotatedConstructor primary = null;
/*     */ 
/*     */         
/* 181 */         if (argCount == 0) {
/* 182 */           primary = beanDesc.findDefaultConstructor();
/* 183 */           this._constructors = Collections.singletonList(primary);
/*     */         } else {
/* 185 */           this._constructors = beanDesc.getConstructors();
/*     */           
/* 187 */           label28: for (AnnotatedConstructor ctor : this._constructors) {
/* 188 */             if (ctor.getParameterCount() != argCount) {
/*     */               continue;
/*     */             }
/* 191 */             for (int i = 0; i < argCount; i++) {
/* 192 */               if (!ctor.getRawParameterType(i).equals((this._recordFields[i]).rawType)) {
/*     */                 continue label28;
/*     */               }
/*     */             } 
/* 196 */             primary = ctor;
/*     */           } 
/*     */         } 
/*     */         
/* 200 */         if (primary == null) {
/* 201 */           throw new IllegalArgumentException("Failed to find the canonical Record constructor of type " + 
/* 202 */               ClassUtil.getTypeDescription(this._beanDesc.getType()));
/*     */         }
/* 204 */         this._primaryConstructor = primary;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AnnotatedConstructor locate(List<String> names) {
/* 213 */       for (AnnotatedConstructor ctor : this._constructors) {
/* 214 */         JsonCreator.Mode creatorMode = this._intr.findCreatorAnnotation((MapperConfig)this._config, (Annotated)ctor);
/* 215 */         if (null == creatorMode || JsonCreator.Mode.DISABLED == creatorMode) {
/*     */           continue;
/*     */         }
/*     */         
/* 219 */         if (JsonCreator.Mode.DELEGATING == creatorMode) {
/* 220 */           return null;
/*     */         }
/* 222 */         if (ctor != this._primaryConstructor) {
/* 223 */           return null;
/*     */         }
/*     */       } 
/*     */       
/* 227 */       if (this._recordFields == null)
/*     */       {
/* 229 */         return null;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 234 */       for (JDK14Util.RawTypeName field : this._recordFields) {
/* 235 */         names.add(field.name);
/*     */       }
/* 237 */       return this._primaryConstructor;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\jackson-databind-2.14.2.jar!\com\fasterxml\jackson\databind\jdk14\JDK14Util.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */