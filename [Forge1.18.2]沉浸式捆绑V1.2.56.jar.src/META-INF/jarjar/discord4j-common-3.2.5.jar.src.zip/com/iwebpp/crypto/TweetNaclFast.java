/*      */ package com.iwebpp.crypto;
/*      */ 
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.security.SecureRandom;
/*      */ import java.util.concurrent.atomic.AtomicLong;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class TweetNaclFast
/*      */ {
/*      */   private static final String TAG = "TweetNaclFast";
/*      */   
/*      */   public static final class Box
/*      */   {
/*      */     private static final String TAG = "Box";
/*      */     private AtomicLong nonce;
/*      */     private byte[] theirPublicKey;
/*      */     private byte[] mySecretKey;
/*      */     private byte[] sharedKey;
/*      */     public static final int publicKeyLength = 32;
/*      */     public static final int secretKeyLength = 32;
/*      */     public static final int sharedKeyLength = 32;
/*      */     public static final int nonceLength = 24;
/*      */     public static final int zerobytesLength = 32;
/*      */     public static final int boxzerobytesLength = 16;
/*      */     public static final int overheadLength = 16;
/*      */     
/*      */     public Box(byte[] theirPublicKey, byte[] mySecretKey) {
/*   37 */       this(theirPublicKey, mySecretKey, 68L);
/*      */     }
/*      */     
/*      */     public Box(byte[] theirPublicKey, byte[] mySecretKey, long nonce) {
/*   41 */       this.theirPublicKey = theirPublicKey;
/*   42 */       this.mySecretKey = mySecretKey;
/*      */       
/*   44 */       this.nonce = new AtomicLong(nonce);
/*      */ 
/*      */       
/*   47 */       before();
/*      */     }
/*      */     
/*      */     public void setNonce(long nonce) {
/*   51 */       this.nonce.set(nonce);
/*      */     }
/*      */     public long getNonce() {
/*   54 */       return this.nonce.get();
/*      */     }
/*      */     public long incrNonce() {
/*   57 */       return this.nonce.incrementAndGet();
/*      */     }
/*      */     
/*      */     private byte[] generateNonce() {
/*   61 */       long nonce = this.nonce.get();
/*      */       
/*   63 */       byte[] n = new byte[24];
/*   64 */       for (int i = 0; i < 24; i += 8) {
/*   65 */         n[i + 0] = (byte)(int)(nonce >>> 0L);
/*   66 */         n[i + 1] = (byte)(int)(nonce >>> 8L);
/*   67 */         n[i + 2] = (byte)(int)(nonce >>> 16L);
/*   68 */         n[i + 3] = (byte)(int)(nonce >>> 24L);
/*   69 */         n[i + 4] = (byte)(int)(nonce >>> 32L);
/*   70 */         n[i + 5] = (byte)(int)(nonce >>> 40L);
/*   71 */         n[i + 6] = (byte)(int)(nonce >>> 48L);
/*   72 */         n[i + 7] = (byte)(int)(nonce >>> 56L);
/*      */       } 
/*      */       
/*   75 */       return n;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public byte[] box(byte[] message) {
/*   88 */       if (message == null) return null; 
/*   89 */       return box(message, 0, message.length);
/*      */     }
/*      */     
/*      */     public byte[] box(byte[] message, int moff) {
/*   93 */       if (message == null || message.length <= moff) return null; 
/*   94 */       return box(message, moff, message.length - moff);
/*      */     }
/*      */     
/*      */     public byte[] box(byte[] message, int moff, int mlen) {
/*   98 */       if (message == null || message.length < moff + mlen) return null;
/*      */ 
/*      */       
/*  101 */       if (this.sharedKey == null) before();
/*      */       
/*  103 */       return after(message, moff, mlen);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public byte[] box(byte[] message, byte[] theNonce) {
/*  118 */       if (message == null) return null; 
/*  119 */       return box(message, 0, message.length, theNonce);
/*      */     }
/*      */     
/*      */     public byte[] box(byte[] message, int moff, byte[] theNonce) {
/*  123 */       if (message == null || message.length <= moff) return null; 
/*  124 */       return box(message, moff, message.length - moff, theNonce);
/*      */     }
/*      */     
/*      */     public byte[] box(byte[] message, int moff, int mlen, byte[] theNonce) {
/*  128 */       if (message == null || message.length < moff + mlen || theNonce == null || theNonce.length != 24)
/*      */       {
/*  130 */         return null;
/*      */       }
/*      */       
/*  133 */       if (this.sharedKey == null) before();
/*      */       
/*  135 */       return after(message, moff, mlen, theNonce);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public byte[] open(byte[] box) {
/*  146 */       if (box == null) return null;
/*      */ 
/*      */       
/*  149 */       if (this.sharedKey == null) before();
/*      */       
/*  151 */       return open_after(box, 0, box.length);
/*      */     }
/*      */     public byte[] open(byte[] box, int boxoff) {
/*  154 */       if (box == null || box.length <= boxoff) return null;
/*      */ 
/*      */       
/*  157 */       if (this.sharedKey == null) before();
/*      */       
/*  159 */       return open_after(box, boxoff, box.length - boxoff);
/*      */     }
/*      */     public byte[] open(byte[] box, int boxoff, int boxlen) {
/*  162 */       if (box == null || box.length < boxoff + boxlen) return null;
/*      */ 
/*      */       
/*  165 */       if (this.sharedKey == null) before();
/*      */       
/*  167 */       return open_after(box, boxoff, boxlen);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public byte[] open(byte[] box, byte[] theNonce) {
/*  179 */       if (box == null || theNonce == null || theNonce.length != 24)
/*      */       {
/*  181 */         return null;
/*      */       }
/*      */       
/*  184 */       if (this.sharedKey == null) before();
/*      */       
/*  186 */       return open_after(box, 0, box.length, theNonce);
/*      */     }
/*      */     public byte[] open(byte[] box, int boxoff, byte[] theNonce) {
/*  189 */       if (box == null || box.length <= boxoff || theNonce == null || theNonce.length != 24)
/*      */       {
/*  191 */         return null;
/*      */       }
/*      */       
/*  194 */       if (this.sharedKey == null) before();
/*      */       
/*  196 */       return open_after(box, boxoff, box.length - boxoff, theNonce);
/*      */     }
/*      */     public byte[] open(byte[] box, int boxoff, int boxlen, byte[] theNonce) {
/*  199 */       if (box == null || box.length < boxoff + boxlen || theNonce == null || theNonce.length != 24)
/*      */       {
/*  201 */         return null;
/*      */       }
/*      */       
/*  204 */       if (this.sharedKey == null) before();
/*      */       
/*  206 */       return open_after(box, boxoff, boxlen, theNonce);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public byte[] before() {
/*  216 */       if (this.sharedKey == null) {
/*  217 */         this.sharedKey = new byte[32];
/*  218 */         TweetNaclFast.crypto_box_beforenm(this.sharedKey, this.theirPublicKey, this.mySecretKey);
/*      */       } 
/*      */       
/*  221 */       return this.sharedKey;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public byte[] after(byte[] message, int moff, int mlen) {
/*  229 */       return after(message, moff, mlen, generateNonce());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public byte[] after(byte[] message, int moff, int mlen, byte[] theNonce) {
/*  239 */       if (message == null || message.length < moff + mlen || theNonce == null || theNonce.length != 24)
/*      */       {
/*  241 */         return null;
/*      */       }
/*      */       
/*  244 */       byte[] m = new byte[mlen + 32];
/*      */ 
/*      */       
/*  247 */       byte[] c = new byte[m.length];
/*      */       
/*  249 */       for (int i = 0; i < mlen; i++) {
/*  250 */         m[i + 32] = message[i + moff];
/*      */       }
/*  252 */       if (0 != TweetNaclFast.crypto_box_afternm(c, m, m.length, theNonce, this.sharedKey)) {
/*  253 */         return null;
/*      */       }
/*      */ 
/*      */       
/*  257 */       byte[] ret = new byte[c.length - 16];
/*      */       
/*  259 */       for (int j = 0; j < ret.length; j++) {
/*  260 */         ret[j] = c[j + 16];
/*      */       }
/*  262 */       return ret;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public byte[] open_after(byte[] box, int boxoff, int boxlen) {
/*  271 */       return open_after(box, boxoff, boxlen, generateNonce());
/*      */     }
/*      */ 
/*      */     
/*      */     public byte[] open_after(byte[] box, int boxoff, int boxlen, byte[] theNonce) {
/*  276 */       if (box == null || box.length < boxoff + boxlen || boxlen < 16) {
/*  277 */         return null;
/*      */       }
/*      */       
/*  280 */       byte[] c = new byte[boxlen + 16];
/*      */ 
/*      */       
/*  283 */       byte[] m = new byte[c.length];
/*      */       
/*  285 */       for (int i = 0; i < boxlen; i++) {
/*  286 */         c[i + 16] = box[i + boxoff];
/*      */       }
/*  288 */       if (TweetNaclFast.crypto_box_open_afternm(m, c, c.length, theNonce, this.sharedKey) != 0) {
/*  289 */         return null;
/*      */       }
/*      */ 
/*      */       
/*  293 */       byte[] ret = new byte[m.length - 32];
/*      */       
/*  295 */       for (int j = 0; j < ret.length; j++) {
/*  296 */         ret[j] = m[j + 32];
/*      */       }
/*  298 */       return ret;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static class KeyPair
/*      */     {
/*  347 */       private byte[] publicKey = new byte[32];
/*  348 */       private byte[] secretKey = new byte[32];
/*      */ 
/*      */       
/*      */       public byte[] getPublicKey() {
/*  352 */         return this.publicKey;
/*      */       }
/*      */       
/*      */       public byte[] getSecretKey() {
/*  356 */         return this.secretKey;
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static KeyPair keyPair() {
/*  366 */       KeyPair kp = new KeyPair();
/*      */       
/*  368 */       TweetNaclFast.crypto_box_keypair(kp.getPublicKey(), kp.getSecretKey());
/*  369 */       return kp;
/*      */     }
/*      */     
/*      */     public static KeyPair keyPair_fromSecretKey(byte[] secretKey) {
/*  373 */       KeyPair kp = new KeyPair();
/*  374 */       byte[] sk = kp.getSecretKey();
/*  375 */       byte[] pk = kp.getPublicKey();
/*      */ 
/*      */       
/*  378 */       for (int i = 0; i < sk.length; i++) {
/*  379 */         sk[i] = secretKey[i];
/*      */       }
/*  381 */       TweetNaclFast.crypto_scalarmult_base(pk, sk);
/*  382 */       return kp;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public static final class SecretBox
/*      */   {
/*      */     private static final String TAG = "SecretBox";
/*      */     
/*      */     private AtomicLong nonce;
/*      */     private byte[] key;
/*      */     public static final int keyLength = 32;
/*      */     public static final int nonceLength = 24;
/*      */     public static final int overheadLength = 16;
/*      */     public static final int zerobytesLength = 32;
/*      */     public static final int boxzerobytesLength = 16;
/*      */     
/*      */     public SecretBox(byte[] key) {
/*  400 */       this(key, 68L);
/*      */     }
/*      */     
/*      */     public SecretBox(byte[] key, long nonce) {
/*  404 */       this.key = key;
/*      */       
/*  406 */       this.nonce = new AtomicLong(nonce);
/*      */     }
/*      */     
/*      */     public void setNonce(long nonce) {
/*  410 */       this.nonce.set(nonce);
/*      */     }
/*      */     public long getNonce() {
/*  413 */       return this.nonce.get();
/*      */     }
/*      */     public long incrNonce() {
/*  416 */       return this.nonce.incrementAndGet();
/*      */     }
/*      */     
/*      */     private byte[] generateNonce() {
/*  420 */       long nonce = this.nonce.get();
/*      */       
/*  422 */       byte[] n = new byte[24];
/*  423 */       for (int i = 0; i < 24; i += 8) {
/*  424 */         n[i + 0] = (byte)(int)(nonce >>> 0L);
/*  425 */         n[i + 1] = (byte)(int)(nonce >>> 8L);
/*  426 */         n[i + 2] = (byte)(int)(nonce >>> 16L);
/*  427 */         n[i + 3] = (byte)(int)(nonce >>> 24L);
/*  428 */         n[i + 4] = (byte)(int)(nonce >>> 32L);
/*  429 */         n[i + 5] = (byte)(int)(nonce >>> 40L);
/*  430 */         n[i + 6] = (byte)(int)(nonce >>> 48L);
/*  431 */         n[i + 7] = (byte)(int)(nonce >>> 56L);
/*      */       } 
/*      */       
/*  434 */       return n;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public byte[] box(byte[] message) {
/*  446 */       if (message == null) return null; 
/*  447 */       return box(message, 0, message.length);
/*      */     }
/*      */     
/*      */     public byte[] box(byte[] message, int moff) {
/*  451 */       if (message == null || message.length <= moff) return null; 
/*  452 */       return box(message, moff, message.length - moff);
/*      */     }
/*      */ 
/*      */     
/*      */     public byte[] box(byte[] message, int moff, int mlen) {
/*  457 */       if (message == null || message.length < moff + mlen)
/*  458 */         return null; 
/*  459 */       return box(message, moff, message.length - moff, generateNonce());
/*      */     }
/*      */     
/*      */     public byte[] box(byte[] message, byte[] theNonce) {
/*  463 */       if (message == null) return null; 
/*  464 */       return box(message, 0, message.length, theNonce);
/*      */     }
/*      */     
/*      */     public byte[] box(byte[] message, int moff, byte[] theNonce) {
/*  468 */       if (message == null || message.length <= moff) return null; 
/*  469 */       return box(message, moff, message.length - moff, theNonce);
/*      */     }
/*      */ 
/*      */     
/*      */     public byte[] box(byte[] message, int moff, int mlen, byte[] theNonce) {
/*  474 */       if (message == null || message.length < moff + mlen || theNonce == null || theNonce.length != 24)
/*      */       {
/*  476 */         return null;
/*      */       }
/*      */       
/*  479 */       byte[] m = new byte[mlen + 32];
/*      */ 
/*      */       
/*  482 */       byte[] c = new byte[m.length];
/*      */       
/*  484 */       for (int i = 0; i < mlen; i++) {
/*  485 */         m[i + 32] = message[i + moff];
/*      */       }
/*  487 */       if (0 != TweetNaclFast.crypto_secretbox(c, m, m.length, theNonce, this.key)) {
/*  488 */         return null;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  493 */       byte[] ret = new byte[c.length - 16];
/*      */       
/*  495 */       for (int j = 0; j < ret.length; j++) {
/*  496 */         ret[j] = c[j + 16];
/*      */       }
/*  498 */       return ret;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public byte[] open(byte[] box) {
/*  509 */       if (box == null) return null; 
/*  510 */       return open(box, 0, box.length);
/*      */     }
/*      */     
/*      */     public byte[] open(byte[] box, int boxoff) {
/*  514 */       if (box == null || box.length <= boxoff) return null; 
/*  515 */       return open(box, boxoff, box.length - boxoff);
/*      */     }
/*      */ 
/*      */     
/*      */     public byte[] open(byte[] box, int boxoff, int boxlen) {
/*  520 */       if (box == null || box.length < boxoff + boxlen || boxlen < 16)
/*  521 */         return null; 
/*  522 */       return open(box, boxoff, box.length - boxoff, generateNonce());
/*      */     }
/*      */     
/*      */     public byte[] open(byte[] box, byte[] theNonce) {
/*  526 */       if (box == null) return null; 
/*  527 */       return open(box, 0, box.length, theNonce);
/*      */     }
/*      */     
/*      */     public byte[] open(byte[] box, int boxoff, byte[] theNonce) {
/*  531 */       if (box == null || box.length <= boxoff) return null; 
/*  532 */       return open(box, boxoff, box.length - boxoff, theNonce);
/*      */     }
/*      */ 
/*      */     
/*      */     public byte[] open(byte[] box, int boxoff, int boxlen, byte[] theNonce) {
/*  537 */       if (box == null || box.length < boxoff + boxlen || boxlen < 16 || theNonce == null || theNonce.length != 24)
/*      */       {
/*  539 */         return null;
/*      */       }
/*      */       
/*  542 */       byte[] c = new byte[boxlen + 16];
/*      */ 
/*      */       
/*  545 */       byte[] m = new byte[c.length];
/*      */       
/*  547 */       for (int i = 0; i < boxlen; i++) {
/*  548 */         c[i + 16] = box[i + boxoff];
/*      */       }
/*  550 */       if (0 != TweetNaclFast.crypto_secretbox_open(m, c, c.length, theNonce, this.key)) {
/*  551 */         return null;
/*      */       }
/*      */ 
/*      */       
/*  555 */       byte[] ret = new byte[m.length - 32];
/*      */       
/*  557 */       for (int j = 0; j < ret.length; j++) {
/*  558 */         ret[j] = m[j + 32];
/*      */       }
/*  560 */       return ret;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final class ScalarMult
/*      */   {
/*      */     private static final String TAG = "ScalarMult";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static final int scalarLength = 32;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static final int groupElementLength = 32;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static byte[] scalseMult(byte[] n, byte[] p) {
/*  608 */       if (n.length != 32 || p.length != 32) {
/*  609 */         return null;
/*      */       }
/*  611 */       byte[] q = new byte[32];
/*      */       
/*  613 */       TweetNaclFast.crypto_scalarmult(q, n, p);
/*      */       
/*  615 */       return q;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static byte[] scalseMult_base(byte[] n) {
/*  624 */       if (n.length != 32) {
/*  625 */         return null;
/*      */       }
/*  627 */       byte[] q = new byte[32];
/*      */       
/*  629 */       TweetNaclFast.crypto_scalarmult_base(q, n);
/*      */       
/*  631 */       return q;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final class Hash
/*      */   {
/*      */     private static final String TAG = "Hash";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static final int hashLength = 64;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static byte[] sha512(byte[] message) {
/*  662 */       if (message == null || message.length <= 0) {
/*  663 */         return null;
/*      */       }
/*  665 */       byte[] out = new byte[64];
/*      */       
/*  667 */       TweetNaclFast.crypto_hash(out, message);
/*      */       
/*  669 */       return out;
/*      */     }
/*      */     public static byte[] sha512(String message) throws UnsupportedEncodingException {
/*  672 */       return sha512(message.getBytes("utf-8"));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static final class Signature
/*      */   {
/*      */     private static final String TAG = "Signature";
/*      */     
/*      */     private byte[] theirPublicKey;
/*      */     
/*      */     private byte[] mySecretKey;
/*      */     
/*      */     public static final int publicKeyLength = 32;
/*      */     
/*      */     public static final int secretKeyLength = 64;
/*      */     
/*      */     public static final int seedLength = 32;
/*      */     
/*      */     public static final int signatureLength = 64;
/*      */ 
/*      */     
/*      */     public Signature(byte[] theirPublicKey, byte[] mySecretKey) {
/*  696 */       this.theirPublicKey = theirPublicKey;
/*  697 */       this.mySecretKey = mySecretKey;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public byte[] sign(byte[] message) {
/*  705 */       if (message == null) return null;
/*      */       
/*  707 */       return sign(message, 0, message.length);
/*      */     }
/*      */     public byte[] sign(byte[] message, int moff) {
/*  710 */       if (message == null || message.length <= moff) return null;
/*      */       
/*  712 */       return sign(message, moff, message.length - moff);
/*      */     }
/*      */     
/*      */     public byte[] sign(byte[] message, int moff, int mlen) {
/*  716 */       if (message == null || message.length < moff + mlen) {
/*  717 */         return null;
/*      */       }
/*      */       
/*  720 */       byte[] sm = new byte[mlen + 64];
/*      */       
/*  722 */       TweetNaclFast.crypto_sign(sm, -1L, message, moff, mlen, this.mySecretKey);
/*      */       
/*  724 */       return sm;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public byte[] open(byte[] signedMessage) {
/*  733 */       if (signedMessage == null) return null;
/*      */       
/*  735 */       return open(signedMessage, 0, signedMessage.length);
/*      */     }
/*      */     public byte[] open(byte[] signedMessage, int smoff) {
/*  738 */       if (signedMessage == null || signedMessage.length <= smoff) return null;
/*      */       
/*  740 */       return open(signedMessage, smoff, signedMessage.length - smoff);
/*      */     }
/*      */     
/*      */     public byte[] open(byte[] signedMessage, int smoff, int smlen) {
/*  744 */       if (signedMessage == null || signedMessage.length < smoff + smlen || smlen < 64) {
/*  745 */         return null;
/*      */       }
/*      */       
/*  748 */       byte[] tmp = new byte[smlen];
/*      */       
/*  750 */       if (0 != TweetNaclFast.crypto_sign_open(tmp, -1L, signedMessage, smoff, smlen, this.theirPublicKey)) {
/*  751 */         return null;
/*      */       }
/*      */       
/*  754 */       byte[] msg = new byte[smlen - 64];
/*  755 */       for (int i = 0; i < msg.length; i++) {
/*  756 */         msg[i] = signedMessage[smoff + i + 64];
/*      */       }
/*  758 */       return msg;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public byte[] detached(byte[] message) {
/*  766 */       byte[] signedMsg = sign(message);
/*  767 */       byte[] sig = new byte[64];
/*  768 */       for (int i = 0; i < sig.length; i++)
/*  769 */         sig[i] = signedMsg[i]; 
/*  770 */       return sig;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean detached_verify(byte[] message, byte[] signature) {
/*  779 */       if (signature.length != 64)
/*  780 */         return false; 
/*  781 */       if (this.theirPublicKey.length != 32)
/*  782 */         return false; 
/*  783 */       byte[] sm = new byte[64 + message.length];
/*  784 */       byte[] m = new byte[64 + message.length]; int i;
/*  785 */       for (i = 0; i < 64; i++)
/*  786 */         sm[i] = signature[i]; 
/*  787 */       for (i = 0; i < message.length; i++)
/*  788 */         sm[i + 64] = message[i]; 
/*  789 */       return (TweetNaclFast.crypto_sign_open(m, -1L, sm, 0, sm.length, this.theirPublicKey) >= 0);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static class KeyPair
/*      */     {
/*  802 */       private byte[] publicKey = new byte[32];
/*  803 */       private byte[] secretKey = new byte[64];
/*      */ 
/*      */       
/*      */       public byte[] getPublicKey() {
/*  807 */         return this.publicKey;
/*      */       }
/*      */       
/*      */       public byte[] getSecretKey() {
/*  811 */         return this.secretKey;
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static KeyPair keyPair() {
/*  820 */       KeyPair kp = new KeyPair();
/*      */       
/*  822 */       TweetNaclFast.crypto_sign_keypair(kp.getPublicKey(), kp.getSecretKey(), false);
/*  823 */       return kp;
/*      */     }
/*      */     public static KeyPair keyPair_fromSecretKey(byte[] secretKey) {
/*  826 */       KeyPair kp = new KeyPair();
/*  827 */       byte[] pk = kp.getPublicKey();
/*  828 */       byte[] sk = kp.getSecretKey();
/*      */       
/*      */       int i;
/*  831 */       for (i = 0; i < (kp.getSecretKey()).length; i++) {
/*  832 */         sk[i] = secretKey[i];
/*      */       }
/*      */       
/*  835 */       for (i = 0; i < (kp.getPublicKey()).length; i++) {
/*  836 */         pk[i] = secretKey[32 + i];
/*      */       }
/*  838 */       return kp;
/*      */     }
/*      */     
/*      */     public static KeyPair keyPair_fromSeed(byte[] seed) {
/*  842 */       KeyPair kp = new KeyPair();
/*  843 */       byte[] pk = kp.getPublicKey();
/*  844 */       byte[] sk = kp.getSecretKey();
/*      */ 
/*      */       
/*  847 */       for (int i = 0; i < 32; i++) {
/*  848 */         sk[i] = seed[i];
/*      */       }
/*      */       
/*  851 */       TweetNaclFast.crypto_sign_keypair(pk, sk, true);
/*      */       
/*  853 */       return kp;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  888 */   private static final byte[] _0 = new byte[16];
/*  889 */   private static final byte[] _9 = new byte[32];
/*      */ 
/*      */ 
/*      */   
/*      */   static {
/*  894 */     _9[0] = 9;
/*      */   }
/*      */   
/*  897 */   private static final long[] gf0 = new long[16];
/*  898 */   private static final long[] gf1 = new long[16];
/*  899 */   private static final long[] _121665 = new long[16];
/*      */ 
/*      */ 
/*      */   
/*      */   static {
/*  904 */     gf1[0] = 1L;
/*      */ 
/*      */     
/*  907 */     _121665[0] = 56129L; _121665[1] = 1L;
/*      */   }
/*      */   
/*  910 */   private static final long[] D = new long[] { 30883L, 4953L, 19914L, 30187L, 55467L, 16705L, 2637L, 112L, 59544L, 30585L, 16505L, 36039L, 65139L, 11119L, 27886L, 20995L };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  916 */   private static final long[] D2 = new long[] { 61785L, 9906L, 39828L, 60374L, 45398L, 33411L, 5274L, 224L, 53552L, 61171L, 33010L, 6542L, 64743L, 22239L, 55772L, 9222L };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  922 */   private static final long[] X = new long[] { 54554L, 36645L, 11616L, 51542L, 42930L, 38181L, 51040L, 26924L, 56412L, 64982L, 57905L, 49316L, 21502L, 52590L, 14035L, 8553L };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  928 */   private static final long[] Y = new long[] { 26200L, 26214L, 26214L, 26214L, 26214L, 26214L, 26214L, 26214L, 26214L, 26214L, 26214L, 26214L, 26214L, 26214L, 26214L, 26214L };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  934 */   private static final long[] I = new long[] { 41136L, 18958L, 6951L, 50414L, 58488L, 44335L, 6150L, 12099L, 55207L, 15867L, 153L, 11085L, 57099L, 20417L, 9344L, 11139L };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void ts64(byte[] x, int xoff, long u) {
/*  946 */     x[7 + xoff] = (byte)(int)(u & 0xFFL); u >>>= 8L;
/*  947 */     x[6 + xoff] = (byte)(int)(u & 0xFFL); u >>>= 8L;
/*  948 */     x[5 + xoff] = (byte)(int)(u & 0xFFL); u >>>= 8L;
/*  949 */     x[4 + xoff] = (byte)(int)(u & 0xFFL); u >>>= 8L;
/*  950 */     x[3 + xoff] = (byte)(int)(u & 0xFFL); u >>>= 8L;
/*  951 */     x[2 + xoff] = (byte)(int)(u & 0xFFL); u >>>= 8L;
/*  952 */     x[1 + xoff] = (byte)(int)(u & 0xFFL); u >>>= 8L;
/*  953 */     x[0 + xoff] = (byte)(int)(u & 0xFFL);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int vn(byte[] x, int xoff, byte[] y, int yoff, int n) {
/*  961 */     int d = 0;
/*  962 */     for (int i = 0; i < n; ) { d |= (x[i + xoff] ^ y[i + yoff]) & 0xFF; i++; }
/*  963 */      return (0x1 & d - 1 >>> 8) - 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int crypto_verify_16(byte[] x, int xoff, byte[] y, int yoff) {
/*  970 */     return vn(x, xoff, y, yoff, 16);
/*      */   }
/*      */   
/*      */   public static int crypto_verify_16(byte[] x, byte[] y) {
/*  974 */     return crypto_verify_16(x, 0, y, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int crypto_verify_32(byte[] x, int xoff, byte[] y, int yoff) {
/*  981 */     return vn(x, xoff, y, yoff, 32);
/*      */   }
/*      */   
/*      */   public static int crypto_verify_32(byte[] x, byte[] y) {
/*  985 */     return crypto_verify_32(x, 0, y, 0);
/*      */   }
/*      */   
/*      */   private static void core_salsa20(byte[] o, byte[] p, byte[] k, byte[] c) {
/*  989 */     int j0 = c[0] & 0xFF | (c[1] & 0xFF) << 8 | (c[2] & 0xFF) << 16 | (c[3] & 0xFF) << 24;
/*  990 */     int j1 = k[0] & 0xFF | (k[1] & 0xFF) << 8 | (k[2] & 0xFF) << 16 | (k[3] & 0xFF) << 24;
/*  991 */     int j2 = k[4] & 0xFF | (k[5] & 0xFF) << 8 | (k[6] & 0xFF) << 16 | (k[7] & 0xFF) << 24;
/*  992 */     int j3 = k[8] & 0xFF | (k[9] & 0xFF) << 8 | (k[10] & 0xFF) << 16 | (k[11] & 0xFF) << 24;
/*  993 */     int j4 = k[12] & 0xFF | (k[13] & 0xFF) << 8 | (k[14] & 0xFF) << 16 | (k[15] & 0xFF) << 24;
/*  994 */     int j5 = c[4] & 0xFF | (c[5] & 0xFF) << 8 | (c[6] & 0xFF) << 16 | (c[7] & 0xFF) << 24;
/*  995 */     int j6 = p[0] & 0xFF | (p[1] & 0xFF) << 8 | (p[2] & 0xFF) << 16 | (p[3] & 0xFF) << 24;
/*  996 */     int j7 = p[4] & 0xFF | (p[5] & 0xFF) << 8 | (p[6] & 0xFF) << 16 | (p[7] & 0xFF) << 24;
/*  997 */     int j8 = p[8] & 0xFF | (p[9] & 0xFF) << 8 | (p[10] & 0xFF) << 16 | (p[11] & 0xFF) << 24;
/*  998 */     int j9 = p[12] & 0xFF | (p[13] & 0xFF) << 8 | (p[14] & 0xFF) << 16 | (p[15] & 0xFF) << 24;
/*  999 */     int j10 = c[8] & 0xFF | (c[9] & 0xFF) << 8 | (c[10] & 0xFF) << 16 | (c[11] & 0xFF) << 24;
/* 1000 */     int j11 = k[16] & 0xFF | (k[17] & 0xFF) << 8 | (k[18] & 0xFF) << 16 | (k[19] & 0xFF) << 24;
/* 1001 */     int j12 = k[20] & 0xFF | (k[21] & 0xFF) << 8 | (k[22] & 0xFF) << 16 | (k[23] & 0xFF) << 24;
/* 1002 */     int j13 = k[24] & 0xFF | (k[25] & 0xFF) << 8 | (k[26] & 0xFF) << 16 | (k[27] & 0xFF) << 24;
/* 1003 */     int j14 = k[28] & 0xFF | (k[29] & 0xFF) << 8 | (k[30] & 0xFF) << 16 | (k[31] & 0xFF) << 24;
/* 1004 */     int j15 = c[12] & 0xFF | (c[13] & 0xFF) << 8 | (c[14] & 0xFF) << 16 | (c[15] & 0xFF) << 24;
/*      */     
/* 1006 */     int x0 = j0, x1 = j1, x2 = j2, x3 = j3, x4 = j4, x5 = j5, x6 = j6, x7 = j7;
/* 1007 */     int x8 = j8, x9 = j9, x10 = j10, x11 = j11, x12 = j12, x13 = j13, x14 = j14;
/* 1008 */     int x15 = j15;
/*      */     
/* 1010 */     for (int i = 0; i < 20; i += 2) {
/* 1011 */       int u = x0 + x12 | 0x0;
/* 1012 */       x4 ^= u << 7 | u >>> 25;
/* 1013 */       u = x4 + x0 | 0x0;
/* 1014 */       x8 ^= u << 9 | u >>> 23;
/* 1015 */       u = x8 + x4 | 0x0;
/* 1016 */       x12 ^= u << 13 | u >>> 19;
/* 1017 */       u = x12 + x8 | 0x0;
/* 1018 */       x0 ^= u << 18 | u >>> 14;
/*      */       
/* 1020 */       u = x5 + x1 | 0x0;
/* 1021 */       x9 ^= u << 7 | u >>> 25;
/* 1022 */       u = x9 + x5 | 0x0;
/* 1023 */       x13 ^= u << 9 | u >>> 23;
/* 1024 */       u = x13 + x9 | 0x0;
/* 1025 */       x1 ^= u << 13 | u >>> 19;
/* 1026 */       u = x1 + x13 | 0x0;
/* 1027 */       x5 ^= u << 18 | u >>> 14;
/*      */       
/* 1029 */       u = x10 + x6 | 0x0;
/* 1030 */       x14 ^= u << 7 | u >>> 25;
/* 1031 */       u = x14 + x10 | 0x0;
/* 1032 */       x2 ^= u << 9 | u >>> 23;
/* 1033 */       u = x2 + x14 | 0x0;
/* 1034 */       x6 ^= u << 13 | u >>> 19;
/* 1035 */       u = x6 + x2 | 0x0;
/* 1036 */       x10 ^= u << 18 | u >>> 14;
/*      */       
/* 1038 */       u = x15 + x11 | 0x0;
/* 1039 */       x3 ^= u << 7 | u >>> 25;
/* 1040 */       u = x3 + x15 | 0x0;
/* 1041 */       x7 ^= u << 9 | u >>> 23;
/* 1042 */       u = x7 + x3 | 0x0;
/* 1043 */       x11 ^= u << 13 | u >>> 19;
/* 1044 */       u = x11 + x7 | 0x0;
/* 1045 */       x15 ^= u << 18 | u >>> 14;
/*      */       
/* 1047 */       u = x0 + x3 | 0x0;
/* 1048 */       x1 ^= u << 7 | u >>> 25;
/* 1049 */       u = x1 + x0 | 0x0;
/* 1050 */       x2 ^= u << 9 | u >>> 23;
/* 1051 */       u = x2 + x1 | 0x0;
/* 1052 */       x3 ^= u << 13 | u >>> 19;
/* 1053 */       u = x3 + x2 | 0x0;
/* 1054 */       x0 ^= u << 18 | u >>> 14;
/*      */       
/* 1056 */       u = x5 + x4 | 0x0;
/* 1057 */       x6 ^= u << 7 | u >>> 25;
/* 1058 */       u = x6 + x5 | 0x0;
/* 1059 */       x7 ^= u << 9 | u >>> 23;
/* 1060 */       u = x7 + x6 | 0x0;
/* 1061 */       x4 ^= u << 13 | u >>> 19;
/* 1062 */       u = x4 + x7 | 0x0;
/* 1063 */       x5 ^= u << 18 | u >>> 14;
/*      */       
/* 1065 */       u = x10 + x9 | 0x0;
/* 1066 */       x11 ^= u << 7 | u >>> 25;
/* 1067 */       u = x11 + x10 | 0x0;
/* 1068 */       x8 ^= u << 9 | u >>> 23;
/* 1069 */       u = x8 + x11 | 0x0;
/* 1070 */       x9 ^= u << 13 | u >>> 19;
/* 1071 */       u = x9 + x8 | 0x0;
/* 1072 */       x10 ^= u << 18 | u >>> 14;
/*      */       
/* 1074 */       u = x15 + x14 | 0x0;
/* 1075 */       x12 ^= u << 7 | u >>> 25;
/* 1076 */       u = x12 + x15 | 0x0;
/* 1077 */       x13 ^= u << 9 | u >>> 23;
/* 1078 */       u = x13 + x12 | 0x0;
/* 1079 */       x14 ^= u << 13 | u >>> 19;
/* 1080 */       u = x14 + x13 | 0x0;
/* 1081 */       x15 ^= u << 18 | u >>> 14;
/*      */     } 
/* 1083 */     x0 = x0 + j0 | 0x0;
/* 1084 */     x1 = x1 + j1 | 0x0;
/* 1085 */     x2 = x2 + j2 | 0x0;
/* 1086 */     x3 = x3 + j3 | 0x0;
/* 1087 */     x4 = x4 + j4 | 0x0;
/* 1088 */     x5 = x5 + j5 | 0x0;
/* 1089 */     x6 = x6 + j6 | 0x0;
/* 1090 */     x7 = x7 + j7 | 0x0;
/* 1091 */     x8 = x8 + j8 | 0x0;
/* 1092 */     x9 = x9 + j9 | 0x0;
/* 1093 */     x10 = x10 + j10 | 0x0;
/* 1094 */     x11 = x11 + j11 | 0x0;
/* 1095 */     x12 = x12 + j12 | 0x0;
/* 1096 */     x13 = x13 + j13 | 0x0;
/* 1097 */     x14 = x14 + j14 | 0x0;
/* 1098 */     x15 = x15 + j15 | 0x0;
/*      */     
/* 1100 */     o[0] = (byte)(x0 >>> 0 & 0xFF);
/* 1101 */     o[1] = (byte)(x0 >>> 8 & 0xFF);
/* 1102 */     o[2] = (byte)(x0 >>> 16 & 0xFF);
/* 1103 */     o[3] = (byte)(x0 >>> 24 & 0xFF);
/*      */     
/* 1105 */     o[4] = (byte)(x1 >>> 0 & 0xFF);
/* 1106 */     o[5] = (byte)(x1 >>> 8 & 0xFF);
/* 1107 */     o[6] = (byte)(x1 >>> 16 & 0xFF);
/* 1108 */     o[7] = (byte)(x1 >>> 24 & 0xFF);
/*      */     
/* 1110 */     o[8] = (byte)(x2 >>> 0 & 0xFF);
/* 1111 */     o[9] = (byte)(x2 >>> 8 & 0xFF);
/* 1112 */     o[10] = (byte)(x2 >>> 16 & 0xFF);
/* 1113 */     o[11] = (byte)(x2 >>> 24 & 0xFF);
/*      */     
/* 1115 */     o[12] = (byte)(x3 >>> 0 & 0xFF);
/* 1116 */     o[13] = (byte)(x3 >>> 8 & 0xFF);
/* 1117 */     o[14] = (byte)(x3 >>> 16 & 0xFF);
/* 1118 */     o[15] = (byte)(x3 >>> 24 & 0xFF);
/*      */     
/* 1120 */     o[16] = (byte)(x4 >>> 0 & 0xFF);
/* 1121 */     o[17] = (byte)(x4 >>> 8 & 0xFF);
/* 1122 */     o[18] = (byte)(x4 >>> 16 & 0xFF);
/* 1123 */     o[19] = (byte)(x4 >>> 24 & 0xFF);
/*      */     
/* 1125 */     o[20] = (byte)(x5 >>> 0 & 0xFF);
/* 1126 */     o[21] = (byte)(x5 >>> 8 & 0xFF);
/* 1127 */     o[22] = (byte)(x5 >>> 16 & 0xFF);
/* 1128 */     o[23] = (byte)(x5 >>> 24 & 0xFF);
/*      */     
/* 1130 */     o[24] = (byte)(x6 >>> 0 & 0xFF);
/* 1131 */     o[25] = (byte)(x6 >>> 8 & 0xFF);
/* 1132 */     o[26] = (byte)(x6 >>> 16 & 0xFF);
/* 1133 */     o[27] = (byte)(x6 >>> 24 & 0xFF);
/*      */     
/* 1135 */     o[28] = (byte)(x7 >>> 0 & 0xFF);
/* 1136 */     o[29] = (byte)(x7 >>> 8 & 0xFF);
/* 1137 */     o[30] = (byte)(x7 >>> 16 & 0xFF);
/* 1138 */     o[31] = (byte)(x7 >>> 24 & 0xFF);
/*      */     
/* 1140 */     o[32] = (byte)(x8 >>> 0 & 0xFF);
/* 1141 */     o[33] = (byte)(x8 >>> 8 & 0xFF);
/* 1142 */     o[34] = (byte)(x8 >>> 16 & 0xFF);
/* 1143 */     o[35] = (byte)(x8 >>> 24 & 0xFF);
/*      */     
/* 1145 */     o[36] = (byte)(x9 >>> 0 & 0xFF);
/* 1146 */     o[37] = (byte)(x9 >>> 8 & 0xFF);
/* 1147 */     o[38] = (byte)(x9 >>> 16 & 0xFF);
/* 1148 */     o[39] = (byte)(x9 >>> 24 & 0xFF);
/*      */     
/* 1150 */     o[40] = (byte)(x10 >>> 0 & 0xFF);
/* 1151 */     o[41] = (byte)(x10 >>> 8 & 0xFF);
/* 1152 */     o[42] = (byte)(x10 >>> 16 & 0xFF);
/* 1153 */     o[43] = (byte)(x10 >>> 24 & 0xFF);
/*      */     
/* 1155 */     o[44] = (byte)(x11 >>> 0 & 0xFF);
/* 1156 */     o[45] = (byte)(x11 >>> 8 & 0xFF);
/* 1157 */     o[46] = (byte)(x11 >>> 16 & 0xFF);
/* 1158 */     o[47] = (byte)(x11 >>> 24 & 0xFF);
/*      */     
/* 1160 */     o[48] = (byte)(x12 >>> 0 & 0xFF);
/* 1161 */     o[49] = (byte)(x12 >>> 8 & 0xFF);
/* 1162 */     o[50] = (byte)(x12 >>> 16 & 0xFF);
/* 1163 */     o[51] = (byte)(x12 >>> 24 & 0xFF);
/*      */     
/* 1165 */     o[52] = (byte)(x13 >>> 0 & 0xFF);
/* 1166 */     o[53] = (byte)(x13 >>> 8 & 0xFF);
/* 1167 */     o[54] = (byte)(x13 >>> 16 & 0xFF);
/* 1168 */     o[55] = (byte)(x13 >>> 24 & 0xFF);
/*      */     
/* 1170 */     o[56] = (byte)(x14 >>> 0 & 0xFF);
/* 1171 */     o[57] = (byte)(x14 >>> 8 & 0xFF);
/* 1172 */     o[58] = (byte)(x14 >>> 16 & 0xFF);
/* 1173 */     o[59] = (byte)(x14 >>> 24 & 0xFF);
/*      */     
/* 1175 */     o[60] = (byte)(x15 >>> 0 & 0xFF);
/* 1176 */     o[61] = (byte)(x15 >>> 8 & 0xFF);
/* 1177 */     o[62] = (byte)(x15 >>> 16 & 0xFF);
/* 1178 */     o[63] = (byte)(x15 >>> 24 & 0xFF);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void core_hsalsa20(byte[] o, byte[] p, byte[] k, byte[] c) {
/* 1187 */     int j0 = c[0] & 0xFF | (c[1] & 0xFF) << 8 | (c[2] & 0xFF) << 16 | (c[3] & 0xFF) << 24;
/* 1188 */     int j1 = k[0] & 0xFF | (k[1] & 0xFF) << 8 | (k[2] & 0xFF) << 16 | (k[3] & 0xFF) << 24;
/* 1189 */     int j2 = k[4] & 0xFF | (k[5] & 0xFF) << 8 | (k[6] & 0xFF) << 16 | (k[7] & 0xFF) << 24;
/* 1190 */     int j3 = k[8] & 0xFF | (k[9] & 0xFF) << 8 | (k[10] & 0xFF) << 16 | (k[11] & 0xFF) << 24;
/* 1191 */     int j4 = k[12] & 0xFF | (k[13] & 0xFF) << 8 | (k[14] & 0xFF) << 16 | (k[15] & 0xFF) << 24;
/* 1192 */     int j5 = c[4] & 0xFF | (c[5] & 0xFF) << 8 | (c[6] & 0xFF) << 16 | (c[7] & 0xFF) << 24;
/* 1193 */     int j6 = p[0] & 0xFF | (p[1] & 0xFF) << 8 | (p[2] & 0xFF) << 16 | (p[3] & 0xFF) << 24;
/* 1194 */     int j7 = p[4] & 0xFF | (p[5] & 0xFF) << 8 | (p[6] & 0xFF) << 16 | (p[7] & 0xFF) << 24;
/* 1195 */     int j8 = p[8] & 0xFF | (p[9] & 0xFF) << 8 | (p[10] & 0xFF) << 16 | (p[11] & 0xFF) << 24;
/* 1196 */     int j9 = p[12] & 0xFF | (p[13] & 0xFF) << 8 | (p[14] & 0xFF) << 16 | (p[15] & 0xFF) << 24;
/* 1197 */     int j10 = c[8] & 0xFF | (c[9] & 0xFF) << 8 | (c[10] & 0xFF) << 16 | (c[11] & 0xFF) << 24;
/* 1198 */     int j11 = k[16] & 0xFF | (k[17] & 0xFF) << 8 | (k[18] & 0xFF) << 16 | (k[19] & 0xFF) << 24;
/* 1199 */     int j12 = k[20] & 0xFF | (k[21] & 0xFF) << 8 | (k[22] & 0xFF) << 16 | (k[23] & 0xFF) << 24;
/* 1200 */     int j13 = k[24] & 0xFF | (k[25] & 0xFF) << 8 | (k[26] & 0xFF) << 16 | (k[27] & 0xFF) << 24;
/* 1201 */     int j14 = k[28] & 0xFF | (k[29] & 0xFF) << 8 | (k[30] & 0xFF) << 16 | (k[31] & 0xFF) << 24;
/* 1202 */     int j15 = c[12] & 0xFF | (c[13] & 0xFF) << 8 | (c[14] & 0xFF) << 16 | (c[15] & 0xFF) << 24;
/*      */     
/* 1204 */     int x0 = j0, x1 = j1, x2 = j2, x3 = j3, x4 = j4, x5 = j5, x6 = j6, x7 = j7;
/* 1205 */     int x8 = j8, x9 = j9, x10 = j10, x11 = j11, x12 = j12, x13 = j13, x14 = j14;
/* 1206 */     int x15 = j15;
/*      */     
/* 1208 */     for (int i = 0; i < 20; i += 2) {
/* 1209 */       int u = x0 + x12 | 0x0;
/* 1210 */       x4 ^= u << 7 | u >>> 25;
/* 1211 */       u = x4 + x0 | 0x0;
/* 1212 */       x8 ^= u << 9 | u >>> 23;
/* 1213 */       u = x8 + x4 | 0x0;
/* 1214 */       x12 ^= u << 13 | u >>> 19;
/* 1215 */       u = x12 + x8 | 0x0;
/* 1216 */       x0 ^= u << 18 | u >>> 14;
/*      */       
/* 1218 */       u = x5 + x1 | 0x0;
/* 1219 */       x9 ^= u << 7 | u >>> 25;
/* 1220 */       u = x9 + x5 | 0x0;
/* 1221 */       x13 ^= u << 9 | u >>> 23;
/* 1222 */       u = x13 + x9 | 0x0;
/* 1223 */       x1 ^= u << 13 | u >>> 19;
/* 1224 */       u = x1 + x13 | 0x0;
/* 1225 */       x5 ^= u << 18 | u >>> 14;
/*      */       
/* 1227 */       u = x10 + x6 | 0x0;
/* 1228 */       x14 ^= u << 7 | u >>> 25;
/* 1229 */       u = x14 + x10 | 0x0;
/* 1230 */       x2 ^= u << 9 | u >>> 23;
/* 1231 */       u = x2 + x14 | 0x0;
/* 1232 */       x6 ^= u << 13 | u >>> 19;
/* 1233 */       u = x6 + x2 | 0x0;
/* 1234 */       x10 ^= u << 18 | u >>> 14;
/*      */       
/* 1236 */       u = x15 + x11 | 0x0;
/* 1237 */       x3 ^= u << 7 | u >>> 25;
/* 1238 */       u = x3 + x15 | 0x0;
/* 1239 */       x7 ^= u << 9 | u >>> 23;
/* 1240 */       u = x7 + x3 | 0x0;
/* 1241 */       x11 ^= u << 13 | u >>> 19;
/* 1242 */       u = x11 + x7 | 0x0;
/* 1243 */       x15 ^= u << 18 | u >>> 14;
/*      */       
/* 1245 */       u = x0 + x3 | 0x0;
/* 1246 */       x1 ^= u << 7 | u >>> 25;
/* 1247 */       u = x1 + x0 | 0x0;
/* 1248 */       x2 ^= u << 9 | u >>> 23;
/* 1249 */       u = x2 + x1 | 0x0;
/* 1250 */       x3 ^= u << 13 | u >>> 19;
/* 1251 */       u = x3 + x2 | 0x0;
/* 1252 */       x0 ^= u << 18 | u >>> 14;
/*      */       
/* 1254 */       u = x5 + x4 | 0x0;
/* 1255 */       x6 ^= u << 7 | u >>> 25;
/* 1256 */       u = x6 + x5 | 0x0;
/* 1257 */       x7 ^= u << 9 | u >>> 23;
/* 1258 */       u = x7 + x6 | 0x0;
/* 1259 */       x4 ^= u << 13 | u >>> 19;
/* 1260 */       u = x4 + x7 | 0x0;
/* 1261 */       x5 ^= u << 18 | u >>> 14;
/*      */       
/* 1263 */       u = x10 + x9 | 0x0;
/* 1264 */       x11 ^= u << 7 | u >>> 25;
/* 1265 */       u = x11 + x10 | 0x0;
/* 1266 */       x8 ^= u << 9 | u >>> 23;
/* 1267 */       u = x8 + x11 | 0x0;
/* 1268 */       x9 ^= u << 13 | u >>> 19;
/* 1269 */       u = x9 + x8 | 0x0;
/* 1270 */       x10 ^= u << 18 | u >>> 14;
/*      */       
/* 1272 */       u = x15 + x14 | 0x0;
/* 1273 */       x12 ^= u << 7 | u >>> 25;
/* 1274 */       u = x12 + x15 | 0x0;
/* 1275 */       x13 ^= u << 9 | u >>> 23;
/* 1276 */       u = x13 + x12 | 0x0;
/* 1277 */       x14 ^= u << 13 | u >>> 19;
/* 1278 */       u = x14 + x13 | 0x0;
/* 1279 */       x15 ^= u << 18 | u >>> 14;
/*      */     } 
/*      */     
/* 1282 */     o[0] = (byte)(x0 >>> 0 & 0xFF);
/* 1283 */     o[1] = (byte)(x0 >>> 8 & 0xFF);
/* 1284 */     o[2] = (byte)(x0 >>> 16 & 0xFF);
/* 1285 */     o[3] = (byte)(x0 >>> 24 & 0xFF);
/*      */     
/* 1287 */     o[4] = (byte)(x5 >>> 0 & 0xFF);
/* 1288 */     o[5] = (byte)(x5 >>> 8 & 0xFF);
/* 1289 */     o[6] = (byte)(x5 >>> 16 & 0xFF);
/* 1290 */     o[7] = (byte)(x5 >>> 24 & 0xFF);
/*      */     
/* 1292 */     o[8] = (byte)(x10 >>> 0 & 0xFF);
/* 1293 */     o[9] = (byte)(x10 >>> 8 & 0xFF);
/* 1294 */     o[10] = (byte)(x10 >>> 16 & 0xFF);
/* 1295 */     o[11] = (byte)(x10 >>> 24 & 0xFF);
/*      */     
/* 1297 */     o[12] = (byte)(x15 >>> 0 & 0xFF);
/* 1298 */     o[13] = (byte)(x15 >>> 8 & 0xFF);
/* 1299 */     o[14] = (byte)(x15 >>> 16 & 0xFF);
/* 1300 */     o[15] = (byte)(x15 >>> 24 & 0xFF);
/*      */     
/* 1302 */     o[16] = (byte)(x6 >>> 0 & 0xFF);
/* 1303 */     o[17] = (byte)(x6 >>> 8 & 0xFF);
/* 1304 */     o[18] = (byte)(x6 >>> 16 & 0xFF);
/* 1305 */     o[19] = (byte)(x6 >>> 24 & 0xFF);
/*      */     
/* 1307 */     o[20] = (byte)(x7 >>> 0 & 0xFF);
/* 1308 */     o[21] = (byte)(x7 >>> 8 & 0xFF);
/* 1309 */     o[22] = (byte)(x7 >>> 16 & 0xFF);
/* 1310 */     o[23] = (byte)(x7 >>> 24 & 0xFF);
/*      */     
/* 1312 */     o[24] = (byte)(x8 >>> 0 & 0xFF);
/* 1313 */     o[25] = (byte)(x8 >>> 8 & 0xFF);
/* 1314 */     o[26] = (byte)(x8 >>> 16 & 0xFF);
/* 1315 */     o[27] = (byte)(x8 >>> 24 & 0xFF);
/*      */     
/* 1317 */     o[28] = (byte)(x9 >>> 0 & 0xFF);
/* 1318 */     o[29] = (byte)(x9 >>> 8 & 0xFF);
/* 1319 */     o[30] = (byte)(x9 >>> 16 & 0xFF);
/* 1320 */     o[31] = (byte)(x9 >>> 24 & 0xFF);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int crypto_core_salsa20(byte[] out, byte[] in, byte[] k, byte[] c) {
/* 1332 */     core_salsa20(out, in, k, c);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1338 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static int crypto_core_hsalsa20(byte[] out, byte[] in, byte[] k, byte[] c) {
/* 1344 */     core_hsalsa20(out, in, k, c);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1350 */     return 0;
/*      */   }
/*      */ 
/*      */   
/* 1354 */   private static final byte[] sigma = new byte[] { 101, 120, 112, 97, 110, 100, 32, 51, 50, 45, 98, 121, 116, 101, 32, 107 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int crypto_stream_salsa20_xor(byte[] c, int cpos, byte[] m, int mpos, long b, byte[] n, byte[] k) {
/* 1366 */     byte[] z = new byte[16], x = new byte[64];
/*      */     int i;
/* 1368 */     for (i = 0; i < 16; ) { z[i] = 0; i++; }
/* 1369 */      for (i = 0; i < 8; ) { z[i] = n[i]; i++; }
/* 1370 */      while (b >= 64L) {
/* 1371 */       crypto_core_salsa20(x, z, k, sigma);
/* 1372 */       for (i = 0; i < 64; ) { c[cpos + i] = (byte)((m[mpos + i] ^ x[i]) & 0xFF); i++; }
/* 1373 */        int u = 1;
/* 1374 */       for (i = 8; i < 16; i++) {
/* 1375 */         u = u + (z[i] & 0xFF) | 0x0;
/* 1376 */         z[i] = (byte)(u & 0xFF);
/* 1377 */         u >>>= 8;
/*      */       } 
/* 1379 */       b -= 64L;
/* 1380 */       cpos += 64;
/* 1381 */       mpos += 64;
/*      */     } 
/* 1383 */     if (b > 0L) {
/* 1384 */       crypto_core_salsa20(x, z, k, sigma);
/* 1385 */       for (i = 0; i < b; ) { c[cpos + i] = (byte)((m[mpos + i] ^ x[i]) & 0xFF); i++; }
/*      */     
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1392 */     return 0;
/*      */   }
/*      */   
/*      */   public static int crypto_stream_salsa20(byte[] c, int cpos, long b, byte[] n, byte[] k) {
/* 1396 */     byte[] z = new byte[16], x = new byte[64];
/*      */     int i;
/* 1398 */     for (i = 0; i < 16; ) { z[i] = 0; i++; }
/* 1399 */      for (i = 0; i < 8; ) { z[i] = n[i]; i++; }
/* 1400 */      while (b >= 64L) {
/* 1401 */       crypto_core_salsa20(x, z, k, sigma);
/* 1402 */       for (i = 0; i < 64; ) { c[cpos + i] = x[i]; i++; }
/* 1403 */        int u = 1;
/* 1404 */       for (i = 8; i < 16; i++) {
/* 1405 */         u = u + (z[i] & 0xFF) | 0x0;
/* 1406 */         z[i] = (byte)(u & 0xFF);
/* 1407 */         u >>>= 8;
/*      */       } 
/* 1409 */       b -= 64L;
/* 1410 */       cpos += 64;
/*      */     } 
/* 1412 */     if (b > 0L) {
/* 1413 */       crypto_core_salsa20(x, z, k, sigma);
/* 1414 */       for (i = 0; i < b; ) { c[cpos + i] = x[i]; i++; }
/*      */     
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1421 */     return 0;
/*      */   }
/*      */   
/*      */   public static int crypto_stream(byte[] c, int cpos, long d, byte[] n, byte[] k) {
/* 1425 */     byte[] s = new byte[32];
/* 1426 */     crypto_core_hsalsa20(s, n, k, sigma);
/* 1427 */     byte[] sn = new byte[8];
/* 1428 */     for (int i = 0; i < 8; ) { sn[i] = n[i + 16]; i++; }
/* 1429 */      return crypto_stream_salsa20(c, cpos, d, sn, s);
/*      */   }
/*      */   
/*      */   public static int crypto_stream_xor(byte[] c, int cpos, byte[] m, int mpos, long d, byte[] n, byte[] k) {
/* 1433 */     byte[] s = new byte[32];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1444 */     crypto_core_hsalsa20(s, n, k, sigma);
/* 1445 */     byte[] sn = new byte[8];
/* 1446 */     for (int i = 0; i < 8; ) { sn[i] = n[i + 16]; i++; }
/* 1447 */      return crypto_stream_salsa20_xor(c, cpos, m, mpos, d, sn, s);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final class poly1305
/*      */   {
/* 1464 */     private byte[] buffer = new byte[16];
/* 1465 */     private int[] r = new int[10];
/* 1466 */     private int[] h = new int[10];
/* 1467 */     private int[] pad = new int[8];
/* 1468 */     private int leftover = 0;
/* 1469 */     private int fin = 0;
/*      */ 
/*      */     
/*      */     public poly1305(byte[] key) {
/* 1473 */       int t0 = key[0] & 0xFF | (key[1] & 0xFF) << 8; this.r[0] = t0 & 0x1FFF;
/* 1474 */       int t1 = key[2] & 0xFF | (key[3] & 0xFF) << 8; this.r[1] = (t0 >>> 13 | t1 << 3) & 0x1FFF;
/* 1475 */       int t2 = key[4] & 0xFF | (key[5] & 0xFF) << 8; this.r[2] = (t1 >>> 10 | t2 << 6) & 0x1F03;
/* 1476 */       int t3 = key[6] & 0xFF | (key[7] & 0xFF) << 8; this.r[3] = (t2 >>> 7 | t3 << 9) & 0x1FFF;
/* 1477 */       int t4 = key[8] & 0xFF | (key[9] & 0xFF) << 8; this.r[4] = (t3 >>> 4 | t4 << 12) & 0xFF;
/* 1478 */       this.r[5] = t4 >>> 1 & 0x1FFE;
/* 1479 */       int t5 = key[10] & 0xFF | (key[11] & 0xFF) << 8; this.r[6] = (t4 >>> 14 | t5 << 2) & 0x1FFF;
/* 1480 */       int t6 = key[12] & 0xFF | (key[13] & 0xFF) << 8; this.r[7] = (t5 >>> 11 | t6 << 5) & 0x1F81;
/* 1481 */       int t7 = key[14] & 0xFF | (key[15] & 0xFF) << 8; this.r[8] = (t6 >>> 8 | t7 << 8) & 0x1FFF;
/* 1482 */       this.r[9] = t7 >>> 5 & 0x7F;
/*      */       
/* 1484 */       this.pad[0] = key[16] & 0xFF | (key[17] & 0xFF) << 8;
/* 1485 */       this.pad[1] = key[18] & 0xFF | (key[19] & 0xFF) << 8;
/* 1486 */       this.pad[2] = key[20] & 0xFF | (key[21] & 0xFF) << 8;
/* 1487 */       this.pad[3] = key[22] & 0xFF | (key[23] & 0xFF) << 8;
/* 1488 */       this.pad[4] = key[24] & 0xFF | (key[25] & 0xFF) << 8;
/* 1489 */       this.pad[5] = key[26] & 0xFF | (key[27] & 0xFF) << 8;
/* 1490 */       this.pad[6] = key[28] & 0xFF | (key[29] & 0xFF) << 8;
/* 1491 */       this.pad[7] = key[30] & 0xFF | (key[31] & 0xFF) << 8;
/*      */     }
/*      */     
/*      */     public poly1305 blocks(byte[] m, int mpos, int bytes) {
/* 1495 */       int hibit = (this.fin != 0) ? 0 : 2048;
/*      */ 
/*      */ 
/*      */       
/* 1499 */       int h0 = this.h[0];
/* 1500 */       int h1 = this.h[1];
/* 1501 */       int h2 = this.h[2];
/* 1502 */       int h3 = this.h[3];
/* 1503 */       int h4 = this.h[4];
/* 1504 */       int h5 = this.h[5];
/* 1505 */       int h6 = this.h[6];
/* 1506 */       int h7 = this.h[7];
/* 1507 */       int h8 = this.h[8];
/* 1508 */       int h9 = this.h[9];
/*      */       
/* 1510 */       int r0 = this.r[0];
/* 1511 */       int r1 = this.r[1];
/* 1512 */       int r2 = this.r[2];
/* 1513 */       int r3 = this.r[3];
/* 1514 */       int r4 = this.r[4];
/* 1515 */       int r5 = this.r[5];
/* 1516 */       int r6 = this.r[6];
/* 1517 */       int r7 = this.r[7];
/* 1518 */       int r8 = this.r[8];
/* 1519 */       int r9 = this.r[9];
/*      */       
/* 1521 */       while (bytes >= 16) {
/* 1522 */         int t0 = m[mpos + 0] & 0xFF | (m[mpos + 1] & 0xFF) << 8; h0 += t0 & 0x1FFF;
/* 1523 */         int t1 = m[mpos + 2] & 0xFF | (m[mpos + 3] & 0xFF) << 8; h1 += (t0 >>> 13 | t1 << 3) & 0x1FFF;
/* 1524 */         int t2 = m[mpos + 4] & 0xFF | (m[mpos + 5] & 0xFF) << 8; h2 += (t1 >>> 10 | t2 << 6) & 0x1FFF;
/* 1525 */         int t3 = m[mpos + 6] & 0xFF | (m[mpos + 7] & 0xFF) << 8; h3 += (t2 >>> 7 | t3 << 9) & 0x1FFF;
/* 1526 */         int t4 = m[mpos + 8] & 0xFF | (m[mpos + 9] & 0xFF) << 8; h4 += (t3 >>> 4 | t4 << 12) & 0x1FFF;
/* 1527 */         h5 += t4 >>> 1 & 0x1FFF;
/* 1528 */         int t5 = m[mpos + 10] & 0xFF | (m[mpos + 11] & 0xFF) << 8; h6 += (t4 >>> 14 | t5 << 2) & 0x1FFF;
/* 1529 */         int t6 = m[mpos + 12] & 0xFF | (m[mpos + 13] & 0xFF) << 8; h7 += (t5 >>> 11 | t6 << 5) & 0x1FFF;
/* 1530 */         int t7 = m[mpos + 14] & 0xFF | (m[mpos + 15] & 0xFF) << 8; h8 += (t6 >>> 8 | t7 << 8) & 0x1FFF;
/* 1531 */         h9 += t7 >>> 5 | hibit;
/*      */         
/* 1533 */         int c = 0;
/*      */         
/* 1535 */         int d0 = c;
/* 1536 */         d0 += h0 * r0;
/* 1537 */         d0 += h1 * 5 * r9;
/* 1538 */         d0 += h2 * 5 * r8;
/* 1539 */         d0 += h3 * 5 * r7;
/* 1540 */         d0 += h4 * 5 * r6;
/* 1541 */         c = d0 >>> 13; d0 &= 0x1FFF;
/* 1542 */         d0 += h5 * 5 * r5;
/* 1543 */         d0 += h6 * 5 * r4;
/* 1544 */         d0 += h7 * 5 * r3;
/* 1545 */         d0 += h8 * 5 * r2;
/* 1546 */         d0 += h9 * 5 * r1;
/* 1547 */         c += d0 >>> 13; d0 &= 0x1FFF;
/*      */         
/* 1549 */         int d1 = c;
/* 1550 */         d1 += h0 * r1;
/* 1551 */         d1 += h1 * r0;
/* 1552 */         d1 += h2 * 5 * r9;
/* 1553 */         d1 += h3 * 5 * r8;
/* 1554 */         d1 += h4 * 5 * r7;
/* 1555 */         c = d1 >>> 13; d1 &= 0x1FFF;
/* 1556 */         d1 += h5 * 5 * r6;
/* 1557 */         d1 += h6 * 5 * r5;
/* 1558 */         d1 += h7 * 5 * r4;
/* 1559 */         d1 += h8 * 5 * r3;
/* 1560 */         d1 += h9 * 5 * r2;
/* 1561 */         c += d1 >>> 13; d1 &= 0x1FFF;
/*      */         
/* 1563 */         int d2 = c;
/* 1564 */         d2 += h0 * r2;
/* 1565 */         d2 += h1 * r1;
/* 1566 */         d2 += h2 * r0;
/* 1567 */         d2 += h3 * 5 * r9;
/* 1568 */         d2 += h4 * 5 * r8;
/* 1569 */         c = d2 >>> 13; d2 &= 0x1FFF;
/* 1570 */         d2 += h5 * 5 * r7;
/* 1571 */         d2 += h6 * 5 * r6;
/* 1572 */         d2 += h7 * 5 * r5;
/* 1573 */         d2 += h8 * 5 * r4;
/* 1574 */         d2 += h9 * 5 * r3;
/* 1575 */         c += d2 >>> 13; d2 &= 0x1FFF;
/*      */         
/* 1577 */         int d3 = c;
/* 1578 */         d3 += h0 * r3;
/* 1579 */         d3 += h1 * r2;
/* 1580 */         d3 += h2 * r1;
/* 1581 */         d3 += h3 * r0;
/* 1582 */         d3 += h4 * 5 * r9;
/* 1583 */         c = d3 >>> 13; d3 &= 0x1FFF;
/* 1584 */         d3 += h5 * 5 * r8;
/* 1585 */         d3 += h6 * 5 * r7;
/* 1586 */         d3 += h7 * 5 * r6;
/* 1587 */         d3 += h8 * 5 * r5;
/* 1588 */         d3 += h9 * 5 * r4;
/* 1589 */         c += d3 >>> 13; d3 &= 0x1FFF;
/*      */         
/* 1591 */         int d4 = c;
/* 1592 */         d4 += h0 * r4;
/* 1593 */         d4 += h1 * r3;
/* 1594 */         d4 += h2 * r2;
/* 1595 */         d4 += h3 * r1;
/* 1596 */         d4 += h4 * r0;
/* 1597 */         c = d4 >>> 13; d4 &= 0x1FFF;
/* 1598 */         d4 += h5 * 5 * r9;
/* 1599 */         d4 += h6 * 5 * r8;
/* 1600 */         d4 += h7 * 5 * r7;
/* 1601 */         d4 += h8 * 5 * r6;
/* 1602 */         d4 += h9 * 5 * r5;
/* 1603 */         c += d4 >>> 13; d4 &= 0x1FFF;
/*      */         
/* 1605 */         int d5 = c;
/* 1606 */         d5 += h0 * r5;
/* 1607 */         d5 += h1 * r4;
/* 1608 */         d5 += h2 * r3;
/* 1609 */         d5 += h3 * r2;
/* 1610 */         d5 += h4 * r1;
/* 1611 */         c = d5 >>> 13; d5 &= 0x1FFF;
/* 1612 */         d5 += h5 * r0;
/* 1613 */         d5 += h6 * 5 * r9;
/* 1614 */         d5 += h7 * 5 * r8;
/* 1615 */         d5 += h8 * 5 * r7;
/* 1616 */         d5 += h9 * 5 * r6;
/* 1617 */         c += d5 >>> 13; d5 &= 0x1FFF;
/*      */         
/* 1619 */         int d6 = c;
/* 1620 */         d6 += h0 * r6;
/* 1621 */         d6 += h1 * r5;
/* 1622 */         d6 += h2 * r4;
/* 1623 */         d6 += h3 * r3;
/* 1624 */         d6 += h4 * r2;
/* 1625 */         c = d6 >>> 13; d6 &= 0x1FFF;
/* 1626 */         d6 += h5 * r1;
/* 1627 */         d6 += h6 * r0;
/* 1628 */         d6 += h7 * 5 * r9;
/* 1629 */         d6 += h8 * 5 * r8;
/* 1630 */         d6 += h9 * 5 * r7;
/* 1631 */         c += d6 >>> 13; d6 &= 0x1FFF;
/*      */         
/* 1633 */         int d7 = c;
/* 1634 */         d7 += h0 * r7;
/* 1635 */         d7 += h1 * r6;
/* 1636 */         d7 += h2 * r5;
/* 1637 */         d7 += h3 * r4;
/* 1638 */         d7 += h4 * r3;
/* 1639 */         c = d7 >>> 13; d7 &= 0x1FFF;
/* 1640 */         d7 += h5 * r2;
/* 1641 */         d7 += h6 * r1;
/* 1642 */         d7 += h7 * r0;
/* 1643 */         d7 += h8 * 5 * r9;
/* 1644 */         d7 += h9 * 5 * r8;
/* 1645 */         c += d7 >>> 13; d7 &= 0x1FFF;
/*      */         
/* 1647 */         int d8 = c;
/* 1648 */         d8 += h0 * r8;
/* 1649 */         d8 += h1 * r7;
/* 1650 */         d8 += h2 * r6;
/* 1651 */         d8 += h3 * r5;
/* 1652 */         d8 += h4 * r4;
/* 1653 */         c = d8 >>> 13; d8 &= 0x1FFF;
/* 1654 */         d8 += h5 * r3;
/* 1655 */         d8 += h6 * r2;
/* 1656 */         d8 += h7 * r1;
/* 1657 */         d8 += h8 * r0;
/* 1658 */         d8 += h9 * 5 * r9;
/* 1659 */         c += d8 >>> 13; d8 &= 0x1FFF;
/*      */         
/* 1661 */         int d9 = c;
/* 1662 */         d9 += h0 * r9;
/* 1663 */         d9 += h1 * r8;
/* 1664 */         d9 += h2 * r7;
/* 1665 */         d9 += h3 * r6;
/* 1666 */         d9 += h4 * r5;
/* 1667 */         c = d9 >>> 13; d9 &= 0x1FFF;
/* 1668 */         d9 += h5 * r4;
/* 1669 */         d9 += h6 * r3;
/* 1670 */         d9 += h7 * r2;
/* 1671 */         d9 += h8 * r1;
/* 1672 */         d9 += h9 * r0;
/* 1673 */         c += d9 >>> 13; d9 &= 0x1FFF;
/*      */         
/* 1675 */         c = (c << 2) + c | 0x0;
/* 1676 */         c = c + d0 | 0x0;
/* 1677 */         d0 = c & 0x1FFF;
/* 1678 */         c >>>= 13;
/* 1679 */         d1 += c;
/*      */         
/* 1681 */         h0 = d0;
/* 1682 */         h1 = d1;
/* 1683 */         h2 = d2;
/* 1684 */         h3 = d3;
/* 1685 */         h4 = d4;
/* 1686 */         h5 = d5;
/* 1687 */         h6 = d6;
/* 1688 */         h7 = d7;
/* 1689 */         h8 = d8;
/* 1690 */         h9 = d9;
/*      */         
/* 1692 */         mpos += 16;
/* 1693 */         bytes -= 16;
/*      */       } 
/* 1695 */       this.h[0] = h0;
/* 1696 */       this.h[1] = h1;
/* 1697 */       this.h[2] = h2;
/* 1698 */       this.h[3] = h3;
/* 1699 */       this.h[4] = h4;
/* 1700 */       this.h[5] = h5;
/* 1701 */       this.h[6] = h6;
/* 1702 */       this.h[7] = h7;
/* 1703 */       this.h[8] = h8;
/* 1704 */       this.h[9] = h9;
/*      */       
/* 1706 */       return this;
/*      */     }
/*      */     
/*      */     public poly1305 finish(byte[] mac, int macpos) {
/* 1710 */       int[] g = new int[10];
/*      */ 
/*      */       
/* 1713 */       if (this.leftover != 0) {
/* 1714 */         int j = this.leftover;
/* 1715 */         this.buffer[j++] = 1;
/* 1716 */         while (j < 16) { this.buffer[j] = 0; j++; }
/* 1717 */          this.fin = 1;
/* 1718 */         blocks(this.buffer, 0, 16);
/*      */       } 
/*      */       
/* 1721 */       int c = this.h[1] >>> 13;
/* 1722 */       this.h[1] = this.h[1] & 0x1FFF; int i;
/* 1723 */       for (i = 2; i < 10; i++) {
/* 1724 */         this.h[i] = this.h[i] + c;
/* 1725 */         c = this.h[i] >>> 13;
/* 1726 */         this.h[i] = this.h[i] & 0x1FFF;
/*      */       } 
/* 1728 */       this.h[0] = this.h[0] + c * 5;
/* 1729 */       c = this.h[0] >>> 13;
/* 1730 */       this.h[0] = this.h[0] & 0x1FFF;
/* 1731 */       this.h[1] = this.h[1] + c;
/* 1732 */       c = this.h[1] >>> 13;
/* 1733 */       this.h[1] = this.h[1] & 0x1FFF;
/* 1734 */       this.h[2] = this.h[2] + c;
/*      */       
/* 1736 */       g[0] = this.h[0] + 5;
/* 1737 */       c = g[0] >>> 13;
/* 1738 */       g[0] = g[0] & 0x1FFF;
/* 1739 */       for (i = 1; i < 10; i++) {
/* 1740 */         g[i] = this.h[i] + c;
/* 1741 */         c = g[i] >>> 13;
/* 1742 */         g[i] = g[i] & 0x1FFF;
/*      */       } 
/* 1744 */       g[9] = g[9] - 8192; g[9] = g[9] & 0xFFFF;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1756 */       int mask = (c ^ 0x1) - 1;
/* 1757 */       mask &= 0xFFFF;
/*      */ 
/*      */       
/* 1760 */       for (i = 0; i < 10; ) { g[i] = g[i] & mask; i++; }
/* 1761 */        mask ^= 0xFFFFFFFF;
/* 1762 */       for (i = 0; i < 10; ) { this.h[i] = this.h[i] & mask | g[i]; i++; }
/*      */       
/* 1764 */       this.h[0] = (this.h[0] | this.h[1] << 13) & 0xFFFF;
/* 1765 */       this.h[1] = (this.h[1] >>> 3 | this.h[2] << 10) & 0xFFFF;
/* 1766 */       this.h[2] = (this.h[2] >>> 6 | this.h[3] << 7) & 0xFFFF;
/* 1767 */       this.h[3] = (this.h[3] >>> 9 | this.h[4] << 4) & 0xFFFF;
/* 1768 */       this.h[4] = (this.h[4] >>> 12 | this.h[5] << 1 | this.h[6] << 14) & 0xFFFF;
/* 1769 */       this.h[5] = (this.h[6] >>> 2 | this.h[7] << 11) & 0xFFFF;
/* 1770 */       this.h[6] = (this.h[7] >>> 5 | this.h[8] << 8) & 0xFFFF;
/* 1771 */       this.h[7] = (this.h[8] >>> 8 | this.h[9] << 5) & 0xFFFF;
/*      */       
/* 1773 */       int f = this.h[0] + this.pad[0];
/* 1774 */       this.h[0] = f & 0xFFFF;
/* 1775 */       for (i = 1; i < 8; i++) {
/* 1776 */         f = (this.h[i] + this.pad[i] | 0x0) + (f >>> 16) | 0x0;
/* 1777 */         this.h[i] = f & 0xFFFF;
/*      */       } 
/*      */       
/* 1780 */       mac[macpos + 0] = (byte)(this.h[0] >>> 0 & 0xFF);
/* 1781 */       mac[macpos + 1] = (byte)(this.h[0] >>> 8 & 0xFF);
/* 1782 */       mac[macpos + 2] = (byte)(this.h[1] >>> 0 & 0xFF);
/* 1783 */       mac[macpos + 3] = (byte)(this.h[1] >>> 8 & 0xFF);
/* 1784 */       mac[macpos + 4] = (byte)(this.h[2] >>> 0 & 0xFF);
/* 1785 */       mac[macpos + 5] = (byte)(this.h[2] >>> 8 & 0xFF);
/* 1786 */       mac[macpos + 6] = (byte)(this.h[3] >>> 0 & 0xFF);
/* 1787 */       mac[macpos + 7] = (byte)(this.h[3] >>> 8 & 0xFF);
/* 1788 */       mac[macpos + 8] = (byte)(this.h[4] >>> 0 & 0xFF);
/* 1789 */       mac[macpos + 9] = (byte)(this.h[4] >>> 8 & 0xFF);
/* 1790 */       mac[macpos + 10] = (byte)(this.h[5] >>> 0 & 0xFF);
/* 1791 */       mac[macpos + 11] = (byte)(this.h[5] >>> 8 & 0xFF);
/* 1792 */       mac[macpos + 12] = (byte)(this.h[6] >>> 0 & 0xFF);
/* 1793 */       mac[macpos + 13] = (byte)(this.h[6] >>> 8 & 0xFF);
/* 1794 */       mac[macpos + 14] = (byte)(this.h[7] >>> 0 & 0xFF);
/* 1795 */       mac[macpos + 15] = (byte)(this.h[7] >>> 8 & 0xFF);
/*      */       
/* 1797 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public poly1305 update(byte[] m, int mpos, int bytes) {
/* 1803 */       if (this.leftover != 0) {
/* 1804 */         int want = 16 - this.leftover;
/* 1805 */         if (want > bytes)
/* 1806 */           want = bytes; 
/* 1807 */         for (int i = 0; i < want; i++)
/* 1808 */           this.buffer[this.leftover + i] = m[mpos + i]; 
/* 1809 */         bytes -= want;
/* 1810 */         mpos += want;
/* 1811 */         this.leftover += want;
/* 1812 */         if (this.leftover < 16)
/* 1813 */           return this; 
/* 1814 */         blocks(this.buffer, 0, 16);
/* 1815 */         this.leftover = 0;
/*      */       } 
/*      */       
/* 1818 */       if (bytes >= 16) {
/* 1819 */         int want = bytes - bytes % 16;
/* 1820 */         blocks(m, mpos, want);
/* 1821 */         mpos += want;
/* 1822 */         bytes -= want;
/*      */       } 
/*      */       
/* 1825 */       if (bytes != 0) {
/* 1826 */         for (int i = 0; i < bytes; i++)
/* 1827 */           this.buffer[this.leftover + i] = m[mpos + i]; 
/* 1828 */         this.leftover += bytes;
/*      */       } 
/*      */       
/* 1831 */       return this;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int crypto_onetimeauth(byte[] out, int outpos, byte[] m, int mpos, int n, byte[] k) {
/* 1842 */     poly1305 s = new poly1305(k);
/* 1843 */     s.update(m, mpos, n);
/* 1844 */     s.finish(out, outpos);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1851 */     return 0;
/*      */   }
/*      */   public static int crypto_onetimeauth(byte[] out, byte[] m, int n, byte[] k) {
/* 1854 */     return crypto_onetimeauth(out, 0, m, 0, n, k);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int crypto_onetimeauth_verify(byte[] h, int hoff, byte[] m, int moff, int n, byte[] k) {
/* 1863 */     byte[] x = new byte[16];
/* 1864 */     crypto_onetimeauth(x, 0, m, moff, n, k);
/* 1865 */     return crypto_verify_16(h, hoff, x, 0);
/*      */   }
/*      */   public static int crypto_onetimeauth_verify(byte[] h, byte[] m, int n, byte[] k) {
/* 1868 */     return crypto_onetimeauth_verify(h, 0, m, 0, n, k);
/*      */   }
/*      */   public static int crypto_onetimeauth_verify(byte[] h, byte[] m, byte[] k) {
/* 1871 */     return crypto_onetimeauth_verify(h, m, (m != null) ? m.length : 0, k);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static int crypto_secretbox(byte[] c, byte[] m, int d, byte[] n, byte[] k) {
/* 1877 */     if (d < 32) return -1; 
/* 1878 */     crypto_stream_xor(c, 0, m, 0, d, n, k);
/* 1879 */     crypto_onetimeauth(c, 16, c, 32, d - 32, c);
/*      */     
/* 1881 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static int crypto_secretbox_open(byte[] m, byte[] c, int d, byte[] n, byte[] k) {
/* 1887 */     byte[] x = new byte[32];
/* 1888 */     if (d < 32) return -1; 
/* 1889 */     crypto_stream(x, 0, 32L, n, k);
/* 1890 */     if (crypto_onetimeauth_verify(c, 16, c, 32, d - 32, x) != 0) return -1; 
/* 1891 */     crypto_stream_xor(m, 0, c, 0, d, n, k);
/*      */     
/* 1893 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static void set25519(long[] r, long[] a) {
/* 1899 */     for (int i = 0; i < 16; ) { r[i] = a[i]; i++; }
/*      */   
/*      */   }
/*      */ 
/*      */   
/*      */   private static void car25519(long[] o) {
/* 1905 */     long c = 1L;
/* 1906 */     for (int i = 0; i < 16; i++) {
/* 1907 */       long v = o[i] + c + 65535L;
/* 1908 */       c = v >> 16L;
/* 1909 */       o[i] = v - c * 65536L;
/*      */     } 
/* 1911 */     o[0] = o[0] + c - 1L + 37L * (c - 1L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void sel25519(long[] p, long[] q, int b) {
/* 1919 */     sel25519(p, 0, q, 0, b);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void sel25519(long[] p, int poff, long[] q, int qoff, int b) {
/* 1926 */     long c = (b - 1 ^ 0xFFFFFFFF);
/* 1927 */     for (int i = 0; i < 16; i++) {
/* 1928 */       long t = c & (p[i + poff] ^ q[i + qoff]);
/* 1929 */       p[i + poff] = p[i + poff] ^ t;
/* 1930 */       q[i + qoff] = q[i + qoff] ^ t;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static void pack25519(byte[] o, long[] n, int noff) {
/* 1937 */     long[] m = new long[16], t = new long[16]; int i;
/* 1938 */     for (i = 0; i < 16; ) { t[i] = n[i + noff]; i++; }
/* 1939 */      car25519(t);
/* 1940 */     car25519(t);
/* 1941 */     car25519(t);
/* 1942 */     for (int j = 0; j < 2; j++) {
/* 1943 */       m[0] = t[0] - 65517L;
/* 1944 */       for (i = 1; i < 15; i++) {
/* 1945 */         m[i] = t[i] - 65535L - (m[i - 1] >> 16L & 0x1L);
/* 1946 */         m[i - 1] = m[i - 1] & 0xFFFFL;
/*      */       } 
/* 1948 */       m[15] = t[15] - 32767L - (m[14] >> 16L & 0x1L);
/* 1949 */       int b = (int)(m[15] >> 16L & 0x1L);
/* 1950 */       m[14] = m[14] & 0xFFFFL;
/* 1951 */       sel25519(t, 0, m, 0, 1 - b);
/*      */     } 
/* 1953 */     for (i = 0; i < 16; i++) {
/* 1954 */       o[2 * i] = (byte)(int)(t[i] & 0xFFL);
/* 1955 */       o[2 * i + 1] = (byte)(int)(t[i] >> 8L);
/*      */     } 
/*      */   }
/*      */   
/*      */   private static int neq25519(long[] a, long[] b) {
/* 1960 */     return neq25519(a, 0, b, 0);
/*      */   }
/*      */   
/*      */   private static int neq25519(long[] a, int aoff, long[] b, int boff) {
/* 1964 */     byte[] c = new byte[32], d = new byte[32];
/* 1965 */     pack25519(c, a, aoff);
/* 1966 */     pack25519(d, b, boff);
/* 1967 */     return crypto_verify_32(c, 0, d, 0);
/*      */   }
/*      */ 
/*      */   
/*      */   private static byte par25519(long[] a) {
/* 1972 */     return par25519(a, 0);
/*      */   }
/*      */   
/*      */   private static byte par25519(long[] a, int aoff) {
/* 1976 */     byte[] d = new byte[32];
/* 1977 */     pack25519(d, a, aoff);
/* 1978 */     return (byte)(d[0] & 0x1);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static void unpack25519(long[] o, byte[] n) {
/* 1984 */     for (int i = 0; i < 16; ) { o[i] = (n[2 * i] & 0xFF) + (n[2 * i + 1] << 8 & 0xFFFF); i++; }
/* 1985 */      o[15] = o[15] & 0x7FFFL;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void A(long[] o, long[] a, long[] b) {
/* 1993 */     A(o, 0, a, 0, b, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void A(long[] o, int ooff, long[] a, int aoff, long[] b, int boff) {
/* 2001 */     for (int i = 0; i < 16; ) { o[i + ooff] = a[i + aoff] + b[i + boff]; i++; }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void Z(long[] o, long[] a, long[] b) {
/* 2009 */     Z(o, 0, a, 0, b, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void Z(long[] o, int ooff, long[] a, int aoff, long[] b, int boff) {
/* 2017 */     for (int i = 0; i < 16; ) { o[i + ooff] = a[i + aoff] - b[i + boff]; i++; }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void M(long[] o, long[] a, long[] b) {
/* 2025 */     M(o, 0, a, 0, b, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void M(long[] o, int ooff, long[] a, int aoff, long[] b, int boff) {
/* 2033 */     long t0 = 0L, t1 = 0L, t2 = 0L, t3 = 0L, t4 = 0L, t5 = 0L, t6 = 0L, t7 = 0L;
/* 2034 */     long t8 = 0L, t9 = 0L, t10 = 0L, t11 = 0L, t12 = 0L, t13 = 0L, t14 = 0L, t15 = 0L;
/* 2035 */     long t16 = 0L, t17 = 0L, t18 = 0L, t19 = 0L, t20 = 0L, t21 = 0L, t22 = 0L, t23 = 0L;
/* 2036 */     long t24 = 0L, t25 = 0L, t26 = 0L, t27 = 0L, t28 = 0L, t29 = 0L, t30 = 0L;
/* 2037 */     long b0 = b[0 + boff];
/* 2038 */     long b1 = b[1 + boff];
/* 2039 */     long b2 = b[2 + boff];
/* 2040 */     long b3 = b[3 + boff];
/* 2041 */     long b4 = b[4 + boff];
/* 2042 */     long b5 = b[5 + boff];
/* 2043 */     long b6 = b[6 + boff];
/* 2044 */     long b7 = b[7 + boff];
/* 2045 */     long b8 = b[8 + boff];
/* 2046 */     long b9 = b[9 + boff];
/* 2047 */     long b10 = b[10 + boff];
/* 2048 */     long b11 = b[11 + boff];
/* 2049 */     long b12 = b[12 + boff];
/* 2050 */     long b13 = b[13 + boff];
/* 2051 */     long b14 = b[14 + boff];
/* 2052 */     long b15 = b[15 + boff];
/*      */     
/* 2054 */     long v = a[0 + aoff];
/* 2055 */     t0 += v * b0;
/* 2056 */     t1 += v * b1;
/* 2057 */     t2 += v * b2;
/* 2058 */     t3 += v * b3;
/* 2059 */     t4 += v * b4;
/* 2060 */     t5 += v * b5;
/* 2061 */     t6 += v * b6;
/* 2062 */     t7 += v * b7;
/* 2063 */     t8 += v * b8;
/* 2064 */     t9 += v * b9;
/* 2065 */     t10 += v * b10;
/* 2066 */     t11 += v * b11;
/* 2067 */     t12 += v * b12;
/* 2068 */     t13 += v * b13;
/* 2069 */     t14 += v * b14;
/* 2070 */     t15 += v * b15;
/* 2071 */     v = a[1 + aoff];
/* 2072 */     t1 += v * b0;
/* 2073 */     t2 += v * b1;
/* 2074 */     t3 += v * b2;
/* 2075 */     t4 += v * b3;
/* 2076 */     t5 += v * b4;
/* 2077 */     t6 += v * b5;
/* 2078 */     t7 += v * b6;
/* 2079 */     t8 += v * b7;
/* 2080 */     t9 += v * b8;
/* 2081 */     t10 += v * b9;
/* 2082 */     t11 += v * b10;
/* 2083 */     t12 += v * b11;
/* 2084 */     t13 += v * b12;
/* 2085 */     t14 += v * b13;
/* 2086 */     t15 += v * b14;
/* 2087 */     t16 += v * b15;
/* 2088 */     v = a[2 + aoff];
/* 2089 */     t2 += v * b0;
/* 2090 */     t3 += v * b1;
/* 2091 */     t4 += v * b2;
/* 2092 */     t5 += v * b3;
/* 2093 */     t6 += v * b4;
/* 2094 */     t7 += v * b5;
/* 2095 */     t8 += v * b6;
/* 2096 */     t9 += v * b7;
/* 2097 */     t10 += v * b8;
/* 2098 */     t11 += v * b9;
/* 2099 */     t12 += v * b10;
/* 2100 */     t13 += v * b11;
/* 2101 */     t14 += v * b12;
/* 2102 */     t15 += v * b13;
/* 2103 */     t16 += v * b14;
/* 2104 */     t17 += v * b15;
/* 2105 */     v = a[3 + aoff];
/* 2106 */     t3 += v * b0;
/* 2107 */     t4 += v * b1;
/* 2108 */     t5 += v * b2;
/* 2109 */     t6 += v * b3;
/* 2110 */     t7 += v * b4;
/* 2111 */     t8 += v * b5;
/* 2112 */     t9 += v * b6;
/* 2113 */     t10 += v * b7;
/* 2114 */     t11 += v * b8;
/* 2115 */     t12 += v * b9;
/* 2116 */     t13 += v * b10;
/* 2117 */     t14 += v * b11;
/* 2118 */     t15 += v * b12;
/* 2119 */     t16 += v * b13;
/* 2120 */     t17 += v * b14;
/* 2121 */     t18 += v * b15;
/* 2122 */     v = a[4 + aoff];
/* 2123 */     t4 += v * b0;
/* 2124 */     t5 += v * b1;
/* 2125 */     t6 += v * b2;
/* 2126 */     t7 += v * b3;
/* 2127 */     t8 += v * b4;
/* 2128 */     t9 += v * b5;
/* 2129 */     t10 += v * b6;
/* 2130 */     t11 += v * b7;
/* 2131 */     t12 += v * b8;
/* 2132 */     t13 += v * b9;
/* 2133 */     t14 += v * b10;
/* 2134 */     t15 += v * b11;
/* 2135 */     t16 += v * b12;
/* 2136 */     t17 += v * b13;
/* 2137 */     t18 += v * b14;
/* 2138 */     t19 += v * b15;
/* 2139 */     v = a[5 + aoff];
/* 2140 */     t5 += v * b0;
/* 2141 */     t6 += v * b1;
/* 2142 */     t7 += v * b2;
/* 2143 */     t8 += v * b3;
/* 2144 */     t9 += v * b4;
/* 2145 */     t10 += v * b5;
/* 2146 */     t11 += v * b6;
/* 2147 */     t12 += v * b7;
/* 2148 */     t13 += v * b8;
/* 2149 */     t14 += v * b9;
/* 2150 */     t15 += v * b10;
/* 2151 */     t16 += v * b11;
/* 2152 */     t17 += v * b12;
/* 2153 */     t18 += v * b13;
/* 2154 */     t19 += v * b14;
/* 2155 */     t20 += v * b15;
/* 2156 */     v = a[6 + aoff];
/* 2157 */     t6 += v * b0;
/* 2158 */     t7 += v * b1;
/* 2159 */     t8 += v * b2;
/* 2160 */     t9 += v * b3;
/* 2161 */     t10 += v * b4;
/* 2162 */     t11 += v * b5;
/* 2163 */     t12 += v * b6;
/* 2164 */     t13 += v * b7;
/* 2165 */     t14 += v * b8;
/* 2166 */     t15 += v * b9;
/* 2167 */     t16 += v * b10;
/* 2168 */     t17 += v * b11;
/* 2169 */     t18 += v * b12;
/* 2170 */     t19 += v * b13;
/* 2171 */     t20 += v * b14;
/* 2172 */     t21 += v * b15;
/* 2173 */     v = a[7 + aoff];
/* 2174 */     t7 += v * b0;
/* 2175 */     t8 += v * b1;
/* 2176 */     t9 += v * b2;
/* 2177 */     t10 += v * b3;
/* 2178 */     t11 += v * b4;
/* 2179 */     t12 += v * b5;
/* 2180 */     t13 += v * b6;
/* 2181 */     t14 += v * b7;
/* 2182 */     t15 += v * b8;
/* 2183 */     t16 += v * b9;
/* 2184 */     t17 += v * b10;
/* 2185 */     t18 += v * b11;
/* 2186 */     t19 += v * b12;
/* 2187 */     t20 += v * b13;
/* 2188 */     t21 += v * b14;
/* 2189 */     t22 += v * b15;
/* 2190 */     v = a[8 + aoff];
/* 2191 */     t8 += v * b0;
/* 2192 */     t9 += v * b1;
/* 2193 */     t10 += v * b2;
/* 2194 */     t11 += v * b3;
/* 2195 */     t12 += v * b4;
/* 2196 */     t13 += v * b5;
/* 2197 */     t14 += v * b6;
/* 2198 */     t15 += v * b7;
/* 2199 */     t16 += v * b8;
/* 2200 */     t17 += v * b9;
/* 2201 */     t18 += v * b10;
/* 2202 */     t19 += v * b11;
/* 2203 */     t20 += v * b12;
/* 2204 */     t21 += v * b13;
/* 2205 */     t22 += v * b14;
/* 2206 */     t23 += v * b15;
/* 2207 */     v = a[9 + aoff];
/* 2208 */     t9 += v * b0;
/* 2209 */     t10 += v * b1;
/* 2210 */     t11 += v * b2;
/* 2211 */     t12 += v * b3;
/* 2212 */     t13 += v * b4;
/* 2213 */     t14 += v * b5;
/* 2214 */     t15 += v * b6;
/* 2215 */     t16 += v * b7;
/* 2216 */     t17 += v * b8;
/* 2217 */     t18 += v * b9;
/* 2218 */     t19 += v * b10;
/* 2219 */     t20 += v * b11;
/* 2220 */     t21 += v * b12;
/* 2221 */     t22 += v * b13;
/* 2222 */     t23 += v * b14;
/* 2223 */     t24 += v * b15;
/* 2224 */     v = a[10 + aoff];
/* 2225 */     t10 += v * b0;
/* 2226 */     t11 += v * b1;
/* 2227 */     t12 += v * b2;
/* 2228 */     t13 += v * b3;
/* 2229 */     t14 += v * b4;
/* 2230 */     t15 += v * b5;
/* 2231 */     t16 += v * b6;
/* 2232 */     t17 += v * b7;
/* 2233 */     t18 += v * b8;
/* 2234 */     t19 += v * b9;
/* 2235 */     t20 += v * b10;
/* 2236 */     t21 += v * b11;
/* 2237 */     t22 += v * b12;
/* 2238 */     t23 += v * b13;
/* 2239 */     t24 += v * b14;
/* 2240 */     t25 += v * b15;
/* 2241 */     v = a[11 + aoff];
/* 2242 */     t11 += v * b0;
/* 2243 */     t12 += v * b1;
/* 2244 */     t13 += v * b2;
/* 2245 */     t14 += v * b3;
/* 2246 */     t15 += v * b4;
/* 2247 */     t16 += v * b5;
/* 2248 */     t17 += v * b6;
/* 2249 */     t18 += v * b7;
/* 2250 */     t19 += v * b8;
/* 2251 */     t20 += v * b9;
/* 2252 */     t21 += v * b10;
/* 2253 */     t22 += v * b11;
/* 2254 */     t23 += v * b12;
/* 2255 */     t24 += v * b13;
/* 2256 */     t25 += v * b14;
/* 2257 */     t26 += v * b15;
/* 2258 */     v = a[12 + aoff];
/* 2259 */     t12 += v * b0;
/* 2260 */     t13 += v * b1;
/* 2261 */     t14 += v * b2;
/* 2262 */     t15 += v * b3;
/* 2263 */     t16 += v * b4;
/* 2264 */     t17 += v * b5;
/* 2265 */     t18 += v * b6;
/* 2266 */     t19 += v * b7;
/* 2267 */     t20 += v * b8;
/* 2268 */     t21 += v * b9;
/* 2269 */     t22 += v * b10;
/* 2270 */     t23 += v * b11;
/* 2271 */     t24 += v * b12;
/* 2272 */     t25 += v * b13;
/* 2273 */     t26 += v * b14;
/* 2274 */     t27 += v * b15;
/* 2275 */     v = a[13 + aoff];
/* 2276 */     t13 += v * b0;
/* 2277 */     t14 += v * b1;
/* 2278 */     t15 += v * b2;
/* 2279 */     t16 += v * b3;
/* 2280 */     t17 += v * b4;
/* 2281 */     t18 += v * b5;
/* 2282 */     t19 += v * b6;
/* 2283 */     t20 += v * b7;
/* 2284 */     t21 += v * b8;
/* 2285 */     t22 += v * b9;
/* 2286 */     t23 += v * b10;
/* 2287 */     t24 += v * b11;
/* 2288 */     t25 += v * b12;
/* 2289 */     t26 += v * b13;
/* 2290 */     t27 += v * b14;
/* 2291 */     t28 += v * b15;
/* 2292 */     v = a[14 + aoff];
/* 2293 */     t14 += v * b0;
/* 2294 */     t15 += v * b1;
/* 2295 */     t16 += v * b2;
/* 2296 */     t17 += v * b3;
/* 2297 */     t18 += v * b4;
/* 2298 */     t19 += v * b5;
/* 2299 */     t20 += v * b6;
/* 2300 */     t21 += v * b7;
/* 2301 */     t22 += v * b8;
/* 2302 */     t23 += v * b9;
/* 2303 */     t24 += v * b10;
/* 2304 */     t25 += v * b11;
/* 2305 */     t26 += v * b12;
/* 2306 */     t27 += v * b13;
/* 2307 */     t28 += v * b14;
/* 2308 */     t29 += v * b15;
/* 2309 */     v = a[15 + aoff];
/* 2310 */     t15 += v * b0;
/* 2311 */     t16 += v * b1;
/* 2312 */     t17 += v * b2;
/* 2313 */     t18 += v * b3;
/* 2314 */     t19 += v * b4;
/* 2315 */     t20 += v * b5;
/* 2316 */     t21 += v * b6;
/* 2317 */     t22 += v * b7;
/* 2318 */     t23 += v * b8;
/* 2319 */     t24 += v * b9;
/* 2320 */     t25 += v * b10;
/* 2321 */     t26 += v * b11;
/* 2322 */     t27 += v * b12;
/* 2323 */     t28 += v * b13;
/* 2324 */     t29 += v * b14;
/* 2325 */     t30 += v * b15;
/*      */     
/* 2327 */     t0 += 38L * t16;
/* 2328 */     t1 += 38L * t17;
/* 2329 */     t2 += 38L * t18;
/* 2330 */     t3 += 38L * t19;
/* 2331 */     t4 += 38L * t20;
/* 2332 */     t5 += 38L * t21;
/* 2333 */     t6 += 38L * t22;
/* 2334 */     t7 += 38L * t23;
/* 2335 */     t8 += 38L * t24;
/* 2336 */     t9 += 38L * t25;
/* 2337 */     t10 += 38L * t26;
/* 2338 */     t11 += 38L * t27;
/* 2339 */     t12 += 38L * t28;
/* 2340 */     t13 += 38L * t29;
/* 2341 */     t14 += 38L * t30;
/*      */ 
/*      */ 
/*      */     
/* 2345 */     long c = 1L;
/* 2346 */     v = t0 + c + 65535L; c = v >> 16L; t0 = v - c * 65536L;
/* 2347 */     v = t1 + c + 65535L; c = v >> 16L; t1 = v - c * 65536L;
/* 2348 */     v = t2 + c + 65535L; c = v >> 16L; t2 = v - c * 65536L;
/* 2349 */     v = t3 + c + 65535L; c = v >> 16L; t3 = v - c * 65536L;
/* 2350 */     v = t4 + c + 65535L; c = v >> 16L; t4 = v - c * 65536L;
/* 2351 */     v = t5 + c + 65535L; c = v >> 16L; t5 = v - c * 65536L;
/* 2352 */     v = t6 + c + 65535L; c = v >> 16L; t6 = v - c * 65536L;
/* 2353 */     v = t7 + c + 65535L; c = v >> 16L; t7 = v - c * 65536L;
/* 2354 */     v = t8 + c + 65535L; c = v >> 16L; t8 = v - c * 65536L;
/* 2355 */     v = t9 + c + 65535L; c = v >> 16L; t9 = v - c * 65536L;
/* 2356 */     v = t10 + c + 65535L; c = v >> 16L; t10 = v - c * 65536L;
/* 2357 */     v = t11 + c + 65535L; c = v >> 16L; t11 = v - c * 65536L;
/* 2358 */     v = t12 + c + 65535L; c = v >> 16L; t12 = v - c * 65536L;
/* 2359 */     v = t13 + c + 65535L; c = v >> 16L; t13 = v - c * 65536L;
/* 2360 */     v = t14 + c + 65535L; c = v >> 16L; t14 = v - c * 65536L;
/* 2361 */     v = t15 + c + 65535L; c = v >> 16L; t15 = v - c * 65536L;
/* 2362 */     t0 += c - 1L + 37L * (c - 1L);
/*      */ 
/*      */     
/* 2365 */     c = 1L;
/* 2366 */     v = t0 + c + 65535L; c = v >> 16L; t0 = v - c * 65536L;
/* 2367 */     v = t1 + c + 65535L; c = v >> 16L; t1 = v - c * 65536L;
/* 2368 */     v = t2 + c + 65535L; c = v >> 16L; t2 = v - c * 65536L;
/* 2369 */     v = t3 + c + 65535L; c = v >> 16L; t3 = v - c * 65536L;
/* 2370 */     v = t4 + c + 65535L; c = v >> 16L; t4 = v - c * 65536L;
/* 2371 */     v = t5 + c + 65535L; c = v >> 16L; t5 = v - c * 65536L;
/* 2372 */     v = t6 + c + 65535L; c = v >> 16L; t6 = v - c * 65536L;
/* 2373 */     v = t7 + c + 65535L; c = v >> 16L; t7 = v - c * 65536L;
/* 2374 */     v = t8 + c + 65535L; c = v >> 16L; t8 = v - c * 65536L;
/* 2375 */     v = t9 + c + 65535L; c = v >> 16L; t9 = v - c * 65536L;
/* 2376 */     v = t10 + c + 65535L; c = v >> 16L; t10 = v - c * 65536L;
/* 2377 */     v = t11 + c + 65535L; c = v >> 16L; t11 = v - c * 65536L;
/* 2378 */     v = t12 + c + 65535L; c = v >> 16L; t12 = v - c * 65536L;
/* 2379 */     v = t13 + c + 65535L; c = v >> 16L; t13 = v - c * 65536L;
/* 2380 */     v = t14 + c + 65535L; c = v >> 16L; t14 = v - c * 65536L;
/* 2381 */     v = t15 + c + 65535L; c = v >> 16L; t15 = v - c * 65536L;
/* 2382 */     t0 += c - 1L + 37L * (c - 1L);
/*      */     
/* 2384 */     o[0 + ooff] = t0;
/* 2385 */     o[1 + ooff] = t1;
/* 2386 */     o[2 + ooff] = t2;
/* 2387 */     o[3 + ooff] = t3;
/* 2388 */     o[4 + ooff] = t4;
/* 2389 */     o[5 + ooff] = t5;
/* 2390 */     o[6 + ooff] = t6;
/* 2391 */     o[7 + ooff] = t7;
/* 2392 */     o[8 + ooff] = t8;
/* 2393 */     o[9 + ooff] = t9;
/* 2394 */     o[10 + ooff] = t10;
/* 2395 */     o[11 + ooff] = t11;
/* 2396 */     o[12 + ooff] = t12;
/* 2397 */     o[13 + ooff] = t13;
/* 2398 */     o[14 + ooff] = t14;
/* 2399 */     o[15 + ooff] = t15;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void S(long[] o, long[] a) {
/* 2406 */     S(o, 0, a, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static void S(long[] o, int ooff, long[] a, int aoff) {
/* 2412 */     M(o, ooff, a, aoff, a, aoff);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void inv25519(long[] o, int ooff, long[] i, int ioff) {
/* 2419 */     long[] c = new long[16];
/*      */     int a;
/* 2421 */     for (a = 0; a < 16; ) { c[a] = i[a + ioff]; a++; }
/* 2422 */      for (a = 253; a >= 0; a--) {
/* 2423 */       S(c, 0, c, 0);
/* 2424 */       if (a != 2 && a != 4) M(c, 0, c, 0, i, ioff); 
/*      */     } 
/* 2426 */     for (a = 0; a < 16; ) { o[a + ooff] = c[a]; a++; }
/*      */   
/*      */   }
/*      */   
/*      */   private static void pow2523(long[] o, long[] i) {
/* 2431 */     long[] c = new long[16];
/*      */     
/*      */     int a;
/* 2434 */     for (a = 0; a < 16; ) { c[a] = i[a]; a++; }
/*      */     
/* 2436 */     for (a = 250; a >= 0; a--) {
/* 2437 */       S(c, 0, c, 0);
/* 2438 */       if (a != 1) M(c, 0, c, 0, i, 0);
/*      */     
/*      */     } 
/* 2441 */     for (a = 0; a < 16; ) { o[a] = c[a]; a++; }
/*      */   
/*      */   }
/*      */   
/*      */   public static int crypto_scalarmult(byte[] q, byte[] n, byte[] p) {
/* 2446 */     byte[] z = new byte[32];
/* 2447 */     long[] x = new long[80];
/*      */     
/* 2449 */     long[] a = new long[16], b = new long[16], c = new long[16];
/* 2450 */     long[] d = new long[16], e = new long[16], f = new long[16]; int i;
/* 2451 */     for (i = 0; i < 31; ) { z[i] = n[i]; i++; }
/* 2452 */      z[31] = (byte)((n[31] & Byte.MAX_VALUE | 0x40) & 0xFF);
/* 2453 */     z[0] = (byte)(z[0] & 0xF8);
/* 2454 */     unpack25519(x, p);
/* 2455 */     for (i = 0; i < 16; i++) {
/* 2456 */       b[i] = x[i];
/* 2457 */       c[i] = 0L; a[i] = 0L; d[i] = 0L;
/*      */     } 
/* 2459 */     d[0] = 1L; a[0] = 1L;
/* 2460 */     for (i = 254; i >= 0; i--) {
/* 2461 */       int r = z[i >>> 3] >>> (i & 0x7) & 0x1;
/* 2462 */       sel25519(a, b, r);
/* 2463 */       sel25519(c, d, r);
/* 2464 */       A(e, a, c);
/* 2465 */       Z(a, a, c);
/* 2466 */       A(c, b, d);
/* 2467 */       Z(b, b, d);
/* 2468 */       S(d, e);
/* 2469 */       S(f, a);
/* 2470 */       M(a, c, a);
/* 2471 */       M(c, b, e);
/* 2472 */       A(e, a, c);
/* 2473 */       Z(a, a, c);
/* 2474 */       S(b, a);
/* 2475 */       Z(c, d, f);
/* 2476 */       M(a, c, _121665);
/* 2477 */       A(a, a, d);
/* 2478 */       M(c, c, a);
/* 2479 */       M(a, d, f);
/* 2480 */       M(d, b, x);
/* 2481 */       S(b, e);
/* 2482 */       sel25519(a, b, r);
/* 2483 */       sel25519(c, d, r);
/*      */     } 
/* 2485 */     for (i = 0; i < 16; i++) {
/* 2486 */       x[i + 16] = a[i];
/* 2487 */       x[i + 32] = c[i];
/* 2488 */       x[i + 48] = b[i];
/* 2489 */       x[i + 64] = d[i];
/*      */     } 
/* 2491 */     inv25519(x, 32, x, 32);
/* 2492 */     M(x, 16, x, 16, x, 32);
/* 2493 */     pack25519(q, x, 16);
/*      */     
/* 2495 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public static int crypto_scalarmult_base(byte[] q, byte[] n) {
/* 2500 */     return crypto_scalarmult(q, n, _9);
/*      */   }
/*      */ 
/*      */   
/*      */   public static int crypto_box_keypair(byte[] y, byte[] x) {
/* 2505 */     randombytes(x, 32);
/* 2506 */     return crypto_scalarmult_base(y, x);
/*      */   }
/*      */ 
/*      */   
/*      */   public static int crypto_box_beforenm(byte[] k, byte[] y, byte[] x) {
/* 2511 */     byte[] s = new byte[32];
/* 2512 */     crypto_scalarmult(s, x, y);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2527 */     return crypto_core_hsalsa20(k, _0, s, sigma);
/*      */   }
/*      */ 
/*      */   
/*      */   public static int crypto_box_afternm(byte[] c, byte[] m, int d, byte[] n, byte[] k) {
/* 2532 */     return crypto_secretbox(c, m, d, n, k);
/*      */   }
/*      */ 
/*      */   
/*      */   public static int crypto_box_open_afternm(byte[] m, byte[] c, int d, byte[] n, byte[] k) {
/* 2537 */     return crypto_secretbox_open(m, c, d, n, k);
/*      */   }
/*      */ 
/*      */   
/*      */   public static int crypto_box(byte[] c, byte[] m, int d, byte[] n, byte[] y, byte[] x) {
/* 2542 */     byte[] k = new byte[32];
/*      */ 
/*      */ 
/*      */     
/* 2546 */     crypto_box_beforenm(k, y, x);
/* 2547 */     return crypto_box_afternm(c, m, d, n, k);
/*      */   }
/*      */ 
/*      */   
/*      */   public static int crypto_box_open(byte[] m, byte[] c, int d, byte[] n, byte[] y, byte[] x) {
/* 2552 */     byte[] k = new byte[32];
/* 2553 */     crypto_box_beforenm(k, y, x);
/* 2554 */     return crypto_box_open_afternm(m, c, d, n, k);
/*      */   }
/*      */   
/* 2557 */   private static final long[] K = new long[] { 4794697086780616226L, 8158064640168781261L, -5349999486874862801L, -1606136188198331460L, 4131703408338449720L, 6480981068601479193L, -7908458776815382629L, -6116909921290321640L, -2880145864133508542L, 1334009975649890238L, 2608012711638119052L, 6128411473006802146L, 8268148722764581231L, -9160688886553864527L, -7215885187991268811L, -4495734319001033068L, -1973867731355612462L, -1171420211273849373L, 1135362057144423861L, 2597628984639134821L, 3308224258029322869L, 5365058923640841347L, 6679025012923562964L, 8573033837759648693L, -7476448914759557205L, -6327057829258317296L, -5763719355590565569L, -4658551843659510044L, -4116276920077217854L, -3051310485924567259L, 489312712824947311L, 1452737877330783856L, 2861767655752347644L, 3322285676063803686L, 5560940570517711597L, 5996557281743188959L, 7280758554555802590L, 8532644243296465576L, -9096487096722542874L, -7894198246740708037L, -6719396339535248540L, -6333637450476146687L, -4446306890439682159L, -4076793802049405392L, -3345356375505022440L, -2983346525034927856L, -860691631967231958L, 1182934255886127544L, 1847814050463011016L, 2177327727835720531L, 2830643537854262169L, 3796741975233480872L, 4115178125766777443L, 5681478168544905931L, 6601373596472566643L, 7507060721942968483L, 8399075790359081724L, 8693463985226723168L, -8878714635349349518L, -8302665154208450068L, -8016688836872298968L, -6606660893046293015L, -4685533653050689259L, -4147400797238176981L, -3880063495543823972L, -3348786107499101689L, -1523767162380948706L, -757361751448694408L, 500013540394364858L, 748580250866718886L, 1242879168328830382L, 1977374033974150939L, 2944078676154940804L, 3659926193048069267L, 4368137639120453308L, 4836135668995329356L, 5532061633213252278L, 6448918945643986474L, 6902733635092675308L, 7801388544844847127L };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int crypto_hashblocks_hl(int[] hh, int[] hl, byte[] m, int moff, int n) {
/* 2586 */     int[] wh = new int[16], wl = new int[16];
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2591 */     int ah0 = hh[0];
/* 2592 */     int ah1 = hh[1];
/* 2593 */     int ah2 = hh[2];
/* 2594 */     int ah3 = hh[3];
/* 2595 */     int ah4 = hh[4];
/* 2596 */     int ah5 = hh[5];
/* 2597 */     int ah6 = hh[6];
/* 2598 */     int ah7 = hh[7];
/*      */     
/* 2600 */     int al0 = hl[0];
/* 2601 */     int al1 = hl[1];
/* 2602 */     int al2 = hl[2];
/* 2603 */     int al3 = hl[3];
/* 2604 */     int al4 = hl[4];
/* 2605 */     int al5 = hl[5];
/* 2606 */     int al6 = hl[6];
/* 2607 */     int al7 = hl[7];
/*      */     
/* 2609 */     int pos = 0;
/* 2610 */     while (n >= 128) {
/* 2611 */       int i; for (i = 0; i < 16; i++) {
/* 2612 */         int j = 8 * i + pos;
/* 2613 */         wh[i] = (m[j + 0 + moff] & 0xFF) << 24 | (m[j + 1 + moff] & 0xFF) << 16 | (m[j + 2 + moff] & 0xFF) << 8 | (m[j + 3 + moff] & 0xFF) << 0;
/* 2614 */         wl[i] = (m[j + 4 + moff] & 0xFF) << 24 | (m[j + 5 + moff] & 0xFF) << 16 | (m[j + 6 + moff] & 0xFF) << 8 | (m[j + 7 + moff] & 0xFF) << 0;
/*      */       } 
/* 2616 */       for (i = 0; i < 80; i++) {
/* 2617 */         int bh0 = ah0;
/* 2618 */         int bh1 = ah1;
/* 2619 */         int bh2 = ah2;
/* 2620 */         int bh3 = ah3;
/* 2621 */         int bh4 = ah4;
/* 2622 */         int bh5 = ah5;
/* 2623 */         int bh6 = ah6;
/* 2624 */         int bh7 = ah7;
/*      */         
/* 2626 */         int bl0 = al0;
/* 2627 */         int bl1 = al1;
/* 2628 */         int bl2 = al2;
/* 2629 */         int bl3 = al3;
/* 2630 */         int bl4 = al4;
/* 2631 */         int bl5 = al5;
/* 2632 */         int bl6 = al6;
/* 2633 */         int bl7 = al7;
/*      */ 
/*      */         
/* 2636 */         int j = ah7;
/* 2637 */         int k = al7;
/*      */         
/* 2639 */         int i1 = k & 0xFFFF, i2 = k >>> 16;
/* 2640 */         int i3 = j & 0xFFFF, i4 = j >>> 16;
/*      */ 
/*      */         
/* 2643 */         j = (ah4 >>> 14 | al4 << 18) ^ (ah4 >>> 18 | al4 << 14) ^ (al4 >>> 9 | ah4 << 23);
/* 2644 */         k = (al4 >>> 14 | ah4 << 18) ^ (al4 >>> 18 | ah4 << 14) ^ (ah4 >>> 9 | al4 << 23);
/*      */         
/* 2646 */         i1 += k & 0xFFFF; i2 += k >>> 16;
/* 2647 */         i3 += j & 0xFFFF; i4 += j >>> 16;
/*      */ 
/*      */         
/* 2650 */         j = ah4 & ah5 ^ (ah4 ^ 0xFFFFFFFF) & ah6;
/* 2651 */         k = al4 & al5 ^ (al4 ^ 0xFFFFFFFF) & al6;
/*      */         
/* 2653 */         i1 += k & 0xFFFF; i2 += k >>> 16;
/* 2654 */         i3 += j & 0xFFFF; i4 += j >>> 16;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2659 */         j = (int)(K[i] >>> 32L & 0xFFFFFFFFFFFFFFFFL);
/* 2660 */         k = (int)(K[i] >>> 0L & 0xFFFFFFFFFFFFFFFFL);
/*      */ 
/*      */ 
/*      */         
/* 2664 */         i1 += k & 0xFFFF; i2 += k >>> 16;
/* 2665 */         i3 += j & 0xFFFF; i4 += j >>> 16;
/*      */ 
/*      */         
/* 2668 */         j = wh[i % 16];
/* 2669 */         k = wl[i % 16];
/*      */         
/* 2671 */         i1 += k & 0xFFFF; i2 += k >>> 16;
/* 2672 */         i3 += j & 0xFFFF; i4 += j >>> 16;
/*      */         
/* 2674 */         i2 += i1 >>> 16;
/* 2675 */         i3 += i2 >>> 16;
/* 2676 */         i4 += i3 >>> 16;
/*      */         
/* 2678 */         int th = i3 & 0xFFFF | i4 << 16;
/* 2679 */         int tl = i1 & 0xFFFF | i2 << 16;
/*      */ 
/*      */         
/* 2682 */         j = th;
/* 2683 */         k = tl;
/*      */         
/* 2685 */         i1 = k & 0xFFFF; i2 = k >>> 16;
/* 2686 */         i3 = j & 0xFFFF; i4 = j >>> 16;
/*      */ 
/*      */         
/* 2689 */         j = (ah0 >>> 28 | al0 << 4) ^ (al0 >>> 2 | ah0 << 30) ^ (al0 >>> 7 | ah0 << 25);
/* 2690 */         k = (al0 >>> 28 | ah0 << 4) ^ (ah0 >>> 2 | al0 << 30) ^ (ah0 >>> 7 | al0 << 25);
/*      */         
/* 2692 */         i1 += k & 0xFFFF; i2 += k >>> 16;
/* 2693 */         i3 += j & 0xFFFF; i4 += j >>> 16;
/*      */ 
/*      */         
/* 2696 */         j = ah0 & ah1 ^ ah0 & ah2 ^ ah1 & ah2;
/* 2697 */         k = al0 & al1 ^ al0 & al2 ^ al1 & al2;
/*      */         
/* 2699 */         i1 += k & 0xFFFF; i2 += k >>> 16;
/* 2700 */         i3 += j & 0xFFFF; i4 += j >>> 16;
/*      */         
/* 2702 */         i2 += i1 >>> 16;
/* 2703 */         i3 += i2 >>> 16;
/* 2704 */         i4 += i3 >>> 16;
/*      */         
/* 2706 */         bh7 = i3 & 0xFFFF | i4 << 16;
/* 2707 */         bl7 = i1 & 0xFFFF | i2 << 16;
/*      */ 
/*      */         
/* 2710 */         j = bh3;
/* 2711 */         k = bl3;
/*      */         
/* 2713 */         i1 = k & 0xFFFF; i2 = k >>> 16;
/* 2714 */         i3 = j & 0xFFFF; i4 = j >>> 16;
/*      */         
/* 2716 */         j = th;
/* 2717 */         k = tl;
/*      */         
/* 2719 */         i1 += k & 0xFFFF; i2 += k >>> 16;
/* 2720 */         i3 += j & 0xFFFF; i4 += j >>> 16;
/*      */         
/* 2722 */         i2 += i1 >>> 16;
/* 2723 */         i3 += i2 >>> 16;
/* 2724 */         i4 += i3 >>> 16;
/*      */         
/* 2726 */         bh3 = i3 & 0xFFFF | i4 << 16;
/* 2727 */         bl3 = i1 & 0xFFFF | i2 << 16;
/*      */         
/* 2729 */         ah1 = bh0;
/* 2730 */         ah2 = bh1;
/* 2731 */         ah3 = bh2;
/* 2732 */         ah4 = bh3;
/* 2733 */         ah5 = bh4;
/* 2734 */         ah6 = bh5;
/* 2735 */         ah7 = bh6;
/* 2736 */         ah0 = bh7;
/*      */         
/* 2738 */         al1 = bl0;
/* 2739 */         al2 = bl1;
/* 2740 */         al3 = bl2;
/* 2741 */         al4 = bl3;
/* 2742 */         al5 = bl4;
/* 2743 */         al6 = bl5;
/* 2744 */         al7 = bl6;
/* 2745 */         al0 = bl7;
/*      */         
/* 2747 */         if (i % 16 == 15) {
/* 2748 */           for (int i5 = 0; i5 < 16; i5++) {
/*      */             
/* 2750 */             j = wh[i5];
/* 2751 */             k = wl[i5];
/*      */             
/* 2753 */             i1 = k & 0xFFFF; i2 = k >>> 16;
/* 2754 */             i3 = j & 0xFFFF; i4 = j >>> 16;
/*      */             
/* 2756 */             j = wh[(i5 + 9) % 16];
/* 2757 */             k = wl[(i5 + 9) % 16];
/*      */             
/* 2759 */             i1 += k & 0xFFFF; i2 += k >>> 16;
/* 2760 */             i3 += j & 0xFFFF; i4 += j >>> 16;
/*      */ 
/*      */             
/* 2763 */             th = wh[(i5 + 1) % 16];
/* 2764 */             tl = wl[(i5 + 1) % 16];
/* 2765 */             j = (th >>> 1 | tl << 31) ^ (th >>> 8 | tl << 24) ^ th >>> 7;
/* 2766 */             k = (tl >>> 1 | th << 31) ^ (tl >>> 8 | th << 24) ^ (tl >>> 7 | th << 25);
/*      */             
/* 2768 */             i1 += k & 0xFFFF; i2 += k >>> 16;
/* 2769 */             i3 += j & 0xFFFF; i4 += j >>> 16;
/*      */ 
/*      */             
/* 2772 */             th = wh[(i5 + 14) % 16];
/* 2773 */             tl = wl[(i5 + 14) % 16];
/* 2774 */             j = (th >>> 19 | tl << 13) ^ (tl >>> 29 | th << 3) ^ th >>> 6;
/* 2775 */             k = (tl >>> 19 | th << 13) ^ (th >>> 29 | tl << 3) ^ (tl >>> 6 | th << 26);
/*      */             
/* 2777 */             i1 += k & 0xFFFF; i2 += k >>> 16;
/* 2778 */             i3 += j & 0xFFFF; i4 += j >>> 16;
/*      */             
/* 2780 */             i2 += i1 >>> 16;
/* 2781 */             i3 += i2 >>> 16;
/* 2782 */             i4 += i3 >>> 16;
/*      */             
/* 2784 */             wh[i5] = i3 & 0xFFFF | i4 << 16;
/* 2785 */             wl[i5] = i1 & 0xFFFF | i2 << 16;
/*      */           } 
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/* 2791 */       int h = ah0;
/* 2792 */       int l = al0;
/*      */       
/* 2794 */       int a = l & 0xFFFF, b = l >>> 16;
/* 2795 */       int c = h & 0xFFFF, d = h >>> 16;
/*      */       
/* 2797 */       h = hh[0];
/* 2798 */       l = hl[0];
/*      */       
/* 2800 */       a += l & 0xFFFF; b += l >>> 16;
/* 2801 */       c += h & 0xFFFF; d += h >>> 16;
/*      */       
/* 2803 */       b += a >>> 16;
/* 2804 */       c += b >>> 16;
/* 2805 */       d += c >>> 16;
/*      */       
/* 2807 */       hh[0] = ah0 = c & 0xFFFF | d << 16;
/* 2808 */       hl[0] = al0 = a & 0xFFFF | b << 16;
/*      */       
/* 2810 */       h = ah1;
/* 2811 */       l = al1;
/*      */       
/* 2813 */       a = l & 0xFFFF; b = l >>> 16;
/* 2814 */       c = h & 0xFFFF; d = h >>> 16;
/*      */       
/* 2816 */       h = hh[1];
/* 2817 */       l = hl[1];
/*      */       
/* 2819 */       a += l & 0xFFFF; b += l >>> 16;
/* 2820 */       c += h & 0xFFFF; d += h >>> 16;
/*      */       
/* 2822 */       b += a >>> 16;
/* 2823 */       c += b >>> 16;
/* 2824 */       d += c >>> 16;
/*      */       
/* 2826 */       hh[1] = ah1 = c & 0xFFFF | d << 16;
/* 2827 */       hl[1] = al1 = a & 0xFFFF | b << 16;
/*      */       
/* 2829 */       h = ah2;
/* 2830 */       l = al2;
/*      */       
/* 2832 */       a = l & 0xFFFF; b = l >>> 16;
/* 2833 */       c = h & 0xFFFF; d = h >>> 16;
/*      */       
/* 2835 */       h = hh[2];
/* 2836 */       l = hl[2];
/*      */       
/* 2838 */       a += l & 0xFFFF; b += l >>> 16;
/* 2839 */       c += h & 0xFFFF; d += h >>> 16;
/*      */       
/* 2841 */       b += a >>> 16;
/* 2842 */       c += b >>> 16;
/* 2843 */       d += c >>> 16;
/*      */       
/* 2845 */       hh[2] = ah2 = c & 0xFFFF | d << 16;
/* 2846 */       hl[2] = al2 = a & 0xFFFF | b << 16;
/*      */       
/* 2848 */       h = ah3;
/* 2849 */       l = al3;
/*      */       
/* 2851 */       a = l & 0xFFFF; b = l >>> 16;
/* 2852 */       c = h & 0xFFFF; d = h >>> 16;
/*      */       
/* 2854 */       h = hh[3];
/* 2855 */       l = hl[3];
/*      */       
/* 2857 */       a += l & 0xFFFF; b += l >>> 16;
/* 2858 */       c += h & 0xFFFF; d += h >>> 16;
/*      */       
/* 2860 */       b += a >>> 16;
/* 2861 */       c += b >>> 16;
/* 2862 */       d += c >>> 16;
/*      */       
/* 2864 */       hh[3] = ah3 = c & 0xFFFF | d << 16;
/* 2865 */       hl[3] = al3 = a & 0xFFFF | b << 16;
/*      */       
/* 2867 */       h = ah4;
/* 2868 */       l = al4;
/*      */       
/* 2870 */       a = l & 0xFFFF; b = l >>> 16;
/* 2871 */       c = h & 0xFFFF; d = h >>> 16;
/*      */       
/* 2873 */       h = hh[4];
/* 2874 */       l = hl[4];
/*      */       
/* 2876 */       a += l & 0xFFFF; b += l >>> 16;
/* 2877 */       c += h & 0xFFFF; d += h >>> 16;
/*      */       
/* 2879 */       b += a >>> 16;
/* 2880 */       c += b >>> 16;
/* 2881 */       d += c >>> 16;
/*      */       
/* 2883 */       hh[4] = ah4 = c & 0xFFFF | d << 16;
/* 2884 */       hl[4] = al4 = a & 0xFFFF | b << 16;
/*      */       
/* 2886 */       h = ah5;
/* 2887 */       l = al5;
/*      */       
/* 2889 */       a = l & 0xFFFF; b = l >>> 16;
/* 2890 */       c = h & 0xFFFF; d = h >>> 16;
/*      */       
/* 2892 */       h = hh[5];
/* 2893 */       l = hl[5];
/*      */       
/* 2895 */       a += l & 0xFFFF; b += l >>> 16;
/* 2896 */       c += h & 0xFFFF; d += h >>> 16;
/*      */       
/* 2898 */       b += a >>> 16;
/* 2899 */       c += b >>> 16;
/* 2900 */       d += c >>> 16;
/*      */       
/* 2902 */       hh[5] = ah5 = c & 0xFFFF | d << 16;
/* 2903 */       hl[5] = al5 = a & 0xFFFF | b << 16;
/*      */       
/* 2905 */       h = ah6;
/* 2906 */       l = al6;
/*      */       
/* 2908 */       a = l & 0xFFFF; b = l >>> 16;
/* 2909 */       c = h & 0xFFFF; d = h >>> 16;
/*      */       
/* 2911 */       h = hh[6];
/* 2912 */       l = hl[6];
/*      */       
/* 2914 */       a += l & 0xFFFF; b += l >>> 16;
/* 2915 */       c += h & 0xFFFF; d += h >>> 16;
/*      */       
/* 2917 */       b += a >>> 16;
/* 2918 */       c += b >>> 16;
/* 2919 */       d += c >>> 16;
/*      */       
/* 2921 */       hh[6] = ah6 = c & 0xFFFF | d << 16;
/* 2922 */       hl[6] = al6 = a & 0xFFFF | b << 16;
/*      */       
/* 2924 */       h = ah7;
/* 2925 */       l = al7;
/*      */       
/* 2927 */       a = l & 0xFFFF; b = l >>> 16;
/* 2928 */       c = h & 0xFFFF; d = h >>> 16;
/*      */       
/* 2930 */       h = hh[7];
/* 2931 */       l = hl[7];
/*      */       
/* 2933 */       a += l & 0xFFFF; b += l >>> 16;
/* 2934 */       c += h & 0xFFFF; d += h >>> 16;
/*      */       
/* 2936 */       b += a >>> 16;
/* 2937 */       c += b >>> 16;
/* 2938 */       d += c >>> 16;
/*      */       
/* 2940 */       hh[7] = ah7 = c & 0xFFFF | d << 16;
/* 2941 */       hl[7] = al7 = a & 0xFFFF | b << 16;
/*      */       
/* 2943 */       pos += 128;
/* 2944 */       n -= 128;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2955 */     return n;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int crypto_hash(byte[] out, byte[] m, int moff, int n) {
/* 2962 */     int[] hh = new int[8];
/* 2963 */     int[] hl = new int[8];
/* 2964 */     byte[] x = new byte[256];
/* 2965 */     int b = n;
/*      */ 
/*      */     
/* 2968 */     hh[0] = 1779033703;
/* 2969 */     hh[1] = -1150833019;
/* 2970 */     hh[2] = 1013904242;
/* 2971 */     hh[3] = -1521486534;
/* 2972 */     hh[4] = 1359893119;
/* 2973 */     hh[5] = -1694144372;
/* 2974 */     hh[6] = 528734635;
/* 2975 */     hh[7] = 1541459225;
/*      */     
/* 2977 */     hl[0] = -205731576;
/* 2978 */     hl[1] = -2067093701;
/* 2979 */     hl[2] = -23791573;
/* 2980 */     hl[3] = 1595750129;
/* 2981 */     hl[4] = -1377402159;
/* 2982 */     hl[5] = 725511199;
/* 2983 */     hl[6] = -79577749;
/* 2984 */     hl[7] = 327033209;
/*      */     
/* 2986 */     if (n >= 128) {
/* 2987 */       crypto_hashblocks_hl(hh, hl, m, moff, n);
/* 2988 */       n %= 128;
/*      */     } 
/*      */     int i;
/* 2991 */     for (i = 0; i < n; ) { x[i] = m[b - n + i + moff]; i++; }
/* 2992 */      x[n] = Byte.MIN_VALUE;
/*      */     
/* 2994 */     n = 256 - 128 * ((n < 112) ? 1 : 0);
/* 2995 */     x[n - 9] = 0;
/*      */     
/* 2997 */     ts64(x, n - 8, (b << 3));
/*      */     
/* 2999 */     crypto_hashblocks_hl(hh, hl, x, 0, n);
/*      */     
/* 3001 */     for (i = 0; i < 8; i++) {
/* 3002 */       long u = hh[i]; u <<= 32L; u |= hl[i] & 0xFFFFFFFFL;
/* 3003 */       ts64(out, 8 * i, u);
/*      */     } 
/*      */     
/* 3006 */     return 0;
/*      */   }
/*      */   public static int crypto_hash(byte[] out, byte[] m) {
/* 3009 */     return crypto_hash(out, m, 0, (m != null) ? m.length : 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void add(long[][] p, long[][] q) {
/* 3016 */     long[] a = new long[16];
/* 3017 */     long[] b = new long[16];
/* 3018 */     long[] c = new long[16];
/* 3019 */     long[] d = new long[16];
/* 3020 */     long[] t = new long[16];
/* 3021 */     long[] e = new long[16];
/* 3022 */     long[] f = new long[16];
/* 3023 */     long[] g = new long[16];
/* 3024 */     long[] h = new long[16];
/*      */ 
/*      */     
/* 3027 */     long[] p0 = p[0];
/* 3028 */     long[] p1 = p[1];
/* 3029 */     long[] p2 = p[2];
/* 3030 */     long[] p3 = p[3];
/*      */     
/* 3032 */     long[] q0 = q[0];
/* 3033 */     long[] q1 = q[1];
/* 3034 */     long[] q2 = q[2];
/* 3035 */     long[] q3 = q[3];
/*      */     
/* 3037 */     Z(a, 0, p1, 0, p0, 0);
/* 3038 */     Z(t, 0, q1, 0, q0, 0);
/* 3039 */     M(a, 0, a, 0, t, 0);
/* 3040 */     A(b, 0, p0, 0, p1, 0);
/* 3041 */     A(t, 0, q0, 0, q1, 0);
/* 3042 */     M(b, 0, b, 0, t, 0);
/* 3043 */     M(c, 0, p3, 0, q3, 0);
/* 3044 */     M(c, 0, c, 0, D2, 0);
/* 3045 */     M(d, 0, p2, 0, q2, 0);
/*      */     
/* 3047 */     A(d, 0, d, 0, d, 0);
/* 3048 */     Z(e, 0, b, 0, a, 0);
/* 3049 */     Z(f, 0, d, 0, c, 0);
/* 3050 */     A(g, 0, d, 0, c, 0);
/* 3051 */     A(h, 0, b, 0, a, 0);
/*      */     
/* 3053 */     M(p0, 0, e, 0, f, 0);
/* 3054 */     M(p1, 0, h, 0, g, 0);
/* 3055 */     M(p2, 0, g, 0, f, 0);
/* 3056 */     M(p3, 0, e, 0, h, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void cswap(long[][] p, long[][] q, byte b) {
/* 3063 */     for (int i = 0; i < 4; i++) {
/* 3064 */       sel25519(p[i], 0, q[i], 0, b);
/*      */     }
/*      */   }
/*      */   
/*      */   private static void pack(byte[] r, long[][] p) {
/* 3069 */     long[] tx = new long[16];
/* 3070 */     long[] ty = new long[16];
/* 3071 */     long[] zi = new long[16];
/*      */     
/* 3073 */     inv25519(zi, 0, p[2], 0);
/*      */     
/* 3075 */     M(tx, 0, p[0], 0, zi, 0);
/* 3076 */     M(ty, 0, p[1], 0, zi, 0);
/*      */     
/* 3078 */     pack25519(r, ty, 0);
/*      */     
/* 3080 */     r[31] = (byte)(r[31] ^ par25519(tx, 0) << 7);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void scalarmult(long[][] p, long[][] q, byte[] s, int soff) {
/* 3087 */     set25519(p[0], gf0);
/* 3088 */     set25519(p[1], gf1);
/* 3089 */     set25519(p[2], gf1);
/* 3090 */     set25519(p[3], gf0);
/*      */     
/* 3092 */     for (int i = 255; i >= 0; i--) {
/* 3093 */       byte b = (byte)(s[i / 8 + soff] >>> (i & 0x7) & 0x1);
/*      */       
/* 3095 */       cswap(p, q, b);
/* 3096 */       add(q, p);
/* 3097 */       add(p, p);
/* 3098 */       cswap(p, q, b);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void scalarbase(long[][] p, byte[] s, int soff) {
/* 3108 */     long[][] q = new long[4][];
/*      */     
/* 3110 */     q[0] = new long[16];
/* 3111 */     q[1] = new long[16];
/* 3112 */     q[2] = new long[16];
/* 3113 */     q[3] = new long[16];
/*      */     
/* 3115 */     set25519(q[0], X);
/* 3116 */     set25519(q[1], Y);
/* 3117 */     set25519(q[2], gf1);
/* 3118 */     M(q[3], 0, X, 0, Y, 0);
/* 3119 */     scalarmult(p, q, s, soff);
/*      */   }
/*      */   
/*      */   public static int crypto_sign_keypair(byte[] pk, byte[] sk, boolean seeded) {
/* 3123 */     byte[] d = new byte[64];
/* 3124 */     long[][] p = new long[4][];
/*      */     
/* 3126 */     p[0] = new long[16];
/* 3127 */     p[1] = new long[16];
/* 3128 */     p[2] = new long[16];
/* 3129 */     p[3] = new long[16];
/*      */ 
/*      */ 
/*      */     
/* 3133 */     if (!seeded) randombytes(sk, 32); 
/* 3134 */     crypto_hash(d, sk, 0, 32);
/* 3135 */     d[0] = (byte)(d[0] & 0xF8);
/* 3136 */     d[31] = (byte)(d[31] & Byte.MAX_VALUE);
/* 3137 */     d[31] = (byte)(d[31] | 0x40);
/*      */     
/* 3139 */     scalarbase(p, d, 0);
/* 3140 */     pack(pk, p);
/*      */     
/* 3142 */     for (int i = 0; i < 32; ) { sk[i + 32] = pk[i]; i++; }
/* 3143 */      return 0;
/*      */   }
/*      */   
/* 3146 */   private static final long[] L = new long[] { 237L, 211L, 245L, 92L, 26L, 99L, 18L, 88L, 214L, 156L, 247L, 162L, 222L, 249L, 222L, 20L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 16L };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void modL(byte[] r, int roff, long[] x) {
/*      */     int i;
/* 3158 */     for (i = 63; i >= 32; i--) {
/* 3159 */       long l = 0L; int k;
/* 3160 */       for (k = i - 32; k < i - 12; k++) {
/* 3161 */         x[k] = x[k] + l - 16L * x[i] * L[k - i - 32];
/* 3162 */         l = x[k] + 128L >> 8L;
/* 3163 */         x[k] = x[k] - (l << 8L);
/*      */       } 
/* 3165 */       x[k] = x[k] + l;
/* 3166 */       x[i] = 0L;
/*      */     } 
/* 3168 */     long carry = 0L;
/*      */     int j;
/* 3170 */     for (j = 0; j < 32; j++) {
/* 3171 */       x[j] = x[j] + carry - (x[31] >> 4L) * L[j];
/* 3172 */       carry = x[j] >> 8L;
/* 3173 */       x[j] = x[j] & 0xFFL;
/*      */     } 
/*      */     
/* 3176 */     for (j = 0; j < 32; ) { x[j] = x[j] - carry * L[j]; j++; }
/*      */     
/* 3178 */     for (i = 0; i < 32; i++) {
/* 3179 */       x[i + 1] = x[i + 1] + (x[i] >> 8L);
/* 3180 */       r[i + roff] = (byte)(int)(x[i] & 0xFFL);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private static void reduce(byte[] r) {
/* 3186 */     long[] x = new long[64];
/*      */     
/*      */     int i;
/* 3189 */     for (i = 0; i < 64; ) { x[i] = (r[i] & 0xFF); i++; }
/*      */     
/* 3191 */     for (i = 0; i < 64; ) { r[i] = 0; i++; }
/*      */     
/* 3193 */     modL(r, 0, x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int crypto_sign(byte[] sm, long dummy, byte[] m, int moff, int n, byte[] sk) {
/* 3200 */     byte[] d = new byte[64], h = new byte[64], r = new byte[64];
/*      */ 
/*      */     
/* 3203 */     long[] x = new long[64];
/*      */     
/* 3205 */     long[][] p = new long[4][];
/* 3206 */     p[0] = new long[16];
/* 3207 */     p[1] = new long[16];
/* 3208 */     p[2] = new long[16];
/* 3209 */     p[3] = new long[16];
/*      */     
/* 3211 */     crypto_hash(d, sk, 0, 32);
/* 3212 */     d[0] = (byte)(d[0] & 0xF8);
/* 3213 */     d[31] = (byte)(d[31] & Byte.MAX_VALUE);
/* 3214 */     d[31] = (byte)(d[31] | 0x40);
/*      */     
/*      */     int i;
/*      */     
/* 3218 */     for (i = 0; i < n; ) { sm[64 + i] = m[i + moff]; i++; }
/*      */     
/* 3220 */     for (i = 0; i < 32; ) { sm[32 + i] = d[32 + i]; i++; }
/*      */     
/* 3222 */     crypto_hash(r, sm, 32, n + 32);
/* 3223 */     reduce(r);
/* 3224 */     scalarbase(p, r, 0);
/* 3225 */     pack(sm, p);
/*      */     
/* 3227 */     for (i = 0; i < 32; ) { sm[i + 32] = sk[i + 32]; i++; }
/* 3228 */      crypto_hash(h, sm, 0, n + 64);
/* 3229 */     reduce(h);
/*      */     
/* 3231 */     for (i = 0; i < 64; ) { x[i] = 0L; i++; }
/*      */     
/* 3233 */     for (i = 0; i < 32; ) { x[i] = (r[i] & 0xFF); i++; }
/*      */     
/* 3235 */     for (i = 0; i < 32; ) { for (int j = 0; j < 32; ) { x[i + j] = x[i + j] + (h[i] & 0xFF) * (d[j] & 0xFF); j++; }  i++; }
/*      */     
/* 3237 */     modL(sm, 32, x);
/*      */     
/* 3239 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   private static int unpackneg(long[][] r, byte[] p) {
/* 3244 */     long[] t = new long[16];
/* 3245 */     long[] chk = new long[16];
/* 3246 */     long[] num = new long[16];
/* 3247 */     long[] den = new long[16];
/* 3248 */     long[] den2 = new long[16];
/* 3249 */     long[] den4 = new long[16];
/* 3250 */     long[] den6 = new long[16];
/*      */     
/* 3252 */     set25519(r[2], gf1);
/* 3253 */     unpack25519(r[1], p);
/* 3254 */     S(num, r[1]);
/* 3255 */     M(den, num, D);
/* 3256 */     Z(num, num, r[2]);
/* 3257 */     A(den, r[2], den);
/*      */     
/* 3259 */     S(den2, den);
/* 3260 */     S(den4, den2);
/* 3261 */     M(den6, den4, den2);
/* 3262 */     M(t, den6, num);
/* 3263 */     M(t, t, den);
/*      */     
/* 3265 */     pow2523(t, t);
/* 3266 */     M(t, t, num);
/* 3267 */     M(t, t, den);
/* 3268 */     M(t, t, den);
/* 3269 */     M(r[0], t, den);
/*      */     
/* 3271 */     S(chk, r[0]);
/* 3272 */     M(chk, chk, den);
/* 3273 */     if (neq25519(chk, num) != 0) M(r[0], r[0], I);
/*      */     
/* 3275 */     S(chk, r[0]);
/* 3276 */     M(chk, chk, den);
/* 3277 */     if (neq25519(chk, num) != 0) return -1;
/*      */     
/* 3279 */     if (par25519(r[0]) == (p[31] & 0xFF) >>> 7) Z(r[0], gf0, r[0]);
/*      */     
/* 3281 */     M(r[3], r[0], r[1]);
/*      */     
/* 3283 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int crypto_sign_open(byte[] m, long dummy, byte[] sm, int smoff, int n, byte[] pk) {
/* 3291 */     byte[] t = new byte[32], h = new byte[64];
/*      */     
/* 3293 */     long[][] p = new long[4][];
/* 3294 */     p[0] = new long[16];
/* 3295 */     p[1] = new long[16];
/* 3296 */     p[2] = new long[16];
/* 3297 */     p[3] = new long[16];
/*      */     
/* 3299 */     long[][] q = new long[4][];
/* 3300 */     q[0] = new long[16];
/* 3301 */     q[1] = new long[16];
/* 3302 */     q[2] = new long[16];
/* 3303 */     q[3] = new long[16];
/*      */ 
/*      */ 
/*      */     
/* 3307 */     if (n < 64) return -1;
/*      */     
/* 3309 */     if (unpackneg(q, pk) != 0) return -1; 
/*      */     int i;
/* 3311 */     for (i = 0; i < n; ) { m[i] = sm[i + smoff]; i++; }
/*      */     
/* 3313 */     for (i = 0; i < 32; ) { m[i + 32] = pk[i]; i++; }
/*      */     
/* 3315 */     crypto_hash(h, m, 0, n);
/*      */     
/* 3317 */     reduce(h);
/* 3318 */     scalarmult(p, q, h, 0);
/*      */     
/* 3320 */     scalarbase(q, sm, 32 + smoff);
/* 3321 */     add(p, q);
/* 3322 */     pack(t, p);
/*      */     
/* 3324 */     n -= 64;
/* 3325 */     if (crypto_verify_32(sm, smoff, t, 0) != 0)
/*      */     {
/*      */       
/* 3328 */       return -1;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3335 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3342 */   private static final SecureRandom jrandom = new SecureRandom();
/*      */   
/*      */   public static byte[] randombytes(byte[] x) {
/* 3345 */     jrandom.nextBytes(x);
/* 3346 */     return x;
/*      */   }
/*      */   
/*      */   public static byte[] randombytes(int len) {
/* 3350 */     return randombytes(new byte[len]);
/*      */   }
/*      */   
/*      */   public static byte[] randombytes(byte[] x, int len) {
/* 3354 */     byte[] b = randombytes(len);
/* 3355 */     System.arraycopy(b, 0, x, 0, len);
/* 3356 */     return x;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] makeBoxNonce() {
/* 3387 */     return randombytes(24);
/*      */   }
/*      */   
/*      */   public static byte[] makeSecretBoxNonce() {
/* 3391 */     return randombytes(24);
/*      */   }
/*      */   
/*      */   public static String hexEncodeToString(byte[] raw) {
/* 3395 */     String HEXES = "0123456789ABCDEF";
/* 3396 */     StringBuilder hex = new StringBuilder(2 * raw.length);
/* 3397 */     for (byte b : raw) {
/* 3398 */       hex.append(HEXES.charAt((b & 0xF0) >> 4))
/* 3399 */         .append(HEXES.charAt(b & 0xF));
/*      */     }
/* 3401 */     return hex.toString();
/*      */   }
/*      */   
/*      */   public static byte[] hexDecode(String s) {
/* 3405 */     byte[] b = new byte[s.length() / 2];
/* 3406 */     for (int i = 0; i < s.length(); i += 2) {
/* 3407 */       b[i / 2] = 
/* 3408 */         (byte)((Character.digit(s.charAt(i), 16) << 4) + Character.digit(s.charAt(i + 1), 16));
/*      */     }
/* 3410 */     return b;
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\com\iwebpp\crypto\TweetNaclFast.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */