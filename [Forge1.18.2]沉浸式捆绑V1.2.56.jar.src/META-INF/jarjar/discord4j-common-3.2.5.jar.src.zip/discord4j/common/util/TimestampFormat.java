/*    */ package discord4j.common.util;
/*    */ 
/*    */ import java.time.Instant;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum TimestampFormat
/*    */ {
/* 30 */   DEFAULT(""),
/*    */ 
/*    */ 
/*    */   
/* 34 */   SHORT_TIME("t"),
/*    */ 
/*    */ 
/*    */   
/* 38 */   LONG_TIME("T"),
/*    */ 
/*    */ 
/*    */   
/* 42 */   SHORT_DATE("d"),
/*    */ 
/*    */ 
/*    */   
/* 46 */   LONG_DATE("D"),
/*    */ 
/*    */ 
/*    */   
/* 50 */   SHORT_DATE_TIME("f"),
/*    */ 
/*    */ 
/*    */   
/* 54 */   LONG_DATE_TIME("F"),
/*    */ 
/*    */ 
/*    */   
/* 58 */   RELATIVE_TIME("R");
/*    */   
/*    */   private final String style;
/*    */   
/*    */   TimestampFormat(String style) {
/* 63 */     this.style = style;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getStyle() {
/* 71 */     return this.style;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String format(Instant instant) {
/* 82 */     if (this.style.isEmpty()) {
/* 83 */       return "<t:" + instant.getEpochSecond() + ">";
/*    */     }
/* 85 */     return "<t:" + instant.getEpochSecond() + ":" + this.style + ">";
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\commo\\util\TimestampFormat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */