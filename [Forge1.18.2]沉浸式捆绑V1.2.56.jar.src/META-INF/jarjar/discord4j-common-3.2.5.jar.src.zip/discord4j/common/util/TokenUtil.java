/*    */ package discord4j.common.util;
/*    */ 
/*    */ import java.nio.charset.StandardCharsets;
/*    */ import java.util.Base64;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class TokenUtil
/*    */ {
/*    */   public static long getSelfId(String token) {
/*    */     try {
/* 32 */       return Long.parseLong(new String(Base64.getDecoder()
/* 33 */             .decode(token.split("\\.")[0]), StandardCharsets.UTF_8));
/* 34 */     } catch (IllegalArgumentException e) {
/* 35 */       throw new IllegalArgumentException("Invalid token, make sure you're using the token from the developer portal Bot section and not the application client secret or public key.", e);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\commo\\util\TokenUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */