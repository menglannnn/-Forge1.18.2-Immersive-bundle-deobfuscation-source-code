/*     */ package discord4j.common.operator;
/*     */ 
/*     */ import discord4j.common.sinks.EmissionStrategy;
/*     */ import java.time.Duration;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscription;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.publisher.Sinks;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ import reactor.core.scheduler.Schedulers;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RateLimitOperator<T>
/*     */   implements Function<Publisher<T>, Publisher<T>>
/*     */ {
/*  41 */   private static final Logger log = Loggers.getLogger("discord4j.limiter");
/*     */   
/*     */   private static final Supplier<Scheduler> DEFAULT_PUBLISH_SCHEDULER = () -> Schedulers.newSingle("d4j-limiter", true);
/*     */   
/*     */   private final AtomicInteger tokens;
/*     */   private final Duration refillPeriod;
/*     */   private final Scheduler delayScheduler;
/*     */   private final Sinks.Many<Integer> tokenSink;
/*     */   private final Scheduler tokenPublishScheduler;
/*     */   private final EmissionStrategy emissionStrategy;
/*     */   
/*     */   public RateLimitOperator(int capacity, Duration refillPeriod, Scheduler delayScheduler) {
/*  53 */     this(capacity, refillPeriod, delayScheduler, DEFAULT_PUBLISH_SCHEDULER.get());
/*     */   }
/*     */   
/*     */   public RateLimitOperator(int capacity, Duration refillPeriod, Scheduler delayScheduler, Scheduler publishScheduler) {
/*  57 */     this.tokens = new AtomicInteger(capacity);
/*  58 */     this.refillPeriod = refillPeriod;
/*  59 */     this.delayScheduler = delayScheduler;
/*  60 */     this.tokenSink = Sinks.many().replay().latestOrDefault(Integer.valueOf(capacity));
/*  61 */     this.tokenPublishScheduler = publishScheduler;
/*  62 */     this.emissionStrategy = EmissionStrategy.park(Duration.ofNanos(10L));
/*     */   }
/*     */   
/*     */   private String id() {
/*  66 */     return Integer.toHexString(hashCode());
/*     */   }
/*     */ 
/*     */   
/*     */   public Publisher<T> apply(Publisher<T> source) {
/*  71 */     return (Publisher<T>)Flux.from(source).flatMap(value -> availableTokens().next().doOnSubscribe(()).map(()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void acquire() {
/*  86 */     int token = this.tokens.decrementAndGet();
/*  87 */     if (log.isTraceEnabled()) {
/*  88 */       log.trace("[{}] Acquired a token, {} tokens remaining", new Object[] { id(), Integer.valueOf(token) });
/*     */     }
/*  90 */     this.emissionStrategy.emitNext(this.tokenSink, Integer.valueOf(token));
/*     */   }
/*     */   
/*     */   private void release() {
/*  94 */     int token = this.tokens.incrementAndGet();
/*  95 */     if (log.isTraceEnabled()) {
/*  96 */       log.trace("[{}] Released a token, {} tokens remaining", new Object[] { id(), Integer.valueOf(token) });
/*     */     }
/*  98 */     this.emissionStrategy.emitNext(this.tokenSink, Integer.valueOf(token));
/*     */   }
/*     */   
/*     */   private Flux<Integer> availableTokens() {
/* 102 */     return this.tokenSink.asFlux().publishOn(this.tokenPublishScheduler).filter(__ -> (this.tokens.get() > 0));
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\operator\RateLimitOperator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */