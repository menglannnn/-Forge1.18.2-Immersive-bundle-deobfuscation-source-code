/*     */ package discord4j.common;
/*     */ 
/*     */ import java.util.Optional;
/*     */ import java.util.function.Function;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.Stream;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.annotation.Nullable;
/*     */ import reactor.util.context.Context;
/*     */ import reactor.util.context.ContextView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LogUtil
/*     */ {
/*     */   public static final String KEY_BUCKET_ID = "discord4j.bucket";
/*     */   public static final String KEY_REQUEST_ID = "discord4j.request";
/*     */   public static final String KEY_GATEWAY_ID = "discord4j.gateway";
/*     */   public static final String KEY_SHARD_ID = "discord4j.shard";
/*     */   public static final String KEY_GUILD_ID = "discord4j.guild";
/*     */   
/*     */   public static String format(ContextView context, String msg) {
/*  57 */     String header = Stream.<Optional>of(new Optional[] { context.getOrEmpty("discord4j.bucket").map(id -> "B:" + id), context.getOrEmpty("discord4j.request").map(id -> "R:" + id), context.getOrEmpty("discord4j.gateway").map(id -> "G:" + id), context.getOrEmpty("discord4j.shard").map(id -> "S:" + id), context.getOrEmpty("discord4j.guild").map(id -> "guildId:" + id) }).map(opt -> (String)opt.orElse("")).filter(str -> !str.isEmpty()).collect(Collectors.joining(", "));
/*  58 */     StringBuilder builder = new StringBuilder();
/*  59 */     if (!header.isEmpty()) {
/*  60 */       return builder.append('[')
/*  61 */         .append(header)
/*  62 */         .append("] ")
/*  63 */         .append(msg)
/*  64 */         .toString();
/*     */     }
/*  66 */     return msg;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String formatValue(@Nullable Object value, int maxLength) {
/*     */     String str;
/*  78 */     if (value == null) {
/*  79 */       return "";
/*     */     }
/*     */     
/*  82 */     if (value instanceof CharSequence) {
/*  83 */       str = String.valueOf(value);
/*     */     } else {
/*     */       try {
/*  86 */         str = value.toString();
/*  87 */       } catch (Throwable ex) {
/*  88 */         str = ex.toString();
/*     */       } 
/*     */     } 
/*  91 */     return (maxLength > 0 && str.length() > maxLength) ? (str.substring(0, maxLength) + "...") : str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void traceDebug(Logger logger, Function<Boolean, String> messageFactory) {
/* 104 */     if (logger.isDebugEnabled()) {
/* 105 */       boolean traceEnabled = logger.isTraceEnabled();
/* 106 */       String logMessage = messageFactory.apply(Boolean.valueOf(traceEnabled));
/* 107 */       if (traceEnabled) {
/* 108 */         logger.trace(logMessage);
/*     */       } else {
/* 110 */         logger.debug(logMessage);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Function<Context, Context> clearContext() {
/* 116 */     return ctx -> ctx.delete("discord4j.bucket").delete("discord4j.request").delete("discord4j.gateway").delete("discord4j.shard").delete("discord4j.guild");
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\LogUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */