/*    */ package discord4j.common.jackson;
/*    */ 
/*    */ import com.fasterxml.jackson.core.JsonParser;
/*    */ import com.fasterxml.jackson.databind.DeserializationContext;
/*    */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*    */ import com.fasterxml.jackson.databind.deser.DeserializationProblemHandler;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnknownPropertyHandler
/*    */   extends DeserializationProblemHandler
/*    */ {
/*    */   private final boolean ignoreUnknown;
/*    */   
/*    */   public UnknownPropertyHandler(boolean ignoreUnknown) {
/* 31 */     this.ignoreUnknown = ignoreUnknown;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean handleUnknownProperty(DeserializationContext ctx, JsonParser parser, JsonDeserializer<?> deser, Object beanOrClass, String propertyName) throws IOException {
/* 37 */     if (!this.ignoreUnknown) {
/* 38 */       return false;
/*    */     }
/* 40 */     parser.skipChildren();
/* 41 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\jackson\UnknownPropertyHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */