/*    */ package discord4j.common;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.util.Properties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GitProperties
/*    */ {
/*    */   public static final String APPLICATION_NAME = "application.name";
/*    */   public static final String APPLICATION_VERSION = "git.build.version";
/*    */   public static final String APPLICATION_URL = "application.url";
/*    */   public static final String GIT_COMMIT_ID_DESCRIBE = "git.commit.id.describe";
/*    */   
/*    */   public static Properties getProperties() {
/* 48 */     Properties properties = new Properties(); 
/* 49 */     try { InputStream inputStream = GitProperties.class.getResourceAsStream("git.properties"); 
/* 50 */       try { if (inputStream != null) {
/* 51 */           properties.load(inputStream);
/*    */         }
/* 53 */         if (inputStream != null) inputStream.close();  } catch (Throwable throwable) { if (inputStream != null) try { inputStream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (IOException iOException) {}
/*    */     
/* 55 */     return properties;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\GitProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */