/*     */ package discord4j.common;
/*     */ 
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.function.Supplier;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ import reactor.core.scheduler.Schedulers;
/*     */ import reactor.netty.http.client.HttpClient;
/*     */ import reactor.netty.resources.ConnectionProvider;
/*     */ import reactor.netty.resources.LoopResources;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReactorResources
/*     */ {
/*  38 */   private static final AtomicInteger ID = new AtomicInteger();
/*     */   
/*     */   public static final Supplier<HttpClient> DEFAULT_HTTP_CLIENT = () -> HttpClient.create().compress(true).followRedirect(true).secure();
/*     */   
/*     */   public static final Supplier<Scheduler> DEFAULT_TIMER_TASK_SCHEDULER = () -> Schedulers.newParallel("d4j-parallel-" + ID.incrementAndGet(), Schedulers.DEFAULT_POOL_SIZE, true);
/*     */   
/*  44 */   public static final Supplier<Scheduler> DEFAULT_BLOCKING_TASK_SCHEDULER = Schedulers::boundedElastic;
/*     */   
/*     */   private final HttpClient httpClient;
/*     */   
/*     */   private final Scheduler timerTaskScheduler;
/*     */   
/*     */   private final Scheduler blockingTaskScheduler;
/*     */ 
/*     */   
/*     */   public ReactorResources() {
/*  54 */     this.httpClient = DEFAULT_HTTP_CLIENT.get();
/*  55 */     this.timerTaskScheduler = DEFAULT_TIMER_TASK_SCHEDULER.get();
/*  56 */     this.blockingTaskScheduler = DEFAULT_BLOCKING_TASK_SCHEDULER.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReactorResources(HttpClient httpClient, Scheduler timerTaskScheduler, Scheduler blockingTaskScheduler) {
/*  67 */     this.httpClient = httpClient;
/*  68 */     this.timerTaskScheduler = timerTaskScheduler;
/*  69 */     this.blockingTaskScheduler = blockingTaskScheduler;
/*     */   }
/*     */   
/*     */   protected ReactorResources(Builder builder) {
/*  73 */     this.httpClient = (builder.httpClient == null) ? DEFAULT_HTTP_CLIENT.get() : builder.httpClient;
/*  74 */     this
/*  75 */       .timerTaskScheduler = (builder.timerTaskScheduler == null) ? DEFAULT_TIMER_TASK_SCHEDULER.get() : builder.timerTaskScheduler;
/*  76 */     this
/*  77 */       .blockingTaskScheduler = (builder.blockingTaskScheduler == null) ? DEFAULT_BLOCKING_TASK_SCHEDULER.get() : builder.blockingTaskScheduler;
/*     */   }
/*     */   
/*     */   public static ReactorResources create() {
/*  81 */     return (new Builder()).build();
/*     */   }
/*     */   
/*     */   public static Builder builder() {
/*  85 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Builder
/*     */   {
/*     */     private HttpClient httpClient;
/*     */ 
/*     */     
/*     */     private Scheduler timerTaskScheduler;
/*     */ 
/*     */     
/*     */     private Scheduler blockingTaskScheduler;
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder httpClient(HttpClient httpClient) {
/* 104 */       this.httpClient = httpClient;
/* 105 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder timerTaskScheduler(Scheduler timerTaskScheduler) {
/* 115 */       this.timerTaskScheduler = timerTaskScheduler;
/* 116 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder blockingTaskScheduler(Scheduler blockingTaskScheduler) {
/* 126 */       this.blockingTaskScheduler = blockingTaskScheduler;
/* 127 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ReactorResources build() {
/* 136 */       return new ReactorResources(this);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpClient getHttpClient() {
/* 147 */     return this.httpClient;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Scheduler getTimerTaskScheduler() {
/* 156 */     return this.timerTaskScheduler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Scheduler getBlockingTaskScheduler() {
/* 165 */     return this.blockingTaskScheduler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static HttpClient newHttpClient(ConnectionProvider provider) {
/* 177 */     return HttpClient.create(provider).compress(true).followRedirect(true).secure();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static HttpClient newHttpClient(ConnectionProvider provider, LoopResources resources) {
/* 190 */     return ((HttpClient)HttpClient.create(provider).runOn(resources)).compress(true).followRedirect(true).secure();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\ReactorResources.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */