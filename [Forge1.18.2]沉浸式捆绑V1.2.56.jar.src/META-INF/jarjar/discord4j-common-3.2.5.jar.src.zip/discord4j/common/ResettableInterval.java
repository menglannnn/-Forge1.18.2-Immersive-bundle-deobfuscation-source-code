/*    */ package discord4j.common;
/*    */ 
/*    */ import java.time.Duration;
/*    */ import java.util.concurrent.locks.LockSupport;
/*    */ import reactor.core.Disposable;
/*    */ import reactor.core.Disposables;
/*    */ import reactor.core.publisher.Flux;
/*    */ import reactor.core.publisher.SignalType;
/*    */ import reactor.core.publisher.Sinks;
/*    */ import reactor.core.scheduler.Scheduler;
/*    */ import reactor.util.concurrent.Queues;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResettableInterval
/*    */   implements Sinks.EmitFailureHandler
/*    */ {
/*    */   private final Scheduler scheduler;
/*    */   private final Disposable.Swap task;
/* 39 */   private final Sinks.Many<Long> sink = Sinks.many().multicast()
/* 40 */     .onBackpressureBuffer(Queues.SMALL_BUFFER_SIZE, false);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ResettableInterval(Scheduler scheduler) {
/* 49 */     this.scheduler = scheduler;
/* 50 */     this.task = Disposables.swap();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void start(Duration delay, Duration period) {
/* 61 */     this.task.update(Flux.interval(delay, period, this.scheduler)
/* 62 */         .subscribe(tick -> this.sink.emitNext(tick, this)));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void stop() {
/* 69 */     if (this.task.get() != null) {
/* 70 */       ((Disposable)this.task.get()).dispose();
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Flux<Long> ticks() {
/* 80 */     return this.sink.asFlux();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean onEmitFailure(SignalType signalType, Sinks.EmitResult result) {
/* 85 */     if (this.task.get() == null) {
/* 86 */       return false;
/*    */     }
/*    */     
/* 89 */     switch (result) {
/*    */       case FAIL_NON_SERIALIZED:
/* 91 */         return true;
/*    */       case FAIL_OVERFLOW:
/* 93 */         LockSupport.parkNanos(10L);
/* 94 */         return true;
/*    */     } 
/* 96 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\ResettableInterval.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */