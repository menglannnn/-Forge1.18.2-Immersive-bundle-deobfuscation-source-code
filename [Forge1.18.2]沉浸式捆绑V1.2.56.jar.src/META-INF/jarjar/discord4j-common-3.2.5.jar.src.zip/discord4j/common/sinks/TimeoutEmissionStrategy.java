/*     */ package discord4j.common.sinks;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.locks.LockSupport;
/*     */ import java.util.function.Supplier;
/*     */ import reactor.core.publisher.Sinks;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class TimeoutEmissionStrategy
/*     */   implements EmissionStrategy
/*     */ {
/*  29 */   private static final Logger log = Loggers.getLogger(TimeoutEmissionStrategy.class);
/*     */   
/*     */   private final long parkNanos;
/*     */   private final long timeoutNanos;
/*     */   private final boolean errorOnTimeout;
/*     */   
/*     */   TimeoutEmissionStrategy(long parkNanos, long timeoutNanos, boolean errorOnTimeout) {
/*  36 */     this.parkNanos = parkNanos;
/*  37 */     this.timeoutNanos = timeoutNanos;
/*  38 */     this.errorOnTimeout = errorOnTimeout;
/*     */   }
/*     */   
/*     */   public <T> boolean emitNext(Sinks.Many<T> sink, T element) {
/*     */     Sinks.EmitResult emission;
/*  43 */     long remaining = 0L;
/*  44 */     if (this.timeoutNanos > 0L) {
/*  45 */       remaining = this.timeoutNanos;
/*     */     }
/*     */     while (true) {
/*  48 */       emission = sink.tryEmitNext(element);
/*  49 */       if (emission.isSuccess()) {
/*  50 */         return true;
/*     */       }
/*  52 */       remaining -= this.parkNanos;
/*  53 */       if (this.timeoutNanos >= 0L && remaining <= 0L) {
/*  54 */         log.debug("Emission timed out at {}: {}", new Object[] { sink.name(), element.toString() });
/*  55 */         if (this.errorOnTimeout) {
/*  56 */           throw new Sinks.EmissionException(emission, "Emission timed out");
/*     */         }
/*  58 */         return false;
/*     */       } 
/*  60 */       switch (emission) {
/*     */         case FAIL_ZERO_SUBSCRIBER:
/*     */         case FAIL_CANCELLED:
/*     */         case FAIL_TERMINATED:
/*  64 */           return false;
/*     */         case FAIL_NON_SERIALIZED:
/*  66 */           LockSupport.parkNanos(this.parkNanos);
/*     */           continue;
/*     */         case FAIL_OVERFLOW:
/*  69 */           log.trace("Emission overflowing at {}: {}", new Object[] { sink.name(), element.toString() });
/*  70 */           LockSupport.parkNanos(this.parkNanos); continue;
/*     */       }  break;
/*     */     } 
/*  73 */     throw new Sinks.EmissionException(emission, "Unknown emitResult value");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> boolean emitComplete(Sinks.Many<T> sink) {
/*  80 */     Objects.requireNonNull(sink); return emitTerminal(sink::tryEmitComplete);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> boolean emitError(Sinks.Many<T> sink, Throwable error) {
/*  85 */     return emitTerminal(() -> sink.tryEmitError(error));
/*     */   }
/*     */   private <T> boolean emitTerminal(Supplier<Sinks.EmitResult> resultSupplier) {
/*     */     Sinks.EmitResult emission;
/*  89 */     long remaining = 0L;
/*  90 */     if (this.timeoutNanos > 0L) {
/*  91 */       remaining = this.timeoutNanos;
/*     */     }
/*     */     while (true) {
/*  94 */       emission = resultSupplier.get();
/*  95 */       if (emission.isSuccess()) {
/*  96 */         return true;
/*     */       }
/*  98 */       remaining -= this.parkNanos;
/*  99 */       if (this.timeoutNanos >= 0L && remaining <= 0L) {
/* 100 */         if (this.errorOnTimeout) {
/* 101 */           throw new Sinks.EmissionException(emission, "Emission timed out");
/*     */         }
/* 103 */         return false;
/*     */       } 
/* 105 */       switch (emission) {
/*     */         case FAIL_ZERO_SUBSCRIBER:
/*     */         case FAIL_CANCELLED:
/*     */         case FAIL_TERMINATED:
/*     */         case FAIL_OVERFLOW:
/* 110 */           return false;
/*     */         case FAIL_NON_SERIALIZED:
/* 112 */           LockSupport.parkNanos(this.parkNanos); continue;
/*     */       }  break;
/*     */     } 
/* 115 */     throw new Sinks.EmissionException(emission, "Unknown emitResult value");
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\sinks\TimeoutEmissionStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */