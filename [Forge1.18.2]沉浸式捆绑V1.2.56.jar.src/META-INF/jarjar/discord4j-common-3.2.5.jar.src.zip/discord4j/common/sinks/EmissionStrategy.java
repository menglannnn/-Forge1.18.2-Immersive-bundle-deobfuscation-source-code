/*    */ package discord4j.common.sinks;
/*    */ 
/*    */ import discord4j.common.annotations.Experimental;
/*    */ import java.time.Duration;
/*    */ import reactor.core.publisher.Sinks;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Experimental
/*    */ public interface EmissionStrategy
/*    */ {
/*    */   static TimeoutEmissionStrategy timeoutDrop(Duration duration) {
/* 39 */     return new TimeoutEmissionStrategy(Duration.ofMillis(10L).toNanos(), duration.toNanos(), false);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static TimeoutEmissionStrategy timeoutError(Duration duration) {
/* 50 */     return new TimeoutEmissionStrategy(Duration.ofMillis(10L).toNanos(), duration.toNanos(), true);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static EmissionStrategy park(Duration duration) {
/* 61 */     return new ParkEmissionStrategy(duration.toNanos());
/*    */   }
/*    */   
/*    */   <T> boolean emitNext(Sinks.Many<T> paramMany, T paramT);
/*    */   
/*    */   <T> boolean emitComplete(Sinks.Many<T> paramMany);
/*    */   
/*    */   <T> boolean emitError(Sinks.Many<T> paramMany, Throwable paramThrowable);
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\sinks\EmissionStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */