/*    */ package discord4j.common.sinks;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import java.util.concurrent.locks.LockSupport;
/*    */ import java.util.function.Supplier;
/*    */ import reactor.core.publisher.Sinks;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ParkEmissionStrategy
/*    */   implements EmissionStrategy
/*    */ {
/*    */   private final long parkNanos;
/*    */   
/*    */   ParkEmissionStrategy(long parkNanos) {
/* 30 */     this.parkNanos = parkNanos;
/*    */   }
/*    */   
/*    */   public <T> boolean emitNext(Sinks.Many<T> sink, T element) {
/*    */     Sinks.EmitResult emission;
/*    */     while (true) {
/* 36 */       emission = sink.tryEmitNext(element);
/* 37 */       if (emission.isSuccess()) {
/* 38 */         return true;
/*    */       }
/* 40 */       switch (emission) {
/*    */         case FAIL_ZERO_SUBSCRIBER:
/*    */         case FAIL_CANCELLED:
/*    */         case FAIL_TERMINATED:
/* 44 */           return false;
/*    */         case FAIL_NON_SERIALIZED:
/*    */           continue;
/*    */         case FAIL_OVERFLOW:
/* 48 */           LockSupport.parkNanos(this.parkNanos); continue;
/*    */       }  break;
/*    */     } 
/* 51 */     throw new Sinks.EmissionException(emission, "Unknown emitResult value");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public <T> boolean emitComplete(Sinks.Many<T> sink) {
/* 58 */     Objects.requireNonNull(sink); return emitTerminal(sink::tryEmitComplete);
/*    */   }
/*    */ 
/*    */   
/*    */   public <T> boolean emitError(Sinks.Many<T> sink, Throwable error) {
/* 63 */     return emitTerminal(() -> sink.tryEmitError(error));
/*    */   }
/*    */   private <T> boolean emitTerminal(Supplier<Sinks.EmitResult> resultSupplier) {
/*    */     Sinks.EmitResult emission;
/*    */     while (true) {
/* 68 */       emission = resultSupplier.get();
/* 69 */       if (emission.isSuccess()) {
/* 70 */         return true;
/*    */       }
/* 72 */       switch (emission) {
/*    */         case FAIL_ZERO_SUBSCRIBER:
/*    */         case FAIL_CANCELLED:
/*    */         case FAIL_TERMINATED:
/*    */         case FAIL_OVERFLOW:
/* 77 */           return false;
/*    */         case FAIL_NON_SERIALIZED:
/* 79 */           LockSupport.parkNanos(this.parkNanos); continue;
/*    */       }  break;
/*    */     } 
/* 82 */     throw new Sinks.EmissionException(emission, "Unknown emitResult value");
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\sinks\ParkEmissionStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */