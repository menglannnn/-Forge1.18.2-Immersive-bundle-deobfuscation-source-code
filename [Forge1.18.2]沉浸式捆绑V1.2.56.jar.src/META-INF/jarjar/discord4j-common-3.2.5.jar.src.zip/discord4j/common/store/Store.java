/*     */ package discord4j.common.store;
/*     */ import discord4j.common.store.action.gateway.ChannelCreateAction;
/*     */ import discord4j.common.store.action.gateway.ChannelDeleteAction;
/*     */ import discord4j.common.store.action.gateway.ChannelUpdateAction;
/*     */ import discord4j.common.store.action.gateway.GuildCreateAction;
/*     */ import discord4j.common.store.action.gateway.GuildDeleteAction;
/*     */ import discord4j.common.store.action.gateway.GuildEmojisUpdateAction;
/*     */ import discord4j.common.store.action.gateway.GuildMemberAddAction;
/*     */ import discord4j.common.store.action.gateway.GuildMemberRemoveAction;
/*     */ import discord4j.common.store.action.gateway.GuildMembersChunkAction;
/*     */ import discord4j.common.store.action.gateway.GuildRoleDeleteAction;
/*     */ import discord4j.common.store.action.gateway.GuildRoleUpdateAction;
/*     */ import discord4j.common.store.action.gateway.GuildScheduledEventDeleteAction;
/*     */ import discord4j.common.store.action.gateway.GuildScheduledEventUpdateAction;
/*     */ import discord4j.common.store.action.gateway.GuildScheduledEventUserAddAction;
/*     */ import discord4j.common.store.action.gateway.GuildStickersUpdateAction;
/*     */ import discord4j.common.store.action.gateway.GuildUpdateAction;
/*     */ import discord4j.common.store.action.gateway.InvalidateShardAction;
/*     */ import discord4j.common.store.action.gateway.MessageCreateAction;
/*     */ import discord4j.common.store.action.gateway.MessageDeleteAction;
/*     */ import discord4j.common.store.action.gateway.MessageDeleteBulkAction;
/*     */ import discord4j.common.store.action.gateway.MessageReactionAddAction;
/*     */ import discord4j.common.store.action.gateway.MessageReactionRemoveAction;
/*     */ import discord4j.common.store.action.gateway.MessageReactionRemoveAllAction;
/*     */ import discord4j.common.store.action.gateway.MessageReactionRemoveEmojiAction;
/*     */ import discord4j.common.store.action.gateway.MessageUpdateAction;
/*     */ import discord4j.common.store.action.gateway.PresenceUpdateAction;
/*     */ import discord4j.common.store.action.gateway.UserUpdateAction;
/*     */ import discord4j.common.store.action.gateway.VoiceStateUpdateDispatchAction;
/*     */ import discord4j.common.store.action.read.CountInGuildAction;
/*     */ import discord4j.common.store.action.read.CountTotalAction;
/*     */ import discord4j.common.store.action.read.CountVoiceStatesInChannelAction;
/*     */ import discord4j.common.store.action.read.GetEmojiByIdAction;
/*     */ import discord4j.common.store.action.read.GetGuildScheduledEventByIdAction;
/*     */ import discord4j.common.store.action.read.GetGuildScheduledEventUsersInEventAction;
/*     */ import discord4j.common.store.action.read.GetMemberByIdAction;
/*     */ import discord4j.common.store.action.read.GetMessageByIdAction;
/*     */ import discord4j.common.store.action.read.GetPresenceByIdAction;
/*     */ import discord4j.common.store.action.read.GetRoleByIdAction;
/*     */ import discord4j.common.store.action.read.GetStickerByIdAction;
/*     */ import discord4j.common.store.action.read.GetVoiceStateByIdAction;
/*     */ import discord4j.common.store.action.read.GetVoiceStatesInChannelAction;
/*     */ import discord4j.common.store.api.ActionMapper;
/*     */ import discord4j.common.store.api.StoreAction;
/*     */ import discord4j.common.store.api.StoreFlag;
/*     */ import discord4j.common.store.api.layout.DataAccessor;
/*     */ import discord4j.common.store.api.layout.GatewayDataUpdater;
/*     */ import discord4j.common.store.api.layout.StoreLayout;
/*     */ import java.util.EnumSet;
/*     */ import org.reactivestreams.Publisher;
/*     */ 
/*     */ public final class Store {
/*  53 */   private static final Store NO_OP = new Store(ActionMapper.empty());
/*     */   
/*     */   private final ActionMapper actionMapper;
/*     */   
/*     */   private Store(ActionMapper actionMapper) {
/*  58 */     this.actionMapper = actionMapper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Store noOp() {
/*  67 */     return NO_OP;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Store fromLayout(StoreLayout layout) {
/*  77 */     return new Store(layoutToMapper(layout));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Experimental
/*     */   public static Store fromLayouts(StoreLayout... layouts) {
/*  90 */     return new Store(ActionMapper.mergeFirst((Collection)Arrays.<StoreLayout>stream(layouts)
/*  91 */           .map(Store::layoutToMapper)
/*  92 */           .collect(Collectors.toList())));
/*     */   }
/*     */   
/*     */   private static ActionMapper layoutToMapper(StoreLayout layout) {
/*  96 */     ActionMapper dataAccessorMapper = dataAccessorToMapper(layout.getDataAccessor(), layout.getEnabledFlags());
/*  97 */     ActionMapper gatewayDataUpdaterMapper = gatewayDataUpdaterToMapper(layout.getGatewayDataUpdater(), layout.getEnabledFlags());
/*  98 */     ActionMapper customMapper = layout.getCustomActionMapper();
/*  99 */     return ActionMapper.aggregate(new ActionMapper[] { dataAccessorMapper, gatewayDataUpdaterMapper, customMapper });
/*     */   }
/*     */   
/*     */   private static ActionMapper dataAccessorToMapper(DataAccessor dataAccessor, EnumSet<StoreFlag> enabled) {
/* 103 */     Objects.requireNonNull(dataAccessor);
/*     */     
/* 105 */     ActionMapper.Builder builder = ActionMapper.builder();
/*     */     
/* 107 */     if (EnumSet.<StoreFlag>allOf(StoreFlag.class).equals(enabled))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 131 */       builder = builder.map(CountInGuildAction.class, action -> { switch (action.getEntity()) { case CHANNELS: return (Publisher)dataAccessor.countChannelsInGuild(action.getGuildId());case STICKERS: return (Publisher)dataAccessor.countStickersInGuild(action.getGuildId());case EMOJIS: return (Publisher)dataAccessor.countEmojisInGuild(action.getGuildId());case MEMBERS: return (Publisher)dataAccessor.countMembersInGuild(action.getGuildId());case MEMBERS_EXACT: return (Publisher)dataAccessor.countExactMembersInGuild(action.getGuildId());case PRESENCES: return (Publisher)dataAccessor.countPresencesInGuild(action.getGuildId());case ROLES: return (Publisher)dataAccessor.countRolesInGuild(action.getGuildId());case VOICE_STATES: return (Publisher)dataAccessor.countVoiceStatesInGuild(action.getGuildId()); }  throw new IllegalArgumentException("Unhandled entity " + action.getEntity()); }).map(CountTotalAction.class, action -> {
/*     */             switch (action.getEntity()) {
/*     */               case CHANNELS:
/*     */                 return (Publisher)dataAccessor.countChannels();
/*     */               
/*     */               case STICKERS:
/*     */                 return (Publisher)dataAccessor.countStickers();
/*     */               
/*     */               case EMOJIS:
/*     */                 return (Publisher)dataAccessor.countEmojis();
/*     */               case MEMBERS:
/*     */                 return (Publisher)dataAccessor.countGuilds();
/*     */               case MEMBERS_EXACT:
/*     */                 return (Publisher)dataAccessor.countMembers();
/*     */               case PRESENCES:
/*     */                 return (Publisher)dataAccessor.countMessages();
/*     */               case ROLES:
/*     */                 return (Publisher)dataAccessor.countPresences();
/*     */               case VOICE_STATES:
/*     */                 return (Publisher)dataAccessor.countRoles();
/*     */               case null:
/*     */                 return (Publisher)dataAccessor.countUsers();
/*     */               case null:
/*     */                 return (Publisher)dataAccessor.countVoiceStates();
/*     */             } 
/*     */             throw new IllegalArgumentException("Unhandled entity " + action.getEntity());
/*     */           });
/*     */     }
/* 159 */     if (enabled.contains(StoreFlag.CHANNEL))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 165 */       builder = builder.map(CountTotalChannelsAction.class, action -> dataAccessor.countChannels()).map(CountChannelsInGuildAction.class, action -> dataAccessor.countChannelsInGuild(action.getGuildId())).map(GetChannelsAction.class, action -> dataAccessor.getChannels()).map(GetChannelsInGuildAction.class, action -> dataAccessor.getChannelsInGuild(action.getGuildId())).map(GetChannelByIdAction.class, action -> dataAccessor.getChannelById(action.getChannelId()));
/*     */     }
/*     */     
/* 168 */     if (enabled.contains(StoreFlag.EMOJI))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 174 */       builder = builder.map(CountTotalEmojisAction.class, action -> dataAccessor.countEmojis()).map(CountEmojisInGuildAction.class, action -> dataAccessor.countEmojisInGuild(action.getGuildId())).map(GetEmojisAction.class, action -> dataAccessor.getEmojis()).map(GetEmojisInGuildAction.class, action -> dataAccessor.getEmojisInGuild(action.getGuildId())).map(GetEmojiByIdAction.class, action -> dataAccessor.getEmojiById(action.getGuildId(), action.getEmojiId()));
/*     */     }
/*     */     
/* 177 */     if (enabled.contains(StoreFlag.GUILD))
/*     */     {
/*     */ 
/*     */       
/* 181 */       builder = builder.map(CountTotalGuildsAction.class, action -> dataAccessor.countGuilds()).map(GetGuildsAction.class, action -> dataAccessor.getGuilds()).map(GetGuildByIdAction.class, action -> dataAccessor.getGuildById(action.getGuildId()));
/*     */     }
/*     */     
/* 184 */     if (enabled.contains(StoreFlag.MEMBER))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 192 */       builder = builder.map(CountTotalMembersAction.class, action -> dataAccessor.countMembers()).map(CountMembersInGuildAction.class, action -> dataAccessor.countMembersInGuild(action.getGuildId())).map(CountExactMembersInGuildAction.class, action -> dataAccessor.countExactMembersInGuild(action.getGuildId())).map(GetMembersAction.class, action -> dataAccessor.getMembers()).map(GetMembersInGuildAction.class, action -> dataAccessor.getMembersInGuild(action.getGuildId())).map(GetExactMembersInGuildAction.class, action -> dataAccessor.getExactMembersInGuild(action.getGuildId())).map(GetMemberByIdAction.class, action -> dataAccessor.getMemberById(action.getGuildId(), action.getUserId()));
/*     */     }
/*     */     
/* 195 */     if (enabled.contains(StoreFlag.MESSAGE))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 201 */       builder = builder.map(CountTotalMessagesAction.class, action -> dataAccessor.countMessages()).map(CountMessagesInChannelAction.class, action -> dataAccessor.countMessagesInChannel(action.getChannelId())).map(GetMessagesAction.class, action -> dataAccessor.getMessages()).map(GetMessagesInChannelAction.class, action -> dataAccessor.getMessagesInChannel(action.getChannelId())).map(GetMessageByIdAction.class, action -> dataAccessor.getMessageById(action.getChannelId(), action.getMessageId()));
/*     */     }
/*     */     
/* 204 */     if (enabled.contains(StoreFlag.PRESENCE))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 210 */       builder = builder.map(CountTotalPresencesAction.class, action -> dataAccessor.countPresences()).map(CountPresencesInGuildAction.class, action -> dataAccessor.countPresencesInGuild(action.getGuildId())).map(GetPresencesAction.class, action -> dataAccessor.getPresences()).map(GetPresencesInGuildAction.class, action -> dataAccessor.getPresencesInGuild(action.getGuildId())).map(GetPresenceByIdAction.class, action -> dataAccessor.getPresenceById(action.getGuildId(), action.getUserId()));
/*     */     }
/*     */     
/* 213 */     if (enabled.contains(StoreFlag.ROLE))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 219 */       builder = builder.map(CountTotalRolesAction.class, action -> dataAccessor.countRoles()).map(CountRolesInGuildAction.class, action -> dataAccessor.countRolesInGuild(action.getGuildId())).map(GetRolesAction.class, action -> dataAccessor.getRoles()).map(GetRolesInGuildAction.class, action -> dataAccessor.getRolesInGuild(action.getGuildId())).map(GetRoleByIdAction.class, action -> dataAccessor.getRoleById(action.getGuildId(), action.getRoleId()));
/*     */     }
/*     */     
/* 222 */     if (enabled.contains(StoreFlag.USER))
/*     */     {
/*     */ 
/*     */       
/* 226 */       builder = builder.map(CountTotalUsersAction.class, action -> dataAccessor.countUsers()).map(GetUsersAction.class, action -> dataAccessor.getUsers()).map(GetUserByIdAction.class, action -> dataAccessor.getUserById(action.getUserId()));
/*     */     }
/*     */     
/* 229 */     if (enabled.contains(StoreFlag.VOICE_STATE))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 237 */       builder = builder.map(CountTotalVoiceStatesAction.class, action -> dataAccessor.countVoiceStates()).map(CountVoiceStatesInGuildAction.class, action -> dataAccessor.countVoiceStatesInGuild(action.getGuildId())).map(CountVoiceStatesInChannelAction.class, action -> dataAccessor.countVoiceStatesInChannel(action.getGuildId(), action.getChannelId())).map(GetVoiceStatesAction.class, action -> dataAccessor.getVoiceStates()).map(GetVoiceStatesInChannelAction.class, action -> dataAccessor.getVoiceStatesInChannel(action.getGuildId(), action.getChannelId())).map(GetVoiceStatesInGuildAction.class, action -> dataAccessor.getVoiceStatesInGuild(action.getGuildId())).map(GetVoiceStateByIdAction.class, action -> dataAccessor.getVoiceStateById(action.getGuildId(), action.getUserId()));
/*     */     }
/*     */     
/* 240 */     if (enabled.contains(StoreFlag.STICKER))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 246 */       builder = builder.map(CountTotalStickersAction.class, action -> dataAccessor.countStickers()).map(CountStickersInGuildAction.class, action -> dataAccessor.countStickersInGuild(action.getGuildId())).map(GetStickersAction.class, action -> dataAccessor.getStickers()).map(GetStickersInGuildAction.class, action -> dataAccessor.getStickersInGuild(action.getGuildId())).map(GetStickerByIdAction.class, action -> dataAccessor.getStickerById(action.getGuildId(), action.getStickerId()));
/*     */     }
/*     */     
/* 249 */     if (enabled.contains(StoreFlag.SCHEDULED_EVENT))
/*     */     {
/*     */ 
/*     */       
/* 253 */       builder = builder.map(GetGuildScheduledEventsInGuildAction.class, action -> dataAccessor.getScheduledEventsInGuild(action.getGuildId())).map(GetGuildScheduledEventByIdAction.class, action -> dataAccessor.getScheduledEventById(action.getGuildId(), action.getEventId())).map(GetGuildScheduledEventUsersInEventAction.class, action -> dataAccessor.getScheduledEventUsersInEvent(action.getGuildId(), action.getEventId()));
/*     */     }
/*     */     
/* 256 */     return builder.build();
/*     */   }
/*     */ 
/*     */   
/*     */   private static ActionMapper gatewayDataUpdaterToMapper(GatewayDataUpdater gatewayDataUpdater, EnumSet<StoreFlag> enabled) {
/* 261 */     Objects.requireNonNull(gatewayDataUpdater);
/*     */ 
/*     */ 
/*     */     
/* 265 */     ActionMapper.Builder builder = ActionMapper.builder().map(ReadyAction.class, action -> gatewayDataUpdater.onReady(action.getReady())).map(InvalidateShardAction.class, action -> gatewayDataUpdater.onShardInvalidation(action.getShardIndex(), action.getCause()));
/*     */     
/* 267 */     if (enabled.contains(StoreFlag.CHANNEL))
/*     */     {
/*     */ 
/*     */       
/* 271 */       builder = builder.map(ChannelCreateAction.class, action -> gatewayDataUpdater.onChannelCreate(action.getShardIndex(), action.getChannelCreate())).map(ChannelDeleteAction.class, action -> gatewayDataUpdater.onChannelDelete(action.getShardIndex(), action.getChannelDelete())).map(ChannelUpdateAction.class, action -> gatewayDataUpdater.onChannelUpdate(action.getShardIndex(), action.getChannelUpdate()));
/*     */     }
/*     */     
/* 274 */     if (enabled.contains(StoreFlag.EMOJI))
/*     */     {
/* 276 */       builder = builder.map(GuildEmojisUpdateAction.class, action -> gatewayDataUpdater.onGuildEmojisUpdate(action.getShardIndex(), action.getGuildEmojisUpdate()));
/*     */     }
/*     */     
/* 279 */     if (enabled.contains(StoreFlag.GUILD))
/*     */     {
/*     */ 
/*     */       
/* 283 */       builder = builder.map(GuildCreateAction.class, action -> gatewayDataUpdater.onGuildCreate(action.getShardIndex(), action.getGuildCreate())).map(GuildDeleteAction.class, action -> gatewayDataUpdater.onGuildDelete(action.getShardIndex(), action.getGuildDelete())).map(GuildUpdateAction.class, action -> gatewayDataUpdater.onGuildUpdate(action.getShardIndex(), action.getGuildUpdate()));
/*     */     }
/*     */     
/* 286 */     if (enabled.contains(StoreFlag.MEMBER))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 292 */       builder = builder.map(GuildMemberAddAction.class, action -> gatewayDataUpdater.onGuildMemberAdd(action.getShardIndex(), action.getGuildMemberAdd())).map(GuildMemberRemoveAction.class, action -> gatewayDataUpdater.onGuildMemberRemove(action.getShardIndex(), action.getGuildMemberRemove())).map(GuildMembersChunkAction.class, action -> gatewayDataUpdater.onGuildMembersChunk(action.getShardIndex(), action.getGuildMembersChunk())).map(GuildMemberUpdateAction.class, action -> gatewayDataUpdater.onGuildMemberUpdate(action.getShardIndex(), action.getGuildMemberUpdate())).map(CompleteGuildMembersAction.class, action -> gatewayDataUpdater.onGuildMembersCompletion(action.getGuildId()));
/*     */     }
/*     */     
/* 295 */     if (enabled.contains(StoreFlag.MESSAGE))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 304 */       builder = builder.map(MessageCreateAction.class, action -> gatewayDataUpdater.onMessageCreate(action.getShardIndex(), action.getMessageCreate())).map(MessageDeleteAction.class, action -> gatewayDataUpdater.onMessageDelete(action.getShardIndex(), action.getMessageDelete())).map(MessageDeleteBulkAction.class, action -> gatewayDataUpdater.onMessageDeleteBulk(action.getShardIndex(), action.getMessageDeleteBulk())).map(MessageReactionAddAction.class, action -> gatewayDataUpdater.onMessageReactionAdd(action.getShardIndex(), action.getMessageReactionAdd())).map(MessageReactionRemoveAction.class, action -> gatewayDataUpdater.onMessageReactionRemove(action.getShardIndex(), action.getMessageReactionRemove())).map(MessageReactionRemoveAllAction.class, action -> gatewayDataUpdater.onMessageReactionRemoveAll(action.getShardIndex(), action.getMessageReactionRemoveAll())).map(MessageReactionRemoveEmojiAction.class, action -> gatewayDataUpdater.onMessageReactionRemoveEmoji(action.getShardIndex(), action.getMessageReactionRemoveEmoji())).map(MessageUpdateAction.class, action -> gatewayDataUpdater.onMessageUpdate(action.getShardIndex(), action.getMessageUpdate()));
/*     */     }
/*     */     
/* 307 */     if (enabled.contains(StoreFlag.PRESENCE))
/*     */     {
/* 309 */       builder = builder.map(PresenceUpdateAction.class, action -> gatewayDataUpdater.onPresenceUpdate(action.getShardIndex(), action.getPresenceUpdate()));
/*     */     }
/*     */     
/* 312 */     if (enabled.contains(StoreFlag.ROLE))
/*     */     {
/*     */ 
/*     */       
/* 316 */       builder = builder.map(GuildRoleCreateAction.class, action -> gatewayDataUpdater.onGuildRoleCreate(action.getShardIndex(), action.getGuildRoleCreate())).map(GuildRoleDeleteAction.class, action -> gatewayDataUpdater.onGuildRoleDelete(action.getShardIndex(), action.getGuildRoleDelete())).map(GuildRoleUpdateAction.class, action -> gatewayDataUpdater.onGuildRoleUpdate(action.getShardIndex(), action.getGuildRoleUpdate()));
/*     */     }
/*     */     
/* 319 */     if (enabled.contains(StoreFlag.USER))
/*     */     {
/* 321 */       builder = builder.map(UserUpdateAction.class, action -> gatewayDataUpdater.onUserUpdate(action.getShardIndex(), action.getUserUpdate()));
/*     */     }
/*     */     
/* 324 */     if (enabled.contains(StoreFlag.VOICE_STATE))
/*     */     {
/* 326 */       builder = builder.map(VoiceStateUpdateDispatchAction.class, action -> gatewayDataUpdater.onVoiceStateUpdateDispatch(action.getShardIndex(), action.getVoiceStateUpdateDispatch()));
/*     */     }
/*     */     
/* 329 */     if (enabled.contains(StoreFlag.STICKER))
/*     */     {
/* 331 */       builder = builder.map(GuildStickersUpdateAction.class, action -> gatewayDataUpdater.onGuildStickersUpdate(action.getShardIndex(), action.getGuildStickersUpdate()));
/*     */     }
/*     */     
/* 334 */     if (enabled.contains(StoreFlag.SCHEDULED_EVENT))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 340 */       builder = builder.map(GuildScheduledEventCreateAction.class, action -> gatewayDataUpdater.onGuildScheduledEventCreate(action.getShardIndex(), action.getGuildScheduledEventCreate())).map(GuildScheduledEventUpdateAction.class, action -> gatewayDataUpdater.onGuildScheduledEventUpdate(action.getShardIndex(), action.getGuildScheduledEventUpdate())).map(GuildScheduledEventDeleteAction.class, action -> gatewayDataUpdater.onGuildScheduledEventDelete(action.getShardIndex(), action.getGuildScheduledEventDelete())).map(GuildScheduledEventUserAddAction.class, actions -> gatewayDataUpdater.onGuildScheduledEventUserAdd(actions.getShardIndex(), actions.getUserAdd())).map(GuildScheduledEventUserRemoveAction.class, actions -> gatewayDataUpdater.onGuildScheduledEventUserRemove(actions.getShardIndex(), actions.getUserRemove()));
/*     */     }
/*     */     
/* 343 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R> Publisher<R> execute(StoreAction<R> action) {
/* 357 */     return (Publisher<R>)this.actionMapper.findHandlerForAction(action)
/* 358 */       .map(h -> (Publisher)h.apply(action))
/* 359 */       .orElse(Flux.empty());
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\Store.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */