/*    */ package discord4j.common.store.action.gateway;
/*    */ 
/*    */ import discord4j.discordjson.json.GuildData;
/*    */ import discord4j.discordjson.json.gateway.GuildDelete;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GuildDeleteAction
/*    */   extends ShardAwareAction<GuildData>
/*    */ {
/*    */   private final GuildDelete guildDelete;
/*    */   
/*    */   GuildDeleteAction(int shardIndex, GuildDelete guildDelete) {
/* 28 */     super(shardIndex);
/* 29 */     this.guildDelete = guildDelete;
/*    */   }
/*    */   
/*    */   public GuildDelete getGuildDelete() {
/* 33 */     return this.guildDelete;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\action\gateway\GuildDeleteAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */