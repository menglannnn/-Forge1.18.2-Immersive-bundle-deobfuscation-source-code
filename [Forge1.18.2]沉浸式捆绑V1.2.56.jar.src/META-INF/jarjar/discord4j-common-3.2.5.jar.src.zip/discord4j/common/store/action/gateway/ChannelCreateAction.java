/*    */ package discord4j.common.store.action.gateway;
/*    */ 
/*    */ import discord4j.discordjson.json.gateway.ChannelCreate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ChannelCreateAction
/*    */   extends ShardAwareAction<Void>
/*    */ {
/*    */   private final ChannelCreate channelCreate;
/*    */   
/*    */   ChannelCreateAction(int shardIndex, ChannelCreate channelCreate) {
/* 27 */     super(shardIndex);
/* 28 */     this.channelCreate = channelCreate;
/*    */   }
/*    */   
/*    */   public ChannelCreate getChannelCreate() {
/* 32 */     return this.channelCreate;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\action\gateway\ChannelCreateAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */