/*    */ package discord4j.common.store.action.gateway;
/*    */ 
/*    */ import discord4j.common.store.api.StoreAction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class ShardAwareAction<R>
/*    */   implements StoreAction<R>
/*    */ {
/*    */   private final int shardIndex;
/*    */   
/*    */   ShardAwareAction(int shardIndex) {
/* 27 */     this.shardIndex = shardIndex;
/*    */   }
/*    */   
/*    */   public int getShardIndex() {
/* 31 */     return this.shardIndex;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\action\gateway\ShardAwareAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */