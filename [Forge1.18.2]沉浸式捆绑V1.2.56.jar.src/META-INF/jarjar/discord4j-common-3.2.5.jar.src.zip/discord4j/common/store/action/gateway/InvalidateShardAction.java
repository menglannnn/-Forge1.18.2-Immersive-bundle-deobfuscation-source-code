/*    */ package discord4j.common.store.action.gateway;
/*    */ 
/*    */ import discord4j.common.store.api.object.InvalidationCause;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InvalidateShardAction
/*    */   extends ShardAwareAction<Void>
/*    */ {
/*    */   private final InvalidationCause cause;
/*    */   
/*    */   InvalidateShardAction(int shardIndex, InvalidationCause cause) {
/* 27 */     super(shardIndex);
/* 28 */     this.cause = cause;
/*    */   }
/*    */   
/*    */   public InvalidationCause getCause() {
/* 32 */     return this.cause;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\action\gateway\InvalidateShardAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */