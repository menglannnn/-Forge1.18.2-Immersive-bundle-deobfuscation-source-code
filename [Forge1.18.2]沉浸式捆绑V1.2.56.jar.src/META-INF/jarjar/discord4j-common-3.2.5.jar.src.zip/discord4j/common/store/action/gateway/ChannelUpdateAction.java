/*    */ package discord4j.common.store.action.gateway;
/*    */ 
/*    */ import discord4j.discordjson.json.ChannelData;
/*    */ import discord4j.discordjson.json.gateway.ChannelUpdate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ChannelUpdateAction
/*    */   extends ShardAwareAction<ChannelData>
/*    */ {
/*    */   private final ChannelUpdate channelUpdate;
/*    */   
/*    */   ChannelUpdateAction(int shardIndex, ChannelUpdate channelUpdate) {
/* 28 */     super(shardIndex);
/* 29 */     this.channelUpdate = channelUpdate;
/*    */   }
/*    */   
/*    */   public ChannelUpdate getChannelUpdate() {
/* 33 */     return this.channelUpdate;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\action\gateway\ChannelUpdateAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */