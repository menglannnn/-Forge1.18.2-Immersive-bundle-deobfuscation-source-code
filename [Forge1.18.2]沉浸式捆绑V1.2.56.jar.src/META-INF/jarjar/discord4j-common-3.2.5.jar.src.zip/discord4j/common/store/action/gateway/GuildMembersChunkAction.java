/*    */ package discord4j.common.store.action.gateway;
/*    */ 
/*    */ import discord4j.discordjson.json.gateway.GuildMembersChunk;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GuildMembersChunkAction
/*    */   extends ShardAwareAction<Void>
/*    */ {
/*    */   private final GuildMembersChunk guildMembersChunk;
/*    */   
/*    */   GuildMembersChunkAction(int shardIndex, GuildMembersChunk guildMembersChunk) {
/* 27 */     super(shardIndex);
/* 28 */     this.guildMembersChunk = guildMembersChunk;
/*    */   }
/*    */   
/*    */   public GuildMembersChunk getGuildMembersChunk() {
/* 32 */     return this.guildMembersChunk;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\action\gateway\GuildMembersChunkAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */