/*    */ package discord4j.common.store.action.read;
/*    */ 
/*    */ import discord4j.common.store.api.StoreAction;
/*    */ import discord4j.discordjson.json.EmojiData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GetEmojisInGuildAction
/*    */   implements StoreAction<EmojiData>
/*    */ {
/*    */   private final long guildId;
/*    */   
/*    */   GetEmojisInGuildAction(long guildId) {
/* 28 */     this.guildId = guildId;
/*    */   }
/*    */   
/*    */   public long getGuildId() {
/* 32 */     return this.guildId;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\action\read\GetEmojisInGuildAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */