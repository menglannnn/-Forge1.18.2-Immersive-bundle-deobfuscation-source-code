/*    */ package discord4j.common.store.action.gateway;
/*    */ 
/*    */ import discord4j.discordjson.json.gateway.GuildRoleCreate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GuildRoleCreateAction
/*    */   extends ShardAwareAction<Void>
/*    */ {
/*    */   private final GuildRoleCreate guildRoleCreate;
/*    */   
/*    */   GuildRoleCreateAction(int shardIndex, GuildRoleCreate guildRoleCreate) {
/* 27 */     super(shardIndex);
/* 28 */     this.guildRoleCreate = guildRoleCreate;
/*    */   }
/*    */   
/*    */   public GuildRoleCreate getGuildRoleCreate() {
/* 32 */     return this.guildRoleCreate;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\action\gateway\GuildRoleCreateAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */