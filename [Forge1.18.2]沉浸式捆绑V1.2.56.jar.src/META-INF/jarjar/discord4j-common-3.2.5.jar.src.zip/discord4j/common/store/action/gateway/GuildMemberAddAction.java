/*    */ package discord4j.common.store.action.gateway;
/*    */ 
/*    */ import discord4j.discordjson.json.gateway.GuildMemberAdd;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GuildMemberAddAction
/*    */   extends ShardAwareAction<Void>
/*    */ {
/*    */   private final GuildMemberAdd guildMemberAdd;
/*    */   
/*    */   GuildMemberAddAction(int shardIndex, GuildMemberAdd guildMemberAdd) {
/* 27 */     super(shardIndex);
/* 28 */     this.guildMemberAdd = guildMemberAdd;
/*    */   }
/*    */   
/*    */   public GuildMemberAdd getGuildMemberAdd() {
/* 32 */     return this.guildMemberAdd;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\action\gateway\GuildMemberAddAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */