/*    */ package discord4j.common.store.action.gateway;
/*    */ 
/*    */ import discord4j.discordjson.json.UserData;
/*    */ import discord4j.discordjson.json.gateway.UserUpdate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UserUpdateAction
/*    */   extends ShardAwareAction<UserData>
/*    */ {
/*    */   private final UserUpdate userUpdate;
/*    */   
/*    */   UserUpdateAction(int shardIndex, UserUpdate userUpdate) {
/* 28 */     super(shardIndex);
/* 29 */     this.userUpdate = userUpdate;
/*    */   }
/*    */   
/*    */   public UserUpdate getUserUpdate() {
/* 33 */     return this.userUpdate;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\action\gateway\UserUpdateAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */