/*    */ package discord4j.common.store.action.read;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CountTotalMessagesAction
/*    */   extends CountTotalAction
/*    */ {
/*    */   CountTotalMessagesAction() {
/* 23 */     super(CountTotalAction.CountableEntity.MESSAGES);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\action\read\CountTotalMessagesAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */