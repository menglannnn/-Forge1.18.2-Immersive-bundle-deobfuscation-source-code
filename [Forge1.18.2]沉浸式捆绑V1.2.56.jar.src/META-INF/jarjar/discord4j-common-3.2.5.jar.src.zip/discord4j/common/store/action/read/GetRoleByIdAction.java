/*    */ package discord4j.common.store.action.read;
/*    */ 
/*    */ import discord4j.common.store.api.StoreAction;
/*    */ import discord4j.discordjson.json.RoleData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GetRoleByIdAction
/*    */   implements StoreAction<RoleData>
/*    */ {
/*    */   private final long guildId;
/*    */   private final long roleId;
/*    */   
/*    */   GetRoleByIdAction(long guildId, long roleId) {
/* 29 */     this.guildId = guildId;
/* 30 */     this.roleId = roleId;
/*    */   }
/*    */   
/*    */   public long getGuildId() {
/* 34 */     return this.guildId;
/*    */   }
/*    */   
/*    */   public long getRoleId() {
/* 38 */     return this.roleId;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\action\read\GetRoleByIdAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */