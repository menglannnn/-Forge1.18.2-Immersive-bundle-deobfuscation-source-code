/*    */ package discord4j.common.store.action.gateway;
/*    */ 
/*    */ import discord4j.discordjson.json.EmojiData;
/*    */ import discord4j.discordjson.json.gateway.GuildEmojisUpdate;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GuildEmojisUpdateAction
/*    */   extends ShardAwareAction<Set<EmojiData>>
/*    */ {
/*    */   private final GuildEmojisUpdate guildEmojisUpdate;
/*    */   
/*    */   GuildEmojisUpdateAction(int shardIndex, GuildEmojisUpdate guildEmojisUpdate) {
/* 30 */     super(shardIndex);
/* 31 */     this.guildEmojisUpdate = guildEmojisUpdate;
/*    */   }
/*    */   
/*    */   public GuildEmojisUpdate getGuildEmojisUpdate() {
/* 35 */     return this.guildEmojisUpdate;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\action\gateway\GuildEmojisUpdateAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */