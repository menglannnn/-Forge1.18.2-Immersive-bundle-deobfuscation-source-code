/*     */ package discord4j.common.store.action.read;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReadActions
/*     */ {
/*     */   private ReadActions() {
/*  31 */     throw new AssertionError("No discord4j.common.store.action.read.ReadActions instances for you!");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CountTotalAction countChannels() {
/*  40 */     return new CountTotalAction(CountTotalAction.CountableEntity.CHANNELS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CountInGuildAction countChannelsInGuild(long guildId) {
/*  50 */     return new CountInGuildAction(CountInGuildAction.InGuildEntity.CHANNELS, guildId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CountTotalAction countEmojis() {
/*  59 */     return new CountTotalAction(CountTotalAction.CountableEntity.EMOJIS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CountInGuildAction countEmojisInGuild(long guildId) {
/*  69 */     return new CountInGuildAction(CountInGuildAction.InGuildEntity.EMOJIS, guildId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CountTotalAction countGuilds() {
/*  78 */     return new CountTotalAction(CountTotalAction.CountableEntity.GUILDS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CountTotalAction countMembers() {
/*  87 */     return new CountTotalAction(CountTotalAction.CountableEntity.MEMBERS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CountInGuildAction countMembersInGuild(long guildId) {
/*  97 */     return new CountInGuildAction(CountInGuildAction.InGuildEntity.MEMBERS, guildId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CountInGuildAction countExactMembersInGuild(long guildId) {
/* 109 */     return new CountInGuildAction(CountInGuildAction.InGuildEntity.MEMBERS_EXACT, guildId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CountTotalAction countMessages() {
/* 118 */     return new CountTotalAction(CountTotalAction.CountableEntity.MESSAGES);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CountMessagesInChannelAction countMessagesInChannel(long channelId) {
/* 128 */     return new CountMessagesInChannelAction(channelId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CountTotalAction countPresences() {
/* 137 */     return new CountTotalAction(CountTotalAction.CountableEntity.PRESENCES);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CountInGuildAction countPresencesInGuild(long guildId) {
/* 147 */     return new CountInGuildAction(CountInGuildAction.InGuildEntity.PRESENCES, guildId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CountTotalAction countRoles() {
/* 156 */     return new CountTotalAction(CountTotalAction.CountableEntity.ROLES);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CountInGuildAction countRolesInGuild(long guildId) {
/* 166 */     return new CountInGuildAction(CountInGuildAction.InGuildEntity.ROLES, guildId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CountTotalAction countUsers() {
/* 175 */     return new CountTotalAction(CountTotalAction.CountableEntity.USERS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CountTotalAction countVoiceStates() {
/* 184 */     return new CountTotalAction(CountTotalAction.CountableEntity.VOICE_STATES);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CountInGuildAction countVoiceStatesInGuild(long guildId) {
/* 194 */     return new CountInGuildAction(CountInGuildAction.InGuildEntity.VOICE_STATES, guildId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CountVoiceStatesInChannelAction countVoiceStatesInChannel(long guildId, long channelId) {
/* 205 */     return new CountVoiceStatesInChannelAction(guildId, channelId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GetChannelsAction getChannels() {
/* 214 */     return new GetChannelsAction();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GetChannelsInGuildAction getChannelsInGuild(long guildId) {
/* 224 */     return new GetChannelsInGuildAction(guildId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GetChannelByIdAction getChannelById(long channelId) {
/* 234 */     return new GetChannelByIdAction(channelId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GetStickersInGuildAction getStickersInGuild(long guildId) {
/* 244 */     return new GetStickersInGuildAction(guildId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GetStickerByIdAction getStickerById(long guildId, long stickerId) {
/* 255 */     return new GetStickerByIdAction(guildId, stickerId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GetAutoModRulesInGuildAction getAutoModRulesInGuild(long guildId) {
/* 265 */     return new GetAutoModRulesInGuildAction(guildId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GetAutoModRuleByIdAction getAutoModRuleById(long guildId, long autoModRuleId) {
/* 276 */     return new GetAutoModRuleByIdAction(guildId, autoModRuleId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GetEmojisAction getEmojis() {
/* 285 */     return new GetEmojisAction();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GetEmojisInGuildAction getEmojisInGuild(long guildId) {
/* 295 */     return new GetEmojisInGuildAction(guildId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GetEmojiByIdAction getEmojiById(long guildId, long emojiId) {
/* 306 */     return new GetEmojiByIdAction(guildId, emojiId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GetGuildsAction getGuilds() {
/* 315 */     return new GetGuildsAction();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GetGuildByIdAction getGuildById(long guildId) {
/* 325 */     return new GetGuildByIdAction(guildId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GetMembersAction getMembers() {
/* 334 */     return new GetMembersAction();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GetMembersInGuildAction getMembersInGuild(long guildId) {
/* 344 */     return new GetMembersInGuildAction(guildId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GetExactMembersInGuildAction getExactMembersInGuild(long guildId) {
/* 356 */     return new GetExactMembersInGuildAction(guildId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GetMemberByIdAction getMemberById(long guildId, long userId) {
/* 367 */     return new GetMemberByIdAction(guildId, userId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GetMessagesAction getMessages() {
/* 376 */     return new GetMessagesAction();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GetMessagesInChannelAction getMessagesInChannel(long channelId) {
/* 386 */     return new GetMessagesInChannelAction(channelId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GetMessageByIdAction getMessageById(long channelId, long messageId) {
/* 397 */     return new GetMessageByIdAction(channelId, messageId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GetPresencesAction getPresences() {
/* 406 */     return new GetPresencesAction();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GetPresencesInGuildAction getPresencesInGuild(long guildId) {
/* 416 */     return new GetPresencesInGuildAction(guildId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GetPresenceByIdAction getPresenceById(long guildId, long userId) {
/* 427 */     return new GetPresenceByIdAction(guildId, userId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GetRolesAction getRoles() {
/* 436 */     return new GetRolesAction();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GetRolesInGuildAction getRolesInGuild(long guildId) {
/* 446 */     return new GetRolesInGuildAction(guildId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GetRoleByIdAction getRoleById(long guildId, long roleId) {
/* 457 */     return new GetRoleByIdAction(guildId, roleId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GetGuildScheduledEventsInGuildAction getScheduledEventsInGuild(long guildId) {
/* 467 */     return new GetGuildScheduledEventsInGuildAction(guildId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GetGuildScheduledEventByIdAction getScheduledEventById(long guildId, long eventId) {
/* 478 */     return new GetGuildScheduledEventByIdAction(guildId, eventId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GetGuildScheduledEventUsersInEventAction getScheduledEventsUsers(long guildId, long eventId) {
/* 489 */     return new GetGuildScheduledEventUsersInEventAction(guildId, eventId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GetUsersAction getUsers() {
/* 498 */     return new GetUsersAction();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GetUserByIdAction getUserById(long userId) {
/* 508 */     return new GetUserByIdAction(userId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GetVoiceStatesAction getVoiceStates() {
/* 517 */     return new GetVoiceStatesAction();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GetVoiceStatesInChannelAction getVoiceStatesInChannel(long guildId, long channelId) {
/* 528 */     return new GetVoiceStatesInChannelAction(guildId, channelId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GetVoiceStatesInGuildAction getVoiceStatesInGuild(long guildId) {
/* 538 */     return new GetVoiceStatesInGuildAction(guildId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GetVoiceStateByIdAction getVoiceStateById(long guildId, long userId) {
/* 549 */     return new GetVoiceStateByIdAction(guildId, userId);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\action\read\ReadActions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */