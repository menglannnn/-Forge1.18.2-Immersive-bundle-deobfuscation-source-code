/*    */ package discord4j.common.store.action.read;
/*    */ 
/*    */ import discord4j.common.store.api.StoreAction;
/*    */ import discord4j.discordjson.Id;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GetGuildScheduledEventUsersInEventAction
/*    */   implements StoreAction<Id>
/*    */ {
/*    */   private final long guildId;
/*    */   private final long eventId;
/*    */   
/*    */   public GetGuildScheduledEventUsersInEventAction(long guildId, long eventId) {
/* 30 */     this.guildId = guildId;
/* 31 */     this.eventId = eventId;
/*    */   }
/*    */   
/*    */   public long getGuildId() {
/* 35 */     return this.guildId;
/*    */   }
/*    */   
/*    */   public long getEventId() {
/* 39 */     return this.eventId;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\action\read\GetGuildScheduledEventUsersInEventAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */