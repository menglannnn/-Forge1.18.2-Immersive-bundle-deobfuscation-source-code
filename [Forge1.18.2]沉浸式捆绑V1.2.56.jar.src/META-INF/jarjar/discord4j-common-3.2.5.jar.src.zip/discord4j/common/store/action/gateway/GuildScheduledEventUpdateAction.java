/*    */ package discord4j.common.store.action.gateway;
/*    */ 
/*    */ import discord4j.discordjson.json.GuildScheduledEventData;
/*    */ import discord4j.discordjson.json.gateway.GuildScheduledEventUpdate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GuildScheduledEventUpdateAction
/*    */   extends ShardAwareAction<GuildScheduledEventData>
/*    */ {
/*    */   private final GuildScheduledEventUpdate guildScheduledEventUpdate;
/*    */   
/*    */   GuildScheduledEventUpdateAction(int shardIndex, GuildScheduledEventUpdate guildScheduledEventUpdate) {
/* 28 */     super(shardIndex);
/* 29 */     this.guildScheduledEventUpdate = guildScheduledEventUpdate;
/*    */   }
/*    */   
/*    */   public GuildScheduledEventUpdate getGuildScheduledEventUpdate() {
/* 33 */     return this.guildScheduledEventUpdate;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\action\gateway\GuildScheduledEventUpdateAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */