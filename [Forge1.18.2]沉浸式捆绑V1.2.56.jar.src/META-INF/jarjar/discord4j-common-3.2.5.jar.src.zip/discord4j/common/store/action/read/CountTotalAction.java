/*    */ package discord4j.common.store.action.read;
/*    */ 
/*    */ import discord4j.common.store.api.StoreAction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CountTotalAction
/*    */   implements StoreAction<Long>
/*    */ {
/*    */   private final CountableEntity entity;
/*    */   
/*    */   public enum CountableEntity
/*    */   {
/* 25 */     CHANNELS,
/* 26 */     STICKERS,
/* 27 */     EMOJIS,
/* 28 */     GUILDS,
/* 29 */     MEMBERS,
/* 30 */     MESSAGES,
/* 31 */     PRESENCES,
/* 32 */     ROLES,
/* 33 */     USERS,
/* 34 */     VOICE_STATES;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   CountTotalAction(CountableEntity entity) {
/* 40 */     this.entity = entity;
/*    */   }
/*    */   
/*    */   public CountableEntity getEntity() {
/* 44 */     return this.entity;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\action\read\CountTotalAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */