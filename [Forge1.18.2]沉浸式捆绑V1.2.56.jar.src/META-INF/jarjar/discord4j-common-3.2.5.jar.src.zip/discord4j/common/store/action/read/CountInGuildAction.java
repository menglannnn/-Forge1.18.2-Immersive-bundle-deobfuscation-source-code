/*    */ package discord4j.common.store.action.read;
/*    */ 
/*    */ import discord4j.common.store.api.StoreAction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CountInGuildAction
/*    */   implements StoreAction<Long>
/*    */ {
/*    */   private final InGuildEntity entity;
/*    */   private final long guildId;
/*    */   
/*    */   public enum InGuildEntity
/*    */   {
/* 25 */     CHANNELS,
/* 26 */     EMOJIS,
/* 27 */     STICKERS,
/* 28 */     MEMBERS,
/* 29 */     MEMBERS_EXACT,
/* 30 */     PRESENCES,
/* 31 */     ROLES,
/* 32 */     VOICE_STATES;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   CountInGuildAction(InGuildEntity entity, long guildId) {
/* 39 */     this.entity = entity;
/* 40 */     this.guildId = guildId;
/*    */   }
/*    */   
/*    */   public InGuildEntity getEntity() {
/* 44 */     return this.entity;
/*    */   }
/*    */   
/*    */   public long getGuildId() {
/* 48 */     return this.guildId;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\action\read\CountInGuildAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */