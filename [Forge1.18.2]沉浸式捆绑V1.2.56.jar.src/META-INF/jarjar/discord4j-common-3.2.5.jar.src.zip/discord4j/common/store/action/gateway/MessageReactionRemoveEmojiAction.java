/*    */ package discord4j.common.store.action.gateway;
/*    */ 
/*    */ import discord4j.discordjson.json.gateway.MessageReactionRemoveEmoji;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MessageReactionRemoveEmojiAction
/*    */   extends ShardAwareAction<Void>
/*    */ {
/*    */   private final MessageReactionRemoveEmoji messageReactionRemoveEmoji;
/*    */   
/*    */   MessageReactionRemoveEmojiAction(int shardIndex, MessageReactionRemoveEmoji messageReactionRemoveEmoji) {
/* 27 */     super(shardIndex);
/* 28 */     this.messageReactionRemoveEmoji = messageReactionRemoveEmoji;
/*    */   }
/*    */   
/*    */   public MessageReactionRemoveEmoji getMessageReactionRemoveEmoji() {
/* 32 */     return this.messageReactionRemoveEmoji;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\action\gateway\MessageReactionRemoveEmojiAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */