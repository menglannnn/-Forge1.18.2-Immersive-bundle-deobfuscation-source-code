/*    */ package discord4j.common.store.action.gateway;
/*    */ 
/*    */ import discord4j.discordjson.json.RoleData;
/*    */ import discord4j.discordjson.json.gateway.GuildRoleDelete;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GuildRoleDeleteAction
/*    */   extends ShardAwareAction<RoleData>
/*    */ {
/*    */   private final GuildRoleDelete guildRoleDelete;
/*    */   
/*    */   GuildRoleDeleteAction(int shardIndex, GuildRoleDelete guildRoleDelete) {
/* 28 */     super(shardIndex);
/* 29 */     this.guildRoleDelete = guildRoleDelete;
/*    */   }
/*    */   
/*    */   public GuildRoleDelete getGuildRoleDelete() {
/* 33 */     return this.guildRoleDelete;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\action\gateway\GuildRoleDeleteAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */