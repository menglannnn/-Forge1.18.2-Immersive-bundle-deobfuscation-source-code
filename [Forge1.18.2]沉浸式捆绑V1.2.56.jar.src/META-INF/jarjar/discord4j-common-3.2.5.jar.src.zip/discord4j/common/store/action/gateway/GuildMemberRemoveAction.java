/*    */ package discord4j.common.store.action.gateway;
/*    */ 
/*    */ import discord4j.discordjson.json.MemberData;
/*    */ import discord4j.discordjson.json.gateway.GuildMemberRemove;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GuildMemberRemoveAction
/*    */   extends ShardAwareAction<MemberData>
/*    */ {
/*    */   private final GuildMemberRemove guildMemberRemove;
/*    */   
/*    */   GuildMemberRemoveAction(int shardIndex, GuildMemberRemove guildMemberRemove) {
/* 28 */     super(shardIndex);
/* 29 */     this.guildMemberRemove = guildMemberRemove;
/*    */   }
/*    */   
/*    */   public GuildMemberRemove getGuildMemberRemove() {
/* 33 */     return this.guildMemberRemove;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\action\gateway\GuildMemberRemoveAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */