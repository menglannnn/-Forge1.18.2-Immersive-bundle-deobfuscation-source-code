/*    */ package discord4j.common.store.action.gateway;
/*    */ 
/*    */ import discord4j.discordjson.json.VoiceStateData;
/*    */ import discord4j.discordjson.json.gateway.VoiceStateUpdateDispatch;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VoiceStateUpdateDispatchAction
/*    */   extends ShardAwareAction<VoiceStateData>
/*    */ {
/*    */   private final VoiceStateUpdateDispatch voiceStateUpdateDispatch;
/*    */   
/*    */   VoiceStateUpdateDispatchAction(int shardIndex, VoiceStateUpdateDispatch voiceStateUpdateDispatch) {
/* 28 */     super(shardIndex);
/* 29 */     this.voiceStateUpdateDispatch = voiceStateUpdateDispatch;
/*    */   }
/*    */   
/*    */   public VoiceStateUpdateDispatch getVoiceStateUpdateDispatch() {
/* 33 */     return this.voiceStateUpdateDispatch;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\action\gateway\VoiceStateUpdateDispatchAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */