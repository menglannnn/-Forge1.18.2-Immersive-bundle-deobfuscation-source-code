/*     */ package discord4j.common.store.action.gateway;
/*     */ import discord4j.common.store.api.object.InvalidationCause;
/*     */ import discord4j.discordjson.json.gateway.ChannelCreate;
/*     */ import discord4j.discordjson.json.gateway.ChannelUpdate;
/*     */ import discord4j.discordjson.json.gateway.GuildCreate;
/*     */ import discord4j.discordjson.json.gateway.GuildDelete;
/*     */ import discord4j.discordjson.json.gateway.GuildMemberAdd;
/*     */ import discord4j.discordjson.json.gateway.GuildMemberRemove;
/*     */ import discord4j.discordjson.json.gateway.GuildMembersChunk;
/*     */ import discord4j.discordjson.json.gateway.GuildRoleCreate;
/*     */ import discord4j.discordjson.json.gateway.GuildRoleDelete;
/*     */ import discord4j.discordjson.json.gateway.GuildRoleUpdate;
/*     */ import discord4j.discordjson.json.gateway.GuildScheduledEventCreate;
/*     */ import discord4j.discordjson.json.gateway.GuildScheduledEventUpdate;
/*     */ import discord4j.discordjson.json.gateway.GuildScheduledEventUserAdd;
/*     */ import discord4j.discordjson.json.gateway.GuildScheduledEventUserRemove;
/*     */ import discord4j.discordjson.json.gateway.GuildStickersUpdate;
/*     */ import discord4j.discordjson.json.gateway.GuildUpdate;
/*     */ import discord4j.discordjson.json.gateway.MessageCreate;
/*     */ import discord4j.discordjson.json.gateway.MessageDeleteBulk;
/*     */ import discord4j.discordjson.json.gateway.MessageReactionAdd;
/*     */ import discord4j.discordjson.json.gateway.MessageReactionRemove;
/*     */ import discord4j.discordjson.json.gateway.MessageReactionRemoveAll;
/*     */ import discord4j.discordjson.json.gateway.MessageReactionRemoveEmoji;
/*     */ import discord4j.discordjson.json.gateway.PresenceUpdate;
/*     */ import discord4j.discordjson.json.gateway.Ready;
/*     */ import discord4j.discordjson.json.gateway.VoiceStateUpdateDispatch;
/*     */ 
/*     */ public class GatewayActions {
/*     */   private GatewayActions() {
/*  31 */     throw new AssertionError("No discord4j.common.store.action.gateway.GatewayActions instances for you!");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ChannelCreateAction channelCreate(int shardIndex, ChannelCreate dispatch) {
/*  42 */     return new ChannelCreateAction(shardIndex, dispatch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ChannelDeleteAction channelDelete(int shardIndex, ChannelDelete dispatch) {
/*  53 */     return new ChannelDeleteAction(shardIndex, dispatch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ChannelUpdateAction channelUpdate(int shardIndex, ChannelUpdate dispatch) {
/*  64 */     return new ChannelUpdateAction(shardIndex, dispatch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GuildCreateAction guildCreate(int shardIndex, GuildCreate dispatch) {
/*  75 */     return new GuildCreateAction(shardIndex, dispatch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GuildDeleteAction guildDelete(int shardIndex, GuildDelete dispatch) {
/*  86 */     return new GuildDeleteAction(shardIndex, dispatch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GuildStickersUpdateAction guildStickersUpdate(int shardIndex, GuildStickersUpdate dispatch) {
/*  97 */     return new GuildStickersUpdateAction(shardIndex, dispatch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GuildEmojisUpdateAction guildEmojisUpdate(int shardIndex, GuildEmojisUpdate dispatch) {
/* 108 */     return new GuildEmojisUpdateAction(shardIndex, dispatch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GuildMemberAddAction guildMemberAdd(int shardIndex, GuildMemberAdd dispatch) {
/* 119 */     return new GuildMemberAddAction(shardIndex, dispatch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GuildMemberRemoveAction guildMemberRemove(int shardIndex, GuildMemberRemove dispatch) {
/* 130 */     return new GuildMemberRemoveAction(shardIndex, dispatch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GuildMembersChunkAction guildMembersChunk(int shardIndex, GuildMembersChunk dispatch) {
/* 141 */     return new GuildMembersChunkAction(shardIndex, dispatch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GuildMemberUpdateAction guildMemberUpdate(int shardIndex, GuildMemberUpdate dispatch) {
/* 152 */     return new GuildMemberUpdateAction(shardIndex, dispatch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GuildRoleCreateAction guildRoleCreate(int shardIndex, GuildRoleCreate dispatch) {
/* 163 */     return new GuildRoleCreateAction(shardIndex, dispatch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GuildRoleDeleteAction guildRoleDelete(int shardIndex, GuildRoleDelete dispatch) {
/* 174 */     return new GuildRoleDeleteAction(shardIndex, dispatch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GuildRoleUpdateAction guildRoleUpdate(int shardIndex, GuildRoleUpdate dispatch) {
/* 185 */     return new GuildRoleUpdateAction(shardIndex, dispatch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GuildScheduledEventCreateAction guildScheduledEventCreate(int shardIndex, GuildScheduledEventCreate dispatch) {
/* 196 */     return new GuildScheduledEventCreateAction(shardIndex, dispatch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GuildScheduledEventUpdateAction guildScheduledEventUpdate(int shardIndex, GuildScheduledEventUpdate dispatch) {
/* 207 */     return new GuildScheduledEventUpdateAction(shardIndex, dispatch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GuildScheduledEventDeleteAction guildScheduledEventDelete(int shardIndex, GuildScheduledEventDelete dispatch) {
/* 218 */     return new GuildScheduledEventDeleteAction(shardIndex, dispatch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GuildScheduledEventUserAddAction guildScheduledEventUserAdd(int shardIndex, GuildScheduledEventUserAdd dispatch) {
/* 231 */     return new GuildScheduledEventUserAddAction(shardIndex, dispatch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GuildScheduledEventUserRemoveAction guildScheduledEventUserRemove(int shardIndex, GuildScheduledEventUserRemove dispatch) {
/* 243 */     return new GuildScheduledEventUserRemoveAction(shardIndex, dispatch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GuildUpdateAction guildUpdate(int shardIndex, GuildUpdate dispatch) {
/* 254 */     return new GuildUpdateAction(shardIndex, dispatch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static InvalidateShardAction invalidateShard(int shardIndex, InvalidationCause cause) {
/* 265 */     return new InvalidateShardAction(shardIndex, cause);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MessageCreateAction messageCreate(int shardIndex, MessageCreate dispatch) {
/* 276 */     return new MessageCreateAction(shardIndex, dispatch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MessageDeleteAction messageDelete(int shardIndex, MessageDelete dispatch) {
/* 287 */     return new MessageDeleteAction(shardIndex, dispatch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MessageDeleteBulkAction messageDeleteBulk(int shardIndex, MessageDeleteBulk dispatch) {
/* 298 */     return new MessageDeleteBulkAction(shardIndex, dispatch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MessageReactionAddAction messageReactionAdd(int shardIndex, MessageReactionAdd dispatch) {
/* 309 */     return new MessageReactionAddAction(shardIndex, dispatch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MessageReactionRemoveAction messageReactionRemove(int shardIndex, MessageReactionRemove dispatch) {
/* 320 */     return new MessageReactionRemoveAction(shardIndex, dispatch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MessageReactionRemoveAllAction messageReactionRemoveAll(int shardIndex, MessageReactionRemoveAll dispatch) {
/* 332 */     return new MessageReactionRemoveAllAction(shardIndex, dispatch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MessageReactionRemoveEmojiAction messageReactionRemoveEmoji(int shardIndex, MessageReactionRemoveEmoji dispatch) {
/* 344 */     return new MessageReactionRemoveEmojiAction(shardIndex, dispatch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MessageUpdateAction messageUpdate(int shardIndex, MessageUpdate dispatch) {
/* 355 */     return new MessageUpdateAction(shardIndex, dispatch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PresenceUpdateAction presenceUpdate(int shardIndex, PresenceUpdate dispatch) {
/* 366 */     return new PresenceUpdateAction(shardIndex, dispatch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ReadyAction ready(Ready dispatch) {
/* 376 */     return new ReadyAction(dispatch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static UserUpdateAction userUpdate(int shardIndex, UserUpdate dispatch) {
/* 387 */     return new UserUpdateAction(shardIndex, dispatch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static VoiceStateUpdateDispatchAction voiceStateUpdateDispatch(int shardIndex, VoiceStateUpdateDispatch dispatch) {
/* 399 */     return new VoiceStateUpdateDispatchAction(shardIndex, dispatch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CompleteGuildMembersAction completeGuildMembers(long guildId) {
/* 409 */     return new CompleteGuildMembersAction(guildId);
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\action\gateway\GatewayActions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */