/*    */ package discord4j.common.store.action.gateway;
/*    */ 
/*    */ import discord4j.discordjson.json.gateway.MessageReactionAdd;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MessageReactionAddAction
/*    */   extends ShardAwareAction<Void>
/*    */ {
/*    */   private final MessageReactionAdd messageReactionAdd;
/*    */   
/*    */   MessageReactionAddAction(int shardIndex, MessageReactionAdd messageReactionAdd) {
/* 27 */     super(shardIndex);
/* 28 */     this.messageReactionAdd = messageReactionAdd;
/*    */   }
/*    */   
/*    */   public MessageReactionAdd getMessageReactionAdd() {
/* 32 */     return this.messageReactionAdd;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\action\gateway\MessageReactionAddAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */