package discord4j.common.store.action.read;

import discord4j.common.store.api.StoreAction;
import discord4j.discordjson.json.GuildData;

public class GetGuildsAction implements StoreAction<GuildData> {}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\action\read\GetGuildsAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */