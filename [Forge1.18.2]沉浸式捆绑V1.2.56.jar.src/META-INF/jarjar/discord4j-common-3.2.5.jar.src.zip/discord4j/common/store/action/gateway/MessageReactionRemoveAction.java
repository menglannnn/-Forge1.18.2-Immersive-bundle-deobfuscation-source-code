/*    */ package discord4j.common.store.action.gateway;
/*    */ 
/*    */ import discord4j.discordjson.json.gateway.MessageReactionRemove;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MessageReactionRemoveAction
/*    */   extends ShardAwareAction<Void>
/*    */ {
/*    */   private final MessageReactionRemove messageReactionRemove;
/*    */   
/*    */   MessageReactionRemoveAction(int shardIndex, MessageReactionRemove messageReactionRemove) {
/* 27 */     super(shardIndex);
/* 28 */     this.messageReactionRemove = messageReactionRemove;
/*    */   }
/*    */   
/*    */   public MessageReactionRemove getMessageReactionRemove() {
/* 32 */     return this.messageReactionRemove;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\action\gateway\MessageReactionRemoveAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */