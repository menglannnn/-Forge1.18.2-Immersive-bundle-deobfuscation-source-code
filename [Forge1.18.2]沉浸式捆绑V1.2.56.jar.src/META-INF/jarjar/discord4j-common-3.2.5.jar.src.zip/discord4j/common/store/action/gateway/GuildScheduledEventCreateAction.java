/*    */ package discord4j.common.store.action.gateway;
/*    */ 
/*    */ import discord4j.discordjson.json.gateway.GuildScheduledEventCreate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GuildScheduledEventCreateAction
/*    */   extends ShardAwareAction<Void>
/*    */ {
/*    */   private final GuildScheduledEventCreate guildScheduledEventCreate;
/*    */   
/*    */   GuildScheduledEventCreateAction(int shardIndex, GuildScheduledEventCreate guildScheduledEventCreate) {
/* 27 */     super(shardIndex);
/* 28 */     this.guildScheduledEventCreate = guildScheduledEventCreate;
/*    */   }
/*    */   
/*    */   public GuildScheduledEventCreate getGuildScheduledEventCreate() {
/* 32 */     return this.guildScheduledEventCreate;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\action\gateway\GuildScheduledEventCreateAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */