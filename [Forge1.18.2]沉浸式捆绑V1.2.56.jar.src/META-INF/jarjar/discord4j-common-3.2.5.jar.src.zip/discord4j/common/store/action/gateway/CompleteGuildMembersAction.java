/*    */ package discord4j.common.store.action.gateway;
/*    */ 
/*    */ import discord4j.common.store.api.StoreAction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompleteGuildMembersAction
/*    */   implements StoreAction<Void>
/*    */ {
/*    */   private final long guildId;
/*    */   
/*    */   CompleteGuildMembersAction(long guildId) {
/* 27 */     this.guildId = guildId;
/*    */   }
/*    */   
/*    */   public long getGuildId() {
/* 31 */     return this.guildId;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\action\gateway\CompleteGuildMembersAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */