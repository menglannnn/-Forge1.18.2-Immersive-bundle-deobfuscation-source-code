/*    */ package discord4j.common.store.action.gateway;
/*    */ 
/*    */ import discord4j.discordjson.json.gateway.GuildScheduledEventUserRemove;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GuildScheduledEventUserRemoveAction
/*    */   extends ShardAwareAction<Void>
/*    */ {
/*    */   private final GuildScheduledEventUserRemove userRemove;
/*    */   
/*    */   public GuildScheduledEventUserRemoveAction(int shardIndex, GuildScheduledEventUserRemove userRemove) {
/* 27 */     super(shardIndex);
/* 28 */     this.userRemove = userRemove;
/*    */   }
/*    */   
/*    */   public GuildScheduledEventUserRemove getUserRemove() {
/* 32 */     return this.userRemove;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\action\gateway\GuildScheduledEventUserRemoveAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */