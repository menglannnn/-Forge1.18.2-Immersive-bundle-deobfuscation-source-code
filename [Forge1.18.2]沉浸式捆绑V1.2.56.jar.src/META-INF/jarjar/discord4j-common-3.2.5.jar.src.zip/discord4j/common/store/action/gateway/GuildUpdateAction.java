/*    */ package discord4j.common.store.action.gateway;
/*    */ 
/*    */ import discord4j.discordjson.json.GuildData;
/*    */ import discord4j.discordjson.json.gateway.GuildUpdate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GuildUpdateAction
/*    */   extends ShardAwareAction<GuildData>
/*    */ {
/*    */   private final GuildUpdate guildUpdate;
/*    */   
/*    */   GuildUpdateAction(int shardIndex, GuildUpdate guildUpdate) {
/* 28 */     super(shardIndex);
/* 29 */     this.guildUpdate = guildUpdate;
/*    */   }
/*    */   
/*    */   public GuildUpdate getGuildUpdate() {
/* 33 */     return this.guildUpdate;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\action\gateway\GuildUpdateAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */