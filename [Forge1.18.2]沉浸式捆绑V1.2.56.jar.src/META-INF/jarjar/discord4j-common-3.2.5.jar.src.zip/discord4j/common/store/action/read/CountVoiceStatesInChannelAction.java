/*    */ package discord4j.common.store.action.read;
/*    */ 
/*    */ import discord4j.common.store.api.StoreAction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CountVoiceStatesInChannelAction
/*    */   implements StoreAction<Long>
/*    */ {
/*    */   private final long guildId;
/*    */   private final long channelId;
/*    */   
/*    */   CountVoiceStatesInChannelAction(long guildId, long channelId) {
/* 28 */     this.guildId = guildId;
/* 29 */     this.channelId = channelId;
/*    */   }
/*    */   
/*    */   public long getGuildId() {
/* 33 */     return this.guildId;
/*    */   }
/*    */   
/*    */   public long getChannelId() {
/* 37 */     return this.channelId;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\action\read\CountVoiceStatesInChannelAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */