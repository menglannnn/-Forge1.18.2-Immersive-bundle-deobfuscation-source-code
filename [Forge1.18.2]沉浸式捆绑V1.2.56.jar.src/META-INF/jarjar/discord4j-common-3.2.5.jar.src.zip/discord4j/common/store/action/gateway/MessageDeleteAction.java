/*    */ package discord4j.common.store.action.gateway;
/*    */ 
/*    */ import discord4j.discordjson.json.MessageData;
/*    */ import discord4j.discordjson.json.gateway.MessageDelete;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MessageDeleteAction
/*    */   extends ShardAwareAction<MessageData>
/*    */ {
/*    */   private final MessageDelete messageDelete;
/*    */   
/*    */   MessageDeleteAction(int shardIndex, MessageDelete messageDelete) {
/* 28 */     super(shardIndex);
/* 29 */     this.messageDelete = messageDelete;
/*    */   }
/*    */   
/*    */   public MessageDelete getMessageDelete() {
/* 33 */     return this.messageDelete;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\action\gateway\MessageDeleteAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */