/*    */ package discord4j.common.store.action.gateway;
/*    */ 
/*    */ import discord4j.discordjson.json.ChannelData;
/*    */ import discord4j.discordjson.json.gateway.ChannelDelete;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ChannelDeleteAction
/*    */   extends ShardAwareAction<ChannelData>
/*    */ {
/*    */   private final ChannelDelete channelCreate;
/*    */   
/*    */   ChannelDeleteAction(int shardIndex, ChannelDelete channelCreate) {
/* 28 */     super(shardIndex);
/* 29 */     this.channelCreate = channelCreate;
/*    */   }
/*    */   
/*    */   public ChannelDelete getChannelDelete() {
/* 33 */     return this.channelCreate;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\action\gateway\ChannelDeleteAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */