/*    */ package discord4j.common.store.action.read;
/*    */ 
/*    */ import discord4j.common.store.api.StoreAction;
/*    */ import discord4j.discordjson.json.MessageData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GetMessageByIdAction
/*    */   implements StoreAction<MessageData>
/*    */ {
/*    */   private final long channelId;
/*    */   private final long messageId;
/*    */   
/*    */   GetMessageByIdAction(long channelId, long messageId) {
/* 29 */     this.channelId = channelId;
/* 30 */     this.messageId = messageId;
/*    */   }
/*    */   
/*    */   public long getChannelId() {
/* 34 */     return this.channelId;
/*    */   }
/*    */   
/*    */   public long getMessageId() {
/* 38 */     return this.messageId;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\action\read\GetMessageByIdAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */