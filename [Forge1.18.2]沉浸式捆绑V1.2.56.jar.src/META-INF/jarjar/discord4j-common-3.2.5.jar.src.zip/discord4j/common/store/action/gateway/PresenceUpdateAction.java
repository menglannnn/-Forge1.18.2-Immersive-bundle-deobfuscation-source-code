/*    */ package discord4j.common.store.action.gateway;
/*    */ 
/*    */ import discord4j.common.store.api.object.PresenceAndUserData;
/*    */ import discord4j.discordjson.json.gateway.PresenceUpdate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PresenceUpdateAction
/*    */   extends ShardAwareAction<PresenceAndUserData>
/*    */ {
/*    */   private final PresenceUpdate presenceUpdate;
/*    */   
/*    */   PresenceUpdateAction(int shardIndex, PresenceUpdate presenceUpdate) {
/* 28 */     super(shardIndex);
/* 29 */     this.presenceUpdate = presenceUpdate;
/*    */   }
/*    */   
/*    */   public PresenceUpdate getPresenceUpdate() {
/* 33 */     return this.presenceUpdate;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\action\gateway\PresenceUpdateAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */