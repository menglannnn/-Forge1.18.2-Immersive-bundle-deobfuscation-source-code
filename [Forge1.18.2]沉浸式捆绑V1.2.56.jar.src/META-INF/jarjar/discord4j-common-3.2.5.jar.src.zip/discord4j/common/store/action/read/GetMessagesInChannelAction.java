/*    */ package discord4j.common.store.action.read;
/*    */ 
/*    */ import discord4j.common.store.api.StoreAction;
/*    */ import discord4j.discordjson.json.MessageData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GetMessagesInChannelAction
/*    */   implements StoreAction<MessageData>
/*    */ {
/*    */   private final long channelId;
/*    */   
/*    */   GetMessagesInChannelAction(long channelId) {
/* 28 */     this.channelId = channelId;
/*    */   }
/*    */   
/*    */   public long getChannelId() {
/* 32 */     return this.channelId;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\action\read\GetMessagesInChannelAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */