/*    */ package discord4j.common.store.action.read;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CountTotalEmojisAction
/*    */   extends CountTotalAction
/*    */ {
/*    */   CountTotalEmojisAction() {
/* 23 */     super(CountTotalAction.CountableEntity.EMOJIS);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\action\read\CountTotalEmojisAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */