/*    */ package discord4j.common.store.action.gateway;
/*    */ 
/*    */ import discord4j.discordjson.json.gateway.GuildCreate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GuildCreateAction
/*    */   extends ShardAwareAction<Void>
/*    */ {
/*    */   private final GuildCreate guildCreate;
/*    */   
/*    */   GuildCreateAction(int shardIndex, GuildCreate guildCreate) {
/* 27 */     super(shardIndex);
/* 28 */     this.guildCreate = guildCreate;
/*    */   }
/*    */   
/*    */   public GuildCreate getGuildCreate() {
/* 32 */     return this.guildCreate;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\action\gateway\GuildCreateAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */