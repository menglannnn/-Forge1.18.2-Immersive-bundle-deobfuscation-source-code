/*    */ package discord4j.common.store.action.gateway;
/*    */ 
/*    */ import discord4j.discordjson.json.MessageData;
/*    */ import discord4j.discordjson.json.gateway.MessageDeleteBulk;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MessageDeleteBulkAction
/*    */   extends ShardAwareAction<Set<MessageData>>
/*    */ {
/*    */   private final MessageDeleteBulk messageDeleteBulk;
/*    */   
/*    */   MessageDeleteBulkAction(int shardIndex, MessageDeleteBulk messageDeleteBulk) {
/* 30 */     super(shardIndex);
/* 31 */     this.messageDeleteBulk = messageDeleteBulk;
/*    */   }
/*    */   
/*    */   public MessageDeleteBulk getMessageDeleteBulk() {
/* 35 */     return this.messageDeleteBulk;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\action\gateway\MessageDeleteBulkAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */