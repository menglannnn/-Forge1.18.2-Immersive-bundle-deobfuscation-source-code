/*    */ package discord4j.common.store.action.gateway;
/*    */ 
/*    */ import discord4j.discordjson.json.MessageData;
/*    */ import discord4j.discordjson.json.gateway.MessageUpdate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MessageUpdateAction
/*    */   extends ShardAwareAction<MessageData>
/*    */ {
/*    */   private final MessageUpdate messageUpdate;
/*    */   
/*    */   MessageUpdateAction(int shardIndex, MessageUpdate messageUpdate) {
/* 28 */     super(shardIndex);
/* 29 */     this.messageUpdate = messageUpdate;
/*    */   }
/*    */   
/*    */   public MessageUpdate getMessageUpdate() {
/* 33 */     return this.messageUpdate;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\action\gateway\MessageUpdateAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */