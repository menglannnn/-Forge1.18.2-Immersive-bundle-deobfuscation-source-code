/*    */ package discord4j.common.store.action.gateway;
/*    */ 
/*    */ import discord4j.common.store.api.StoreAction;
/*    */ import discord4j.discordjson.json.gateway.Ready;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReadyAction
/*    */   implements StoreAction<Void>
/*    */ {
/*    */   private final Ready ready;
/*    */   
/*    */   ReadyAction(Ready ready) {
/* 28 */     this.ready = ready;
/*    */   }
/*    */   
/*    */   public Ready getReady() {
/* 32 */     return this.ready;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\action\gateway\ReadyAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */