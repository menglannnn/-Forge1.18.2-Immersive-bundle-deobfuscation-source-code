/*    */ package discord4j.common.store.action.gateway;
/*    */ 
/*    */ import discord4j.discordjson.json.StickerData;
/*    */ import discord4j.discordjson.json.gateway.GuildStickersUpdate;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GuildStickersUpdateAction
/*    */   extends ShardAwareAction<Set<StickerData>>
/*    */ {
/*    */   private final GuildStickersUpdate guildStickersUpdate;
/*    */   
/*    */   GuildStickersUpdateAction(int shardIndex, GuildStickersUpdate guildStickersUpdate) {
/* 29 */     super(shardIndex);
/* 30 */     this.guildStickersUpdate = guildStickersUpdate;
/*    */   }
/*    */   
/*    */   public GuildStickersUpdate getGuildStickersUpdate() {
/* 34 */     return this.guildStickersUpdate;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\action\gateway\GuildStickersUpdateAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */