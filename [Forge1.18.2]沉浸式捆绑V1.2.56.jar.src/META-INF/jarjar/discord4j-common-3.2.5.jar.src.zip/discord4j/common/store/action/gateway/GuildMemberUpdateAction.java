/*    */ package discord4j.common.store.action.gateway;
/*    */ 
/*    */ import discord4j.discordjson.json.MemberData;
/*    */ import discord4j.discordjson.json.gateway.GuildMemberUpdate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GuildMemberUpdateAction
/*    */   extends ShardAwareAction<MemberData>
/*    */ {
/*    */   private final GuildMemberUpdate guildMemberUpdate;
/*    */   
/*    */   GuildMemberUpdateAction(int shardIndex, GuildMemberUpdate guildMemberUpdate) {
/* 28 */     super(shardIndex);
/* 29 */     this.guildMemberUpdate = guildMemberUpdate;
/*    */   }
/*    */   
/*    */   public GuildMemberUpdate getGuildMemberUpdate() {
/* 33 */     return this.guildMemberUpdate;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\action\gateway\GuildMemberUpdateAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */