/*    */ package discord4j.common.store.action.read;
/*    */ 
/*    */ import discord4j.common.store.api.StoreAction;
/*    */ import discord4j.discordjson.json.AutoModRuleData;
/*    */ 
/*    */ public class GetAutoModRuleByIdAction implements StoreAction<AutoModRuleData> {
/*    */   private final long guildId;
/*    */   private final long autoModRuleId;
/*    */   
/*    */   GetAutoModRuleByIdAction(long guildId, long autoModRuleId) {
/* 11 */     this.guildId = guildId;
/* 12 */     this.autoModRuleId = autoModRuleId;
/*    */   }
/*    */   
/*    */   public long getGuildId() {
/* 16 */     return this.guildId;
/*    */   }
/*    */   
/*    */   public long getAutoModRuleId() {
/* 20 */     return this.autoModRuleId;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\action\read\GetAutoModRuleByIdAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */