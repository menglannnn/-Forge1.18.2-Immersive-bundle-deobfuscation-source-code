/*     */ package discord4j.common.store.legacy;
/*     */ 
/*     */ import discord4j.discordjson.json.ChannelData;
/*     */ import discord4j.discordjson.json.EmojiData;
/*     */ import discord4j.discordjson.json.GuildData;
/*     */ import discord4j.discordjson.json.GuildScheduledEventData;
/*     */ import discord4j.discordjson.json.MemberData;
/*     */ import discord4j.discordjson.json.MessageData;
/*     */ import discord4j.discordjson.json.PresenceData;
/*     */ import discord4j.discordjson.json.RoleData;
/*     */ import discord4j.discordjson.json.StickerData;
/*     */ import discord4j.discordjson.json.UserData;
/*     */ import discord4j.discordjson.json.VoiceStateData;
/*     */ import discord4j.store.api.Store;
/*     */ import discord4j.store.api.primitive.LongObjStore;
/*     */ import discord4j.store.api.service.StoreService;
/*     */ import discord4j.store.api.util.LongLongTuple2;
/*     */ import discord4j.store.api.util.StoreContext;
/*     */ import java.util.Collections;
/*     */ import java.util.Set;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.Logger;
/*     */ import reactor.util.Loggers;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StateHolder
/*     */ {
/*  57 */   private static final Logger log = Loggers.getLogger(StateHolder.class);
/*     */   
/*     */   private final StoreService storeService;
/*     */   
/*     */   private final LongObjStore<ChannelData> channelStore;
/*     */   
/*     */   private final LongObjStore<GuildData> guildStore;
/*     */   private final Store<LongLongTuple2, GuildScheduledEventData> guildEventsStore;
/*     */   private final Store<LongLongTuple2, Set> guildEventsUsersStore;
/*     */   private final LongObjStore<EmojiData> guildEmojiStore;
/*     */   private final LongObjStore<StickerData> guildStickerStore;
/*     */   private final Store<LongLongTuple2, MemberData> memberStore;
/*     */   private final LongObjStore<MessageData> messageStore;
/*     */   private final Store<LongLongTuple2, PresenceData> presenceStore;
/*     */   private final LongObjStore<RoleData> roleStore;
/*     */   private final LongObjStore<UserData> userStore;
/*     */   private final Store<LongLongTuple2, VoiceStateData> voiceStateStore;
/*     */   
/*     */   public StateHolder(StoreService service) {
/*  76 */     this.storeService = service;
/*     */     
/*  78 */     service.init(new StoreContext(Collections.singletonMap("messageClass", MessageData.class)));
/*     */     
/*  80 */     this.channelStore = service.provideLongObjStore(ChannelData.class);
/*  81 */     log.debug("Channel storage           : {}", new Object[] { this.channelStore });
/*     */     
/*  83 */     this.guildStore = service.provideLongObjStore(GuildData.class);
/*  84 */     log.debug("Guild storage             : {}", new Object[] { this.guildStore });
/*     */     
/*  86 */     this.guildStickerStore = service.provideLongObjStore(StickerData.class);
/*  87 */     log.debug("Guild sticker storage : {}", new Object[] { this.guildStickerStore });
/*     */     
/*  89 */     this.guildEventsStore = service.provideGenericStore(LongLongTuple2.class, GuildScheduledEventData.class);
/*  90 */     log.debug("Guild event storage       : {}", new Object[] { this.guildEventsStore });
/*     */     
/*  92 */     this.guildEventsUsersStore = service.provideGenericStore(LongLongTuple2.class, Set.class);
/*  93 */     log.debug("Guild event users storage : {}", new Object[] { this.guildEventsUsersStore });
/*     */     
/*  95 */     this.guildEmojiStore = service.provideLongObjStore(EmojiData.class);
/*  96 */     log.debug("Guild emoji storage       : {}", new Object[] { this.guildEmojiStore });
/*     */     
/*  98 */     this.memberStore = service.provideGenericStore(LongLongTuple2.class, MemberData.class);
/*  99 */     log.debug("Member storage            : {}", new Object[] { this.memberStore });
/*     */     
/* 101 */     this.messageStore = service.provideLongObjStore(MessageData.class);
/* 102 */     log.debug("Message storage           : {}", new Object[] { this.messageStore });
/*     */     
/* 104 */     this.presenceStore = service.provideGenericStore(LongLongTuple2.class, PresenceData.class);
/* 105 */     log.debug("Presence storage          : {}", new Object[] { this.presenceStore });
/*     */     
/* 107 */     this.roleStore = service.provideLongObjStore(RoleData.class);
/* 108 */     log.debug("Role storage              : {}", new Object[] { this.roleStore });
/*     */     
/* 110 */     this.userStore = service.provideLongObjStore(UserData.class);
/* 111 */     log.debug("User storage              : {}", new Object[] { this.userStore });
/*     */     
/* 113 */     this.voiceStateStore = service.provideGenericStore(LongLongTuple2.class, VoiceStateData.class);
/* 114 */     log.debug("Voice state storage       : {}", new Object[] { this.voiceStateStore });
/*     */   }
/*     */   
/*     */   public StoreService getStoreService() {
/* 118 */     return this.storeService;
/*     */   }
/*     */   
/*     */   public LongObjStore<ChannelData> getChannelStore() {
/* 122 */     return this.channelStore;
/*     */   }
/*     */   
/*     */   public LongObjStore<GuildData> getGuildStore() {
/* 126 */     return this.guildStore;
/*     */   }
/*     */   
/*     */   public LongObjStore<StickerData> getGuildStickerStore() {
/* 130 */     return this.guildStickerStore;
/*     */   }
/*     */   
/*     */   public Store<LongLongTuple2, GuildScheduledEventData> getGuildEventsStore() {
/* 134 */     return this.guildEventsStore;
/*     */   }
/*     */   
/*     */   public Store<LongLongTuple2, Set> getGuildEventsUsersStore() {
/* 138 */     return this.guildEventsUsersStore;
/*     */   }
/*     */   
/*     */   public LongObjStore<EmojiData> getGuildEmojiStore() {
/* 142 */     return this.guildEmojiStore;
/*     */   }
/*     */   
/*     */   public Store<LongLongTuple2, MemberData> getMemberStore() {
/* 146 */     return this.memberStore;
/*     */   }
/*     */   
/*     */   public LongObjStore<MessageData> getMessageStore() {
/* 150 */     return this.messageStore;
/*     */   }
/*     */   
/*     */   public Store<LongLongTuple2, PresenceData> getPresenceStore() {
/* 154 */     return this.presenceStore;
/*     */   }
/*     */   
/*     */   public LongObjStore<RoleData> getRoleStore() {
/* 158 */     return this.roleStore;
/*     */   }
/*     */   
/*     */   public LongObjStore<UserData> getUserStore() {
/* 162 */     return this.userStore;
/*     */   }
/*     */   
/*     */   public Store<LongLongTuple2, VoiceStateData> getVoiceStateStore() {
/* 166 */     return this.voiceStateStore;
/*     */   }
/*     */   
/*     */   public Mono<Void> invalidateStores() {
/* 170 */     return this.channelStore.invalidate()
/* 171 */       .and((Publisher)this.guildStore.invalidate())
/* 172 */       .and((Publisher)this.guildEmojiStore.invalidate())
/* 173 */       .and((Publisher)this.guildEventsStore.invalidate())
/* 174 */       .and((Publisher)this.memberStore.invalidate())
/* 175 */       .and((Publisher)this.messageStore.invalidate())
/* 176 */       .and((Publisher)this.presenceStore.invalidate())
/* 177 */       .and((Publisher)this.roleStore.invalidate())
/* 178 */       .and((Publisher)this.userStore.invalidate())
/* 179 */       .and((Publisher)this.voiceStateStore.invalidate());
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\legacy\StateHolder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */