/*      */ package discord4j.common.store.legacy;
/*      */ import discord4j.common.util.Snowflake;
/*      */ import discord4j.discordjson.Id;
/*      */ import discord4j.discordjson.json.ChannelData;
/*      */ import discord4j.discordjson.json.EmojiData;
/*      */ import discord4j.discordjson.json.GuildCreateData;
/*      */ import discord4j.discordjson.json.GuildData;
/*      */ import discord4j.discordjson.json.ImmutableGuildData;
/*      */ import discord4j.discordjson.json.ImmutableMemberData;
/*      */ import discord4j.discordjson.json.ImmutableMessageData;
/*      */ import discord4j.discordjson.json.ImmutableReactionData;
/*      */ import discord4j.discordjson.json.MemberData;
/*      */ import discord4j.discordjson.json.MessageData;
/*      */ import discord4j.discordjson.json.PartialMessageData;
/*      */ import discord4j.discordjson.json.PartialUserData;
/*      */ import discord4j.discordjson.json.PresenceData;
/*      */ import discord4j.discordjson.json.ReactionData;
/*      */ import discord4j.discordjson.json.RoleData;
/*      */ import discord4j.discordjson.json.StickerData;
/*      */ import discord4j.discordjson.json.UserData;
/*      */ import discord4j.discordjson.json.VoiceStateData;
/*      */ import discord4j.discordjson.json.gateway.GuildMemberUpdate;
/*      */ import discord4j.discordjson.json.gateway.GuildRoleDelete;
/*      */ import discord4j.discordjson.json.gateway.GuildScheduledEventUserAdd;
/*      */ import discord4j.discordjson.json.gateway.GuildStickersUpdate;
/*      */ import discord4j.discordjson.json.gateway.GuildUpdate;
/*      */ import discord4j.discordjson.json.gateway.MessageReactionAdd;
/*      */ import discord4j.discordjson.json.gateway.PresenceUpdate;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import discord4j.store.api.util.LongLongTuple2;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import java.util.Set;
/*      */ import java.util.stream.Collectors;
/*      */ import org.reactivestreams.Publisher;
/*      */ import org.reactivestreams.Subscription;
/*      */ import reactor.core.publisher.Flux;
/*      */ import reactor.core.publisher.Mono;
/*      */ import reactor.core.publisher.SignalType;
/*      */ import reactor.util.function.Tuple2;
/*      */ import reactor.util.function.Tuples;
/*      */ 
/*      */ public class LegacyStoreLayout implements StoreLayout, DataAccessor, GatewayDataUpdater {
/*   45 */   private static final Logger log = Loggers.getLogger(LegacyStoreLayout.class);
/*      */   
/*      */   private final StateHolder stateHolder;
/*      */   
/*      */   private LegacyStoreLayout(StoreService storeService) {
/*   50 */     this.stateHolder = new StateHolder(storeService);
/*      */   }
/*      */   
/*      */   public static LegacyStoreLayout of(StoreService storeService) {
/*   54 */     return new LegacyStoreLayout(storeService);
/*      */   }
/*      */ 
/*      */   
/*      */   public DataAccessor getDataAccessor() {
/*   59 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public GatewayDataUpdater getGatewayDataUpdater() {
/*   64 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Long> countChannels() {
/*   73 */     return this.stateHolder.getChannelStore().count();
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Long> countChannelsInGuild(long guildId) {
/*   78 */     return getChannelsInGuild(guildId).count();
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Long> countStickers() {
/*   83 */     return this.stateHolder.getGuildStickerStore().count();
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Long> countStickersInGuild(long guildId) {
/*   88 */     return getStickersInGuild(guildId).count();
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Long> countEmojis() {
/*   93 */     return this.stateHolder.getGuildEmojiStore().count();
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Long> countEmojisInGuild(long guildId) {
/*   98 */     return getEmojisInGuild(guildId).count();
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Long> countGuilds() {
/*  103 */     return this.stateHolder.getGuildStore().count();
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Long> countMembers() {
/*  108 */     return this.stateHolder.getMemberStore().count();
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Long> countMembersInGuild(long guildId) {
/*  113 */     return getMembersInGuild(guildId).count();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Long> countExactMembersInGuild(long guildId) {
/*  119 */     return countMembersInGuild(guildId);
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Long> countMessages() {
/*  124 */     return this.stateHolder.getMessageStore().count();
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Long> countMessagesInChannel(long channelId) {
/*  129 */     return getMessagesInChannel(channelId).count();
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Long> countPresences() {
/*  134 */     return this.stateHolder.getPresenceStore().count();
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Long> countPresencesInGuild(long guildId) {
/*  139 */     return getPresencesInGuild(guildId).count();
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Long> countRoles() {
/*  144 */     return this.stateHolder.getRoleStore().count();
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Long> countRolesInGuild(long guildId) {
/*  149 */     return getRolesInGuild(guildId).count();
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Long> countUsers() {
/*  154 */     return this.stateHolder.getUserStore().count();
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Long> countVoiceStates() {
/*  159 */     return this.stateHolder.getVoiceStateStore().count();
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Long> countVoiceStatesInGuild(long guildId) {
/*  164 */     return getVoiceStatesInGuild(guildId).count();
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Long> countVoiceStatesInChannel(long guildId, long channelId) {
/*  169 */     return getVoiceStatesInChannel(guildId, channelId).count();
/*      */   }
/*      */ 
/*      */   
/*      */   public Flux<ChannelData> getChannels() {
/*  174 */     return this.stateHolder.getChannelStore().values();
/*      */   }
/*      */ 
/*      */   
/*      */   public Flux<ChannelData> getChannelsInGuild(long guildId) {
/*  179 */     return this.stateHolder.getGuildStore().find(guildId)
/*  180 */       .flatMapMany(guild -> Flux.fromStream(guild.channels().stream().map(Snowflake::asLong)))
/*  181 */       .flatMap(id -> this.stateHolder.getChannelStore().find(id));
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<ChannelData> getChannelById(long channelId) {
/*  186 */     return this.stateHolder.getChannelStore().find(channelId);
/*      */   }
/*      */ 
/*      */   
/*      */   public Flux<StickerData> getStickers() {
/*  191 */     return this.stateHolder.getGuildStickerStore().values();
/*      */   }
/*      */ 
/*      */   
/*      */   public Flux<StickerData> getStickersInGuild(long guildId) {
/*  196 */     return this.stateHolder.getGuildStore().find(guildId)
/*  197 */       .flatMapMany(guild -> Flux.fromStream(((List)guild.stickers().toOptional().orElse(Collections.emptyList())).stream().map(Snowflake::asLong)))
/*  198 */       .flatMap(id -> this.stateHolder.getGuildStickerStore().find(id));
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<StickerData> getStickerById(long guildId, long stickerId) {
/*  203 */     return this.stateHolder.getGuildStickerStore().find(stickerId);
/*      */   }
/*      */ 
/*      */   
/*      */   public Flux<EmojiData> getEmojis() {
/*  208 */     return this.stateHolder.getGuildEmojiStore().values();
/*      */   }
/*      */ 
/*      */   
/*      */   public Flux<EmojiData> getEmojisInGuild(long guildId) {
/*  213 */     return this.stateHolder.getGuildStore().find(guildId)
/*  214 */       .flatMapMany(guild -> Flux.fromStream(guild.emojis().stream().map(Snowflake::asLong)))
/*  215 */       .flatMap(id -> this.stateHolder.getGuildEmojiStore().find(id));
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<EmojiData> getEmojiById(long guildId, long emojiId) {
/*  220 */     return this.stateHolder.getGuildEmojiStore().find(emojiId);
/*      */   }
/*      */ 
/*      */   
/*      */   public Flux<GuildData> getGuilds() {
/*  225 */     return this.stateHolder.getGuildStore().values();
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<GuildData> getGuildById(long guildId) {
/*  230 */     return this.stateHolder.getGuildStore().find(guildId);
/*      */   }
/*      */ 
/*      */   
/*      */   public Flux<GuildScheduledEventData> getScheduledEventsInGuild(long guildId) {
/*  235 */     return this.stateHolder.getGuildEventsStore()
/*  236 */       .findInRange((Comparable)LongLongTuple2.of(guildId, 0L), (Comparable)LongLongTuple2.of(guildId, Long.MAX_VALUE));
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<GuildScheduledEventData> getScheduledEventById(long guildId, long eventId) {
/*  241 */     return this.stateHolder.getGuildEventsStore().find((Comparable)LongLongTuple2.of(guildId, eventId));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Flux<Id> getScheduledEventUsersInEvent(long guildId, long eventId) {
/*  247 */     return this.stateHolder.getGuildEventsUsersStore().find((Comparable)LongLongTuple2.of(guildId, eventId))
/*  248 */       .flatMapIterable(list -> list)
/*  249 */       .map(value -> Id.of(((Long)value).longValue()));
/*      */   }
/*      */ 
/*      */   
/*      */   public Flux<MemberData> getMembers() {
/*  254 */     return this.stateHolder.getMemberStore().values();
/*      */   }
/*      */ 
/*      */   
/*      */   public Flux<MemberData> getMembersInGuild(long guildId) {
/*  259 */     return this.stateHolder.getMemberStore()
/*  260 */       .findInRange((Comparable)LongLongTuple2.of(guildId, 0L), (Comparable)LongLongTuple2.of(guildId, Long.MAX_VALUE));
/*      */   }
/*      */ 
/*      */   
/*      */   public Flux<MemberData> getExactMembersInGuild(long guildId) {
/*  265 */     return this.stateHolder.getMemberStore()
/*  266 */       .findInRange((Comparable)LongLongTuple2.of(guildId, 0L), (Comparable)LongLongTuple2.of(guildId, Long.MAX_VALUE));
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<MemberData> getMemberById(long guildId, long userId) {
/*  271 */     return this.stateHolder.getMemberStore().find((Comparable)LongLongTuple2.of(guildId, userId));
/*      */   }
/*      */ 
/*      */   
/*      */   public Flux<MessageData> getMessages() {
/*  276 */     return this.stateHolder.getMessageStore().values();
/*      */   }
/*      */ 
/*      */   
/*      */   public Flux<MessageData> getMessagesInChannel(long channelId) {
/*  281 */     return this.stateHolder.getMessageStore().values()
/*  282 */       .filter(data -> (Snowflake.asLong(data.channelId()) == channelId));
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<MessageData> getMessageById(long channelId, long messageId) {
/*  287 */     return this.stateHolder.getMessageStore().find(messageId);
/*      */   }
/*      */ 
/*      */   
/*      */   public Flux<PresenceData> getPresences() {
/*  292 */     return this.stateHolder.getPresenceStore().values();
/*      */   }
/*      */ 
/*      */   
/*      */   public Flux<PresenceData> getPresencesInGuild(long guildId) {
/*  297 */     return this.stateHolder.getPresenceStore()
/*  298 */       .findInRange((Comparable)LongLongTuple2.of(guildId, 0L), (Comparable)LongLongTuple2.of(guildId, Long.MAX_VALUE));
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<PresenceData> getPresenceById(long guildId, long userId) {
/*  303 */     return this.stateHolder.getPresenceStore().find((Comparable)LongLongTuple2.of(guildId, userId));
/*      */   }
/*      */ 
/*      */   
/*      */   public Flux<RoleData> getRoles() {
/*  308 */     return this.stateHolder.getRoleStore().values();
/*      */   }
/*      */ 
/*      */   
/*      */   public Flux<RoleData> getRolesInGuild(long guildId) {
/*  313 */     return this.stateHolder.getGuildStore().find(guildId)
/*  314 */       .flatMapMany(guild -> Flux.fromStream(guild.roles().stream().map(Snowflake::asLong)))
/*  315 */       .flatMap(id -> this.stateHolder.getRoleStore().find(id));
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<RoleData> getRoleById(long guildId, long roleId) {
/*  320 */     return this.stateHolder.getRoleStore().find(roleId);
/*      */   }
/*      */ 
/*      */   
/*      */   public Flux<UserData> getUsers() {
/*  325 */     return this.stateHolder.getUserStore().values();
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<UserData> getUserById(long userId) {
/*  330 */     return this.stateHolder.getUserStore().find(userId);
/*      */   }
/*      */ 
/*      */   
/*      */   public Flux<VoiceStateData> getVoiceStates() {
/*  335 */     return this.stateHolder.getVoiceStateStore().values();
/*      */   }
/*      */ 
/*      */   
/*      */   public Flux<VoiceStateData> getVoiceStatesInChannel(long guildId, long channelId) {
/*  340 */     return this.stateHolder.getVoiceStateStore()
/*  341 */       .findInRange((Comparable)LongLongTuple2.of(guildId, 0L), (Comparable)LongLongTuple2.of(guildId, Long.MAX_VALUE))
/*  342 */       .filter(data -> data.channelId().filter(()).isPresent());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Flux<VoiceStateData> getVoiceStatesInGuild(long guildId) {
/*  349 */     return this.stateHolder.getVoiceStateStore()
/*  350 */       .findInRange((Comparable)LongLongTuple2.of(guildId, 0L), (Comparable)LongLongTuple2.of(guildId, Long.MAX_VALUE));
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<VoiceStateData> getVoiceStateById(long guildId, long userId) {
/*  355 */     return this.stateHolder.getVoiceStateStore().find((Comparable)LongLongTuple2.of(guildId, userId));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Void> onChannelCreate(int shardIndex, ChannelCreate dispatch) {
/*  364 */     Type type = Type.of(dispatch.channel().type());
/*  365 */     switch (type) { case GUILD_TEXT:
/*      */       case GUILD_VOICE:
/*      */       case GUILD_CATEGORY:
/*      */       case GUILD_NEWS:
/*      */       case GUILD_STORE:
/*      */       case GUILD_STAGE_VOICE:
/*  371 */         return saveChannel(dispatch);
/*      */       case DM: case GROUP_DM:
/*  373 */         return Mono.empty(); }
/*  374 */      throw new IllegalArgumentException("Unhandled channel type " + dispatch.channel().type());
/*      */   }
/*      */ 
/*      */   
/*      */   private Mono<Void> saveChannel(ChannelCreate dispatch) {
/*  379 */     ChannelData channel = dispatch.channel();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  387 */     Mono<Void> addChannelToGuild = this.stateHolder.getGuildStore().find(Snowflake.asLong((Id)channel.guildId().get())).map(guildData -> GuildData.builder().from(guildData).channels(ListUtil.add(guildData.channels(), channel.id())).build()).flatMap(guild -> this.stateHolder.getGuildStore().save(Long.valueOf(Snowflake.asLong(guild.id())), guild));
/*      */ 
/*      */     
/*  390 */     Mono<Void> saveChannel = this.stateHolder.getChannelStore().save(Long.valueOf(Snowflake.asLong(channel.id())), channel);
/*      */     
/*  392 */     return addChannelToGuild.then(saveChannel);
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<ChannelData> onChannelDelete(int shardIndex, ChannelDelete dispatch) {
/*  397 */     Type type = Type.of(dispatch.channel().type());
/*  398 */     switch (type) { case GUILD_TEXT:
/*      */       case GUILD_VOICE:
/*      */       case GUILD_CATEGORY:
/*      */       case GUILD_NEWS:
/*      */       case GUILD_STORE:
/*      */       case GUILD_STAGE_VOICE:
/*  404 */         return deleteChannel(dispatch);
/*      */       case DM: case GROUP_DM:
/*  406 */         return Mono.empty(); }
/*  407 */      throw new IllegalArgumentException("Unhandled channel type " + dispatch.channel().type());
/*      */   }
/*      */ 
/*      */   
/*      */   private Mono<ChannelData> deleteChannel(ChannelDelete dispatch) {
/*  412 */     ChannelData channel = dispatch.channel();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  420 */     Mono<Void> removeChannelFromGuild = this.stateHolder.getGuildStore().find(Snowflake.asLong((Id)channel.guildId().get())).map(guildData -> GuildData.builder().from(guildData).channels(ListUtil.remove(guildData.channels(), ())).build()).flatMap(guild -> this.stateHolder.getGuildStore().save(Long.valueOf(Snowflake.asLong(guild.id())), guild));
/*      */ 
/*      */     
/*  423 */     Mono<Void> deleteChannel = this.stateHolder.getChannelStore().delete(Snowflake.asLong(channel.id()));
/*      */     
/*  425 */     return removeChannelFromGuild.then(deleteChannel).thenReturn(channel);
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<ChannelData> onChannelUpdate(int shardIndex, ChannelUpdate dispatch) {
/*  430 */     Type type = Type.of(dispatch.channel().type());
/*  431 */     switch (type) { case GUILD_TEXT:
/*      */       case GUILD_VOICE:
/*      */       case GUILD_CATEGORY:
/*      */       case GUILD_NEWS:
/*      */       case GUILD_STORE:
/*      */       case GUILD_STAGE_VOICE:
/*  437 */         return updateChannel(dispatch);
/*      */       case DM: case GROUP_DM:
/*  439 */         return Mono.empty(); }
/*  440 */      throw new IllegalArgumentException("Unhandled channel type " + dispatch.channel().type());
/*      */   }
/*      */   
/*      */   private enum Type
/*      */   {
/*  445 */     UNKNOWN(-1),
/*  446 */     GUILD_TEXT(0),
/*  447 */     DM(1),
/*  448 */     GUILD_VOICE(2),
/*  449 */     GROUP_DM(3),
/*  450 */     GUILD_CATEGORY(4),
/*  451 */     GUILD_NEWS(5),
/*  452 */     GUILD_STORE(6),
/*  453 */     GUILD_STAGE_VOICE(13);
/*      */     
/*      */     private final int value;
/*      */     
/*      */     Type(int value) {
/*  458 */       this.value = value;
/*      */     }
/*      */     
/*      */     public int getValue() {
/*  462 */       return this.value;
/*      */     }
/*      */     
/*      */     public static Type of(int value) {
/*  466 */       switch (value) { case 0:
/*  467 */           return GUILD_TEXT;
/*  468 */         case 1: return DM;
/*  469 */         case 2: return GUILD_VOICE;
/*  470 */         case 3: return GROUP_DM;
/*  471 */         case 4: return GUILD_CATEGORY;
/*  472 */         case 5: return GUILD_NEWS;
/*  473 */         case 6: return GUILD_STORE;
/*  474 */         case 13: return GUILD_STAGE_VOICE; }
/*  475 */        return UNKNOWN;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private Mono<ChannelData> updateChannel(ChannelUpdate dispatch) {
/*  481 */     ChannelData channel = dispatch.channel();
/*      */     
/*  483 */     Mono<Void> saveNew = this.stateHolder.getChannelStore().save(Long.valueOf(Snowflake.asLong(channel.id())), channel);
/*      */ 
/*      */ 
/*      */     
/*  487 */     Objects.requireNonNull(saveNew); return this.stateHolder.getChannelStore().find(Snowflake.asLong(channel.id())).flatMap(saveNew::thenReturn)
/*  488 */       .switchIfEmpty(saveNew.then(Mono.empty()));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Void> onGuildCreate(int shardIndex, GuildCreate dispatch) {
/*      */     GuildCreateData createData;
/*      */     ImmutableGuildData immutableGuildData;
/*  496 */     if (dispatch.guild().large()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  504 */       ImmutableGuildCreateData immutableGuildCreateData = GuildCreateData.builder().from(dispatch.guild()).members(Collections.emptyList()).build();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  510 */       immutableGuildData = GuildData.builder().from((GuildCreateFields)immutableGuildCreateData).roles((List)immutableGuildCreateData.roles().stream().map(RoleDataFields::id).collect(Collectors.toList())).emojis((List)immutableGuildCreateData.emojis().stream().map(EmojiData::id).filter(Optional::isPresent).map(Optional::get).collect(Collectors.toList())).channels((List)immutableGuildCreateData.channels().stream().map(ChannelData::id).collect(Collectors.toList())).build();
/*      */     } else {
/*  512 */       createData = dispatch.guild();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  519 */       immutableGuildData = GuildData.builder().from((GuildCreateFields)createData).roles((List)createData.roles().stream().map(RoleDataFields::id).collect(Collectors.toList())).emojis((List)createData.emojis().stream().map(EmojiData::id).filter(Optional::isPresent).map(Optional::get).collect(Collectors.toList())).members((List)createData.members().stream().map(data -> data.user().id()).distinct().collect(Collectors.toList())).channels((List)createData.channels().stream().map(ChannelData::id).collect(Collectors.toList())).build();
/*      */     } 
/*      */     
/*  522 */     long guildId = Snowflake.asLong(immutableGuildData.id());
/*      */ 
/*      */ 
/*      */     
/*  526 */     Mono<Void> saveGuild = this.stateHolder.getGuildStore().save(Long.valueOf(guildId), immutableGuildData).doOnSubscribe(s -> log.trace("GuildCreate doOnSubscribe {}", new Object[] { Long.valueOf(guildId) })).doFinally(s -> log.trace("GuildCreate doFinally {}: {}", new Object[] { Long.valueOf(guildId), s }));
/*      */ 
/*      */     
/*  529 */     Mono<Void> saveChannels = this.stateHolder.getChannelStore().save((Publisher)Flux.fromIterable(createData.channels())
/*  530 */         .map(channel -> Tuples.of(Long.valueOf(Snowflake.asLong(channel.id())), ChannelData.builder().from(channel).guildId(guild.id()).build())));
/*      */ 
/*      */ 
/*      */     
/*  534 */     Mono<Void> saveRoles = this.stateHolder.getRoleStore().save((Publisher)Flux.fromIterable(createData.roles())
/*  535 */         .map(role -> Tuples.of(Long.valueOf(Snowflake.asLong(role.id())), role)));
/*      */ 
/*      */     
/*  538 */     Mono<Void> saveEmojis = this.stateHolder.getGuildEmojiStore().save((Publisher)Flux.fromIterable(createData.emojis())
/*  539 */         .map(emoji -> Tuples.of(Long.valueOf(Snowflake.asLong((Id)emoji.id().orElseThrow(java.util.NoSuchElementException::new))), emoji)));
/*      */ 
/*      */ 
/*      */     
/*  543 */     Mono<Void> saveMembers = this.stateHolder.getMemberStore().save((Publisher)Flux.fromIterable(createData.members())
/*  544 */         .map(member -> Tuples.of(LongLongTuple2.of(guildId, Snowflake.asLong(member.user().id())), member)));
/*      */ 
/*      */ 
/*      */     
/*  548 */     Mono<Void> saveUsers = this.stateHolder.getUserStore().save((Publisher)Flux.fromIterable(createData.members())
/*  549 */         .map(MemberData::user)
/*  550 */         .map(user -> Tuples.of(Long.valueOf(Snowflake.asLong(user.id())), user)));
/*      */ 
/*      */     
/*  553 */     Mono<Void> saveVoiceStates = this.stateHolder.getVoiceStateStore().save((Publisher)Flux.fromIterable(createData.voiceStates())
/*  554 */         .map(voiceState -> Tuples.of(LongLongTuple2.of(guildId, Snowflake.asLong(voiceState.userId())), VoiceStateData.builder().from(voiceState).guildId(guild.id()).build())));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  562 */     Mono<Void> savePresences = this.stateHolder.getPresenceStore().save((Publisher)Flux.fromIterable(createData.presences())
/*  563 */         .map(presence -> Tuples.of(LongLongTuple2.of(guildId, Snowflake.asLong(presence.user().id())), presence)));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  574 */     Mono<Void> saveOfflinePresences = Flux.fromIterable(createData.members()).filterWhen(member -> this.stateHolder.getPresenceStore().find((Comparable)LongLongTuple2.of(guildId, Snowflake.asLong(member.user().id()))).hasElement().map(())).flatMap(member -> this.stateHolder.getPresenceStore().save((Comparable)LongLongTuple2.of(guildId, Snowflake.asLong(member.user().id())), createPresence(member))).then();
/*      */     
/*  576 */     return saveGuild
/*  577 */       .and((Publisher)saveChannels)
/*  578 */       .and((Publisher)saveRoles)
/*  579 */       .and((Publisher)saveEmojis)
/*  580 */       .and((Publisher)saveMembers)
/*  581 */       .and((Publisher)saveUsers)
/*  582 */       .and((Publisher)saveVoiceStates)
/*  583 */       .and((Publisher)savePresences)
/*  584 */       .and((Publisher)saveOfflinePresences);
/*      */   }
/*      */   
/*      */   private PresenceData createPresence(MemberData member) {
/*  588 */     return (PresenceData)PresenceData.builder()
/*  589 */       .user((PartialUserData)PartialUserData.builder()
/*  590 */         .id(member.user().id())
/*  591 */         .globalName(Possible.of(member.user().globalName()))
/*  592 */         .username(member.user().username())
/*  593 */         .discriminator(member.user().discriminator())
/*  594 */         .avatar(Possible.of(member.user().avatar()))
/*  595 */         .bot(member.user().bot())
/*  596 */         .system(member.user().system())
/*  597 */         .mfaEnabled(member.user().mfaEnabled())
/*  598 */         .locale(member.user().locale())
/*  599 */         .verified(member.user().verified())
/*  600 */         .email(member.user().email().isAbsent() ? Possible.absent() : (
/*  601 */           (Optional)member.user().email().get()).map(Possible::of).orElse(Possible.absent()))
/*  602 */         .flags(member.user().flags())
/*  603 */         .premiumType(member.user().premiumType())
/*  604 */         .build())
/*  605 */       .status("offline")
/*  606 */       .clientStatus((ClientStatusData)ClientStatusData.builder()
/*  607 */         .desktop(Possible.absent())
/*  608 */         .mobile(Possible.absent())
/*  609 */         .web(Possible.absent())
/*  610 */         .build())
/*  611 */       .build();
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<GuildData> onGuildDelete(int shardIndex, GuildDelete dispatch) {
/*  616 */     long guildId = Snowflake.asLong(dispatch.guild().id());
/*      */     
/*  618 */     Mono<Void> deleteGuild = this.stateHolder.getGuildStore().delete(guildId);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  646 */     Objects.requireNonNull(deleteGuild); return this.stateHolder.getGuildStore().find(guildId).flatMap(guild -> { Flux<Long> channels = Flux.fromIterable(guild.channels()).map(Snowflake::asLong); Flux<Long> roles = Flux.fromIterable(guild.roles()).map(Snowflake::asLong); Flux<Long> emojis = Flux.fromIterable(guild.emojis()).map(Snowflake::asLong); Mono<Void> deleteChannels = this.stateHolder.getChannelStore().delete((Publisher)channels); Mono<Void> deleteRoles = this.stateHolder.getRoleStore().delete((Publisher)roles); Mono<Void> deleteEmojis = this.stateHolder.getGuildEmojiStore().delete((Publisher)emojis); Mono<Void> deleteMembers = this.stateHolder.getMemberStore().deleteInRange((Comparable)LongLongTuple2.of(guildId, 0L), (Comparable)LongLongTuple2.of(guildId, -1L)); Mono<Void> deleteVoiceStates = this.stateHolder.getVoiceStateStore().deleteInRange((Comparable)LongLongTuple2.of(guildId, 0L), (Comparable)LongLongTuple2.of(guildId, -1L)); Mono<Void> deletePresences = this.stateHolder.getPresenceStore().deleteInRange((Comparable)LongLongTuple2.of(guildId, 0L), (Comparable)LongLongTuple2.of(guildId, -1L)); return deleteChannels.and((Publisher)deleteRoles).and((Publisher)deleteEmojis).and((Publisher)deleteMembers).and((Publisher)deleteVoiceStates).and((Publisher)deletePresences).thenReturn(guild); }).flatMap(deleteGuild::thenReturn);
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Set<StickerData>> onGuildStickersUpdate(int shardIndex, GuildStickersUpdate dispatch) {
/*  651 */     long guildId = Snowflake.asLong(dispatch.guildId());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  663 */     Mono<Void> updateGuildBean = this.stateHolder.getGuildStore().find(guildId).map(guild -> GuildData.builder().from(guild).emojis((List)dispatch.stickers().stream().map(PartialStickerData::id).collect(Collectors.toList())).build()).flatMap(guild -> this.stateHolder.getGuildStore().save(Long.valueOf(guildId), guild)).doOnSubscribe(s -> log.trace("GuildStickersUpdate doOnSubscribe {}", new Object[] { Long.valueOf(guildId) })).doFinally(s -> log.trace("GuildStickersUpdate doFinally {}: {}", new Object[] { Long.valueOf(guildId), s }));
/*      */ 
/*      */     
/*  666 */     Mono<Void> saveStickers = this.stateHolder.getGuildStickerStore().saveWithLong((Publisher)Flux.fromIterable(dispatch.stickers())
/*  667 */         .map(sticker -> LongObjTuple2.of(Snowflake.asLong(sticker.id()), sticker)));
/*      */     
/*  669 */     return this.stateHolder.getGuildStore()
/*  670 */       .find(guildId)
/*  671 */       .flatMapMany(guild -> updateGuildBean.and((Publisher)saveStickers).thenMany((Publisher)Flux.fromIterable(guild.stickers().toOptional().orElse(Collections.emptyList())).map(Snowflake::asLong).flatMap(())))
/*      */ 
/*      */ 
/*      */       
/*  675 */       .collect(Collectors.toSet());
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Set<EmojiData>> onGuildEmojisUpdate(int shardIndex, GuildEmojisUpdate dispatch) {
/*  680 */     long guildId = Snowflake.asLong(dispatch.guildId());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  694 */     Mono<Void> updateGuildBean = this.stateHolder.getGuildStore().find(guildId).map(guild -> GuildData.builder().from(guild).emojis((List)dispatch.emojis().stream().map(EmojiData::id).filter(Optional::isPresent).map(Optional::get).collect(Collectors.toList())).build()).flatMap(guild -> this.stateHolder.getGuildStore().save(Long.valueOf(guildId), guild)).doOnSubscribe(s -> log.trace("GuildEmojisUpdate doOnSubscribe {}", new Object[] { Long.valueOf(guildId) })).doFinally(s -> log.trace("GuildEmojisUpdate doFinally {}: {}", new Object[] { Long.valueOf(guildId), s }));
/*      */ 
/*      */     
/*  697 */     Mono<Void> saveEmojis = this.stateHolder.getGuildEmojiStore().saveWithLong((Publisher)Flux.fromIterable(dispatch.emojis())
/*  698 */         .map(emoji -> LongObjTuple2.of(((Long)emoji.id().map(Snowflake::asLong).orElseThrow(java.util.NoSuchElementException::new)).longValue(), emoji)));
/*      */ 
/*      */ 
/*      */     
/*  702 */     return this.stateHolder.getGuildStore()
/*  703 */       .find(guildId)
/*  704 */       .flatMapMany(guild -> updateGuildBean.and((Publisher)saveEmojis).thenMany((Publisher)Flux.fromIterable(guild.emojis()).map(Snowflake::asLong).flatMap(())))
/*      */ 
/*      */ 
/*      */       
/*  708 */       .collect(Collectors.toSet());
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Void> onGuildMemberAdd(int shardIndex, GuildMemberAdd dispatch) {
/*  713 */     long guildId = Snowflake.asLong(dispatch.guildId());
/*  714 */     MemberData member = dispatch.member();
/*  715 */     UserData user = member.user();
/*  716 */     long userId = Snowflake.asLong(user.id());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  727 */     Mono<Void> addMemberId = this.stateHolder.getGuildStore().find(guildId).map(guild -> GuildData.builder().from(guild).members(ListUtil.add(guild.members(), member.user().id())).memberCount(guild.memberCount() + 1).build()).flatMap(guild -> this.stateHolder.getGuildStore().save(Long.valueOf(guildId), guild)).doOnSubscribe(s -> log.trace("GuildMemberAdd doOnSubscribe {}", new Object[] { Long.valueOf(guildId) })).doFinally(s -> log.trace("GuildMemberAdd doFinally {}: {}", new Object[] { Long.valueOf(guildId), s }));
/*      */ 
/*      */     
/*  730 */     Mono<Void> saveMember = this.stateHolder.getMemberStore().save((Comparable)LongLongTuple2.of(guildId, userId), member);
/*      */ 
/*      */     
/*  733 */     Mono<Void> saveUser = this.stateHolder.getUserStore().save(Long.valueOf(userId), user);
/*      */     
/*  735 */     return addMemberId
/*  736 */       .and((Publisher)saveMember)
/*  737 */       .and((Publisher)saveUser);
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<MemberData> onGuildMemberRemove(int shardIndex, GuildMemberRemove dispatch) {
/*  742 */     long guildId = Snowflake.asLong(dispatch.guildId());
/*  743 */     UserData userData = dispatch.user();
/*  744 */     long userId = Snowflake.asLong(userData.id());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  755 */     Mono<Void> removeMemberId = this.stateHolder.getGuildStore().find(guildId).map(guild -> GuildData.builder().from(guild).members(ListUtil.remove(guild.members(), ())).memberCount(guild.memberCount() - 1).build()).flatMap(guild -> this.stateHolder.getGuildStore().save(Long.valueOf(guildId), guild)).doOnSubscribe(s -> log.trace("GuildMemberRemove doOnSubscribe {}", new Object[] { Long.valueOf(guildId) })).doFinally(s -> log.trace("GuildMemberRemove doFinally {}: {}", new Object[] { Long.valueOf(guildId), s }));
/*      */ 
/*      */     
/*  758 */     Mono<MemberData> member = this.stateHolder.getMemberStore().find((Comparable)LongLongTuple2.of(guildId, userId));
/*      */ 
/*      */     
/*  761 */     Mono<Void> deleteMember = this.stateHolder.getMemberStore().delete((Comparable)LongLongTuple2.of(guildId, userId));
/*      */ 
/*      */     
/*  764 */     Mono<Void> deletePresence = this.stateHolder.getPresenceStore().delete((Comparable)LongLongTuple2.of(guildId, userId));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  769 */     Mono<Void> deleteOrphanUser = this.stateHolder.getMemberStore().keys().filter(key -> (key.getT1() != guildId && key.getT2() == userId)).hasElements().flatMap(hasMutualServers -> {
/*      */           Objects.requireNonNull(this.stateHolder.getUserStore());
/*      */           return Mono.just(Long.valueOf(userId)).filter(()).flatMap(this.stateHolder.getUserStore()::delete);
/*      */         });
/*  773 */     return member.flatMap(value -> Mono.when(new Publisher[] { (Publisher)removeMemberId, (Publisher)deleteMember, (Publisher)deletePresence, (Publisher)deleteOrphanUser }).thenReturn(value));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Void> onGuildMembersChunk(int shardIndex, GuildMembersChunk dispatch) {
/*  779 */     long guildId = Snowflake.asLong(dispatch.guildId());
/*  780 */     List<MemberData> members = dispatch.members();
/*      */ 
/*      */     
/*  783 */     Flux<Tuple2<LongLongTuple2, MemberData>> memberPairs = Flux.fromIterable(members).map(data -> Tuples.of(LongLongTuple2.of(guildId, Snowflake.asLong(data.user().id())), data));
/*      */ 
/*      */ 
/*      */     
/*  787 */     Flux<Tuple2<Long, UserData>> userPairs = Flux.fromIterable(members).map(data -> Tuples.of(Long.valueOf(Snowflake.asLong(data.user().id())), data.user()));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  799 */     Mono<Void> addMemberIds = this.stateHolder.getGuildStore().find(guildId).map(guild -> GuildData.builder().from(guild).members(ListUtil.addAllDistinct(guild.members(), (List)members.stream().map(()).collect(Collectors.toList()))).build()).flatMap(guild -> this.stateHolder.getGuildStore().save(Long.valueOf(guildId), guild)).doOnSubscribe(s -> log.trace("GuildMembersChunk doOnSubscribe {}", new Object[] { Long.valueOf(guildId) })).doFinally(s -> log.trace("GuildMembersChunk doFinally {}: {}", new Object[] { Long.valueOf(guildId), s }));
/*      */     
/*  801 */     Mono<Void> saveMembers = this.stateHolder.getMemberStore().save((Publisher)memberPairs);
/*      */     
/*  803 */     Mono<Void> saveUsers = this.stateHolder.getUserStore().save((Publisher)userPairs);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  813 */     Mono<Void> saveOfflinePresences = Flux.fromIterable(members).filterWhen(member -> this.stateHolder.getPresenceStore().find((Comparable)LongLongTuple2.of(guildId, Snowflake.asLong(member.user().id()))).hasElement().map(())).flatMap(member -> this.stateHolder.getPresenceStore().save((Comparable)LongLongTuple2.of(guildId, Snowflake.asLong(member.user().id())), createPresence(member))).then();
/*      */     
/*  815 */     return addMemberIds
/*  816 */       .and((Publisher)saveMembers)
/*  817 */       .and((Publisher)saveUsers)
/*  818 */       .and((Publisher)saveOfflinePresences);
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<MemberData> onGuildMemberUpdate(int shardIndex, GuildMemberUpdate dispatch) {
/*  823 */     long guildId = Snowflake.asLong(dispatch.guildId());
/*  824 */     long memberId = Snowflake.asLong(dispatch.user().id());
/*      */     
/*  826 */     LongLongTuple2 key = LongLongTuple2.of(guildId, memberId);
/*      */     
/*  828 */     return this.stateHolder.getMemberStore()
/*  829 */       .find((Comparable)key)
/*  830 */       .flatMap(oldMember -> {
/*      */           ImmutableMemberData immutableMemberData = MemberData.builder().from(oldMember).roles((List)dispatch.roles().stream().map(Id::of).collect(Collectors.toList())).user(dispatch.user()).nick(dispatch.nick()).joinedAt(dispatch.joinedAt()).premiumSince(dispatch.premiumSince()).pending(dispatch.pending()).build();
/*      */           return this.stateHolder.getMemberStore().save((Comparable)key, immutableMemberData).thenReturn(oldMember);
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Void> onGuildRoleCreate(int shardIndex, GuildRoleCreate dispatch) {
/*  847 */     long guildId = Snowflake.asLong(dispatch.guildId());
/*  848 */     RoleData role = dispatch.role();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  858 */     Mono<Void> addRoleId = this.stateHolder.getGuildStore().find(guildId).map(guild -> GuildData.builder().from(guild).addRole(role.id()).build()).flatMap(guild -> this.stateHolder.getGuildStore().save(Long.valueOf(guildId), guild)).doOnSubscribe(s -> log.trace("GuildRoleCreate doOnSubscribe {}", new Object[] { Long.valueOf(guildId) })).doFinally(s -> log.trace("GuildRoleCreate doFinally {}: {}", new Object[] { Long.valueOf(guildId), s }));
/*      */ 
/*      */     
/*  861 */     Mono<Void> saveRole = this.stateHolder.getRoleStore().save(Long.valueOf(Snowflake.asLong(role.id())), role);
/*      */     
/*  863 */     return addRoleId.and((Publisher)saveRole);
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<RoleData> onGuildRoleDelete(int shardIndex, GuildRoleDelete dispatch) {
/*  868 */     long guildId = Snowflake.asLong(dispatch.guildId());
/*  869 */     long roleId = Snowflake.asLong(dispatch.roleId());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  880 */     Mono<Void> removeRoleId = this.stateHolder.getGuildStore().find(guildId).map(guild -> GuildData.builder().from(guild).roles(ListUtil.remove(guild.roles(), ())).build()).flatMap(guild -> this.stateHolder.getGuildStore().save(Long.valueOf(guildId), guild)).doOnSubscribe(s -> log.trace("GuildRoleDelete doOnSubscribe {}", new Object[] { Long.valueOf(guildId) })).doFinally(s -> log.trace("GuildRoleDelete doFinally {}: {}", new Object[] { Long.valueOf(guildId), s }));
/*      */     
/*  882 */     Mono<Void> deleteRole = this.stateHolder.getRoleStore().delete(roleId);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  899 */     Mono<Void> removeRoleFromMembers = this.stateHolder.getGuildStore().find(guildId).flatMapMany(guild -> Flux.fromIterable(guild.members()).map(Snowflake::asLong)).flatMap(memberId -> this.stateHolder.getMemberStore().find((Comparable)LongLongTuple2.of(guildId, memberId.longValue()))).filter(member -> member.roles().contains(dispatch.roleId())).map(member -> MemberData.builder().from(member).roles(ListUtil.remove(member.roles(), ())).build()).flatMap(member -> this.stateHolder.getMemberStore().save((Comparable)LongLongTuple2.of(guildId, Snowflake.asLong(member.user().id())), member)).then();
/*      */ 
/*      */ 
/*      */     
/*  903 */     Objects.requireNonNull(removeRoleId);
/*  904 */     Objects.requireNonNull(deleteRole);
/*  905 */     Objects.requireNonNull(removeRoleFromMembers); return this.stateHolder.getRoleStore().find(roleId).flatMap(removeRoleId::thenReturn).flatMap(deleteRole::thenReturn).flatMap(removeRoleFromMembers::thenReturn);
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<RoleData> onGuildRoleUpdate(int shardIndex, GuildRoleUpdate dispatch) {
/*  910 */     RoleData role = dispatch.role();
/*  911 */     long roleId = Snowflake.asLong(role.id());
/*      */     
/*  913 */     Mono<Void> saveNew = this.stateHolder.getRoleStore().save(Long.valueOf(roleId), role);
/*      */ 
/*      */ 
/*      */     
/*  917 */     Objects.requireNonNull(saveNew); return this.stateHolder.getRoleStore().find(roleId).flatMap(saveNew::thenReturn)
/*  918 */       .switchIfEmpty(saveNew.then(Mono.empty()));
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Void> onGuildScheduledEventCreate(int shardIndex, GuildScheduledEventCreate dispatch) {
/*  923 */     LongLongTuple2 key = LongLongTuple2.of(dispatch.scheduledEvent().guildId().asLong(), dispatch.scheduledEvent().id().asLong());
/*      */     
/*  925 */     return this.stateHolder.getGuildEventsStore().save((Comparable)key, dispatch.scheduledEvent());
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<GuildScheduledEventData> onGuildScheduledEventUpdate(int shardIndex, GuildScheduledEventUpdate dispatch) {
/*  930 */     LongLongTuple2 key = LongLongTuple2.of(dispatch.scheduledEvent().guildId().asLong(), dispatch.scheduledEvent().id().asLong());
/*      */     
/*  932 */     Mono<Void> saveNew = this.stateHolder.getGuildEventsStore().save((Comparable)key, dispatch.scheduledEvent());
/*      */ 
/*      */ 
/*      */     
/*  936 */     Objects.requireNonNull(saveNew); return this.stateHolder.getGuildEventsStore().find((Comparable)key).flatMap(saveNew::thenReturn)
/*  937 */       .switchIfEmpty(saveNew.then(Mono.empty()));
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<GuildScheduledEventData> onGuildScheduledEventDelete(int shardIndex, GuildScheduledEventDelete dispatch) {
/*  942 */     LongLongTuple2 key = LongLongTuple2.of(dispatch.scheduledEvent().guildId().asLong(), dispatch.scheduledEvent().id().asLong());
/*      */     
/*  944 */     Mono<Void> deletion = this.stateHolder.getGuildEventsStore().delete((Comparable)key);
/*      */ 
/*      */ 
/*      */     
/*  948 */     Objects.requireNonNull(deletion); return this.stateHolder.getGuildEventsStore().find((Comparable)key).flatMap(deletion::thenReturn)
/*  949 */       .switchIfEmpty(deletion.then(Mono.empty()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Void> onGuildScheduledEventUserAdd(int shardIndex, GuildScheduledEventUserAdd dispatch) {
/*  956 */     LongLongTuple2 key = LongLongTuple2.of(dispatch.guildId().asLong(), dispatch.scheduledEventId().asLong());
/*      */     
/*  958 */     return this.stateHolder.getGuildEventsUsersStore().find((Comparable)key)
/*  959 */       .defaultIfEmpty(new HashSet())
/*  960 */       .map(set -> {
/*      */           set.add(Long.valueOf(dispatch.userId().asLong()));
/*      */           
/*      */           return set;
/*  964 */         }).flatMap(set -> this.stateHolder.getGuildEventsUsersStore().save((Comparable)key, set));
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Void> onGuildScheduledEventUserRemove(int shardIndex, GuildScheduledEventUserRemove dispatch) {
/*  969 */     LongLongTuple2 key = LongLongTuple2.of(dispatch.guildId().asLong(), dispatch.scheduledEventId().asLong());
/*      */     
/*  971 */     return this.stateHolder.getGuildEventsUsersStore().find((Comparable)key)
/*  972 */       .defaultIfEmpty(new HashSet())
/*  973 */       .map(set -> {
/*      */           set.remove(Long.valueOf(dispatch.userId().asLong()));
/*      */           
/*      */           return set;
/*  977 */         }).flatMap(set -> this.stateHolder.getGuildEventsUsersStore().save((Comparable)key, set));
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<GuildData> onGuildUpdate(int shardIndex, GuildUpdate dispatch) {
/*  982 */     long guildId = Snowflake.asLong(dispatch.guild().id());
/*      */     
/*  984 */     return this.stateHolder.getGuildStore()
/*  985 */       .find(guildId)
/*  986 */       .flatMap(oldGuildData -> {
/*      */           ImmutableGuildData immutableGuildData = GuildData.builder().from(oldGuildData).from((GuildUpdateFields)dispatch.guild()).roles((List)dispatch.guild().roles().stream().map(RoleDataFields::id).collect(Collectors.toList())).emojis((List)dispatch.guild().emojis().stream().map(EmojiData::id).filter(Optional::isPresent).map(Optional::get).collect(Collectors.toList())).build();
/*      */           return this.stateHolder.getGuildStore().save(Long.valueOf(guildId), immutableGuildData).doOnSubscribe(()).doFinally(()).thenReturn(oldGuildData);
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Void> onShardInvalidation(int shardIndex, InvalidationCause cause) {
/* 1011 */     return Mono.empty();
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Void> onMessageCreate(int shardIndex, MessageCreate dispatch) {
/* 1016 */     MessageData message = dispatch.message();
/* 1017 */     long messageId = Snowflake.asLong(message.id());
/* 1018 */     long channelId = Snowflake.asLong(message.channelId());
/*      */ 
/*      */     
/* 1021 */     Mono<Void> saveMessage = this.stateHolder.getMessageStore().save(Long.valueOf(messageId), message);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1029 */     Mono<Void> editLastMessageId = this.stateHolder.getChannelStore().find(channelId).map(channel -> ChannelData.builder().from(channel).lastMessageId(message.id()).build()).flatMap(channelBean -> this.stateHolder.getChannelStore().save(Long.valueOf(channelId), channelBean));
/*      */     
/* 1031 */     return saveMessage.and((Publisher)editLastMessageId);
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<MessageData> onMessageDelete(int shardIndex, MessageDelete dispatch) {
/* 1036 */     long messageId = Snowflake.asLong(dispatch.id());
/*      */     
/* 1038 */     Mono<Void> deleteMessage = this.stateHolder.getMessageStore().delete(messageId);
/*      */ 
/*      */ 
/*      */     
/* 1042 */     Objects.requireNonNull(deleteMessage); return this.stateHolder.getMessageStore().find(messageId).flatMap(deleteMessage::thenReturn);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Set<MessageData>> onMessageDeleteBulk(int shardIndex, MessageDeleteBulk dispatch) {
/* 1049 */     List<Long> messageIds = (List<Long>)dispatch.ids().stream().map(Snowflake::asLong).collect(Collectors.toList());
/*      */ 
/*      */     
/* 1052 */     Mono<Void> deleteMessages = this.stateHolder.getMessageStore().delete((Publisher)Flux.fromIterable(messageIds));
/*      */ 
/*      */     
/* 1055 */     Objects.requireNonNull(this.stateHolder.getMessageStore());
/* 1056 */     Objects.requireNonNull(deleteMessages); return Flux.fromIterable(messageIds).flatMap(this.stateHolder.getMessageStore()::find).flatMap(deleteMessages::thenReturn)
/* 1057 */       .collect(Collectors.toSet());
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Void> onMessageReactionAdd(int shardIndex, MessageReactionAdd dispatch) {
/* 1062 */     long selfId = 0L;
/* 1063 */     long userId = Snowflake.asLong(dispatch.userId());
/* 1064 */     long messageId = Snowflake.asLong(dispatch.messageId());
/*      */ 
/*      */     
/* 1067 */     return this.stateHolder.getMessageStore()
/* 1068 */       .find(messageId)
/* 1069 */       .map(oldMessage -> {
/*      */           boolean me = Objects.equals(Long.valueOf(userId), Long.valueOf(selfId));
/*      */ 
/*      */           
/*      */           ImmutableMessageData.Builder newMessageBuilder = MessageData.builder().from(oldMessage);
/*      */ 
/*      */           
/*      */           if (oldMessage.reactions().isAbsent()) {
/*      */             newMessageBuilder.addReaction((ReactionData)ReactionData.builder().count(1).me(me).emoji(dispatch.emoji()).build());
/*      */           } else {
/*      */             List<ReactionData> reactions = (List<ReactionData>)oldMessage.reactions().get();
/*      */             
/*      */             int i = indexOfReactionByEmojiData(reactions, dispatch.emoji());
/*      */             
/*      */             if (i < reactions.size()) {
/*      */               ReactionData oldExisting = reactions.get(i);
/*      */               
/* 1086 */               ImmutableReactionData immutableReactionData = ReactionData.builder().from(oldExisting).me((oldExisting.me() || me)).count(oldExisting.count() + 1).build();
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               newMessageBuilder.reactions(ListUtil.replace(reactions, oldExisting, immutableReactionData));
/*      */             } else {
/*      */               ImmutableReactionData immutableReactionData = ReactionData.builder().emoji(dispatch.emoji()).me(me).count(1).build();
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               newMessageBuilder.reactions(ListUtil.add(reactions, immutableReactionData));
/*      */             } 
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           return newMessageBuilder.build();
/* 1106 */         }).flatMap(message -> this.stateHolder.getMessageStore().save(Long.valueOf(messageId), message));
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Void> onMessageReactionRemove(int shardIndex, MessageReactionRemove dispatch) {
/* 1111 */     long selfId = 0L;
/* 1112 */     long userId = Snowflake.asLong(dispatch.userId());
/* 1113 */     long messageId = Snowflake.asLong(dispatch.messageId());
/*      */ 
/*      */     
/* 1116 */     return this.stateHolder.getMessageStore()
/* 1117 */       .find(messageId)
/* 1118 */       .filter(message -> !message.reactions().isAbsent())
/* 1119 */       .map(oldMessage -> {
/*      */           boolean me = Objects.equals(Long.valueOf(userId), Long.valueOf(selfId));
/*      */           
/*      */           ImmutableMessageData.Builder newMessageBuilder = MessageData.builder().from(oldMessage);
/*      */           
/*      */           List<ReactionData> reactions = (List<ReactionData>)oldMessage.reactions().get();
/*      */           
/*      */           int i = indexOfReactionByEmojiData(reactions, dispatch.emoji());
/*      */           if (i < reactions.size()) {
/*      */             ReactionData existing = reactions.get(i);
/*      */             if (existing.count() - 1 == 0) {
/*      */               newMessageBuilder.reactions(ListUtil.remove(reactions, ()));
/*      */             } else {
/* 1132 */               ImmutableReactionData immutableReactionData = ReactionData.builder().from(existing).count(existing.count() - 1).me((!me && existing.me())).build();
/*      */ 
/*      */ 
/*      */               
/*      */               newMessageBuilder.reactions(ListUtil.replace(reactions, existing, immutableReactionData));
/*      */             } 
/*      */           } 
/*      */ 
/*      */           
/*      */           return newMessageBuilder.build();
/* 1142 */         }).flatMap(message -> this.stateHolder.getMessageStore().save(Long.valueOf(messageId), message));
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Void> onMessageReactionRemoveAll(int shardIndex, MessageReactionRemoveAll dispatch) {
/* 1147 */     long messageId = Snowflake.asLong(dispatch.messageId());
/*      */     
/* 1149 */     return this.stateHolder.getMessageStore()
/* 1150 */       .find(messageId)
/* 1151 */       .map(message -> MessageData.builder().from(message).reactions(Possible.absent()).build())
/*      */ 
/*      */ 
/*      */       
/* 1155 */       .flatMap(message -> this.stateHolder.getMessageStore().save(Long.valueOf(messageId), message));
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Void> onMessageReactionRemoveEmoji(int shardIndex, MessageReactionRemoveEmoji dispatch) {
/* 1160 */     long messageId = Snowflake.asLong(dispatch.messageId());
/*      */     
/* 1162 */     return this.stateHolder.getMessageStore()
/* 1163 */       .find(messageId)
/* 1164 */       .filter(message -> !message.reactions().isAbsent())
/* 1165 */       .map(oldMessage -> {
/*      */           ImmutableMessageData.Builder newMessageBuilder = MessageData.builder().from(oldMessage);
/*      */           
/*      */           List<ReactionData> reactions = (List<ReactionData>)oldMessage.reactions().get();
/*      */           
/*      */           int i = indexOfReactionByEmojiData(reactions, dispatch.emoji());
/*      */           
/*      */           if (i < reactions.size()) {
/*      */             ReactionData existing = reactions.get(i);
/*      */             
/*      */             newMessageBuilder.reactions(ListUtil.remove(reactions, ()));
/*      */           } 
/*      */           return newMessageBuilder.build();
/* 1178 */         }).flatMap(message -> this.stateHolder.getMessageStore().save(Long.valueOf(messageId), message));
/*      */   }
/*      */   
/*      */   private int indexOfReactionByEmojiData(List<ReactionData> reactions, EmojiData emojiData) {
/*      */     int i;
/* 1183 */     for (i = 0; i < reactions.size(); i++) {
/* 1184 */       ReactionData r = reactions.get(i);
/*      */       
/* 1186 */       boolean emojiHasId = emojiData.id().isPresent();
/* 1187 */       if ((emojiHasId && emojiData.id().equals(r.emoji().id())) || (!emojiHasId && emojiData
/* 1188 */         .name().equals(r.emoji().name()))) {
/*      */         break;
/*      */       }
/*      */     } 
/* 1192 */     return i;
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<MessageData> onMessageUpdate(int shardIndex, MessageUpdate dispatch) {
/* 1197 */     PartialMessageData messageData = dispatch.message();
/* 1198 */     long messageId = Snowflake.asLong(messageData.id());
/*      */     
/* 1200 */     return this.stateHolder.getMessageStore()
/* 1201 */       .find(messageId)
/* 1202 */       .flatMap(oldMessageData -> {
/*      */           
/* 1204 */           boolean contentChanged = (!messageData.content().isAbsent() && !Objects.equals(oldMessageData.content(), messageData.content().get()));
/*      */           boolean embedsChanged = !Objects.equals(oldMessageData.embeds(), messageData.embeds());
/*      */           ImmutableMessageData immutableMessageData = MessageData.builder().from(oldMessageData).content(messageData.content().toOptional().orElse(oldMessageData.content())).embeds(messageData.embeds()).mentions(messageData.mentions()).mentionRoles(messageData.mentionRoles()).mentionEveryone(((Boolean)messageData.mentionEveryone().toOptional().orElse(Boolean.valueOf(oldMessageData.mentionEveryone()))).booleanValue()).editedTimestamp(messageData.editedTimestamp()).build();
/*      */           return this.stateHolder.getMessageStore().save(Long.valueOf(messageId), immutableMessageData).thenReturn(oldMessageData);
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<PresenceAndUserData> onPresenceUpdate(int shardIndex, PresenceUpdate dispatch) {
/* 1228 */     long guildId = Snowflake.asLong(dispatch.guildId());
/* 1229 */     PartialUserData userData = dispatch.user();
/* 1230 */     long userId = Snowflake.asLong(userData.id());
/* 1231 */     LongLongTuple2 key = LongLongTuple2.of(guildId, userId);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1237 */     ImmutablePresenceData immutablePresenceData = PresenceData.builder().user(dispatch.user()).status(dispatch.status()).activities(dispatch.activities()).clientStatus(dispatch.clientStatus()).build();
/*      */     
/* 1239 */     Mono<Void> saveNew = this.stateHolder.getPresenceStore().save((Comparable)key, immutablePresenceData);
/*      */ 
/*      */ 
/*      */     
/* 1243 */     Objects.requireNonNull(saveNew);
/*      */     
/* 1245 */     Mono<Optional<PresenceData>> savePresence = this.stateHolder.getPresenceStore().find((Comparable)key).flatMap(saveNew::thenReturn).map(Optional::of).switchIfEmpty(saveNew.thenReturn(Optional.empty()));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1265 */     Mono<Optional<UserData>> saveUser = this.stateHolder.getUserStore().find(userId).flatMap(oldUserData -> { ImmutableUserData immutableUserData = UserData.builder().from(oldUserData).globalName(userData.globalName().isAbsent() ? oldUserData.globalName() : Possible.flatOpt(userData.globalName())).username(userData.username().toOptional().orElse(oldUserData.username())).discriminator(userData.discriminator().toOptional().orElse(oldUserData.discriminator())).avatar(userData.avatar().isAbsent() ? oldUserData.avatar() : Possible.flatOpt(userData.avatar())).build(); return this.stateHolder.getUserStore().save(Long.valueOf(userId), immutableUserData).thenReturn(oldUserData); }).map(Optional::of).defaultIfEmpty(Optional.empty());
/*      */     
/* 1267 */     return Mono.zip(savePresence, saveUser, (p, u) -> PresenceAndUserData.of(p.orElse(null), u.orElse(null)));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Void> onReady(Ready dispatch) {
/* 1273 */     UserData userData = dispatch.user();
/* 1274 */     long userId = Snowflake.asLong(userData.id());
/*      */     
/* 1276 */     return this.stateHolder.getUserStore().save(Long.valueOf(userId), userData);
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<UserData> onUserUpdate(int shardIndex, UserUpdate dispatch) {
/* 1281 */     UserData userData = dispatch.user();
/* 1282 */     long userId = Snowflake.asLong(userData.id());
/*      */     
/* 1284 */     Mono<Void> saveNew = this.stateHolder.getUserStore().save(Long.valueOf(userId), userData);
/*      */ 
/*      */ 
/*      */     
/* 1288 */     Objects.requireNonNull(saveNew); return this.stateHolder.getUserStore().find(userId).flatMap(saveNew::thenReturn)
/* 1289 */       .switchIfEmpty(saveNew.then(Mono.empty()));
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<VoiceStateData> onVoiceStateUpdateDispatch(int shardIndex, VoiceStateUpdateDispatch dispatch) {
/* 1294 */     VoiceStateData voiceStateData = dispatch.voiceState();
/*      */     
/* 1296 */     long guildId = Snowflake.asLong((Id)voiceStateData.guildId().get());
/* 1297 */     long userId = Snowflake.asLong(voiceStateData.userId());
/*      */     
/* 1299 */     LongLongTuple2 key = LongLongTuple2.of(guildId, userId);
/*      */ 
/*      */ 
/*      */     
/* 1303 */     Mono<Void> saveNewOrRemove = voiceStateData.channelId().isPresent() ? this.stateHolder.getVoiceStateStore().save((Comparable)key, voiceStateData) : this.stateHolder.getVoiceStateStore().delete((Comparable)key);
/*      */ 
/*      */ 
/*      */     
/* 1307 */     Objects.requireNonNull(saveNewOrRemove); return this.stateHolder.getVoiceStateStore().find((Comparable)key).flatMap(saveNewOrRemove::thenReturn)
/* 1308 */       .switchIfEmpty(saveNewOrRemove.then(Mono.empty()));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Void> onGuildMembersCompletion(long guildId) {
/* 1314 */     return Mono.empty();
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\legacy\LegacyStoreLayout.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */