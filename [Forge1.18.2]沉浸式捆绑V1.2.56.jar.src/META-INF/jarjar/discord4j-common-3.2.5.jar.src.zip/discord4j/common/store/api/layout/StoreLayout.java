/*    */ package discord4j.common.store.api.layout;
/*    */ 
/*    */ import discord4j.common.store.api.ActionMapper;
/*    */ import discord4j.common.store.api.StoreFlag;
/*    */ import java.util.EnumSet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface StoreLayout
/*    */ {
/*    */   DataAccessor getDataAccessor();
/*    */   
/*    */   GatewayDataUpdater getGatewayDataUpdater();
/*    */   
/*    */   default ActionMapper getCustomActionMapper() {
/* 53 */     return ActionMapper.empty();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default EnumSet<StoreFlag> getEnabledFlags() {
/* 64 */     return EnumSet.allOf(StoreFlag.class);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\api\layout\StoreLayout.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */