package discord4j.common.store.api.layout;

import discord4j.common.store.api.object.InvalidationCause;
import discord4j.common.store.api.object.PresenceAndUserData;
import discord4j.discordjson.json.ChannelData;
import discord4j.discordjson.json.EmojiData;
import discord4j.discordjson.json.GuildData;
import discord4j.discordjson.json.GuildScheduledEventData;
import discord4j.discordjson.json.MemberData;
import discord4j.discordjson.json.MessageData;
import discord4j.discordjson.json.RoleData;
import discord4j.discordjson.json.StickerData;
import discord4j.discordjson.json.UserData;
import discord4j.discordjson.json.VoiceStateData;
import discord4j.discordjson.json.gateway.ChannelCreate;
import discord4j.discordjson.json.gateway.ChannelDelete;
import discord4j.discordjson.json.gateway.ChannelUpdate;
import discord4j.discordjson.json.gateway.GuildCreate;
import discord4j.discordjson.json.gateway.GuildDelete;
import discord4j.discordjson.json.gateway.GuildEmojisUpdate;
import discord4j.discordjson.json.gateway.GuildMemberAdd;
import discord4j.discordjson.json.gateway.GuildMemberRemove;
import discord4j.discordjson.json.gateway.GuildMemberUpdate;
import discord4j.discordjson.json.gateway.GuildMembersChunk;
import discord4j.discordjson.json.gateway.GuildRoleCreate;
import discord4j.discordjson.json.gateway.GuildRoleDelete;
import discord4j.discordjson.json.gateway.GuildRoleUpdate;
import discord4j.discordjson.json.gateway.GuildScheduledEventCreate;
import discord4j.discordjson.json.gateway.GuildScheduledEventDelete;
import discord4j.discordjson.json.gateway.GuildScheduledEventUpdate;
import discord4j.discordjson.json.gateway.GuildScheduledEventUserAdd;
import discord4j.discordjson.json.gateway.GuildScheduledEventUserRemove;
import discord4j.discordjson.json.gateway.GuildStickersUpdate;
import discord4j.discordjson.json.gateway.GuildUpdate;
import discord4j.discordjson.json.gateway.MessageCreate;
import discord4j.discordjson.json.gateway.MessageDelete;
import discord4j.discordjson.json.gateway.MessageDeleteBulk;
import discord4j.discordjson.json.gateway.MessageReactionAdd;
import discord4j.discordjson.json.gateway.MessageReactionRemove;
import discord4j.discordjson.json.gateway.MessageReactionRemoveAll;
import discord4j.discordjson.json.gateway.MessageReactionRemoveEmoji;
import discord4j.discordjson.json.gateway.MessageUpdate;
import discord4j.discordjson.json.gateway.PresenceUpdate;
import discord4j.discordjson.json.gateway.Ready;
import discord4j.discordjson.json.gateway.UserUpdate;
import discord4j.discordjson.json.gateway.VoiceStateUpdateDispatch;
import java.util.Set;
import reactor.core.publisher.Mono;

public interface GatewayDataUpdater {
  Mono<Void> onChannelCreate(int paramInt, ChannelCreate paramChannelCreate);
  
  Mono<ChannelData> onChannelDelete(int paramInt, ChannelDelete paramChannelDelete);
  
  Mono<ChannelData> onChannelUpdate(int paramInt, ChannelUpdate paramChannelUpdate);
  
  Mono<Void> onGuildCreate(int paramInt, GuildCreate paramGuildCreate);
  
  Mono<GuildData> onGuildDelete(int paramInt, GuildDelete paramGuildDelete);
  
  Mono<Set<StickerData>> onGuildStickersUpdate(int paramInt, GuildStickersUpdate paramGuildStickersUpdate);
  
  Mono<Set<EmojiData>> onGuildEmojisUpdate(int paramInt, GuildEmojisUpdate paramGuildEmojisUpdate);
  
  Mono<Void> onGuildMemberAdd(int paramInt, GuildMemberAdd paramGuildMemberAdd);
  
  Mono<MemberData> onGuildMemberRemove(int paramInt, GuildMemberRemove paramGuildMemberRemove);
  
  Mono<Void> onGuildMembersChunk(int paramInt, GuildMembersChunk paramGuildMembersChunk);
  
  Mono<MemberData> onGuildMemberUpdate(int paramInt, GuildMemberUpdate paramGuildMemberUpdate);
  
  Mono<Void> onGuildRoleCreate(int paramInt, GuildRoleCreate paramGuildRoleCreate);
  
  Mono<RoleData> onGuildRoleDelete(int paramInt, GuildRoleDelete paramGuildRoleDelete);
  
  Mono<RoleData> onGuildRoleUpdate(int paramInt, GuildRoleUpdate paramGuildRoleUpdate);
  
  Mono<Void> onGuildScheduledEventCreate(int paramInt, GuildScheduledEventCreate paramGuildScheduledEventCreate);
  
  Mono<GuildScheduledEventData> onGuildScheduledEventUpdate(int paramInt, GuildScheduledEventUpdate paramGuildScheduledEventUpdate);
  
  Mono<GuildScheduledEventData> onGuildScheduledEventDelete(int paramInt, GuildScheduledEventDelete paramGuildScheduledEventDelete);
  
  Mono<Void> onGuildScheduledEventUserAdd(int paramInt, GuildScheduledEventUserAdd paramGuildScheduledEventUserAdd);
  
  Mono<Void> onGuildScheduledEventUserRemove(int paramInt, GuildScheduledEventUserRemove paramGuildScheduledEventUserRemove);
  
  Mono<GuildData> onGuildUpdate(int paramInt, GuildUpdate paramGuildUpdate);
  
  Mono<Void> onShardInvalidation(int paramInt, InvalidationCause paramInvalidationCause);
  
  Mono<Void> onMessageCreate(int paramInt, MessageCreate paramMessageCreate);
  
  Mono<MessageData> onMessageDelete(int paramInt, MessageDelete paramMessageDelete);
  
  Mono<Set<MessageData>> onMessageDeleteBulk(int paramInt, MessageDeleteBulk paramMessageDeleteBulk);
  
  Mono<Void> onMessageReactionAdd(int paramInt, MessageReactionAdd paramMessageReactionAdd);
  
  Mono<Void> onMessageReactionRemove(int paramInt, MessageReactionRemove paramMessageReactionRemove);
  
  Mono<Void> onMessageReactionRemoveAll(int paramInt, MessageReactionRemoveAll paramMessageReactionRemoveAll);
  
  Mono<Void> onMessageReactionRemoveEmoji(int paramInt, MessageReactionRemoveEmoji paramMessageReactionRemoveEmoji);
  
  Mono<MessageData> onMessageUpdate(int paramInt, MessageUpdate paramMessageUpdate);
  
  Mono<PresenceAndUserData> onPresenceUpdate(int paramInt, PresenceUpdate paramPresenceUpdate);
  
  Mono<Void> onReady(Ready paramReady);
  
  Mono<UserData> onUserUpdate(int paramInt, UserUpdate paramUserUpdate);
  
  Mono<VoiceStateData> onVoiceStateUpdateDispatch(int paramInt, VoiceStateUpdateDispatch paramVoiceStateUpdateDispatch);
  
  Mono<Void> onGuildMembersCompletion(long paramLong);
}


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\api\layout\GatewayDataUpdater.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */