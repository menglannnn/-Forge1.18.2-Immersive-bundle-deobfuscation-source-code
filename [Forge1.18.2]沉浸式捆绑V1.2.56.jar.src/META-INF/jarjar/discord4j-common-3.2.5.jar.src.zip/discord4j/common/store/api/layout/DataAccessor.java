/*     */ package discord4j.common.store.api.layout;
/*     */ 
/*     */ import discord4j.discordjson.Id;
/*     */ import discord4j.discordjson.json.ChannelData;
/*     */ import discord4j.discordjson.json.EmojiData;
/*     */ import discord4j.discordjson.json.GuildData;
/*     */ import discord4j.discordjson.json.GuildScheduledEventData;
/*     */ import discord4j.discordjson.json.MemberData;
/*     */ import discord4j.discordjson.json.MessageData;
/*     */ import discord4j.discordjson.json.PresenceData;
/*     */ import discord4j.discordjson.json.RoleData;
/*     */ import discord4j.discordjson.json.StickerData;
/*     */ import discord4j.discordjson.json.UserData;
/*     */ import discord4j.discordjson.json.VoiceStateData;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface DataAccessor
/*     */ {
/*     */   Mono<Long> countChannels();
/*     */   
/*     */   Mono<Long> countChannelsInGuild(long paramLong);
/*     */   
/*     */   default Mono<Long> countStickers() {
/*  53 */     return Mono.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Mono<Long> countStickersInGuild(long guildId) {
/*  64 */     return Mono.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Mono<Long> countEmojis();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Mono<Long> countEmojisInGuild(long paramLong);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Mono<Long> countGuilds();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Mono<Long> countMembers();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Mono<Long> countMembersInGuild(long paramLong);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Mono<Long> countExactMembersInGuild(long paramLong);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Mono<Long> countMessages();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Mono<Long> countMessagesInChannel(long paramLong);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Mono<Long> countPresences();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Mono<Long> countPresencesInGuild(long paramLong);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Mono<Long> countRoles();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Mono<Long> countRolesInGuild(long paramLong);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Mono<Long> countUsers();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Mono<Long> countVoiceStates();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Mono<Long> countVoiceStatesInGuild(long paramLong);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Mono<Long> countVoiceStatesInChannel(long paramLong1, long paramLong2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Flux<ChannelData> getChannels();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Flux<ChannelData> getChannelsInGuild(long paramLong);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Mono<ChannelData> getChannelById(long paramLong);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Flux<StickerData> getStickers() {
/* 219 */     return Flux.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Flux<StickerData> getStickersInGuild(long guildId) {
/* 230 */     return Flux.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Mono<StickerData> getStickerById(long guildId, long stickerId) {
/* 242 */     return Mono.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Flux<EmojiData> getEmojis();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Flux<EmojiData> getEmojisInGuild(long paramLong);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Mono<EmojiData> getEmojiById(long paramLong1, long paramLong2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Flux<GuildData> getGuilds();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Mono<GuildData> getGuildById(long paramLong);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Flux<GuildScheduledEventData> getScheduledEventsInGuild(long guildId) {
/* 292 */     return Flux.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Mono<GuildScheduledEventData> getScheduledEventById(long guildId, long eventId) {
/* 304 */     return Mono.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Flux<Id> getScheduledEventUsersInEvent(long guildId, long eventId) {
/* 316 */     return Flux.empty();
/*     */   }
/*     */   
/*     */   Flux<MemberData> getMembers();
/*     */   
/*     */   Flux<MemberData> getMembersInGuild(long paramLong);
/*     */   
/*     */   Flux<MemberData> getExactMembersInGuild(long paramLong);
/*     */   
/*     */   Mono<MemberData> getMemberById(long paramLong1, long paramLong2);
/*     */   
/*     */   Flux<MessageData> getMessages();
/*     */   
/*     */   Flux<MessageData> getMessagesInChannel(long paramLong);
/*     */   
/*     */   Mono<MessageData> getMessageById(long paramLong1, long paramLong2);
/*     */   
/*     */   Flux<PresenceData> getPresences();
/*     */   
/*     */   Flux<PresenceData> getPresencesInGuild(long paramLong);
/*     */   
/*     */   Mono<PresenceData> getPresenceById(long paramLong1, long paramLong2);
/*     */   
/*     */   Flux<RoleData> getRoles();
/*     */   
/*     */   Flux<RoleData> getRolesInGuild(long paramLong);
/*     */   
/*     */   Mono<RoleData> getRoleById(long paramLong1, long paramLong2);
/*     */   
/*     */   Flux<UserData> getUsers();
/*     */   
/*     */   Mono<UserData> getUserById(long paramLong);
/*     */   
/*     */   Flux<VoiceStateData> getVoiceStates();
/*     */   
/*     */   Flux<VoiceStateData> getVoiceStatesInChannel(long paramLong1, long paramLong2);
/*     */   
/*     */   Flux<VoiceStateData> getVoiceStatesInGuild(long paramLong);
/*     */   
/*     */   Mono<VoiceStateData> getVoiceStateById(long paramLong1, long paramLong2);
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\api\layout\DataAccessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */