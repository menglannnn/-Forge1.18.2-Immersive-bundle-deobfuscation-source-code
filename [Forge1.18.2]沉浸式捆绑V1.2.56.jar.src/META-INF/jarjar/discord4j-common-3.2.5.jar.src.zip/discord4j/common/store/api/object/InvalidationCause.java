/*    */ package discord4j.common.store.api.object;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum InvalidationCause
/*    */ {
/* 24 */   HARD_RECONNECT,
/* 25 */   LOGOUT;
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\api\object\InvalidationCause.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */