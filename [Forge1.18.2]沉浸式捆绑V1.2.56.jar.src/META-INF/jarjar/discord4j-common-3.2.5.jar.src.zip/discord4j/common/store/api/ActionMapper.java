/*     */ package discord4j.common.store.api;
/*     */ 
/*     */ import discord4j.common.annotations.Experimental;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Function;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.Stream;
/*     */ import org.reactivestreams.Publisher;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ActionMapper
/*     */ {
/*  32 */   private static final ActionMapper EMPTY = new ActionMapper(Collections.emptyMap());
/*     */   
/*     */   private final Map<Class<? extends StoreAction<?>>, Function<StoreAction<?>, ? extends Publisher<?>>> mappings;
/*     */   
/*     */   private ActionMapper(Map<Class<? extends StoreAction<?>>, Function<StoreAction<?>, ? extends Publisher<?>>> mappings) {
/*  37 */     this.mappings = mappings;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/*  46 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ActionMapper empty() {
/*  55 */     return EMPTY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ActionMapper aggregate(ActionMapper... mappers) {
/*  68 */     Objects.requireNonNull(mappers);
/*  69 */     if (mappers.length == 0) return EMPTY; 
/*  70 */     if (mappers.length == 1) return mappers[0]; 
/*  71 */     return new ActionMapper((Map<Class<? extends StoreAction<?>>, Function<StoreAction<?>, ? extends Publisher<?>>>)Arrays.<ActionMapper>stream(mappers)
/*  72 */         .flatMap(mapper -> mapper.mappings.entrySet().stream())
/*  73 */         .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Experimental
/*     */   public static ActionMapper mergeFirst(Collection<ActionMapper> mappers) {
/*  86 */     Objects.requireNonNull(mappers);
/*  87 */     return new ActionMapper((Map<Class<? extends StoreAction<?>>, Function<StoreAction<?>, ? extends Publisher<?>>>)mappers.stream()
/*  88 */         .flatMap(mapper -> mapper.mappings.entrySet().stream())
/*  89 */         .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (a, b) -> a)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R> Optional<Function<StoreAction<R>, ? extends Publisher<R>>> findHandlerForAction(StoreAction<R> action) {
/* 101 */     Objects.requireNonNull(action);
/* 102 */     return Optional.<Function>ofNullable(this.mappings.get(action.getClass()))
/* 103 */       .map(handler -> ());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Builder
/*     */   {
/* 111 */     private final Map<Class<? extends StoreAction<?>>, Function<StoreAction<?>, ? extends Publisher<?>>> mappings = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <R, S extends StoreAction<R>> Builder map(Class<S> actionType, Function<? super S, ? extends Publisher<R>> handler) {
/* 126 */       Objects.requireNonNull(actionType);
/* 127 */       Objects.requireNonNull(handler);
/* 128 */       this.mappings.put(actionType, action -> (Publisher)handler.apply(action));
/* 129 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ActionMapper build() {
/* 138 */       return new ActionMapper(this.mappings);
/*     */     }
/*     */     
/*     */     private Builder() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\api\ActionMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */