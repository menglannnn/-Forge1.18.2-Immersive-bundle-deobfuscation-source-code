/*    */ package discord4j.common.store.api.object;
/*    */ 
/*    */ import discord4j.discordjson.json.PresenceData;
/*    */ import discord4j.discordjson.json.UserData;
/*    */ import java.util.Objects;
/*    */ import java.util.Optional;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PresenceAndUserData
/*    */ {
/*    */   private final PresenceData presenceData;
/*    */   private final UserData userData;
/*    */   
/*    */   private PresenceAndUserData(@Nullable PresenceData presenceData, @Nullable UserData userData) {
/* 36 */     this.presenceData = presenceData;
/* 37 */     this.userData = userData;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static PresenceAndUserData of(@Nullable PresenceData presenceData, @Nullable UserData userData) {
/* 48 */     return new PresenceAndUserData(presenceData, userData);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Optional<PresenceData> getPresenceData() {
/* 57 */     return Optional.ofNullable(this.presenceData);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Optional<UserData> getUserData() {
/* 66 */     return Optional.ofNullable(this.userData);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 71 */     if (this == o) return true; 
/* 72 */     if (!(o instanceof PresenceAndUserData)) return false; 
/* 73 */     PresenceAndUserData that = (PresenceAndUserData)o;
/* 74 */     return (Objects.equals(this.presenceData, that.presenceData) && 
/* 75 */       Objects.equals(this.userData, that.userData));
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 80 */     return Objects.hash(new Object[] { this.presenceData, this.userData });
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 85 */     return "PresenceAndUserData{presenceData=" + this.presenceData + ", userData=" + this.userData + '}';
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\api\object\PresenceAndUserData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */