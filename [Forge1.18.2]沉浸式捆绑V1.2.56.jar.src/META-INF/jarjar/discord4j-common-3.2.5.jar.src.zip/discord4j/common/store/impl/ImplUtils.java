/*    */ package discord4j.common.store.impl;
/*    */ 
/*    */ import discord4j.discordjson.Id;
/*    */ import discord4j.discordjson.json.PresenceData;
/*    */ import discord4j.discordjson.json.gateway.PresenceUpdate;
/*    */ import java.util.List;
/*    */ import java.util.Objects;
/*    */ import java.util.Optional;
/*    */ import java.util.Set;
/*    */ import java.util.function.Consumer;
/*    */ import java.util.function.Function;
/*    */ import java.util.function.Supplier;
/*    */ import java.util.stream.Collectors;
/*    */ import java.util.stream.Stream;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ImplUtils
/*    */ {
/*    */   static <T> void ifNonNullDo(@Nullable T val, Consumer<? super T> action) {
/* 38 */     if (val != null)
/* 39 */       action.accept(val); 
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   static <T, R> R ifNonNullMap(@Nullable T val, Function<? super T, ? extends R> mapper) {
/* 44 */     if (val != null) {
/* 45 */       return mapper.apply(val);
/*    */     }
/* 47 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   static <T> Optional<T> or(Optional<T> first, Supplier<Optional<T>> supplier) {
/* 53 */     Objects.requireNonNull(supplier);
/* 54 */     if (first.isPresent()) {
/* 55 */       return first;
/*    */     }
/* 57 */     Optional<T> r = supplier.get();
/* 58 */     return Objects.<Optional<T>>requireNonNull(r);
/*    */   }
/*    */ 
/*    */   
/*    */   static PresenceData createPresence(PresenceUpdate update) {
/* 63 */     return (PresenceData)PresenceData.builder()
/* 64 */       .user(update.user())
/* 65 */       .status(update.status())
/* 66 */       .activities(update.activities())
/* 67 */       .clientStatus(update.clientStatus())
/* 68 */       .build();
/*    */   }
/*    */   
/*    */   static <T> List<T> add(List<T> list, T element) {
/* 72 */     return (List<T>)Stream.concat(list.stream(), Stream.of(element)).collect(Collectors.toList());
/*    */   }
/*    */   
/*    */   static <T> List<T> remove(List<T> list, T element) {
/* 76 */     return (List<T>)list.stream().filter(x -> !x.equals(element)).collect(Collectors.toList());
/*    */   }
/*    */   
/*    */   static List<Id> removeAllIds(List<Id> list, Set<Long> elements) {
/* 80 */     return (List<Id>)list.stream().filter(x -> !elements.contains(Long.valueOf(x.asLong()))).collect(Collectors.toList());
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\impl\ImplUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */