/*     */ package discord4j.common.store.impl;
/*     */ 
/*     */ import discord4j.discordjson.Id;
/*     */ import discord4j.discordjson.json.UserData;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.Optional;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class EmptyUser
/*     */   implements UserData
/*     */ {
/*  28 */   static final EmptyUser INSTANCE = new EmptyUser();
/*     */ 
/*     */   
/*     */   public Id id() {
/*  32 */     return Id.of(0L);
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<String> globalName() {
/*  37 */     return Optional.empty();
/*     */   }
/*     */ 
/*     */   
/*     */   public String username() {
/*  42 */     return "";
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public String discriminator() {
/*  48 */     return "";
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<String> avatar() {
/*  53 */     return Optional.empty();
/*     */   }
/*     */ 
/*     */   
/*     */   public Possible<Optional<String>> banner() {
/*  58 */     return Possible.absent();
/*     */   }
/*     */ 
/*     */   
/*     */   public Possible<Optional<Integer>> accentColor() {
/*  63 */     return Possible.absent();
/*     */   }
/*     */ 
/*     */   
/*     */   public Possible<Boolean> bot() {
/*  68 */     return Possible.absent();
/*     */   }
/*     */ 
/*     */   
/*     */   public Possible<Boolean> system() {
/*  73 */     return Possible.absent();
/*     */   }
/*     */ 
/*     */   
/*     */   public Possible<Boolean> mfaEnabled() {
/*  78 */     return Possible.absent();
/*     */   }
/*     */ 
/*     */   
/*     */   public Possible<String> locale() {
/*  83 */     return Possible.absent();
/*     */   }
/*     */ 
/*     */   
/*     */   public Possible<Boolean> verified() {
/*  88 */     return Possible.absent();
/*     */   }
/*     */ 
/*     */   
/*     */   public Possible<Optional<String>> email() {
/*  93 */     return Possible.absent();
/*     */   }
/*     */ 
/*     */   
/*     */   public Possible<Long> flags() {
/*  98 */     return Possible.absent();
/*     */   }
/*     */ 
/*     */   
/*     */   public Possible<Integer> premiumType() {
/* 103 */     return Possible.absent();
/*     */   }
/*     */ 
/*     */   
/*     */   public Possible<Long> publicFlags() {
/* 108 */     return Possible.absent();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\impl\EmptyUser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */