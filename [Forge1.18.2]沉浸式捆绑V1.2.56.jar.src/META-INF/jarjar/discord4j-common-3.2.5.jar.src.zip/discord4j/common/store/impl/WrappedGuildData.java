/*    */ package discord4j.common.store.impl;
/*    */ 
/*    */ import discord4j.discordjson.Id;
/*    */ import discord4j.discordjson.json.GuildData;
/*    */ import discord4j.discordjson.json.ImmutableGuildData;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class WrappedGuildData
/*    */ {
/*    */   private final ImmutableGuildData guild;
/*    */   private final List<Id> members;
/*    */   private final List<Id> emojis;
/*    */   private final List<Id> stickers;
/*    */   private final List<Id> channels;
/*    */   private final List<Id> roles;
/*    */   
/*    */   WrappedGuildData(ImmutableGuildData guild) {
/* 37 */     this
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 44 */       .guild = ImmutableGuildData.builder().from((GuildData)guild).members(Collections.emptyList()).emojis(Collections.emptyList()).stickers(Collections.emptyList()).channels(Collections.emptyList()).roles(Collections.emptyList()).build();
/* 45 */     this.members = new ArrayList<>(guild.members());
/* 46 */     this.emojis = new ArrayList<>(guild.emojis());
/* 47 */     this.stickers = new ArrayList<>(guild.stickers().toOptional().orElse(Collections.emptyList()));
/* 48 */     this.channels = new ArrayList<>(guild.channels());
/* 49 */     this.roles = new ArrayList<>(guild.roles());
/*    */   }
/*    */   
/*    */   ImmutableGuildData unwrap() {
/* 53 */     return ImmutableGuildData.builder()
/* 54 */       .from((GuildData)this.guild)
/* 55 */       .members(this.members)
/* 56 */       .emojis(this.emojis)
/* 57 */       .stickers(this.stickers)
/* 58 */       .channels(this.channels)
/* 59 */       .roles(this.roles)
/* 60 */       .build();
/*    */   }
/*    */   
/*    */   List<Id> getMembers() {
/* 64 */     return this.members;
/*    */   }
/*    */   
/*    */   List<Id> getEmojis() {
/* 68 */     return this.emojis;
/*    */   }
/*    */   
/*    */   List<Id> getStickers() {
/* 72 */     return this.stickers;
/*    */   }
/*    */   
/*    */   List<Id> getChannels() {
/* 76 */     return this.channels;
/*    */   }
/*    */   
/*    */   List<Id> getRoles() {
/* 80 */     return this.roles;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\impl\WrappedGuildData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */