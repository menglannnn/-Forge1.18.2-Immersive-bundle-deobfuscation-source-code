/*    */ package discord4j.common.store.impl;
/*    */ 
/*    */ import discord4j.common.annotations.Experimental;
/*    */ import discord4j.common.store.api.StoreFlag;
/*    */ import discord4j.common.store.api.layout.DataAccessor;
/*    */ import discord4j.common.store.api.layout.GatewayDataUpdater;
/*    */ import discord4j.common.store.api.layout.StoreLayout;
/*    */ import java.util.EnumSet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Experimental
/*    */ public class SelectiveStoreLayout
/*    */   implements StoreLayout
/*    */ {
/*    */   private final EnumSet<StoreFlag> enabledFlags;
/*    */   private final DataAccessor dataAccessor;
/*    */   private final GatewayDataUpdater gatewayDataUpdater;
/*    */   
/*    */   public static <U extends DataAccessor & GatewayDataUpdater> StoreLayout create(EnumSet<StoreFlag> enabledStoreFlags, U delegate) {
/* 46 */     return new SelectiveStoreLayout(enabledStoreFlags, (DataAccessor)delegate, (GatewayDataUpdater)delegate);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static StoreLayout create(EnumSet<StoreFlag> enabledFlags, DataAccessor dataAccessor, GatewayDataUpdater gatewayDataUpdater) {
/* 60 */     return new SelectiveStoreLayout(enabledFlags, dataAccessor, gatewayDataUpdater);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private SelectiveStoreLayout(EnumSet<StoreFlag> enabledFlags, DataAccessor dataAccessor, GatewayDataUpdater gatewayDataUpdater) {
/* 66 */     this.enabledFlags = enabledFlags;
/* 67 */     this.dataAccessor = dataAccessor;
/* 68 */     this.gatewayDataUpdater = gatewayDataUpdater;
/*    */   }
/*    */ 
/*    */   
/*    */   public DataAccessor getDataAccessor() {
/* 73 */     return this.dataAccessor;
/*    */   }
/*    */ 
/*    */   
/*    */   public GatewayDataUpdater getGatewayDataUpdater() {
/* 78 */     return this.gatewayDataUpdater;
/*    */   }
/*    */ 
/*    */   
/*    */   public EnumSet<StoreFlag> getEnabledFlags() {
/* 83 */     return this.enabledFlags;
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\impl\SelectiveStoreLayout.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */