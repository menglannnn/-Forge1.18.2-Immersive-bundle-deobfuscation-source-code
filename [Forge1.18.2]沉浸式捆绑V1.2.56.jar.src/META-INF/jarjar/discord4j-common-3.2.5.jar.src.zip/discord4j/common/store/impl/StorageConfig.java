/*     */ package discord4j.common.store.impl;
/*     */ 
/*     */ import com.github.benmanes.caffeine.cache.Caffeine;
/*     */ import discord4j.common.store.api.object.InvalidationCause;
/*     */ import java.util.EnumSet;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StorageConfig
/*     */ {
/*     */   private final StorageBackend messageBackend;
/*     */   private final EnumSet<InvalidationCause> invalidationFilter;
/*     */   
/*     */   private StorageConfig(Builder b) {
/*  35 */     this.messageBackend = (b.messageBackend == null) ? defaultMessageBackend() : b.messageBackend;
/*  36 */     this.invalidationFilter = (b.invalidationFilter == null) ? defaultInvalidationFilter() : b.invalidationFilter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/*  45 */     return new Builder();
/*     */   }
/*     */   
/*     */   private static StorageBackend defaultMessageBackend() {
/*  49 */     return StorageBackend.caffeine(builder -> builder.maximumSize(1000L));
/*     */   }
/*     */   
/*     */   private static EnumSet<InvalidationCause> defaultInvalidationFilter() {
/*  53 */     return EnumSet.allOf(InvalidationCause.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StorageBackend getMessageBackend() {
/*  62 */     return this.messageBackend;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EnumSet<InvalidationCause> getInvalidationFilter() {
/*  71 */     return this.invalidationFilter;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Builder
/*     */   {
/*     */     private StorageBackend messageBackend;
/*     */ 
/*     */     
/*     */     private EnumSet<InvalidationCause> invalidationFilter;
/*     */ 
/*     */ 
/*     */     
/*     */     private Builder() {}
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setMessageBackend(@Nullable StorageBackend messageBackend) {
/*  90 */       this.messageBackend = messageBackend;
/*  91 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setInvalidationFilter(@Nullable EnumSet<InvalidationCause> invalidationFilter) {
/* 104 */       this.invalidationFilter = invalidationFilter;
/* 105 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public StorageConfig build() {
/* 114 */       return new StorageConfig(this);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\impl\StorageConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */