/*    */ package discord4j.common.store.impl;
/*    */ 
/*    */ import discord4j.discordjson.json.ImmutableUserData;
/*    */ import java.util.concurrent.atomic.AtomicReference;
/*    */ import java.util.function.BiFunction;
/*    */ import java.util.function.UnaryOperator;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class WithUser<T>
/*    */ {
/*    */   private final T value;
/*    */   private final AtomicReference<ImmutableUserData> ref;
/*    */   private final BiFunction<T, ImmutableUserData, T> setter;
/*    */   
/*    */   public WithUser(T value, @Nullable AtomicReference<ImmutableUserData> ref, BiFunction<T, ImmutableUserData, T> setter) {
/* 35 */     this.value = value;
/* 36 */     this.ref = ref;
/* 37 */     this.setter = setter;
/*    */   }
/*    */   
/*    */   T get() {
/* 41 */     return (this.ref == null) ? this.value : this.setter.apply(this.value, this.ref.get());
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   AtomicReference<ImmutableUserData> userRef() {
/* 46 */     return this.ref;
/*    */   }
/*    */   
/*    */   WithUser<T> update(UnaryOperator<T> operator) {
/* 50 */     return new WithUser(operator.apply(this.value), this.ref, this.setter);
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\impl\WithUser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */