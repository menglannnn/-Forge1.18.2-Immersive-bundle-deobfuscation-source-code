/*     */ package discord4j.common.store.impl;
/*     */ 
/*     */ import discord4j.discordjson.Id;
/*     */ import discord4j.discordjson.json.PartialUserData;
/*     */ import discord4j.discordjson.possible.Possible;
/*     */ import java.util.Optional;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class EmptyPartialUser
/*     */   implements PartialUserData
/*     */ {
/*  28 */   static final EmptyPartialUser INSTANCE = new EmptyPartialUser();
/*     */ 
/*     */   
/*     */   public Id id() {
/*  32 */     return Id.of(0L);
/*     */   }
/*     */ 
/*     */   
/*     */   public Possible<Optional<String>> globalName() {
/*  37 */     return Possible.absent();
/*     */   }
/*     */ 
/*     */   
/*     */   public Possible<String> username() {
/*  42 */     return Possible.absent();
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Possible<String> discriminator() {
/*  48 */     return Possible.absent();
/*     */   }
/*     */ 
/*     */   
/*     */   public Possible<Optional<String>> avatar() {
/*  53 */     return Possible.absent();
/*     */   }
/*     */ 
/*     */   
/*     */   public Possible<Optional<String>> banner() {
/*  58 */     return Possible.absent();
/*     */   }
/*     */ 
/*     */   
/*     */   public Possible<Optional<Integer>> accentColor() {
/*  63 */     return Possible.absent();
/*     */   }
/*     */ 
/*     */   
/*     */   public Possible<Boolean> bot() {
/*  68 */     return Possible.absent();
/*     */   }
/*     */ 
/*     */   
/*     */   public Possible<Boolean> system() {
/*  73 */     return Possible.absent();
/*     */   }
/*     */ 
/*     */   
/*     */   public Possible<Boolean> mfaEnabled() {
/*  78 */     return Possible.absent();
/*     */   }
/*     */ 
/*     */   
/*     */   public Possible<String> locale() {
/*  83 */     return Possible.absent();
/*     */   }
/*     */ 
/*     */   
/*     */   public Possible<Boolean> verified() {
/*  88 */     return Possible.absent();
/*     */   }
/*     */ 
/*     */   
/*     */   public Possible<String> email() {
/*  93 */     return Possible.absent();
/*     */   }
/*     */ 
/*     */   
/*     */   public Possible<Long> flags() {
/*  98 */     return Possible.absent();
/*     */   }
/*     */ 
/*     */   
/*     */   public Possible<Integer> premiumType() {
/* 103 */     return Possible.absent();
/*     */   }
/*     */ 
/*     */   
/*     */   public Possible<Long> publicFlags() {
/* 108 */     return Possible.absent();
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\impl\EmptyPartialUser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */