/*     */ package discord4j.common.store.impl;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NoOpMap<K, V>
/*     */   implements ConcurrentMap<K, V>
/*     */ {
/*     */   public int size() {
/*  31 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/*  36 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsKey(Object key) {
/*  41 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsValue(Object value) {
/*  46 */     return false;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public V get(Object key) {
/*  51 */     return null;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public V put(K key, V value) {
/*  56 */     return null;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public V remove(Object key) {
/*  61 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void putAll(Map<? extends K, ? extends V> m) {}
/*     */ 
/*     */   
/*     */   public void clear() {}
/*     */ 
/*     */   
/*     */   public Set<K> keySet() {
/*  72 */     return Collections.emptySet();
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<V> values() {
/*  77 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<Map.Entry<K, V>> entrySet() {
/*  82 */     return Collections.emptySet();
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public V putIfAbsent(K key, V value) {
/*  87 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean remove(Object key, Object value) {
/*  92 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean replace(K key, V oldValue, V newValue) {
/*  97 */     return (oldValue == null);
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public V replace(K key, V value) {
/* 102 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\impl\NoOpMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */