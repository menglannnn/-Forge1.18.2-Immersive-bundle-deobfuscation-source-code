/*    */ package discord4j.common.store.impl;
/*    */ 
/*    */ import com.github.benmanes.caffeine.cache.Caffeine;
/*    */ import com.github.benmanes.caffeine.cache.RemovalListener;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import java.util.concurrent.ConcurrentMap;
/*    */ import java.util.function.UnaryOperator;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface StorageBackend
/*    */ {
/*    */   static StorageBackend noOp() {
/* 40 */     return new StorageBackend()
/*    */       {
/*    */         public <K, V> ConcurrentMap<K, V> newMap(@Nullable RemovalListener<K, V> removalListener) {
/* 43 */           return new NoOpMap<>();
/*    */         }
/*    */       };
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static StorageBackend concurrentHashMap() {
/* 54 */     return new StorageBackend()
/*    */       {
/*    */         public <K, V> ConcurrentMap<K, V> newMap(@Nullable RemovalListener<K, V> removalListener) {
/* 57 */           return new ConcurrentHashMap<>();
/*    */         }
/*    */       };
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static StorageBackend caffeine(final UnaryOperator<Caffeine<Object, Object>> caffeineBuilder) {
/* 69 */     return new StorageBackend()
/*    */       {
/*    */         public <K, V> ConcurrentMap<K, V> newMap(@Nullable RemovalListener<K, V> removalListener) {
/* 72 */           Caffeine<Object, Object> configured = caffeineBuilder.apply(Caffeine.newBuilder());
/* 73 */           if (removalListener != null) {
/* 74 */             return configured.removalListener(removalListener).build().asMap();
/*    */           }
/* 76 */           return configured.build().asMap();
/*    */         }
/*    */       };
/*    */   }
/*    */   
/*    */   default <K, V> ConcurrentMap<K, V> newMap() {
/* 82 */     return newMap(null);
/*    */   }
/*    */   
/*    */   <K, V> ConcurrentMap<K, V> newMap(@Nullable RemovalListener<K, V> paramRemovalListener);
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\impl\StorageBackend.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */