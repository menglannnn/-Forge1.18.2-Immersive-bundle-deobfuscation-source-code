/*      */ package discord4j.common.store.impl;
/*      */ import discord4j.common.store.api.object.PresenceAndUserData;
/*      */ import discord4j.discordjson.Id;
/*      */ import discord4j.discordjson.json.ChannelData;
/*      */ import discord4j.discordjson.json.EmojiData;
/*      */ import discord4j.discordjson.json.GuildCreateData;
/*      */ import discord4j.discordjson.json.GuildData;
/*      */ import discord4j.discordjson.json.GuildScheduledEventData;
/*      */ import discord4j.discordjson.json.ImmutableEmojiData;
/*      */ import discord4j.discordjson.json.ImmutableGuildData;
/*      */ import discord4j.discordjson.json.ImmutableMemberData;
/*      */ import discord4j.discordjson.json.ImmutableMessageData;
/*      */ import discord4j.discordjson.json.ImmutablePartialMessageData;
/*      */ import discord4j.discordjson.json.ImmutablePartialUserData;
/*      */ import discord4j.discordjson.json.ImmutablePresenceData;
/*      */ import discord4j.discordjson.json.ImmutableUserData;
/*      */ import discord4j.discordjson.json.MemberData;
/*      */ import discord4j.discordjson.json.MessageData;
/*      */ import discord4j.discordjson.json.PresenceData;
/*      */ import discord4j.discordjson.json.ReactionData;
/*      */ import discord4j.discordjson.json.RoleData;
/*      */ import discord4j.discordjson.json.StickerData;
/*      */ import discord4j.discordjson.json.UserData;
/*      */ import discord4j.discordjson.json.VoiceStateData;
/*      */ import discord4j.discordjson.json.gateway.GuildMemberAdd;
/*      */ import discord4j.discordjson.json.gateway.GuildMemberUpdate;
/*      */ import discord4j.discordjson.json.gateway.GuildRoleCreate;
/*      */ import discord4j.discordjson.json.gateway.GuildRoleUpdate;
/*      */ import discord4j.discordjson.json.gateway.GuildScheduledEventCreate;
/*      */ import discord4j.discordjson.json.gateway.GuildScheduledEventUserAdd;
/*      */ import discord4j.discordjson.json.gateway.GuildScheduledEventUserRemove;
/*      */ import discord4j.discordjson.json.gateway.MessageDeleteBulk;
/*      */ import discord4j.discordjson.json.gateway.MessageReactionAdd;
/*      */ import discord4j.discordjson.json.gateway.MessageReactionRemove;
/*      */ import discord4j.discordjson.json.gateway.MessageReactionRemoveEmoji;
/*      */ import discord4j.discordjson.json.gateway.PresenceUpdate;
/*      */ import discord4j.discordjson.json.gateway.Ready;
/*      */ import discord4j.discordjson.possible.Possible;
/*      */ import java.util.Collections;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.ConcurrentMap;
/*      */ import java.util.concurrent.atomic.AtomicReference;
/*      */ import java.util.stream.Collectors;
/*      */ import org.reactivestreams.Publisher;
/*      */ import reactor.core.publisher.Flux;
/*      */ import reactor.core.publisher.Mono;
/*      */ import reactor.util.annotation.Nullable;
/*      */ 
/*      */ public class LocalStoreLayout implements StoreLayout, DataAccessor, GatewayDataUpdater {
/*   54 */   private final ConcurrentMap<Long, GuildContent> contentByGuild = new ConcurrentHashMap<>(); private final StorageConfig config;
/*   55 */   private final ConcurrentMap<Long, ChannelContent> contentByChannel = new ConcurrentHashMap<>();
/*      */   
/*   57 */   private final ConcurrentMap<Long, ImmutableChannelData> channels = new ConcurrentHashMap<>();
/*      */   
/*   59 */   private final ConcurrentMap<Long, WithUser<ImmutableEmojiData>> emojis = new ConcurrentHashMap<>();
/*      */ 
/*      */   
/*   62 */   private final ConcurrentMap<Long, ImmutableStickerData> stickers = new ConcurrentHashMap<>();
/*      */ 
/*      */   
/*   65 */   private final ConcurrentMap<Long, WrappedGuildData> guilds = new ConcurrentHashMap<>();
/*      */   
/*   67 */   private final ConcurrentMap<Long2, WithUser<ImmutableMemberData>> members = new ConcurrentHashMap<>();
/*      */ 
/*      */   
/*      */   private final ConcurrentMap<Long2, WithUser<ImmutableMessageData>> messages;
/*      */   
/*   72 */   private final ConcurrentMap<Long2, WithUser<ImmutablePresenceData>> presences = new ConcurrentHashMap<>();
/*      */ 
/*      */   
/*   75 */   private final ConcurrentMap<Long, RoleData> roles = new ConcurrentHashMap<>();
/*      */   
/*   77 */   private final ConcurrentMap<Long, GuildScheduledEventData> scheduledEvents = new ConcurrentHashMap<>();
/*   78 */   private final ConcurrentMap<Long2, List<Long>> scheduledEventsUsers = new ConcurrentHashMap<>();
/*      */ 
/*      */   
/*   81 */   private final ConcurrentMap<Long, AtomicReference<ImmutableUserData>> users = StorageBackend.caffeine(Caffeine::weakValues).newMap();
/*      */   
/*   83 */   private final ConcurrentMap<Long2, ImmutableVoiceStateData> voiceStates = new ConcurrentHashMap<>();
/*      */ 
/*      */   
/*   86 */   private final Set<Integer> shardsConnected = new HashSet<>();
/*      */   private volatile AtomicReference<ImmutableUserData> selfUser;
/*      */   private volatile int shardCount;
/*      */   
/*      */   private LocalStoreLayout(StorageConfig config) {
/*   91 */     this.messages = config.getMessageBackend().newMap((k, v, reason) -> {
/*      */           if (k != null && reason.wasEvicted()) {
/*      */             ImplUtils.ifNonNullDo(this.contentByChannel.get(Long.valueOf(k.a)), ());
/*      */           }
/*      */         });
/*   96 */     this.config = config;
/*      */   }
/*      */   
/*      */   public static LocalStoreLayout create(StorageConfig config) {
/*  100 */     return new LocalStoreLayout(config);
/*      */   }
/*      */   
/*      */   public static LocalStoreLayout create() {
/*  104 */     return create(StorageConfig.builder().build());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Long> countChannels() {
/*  111 */     return Mono.just(Long.valueOf(this.channels.size()));
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Long> countChannelsInGuild(long guildId) {
/*  116 */     return Mono.justOrEmpty(this.contentByGuild.get(Long.valueOf(guildId)))
/*  117 */       .map(content -> Long.valueOf(content.channelIds.size()));
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Long> countStickers() {
/*  122 */     return Mono.just(Long.valueOf(this.stickers.size()));
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Long> countStickersInGuild(long guildId) {
/*  127 */     return Mono.justOrEmpty(this.contentByGuild.get(Long.valueOf(guildId)))
/*  128 */       .map(content -> Long.valueOf(content.stickerIds.size()));
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Long> countEmojis() {
/*  133 */     return Mono.just(Long.valueOf(this.emojis.size()));
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Long> countEmojisInGuild(long guildId) {
/*  138 */     return Mono.justOrEmpty(this.contentByGuild.get(Long.valueOf(guildId)))
/*  139 */       .map(content -> Long.valueOf(content.emojiIds.size()));
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Long> countGuilds() {
/*  144 */     return Mono.just(Long.valueOf(this.guilds.size()));
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Long> countMembers() {
/*  149 */     return Mono.just(Long.valueOf(this.members.size()));
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Long> countMembersInGuild(long guildId) {
/*  154 */     return Mono.justOrEmpty(this.contentByGuild.get(Long.valueOf(guildId)))
/*  155 */       .map(content -> Long.valueOf(content.memberIds.size()));
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Long> countExactMembersInGuild(long guildId) {
/*  160 */     return Mono.justOrEmpty(this.contentByGuild.get(Long.valueOf(guildId)))
/*  161 */       .filter(rec$ -> ((GuildContent)rec$).isMemberListComplete())
/*  162 */       .switchIfEmpty(Mono.error(discord4j.common.store.api.object.ExactResultNotAvailableException::new))
/*  163 */       .map(content -> Long.valueOf(content.memberIds.size()));
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Long> countMessages() {
/*  168 */     return Mono.just(Long.valueOf(this.messages.size()));
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Long> countMessagesInChannel(long channelId) {
/*  173 */     return Mono.justOrEmpty(this.contentByChannel.get(Long.valueOf(channelId)))
/*  174 */       .map(content -> Long.valueOf(content.messageIds.size()));
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Long> countPresences() {
/*  179 */     return Mono.just(Long.valueOf(this.presences.size()));
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Long> countPresencesInGuild(long guildId) {
/*  184 */     return Mono.justOrEmpty(this.contentByGuild.get(Long.valueOf(guildId)))
/*  185 */       .map(content -> Long.valueOf(content.presenceIds.size()));
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Long> countRoles() {
/*  190 */     return Mono.just(Long.valueOf(this.roles.size()));
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Long> countRolesInGuild(long guildId) {
/*  195 */     return Mono.justOrEmpty(this.contentByGuild.get(Long.valueOf(guildId)))
/*  196 */       .map(content -> Long.valueOf(content.roleIds.size()));
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Long> countUsers() {
/*  201 */     return Mono.just(Long.valueOf(this.users.size()));
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Long> countVoiceStates() {
/*  206 */     return Mono.just(Long.valueOf(this.voiceStates.size()));
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Long> countVoiceStatesInGuild(long guildId) {
/*  211 */     return Mono.justOrEmpty(this.contentByGuild.get(Long.valueOf(guildId)))
/*  212 */       .map(content -> Long.valueOf(content.voiceStateIds.size()));
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Long> countVoiceStatesInChannel(long guildId, long channelId) {
/*  217 */     return Mono.justOrEmpty(this.contentByChannel.get(Long.valueOf(channelId)))
/*  218 */       .map(content -> Long.valueOf(content.voiceStateIds.size()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Flux<ChannelData> getChannels() {
/*  225 */     return Flux.fromIterable(this.channels.values());
/*      */   }
/*      */ 
/*      */   
/*      */   public Flux<ChannelData> getChannelsInGuild(long guildId) {
/*  230 */     return Mono.justOrEmpty(this.contentByGuild.get(Long.valueOf(guildId)))
/*  231 */       .flatMapIterable(content -> content.channelIds)
/*  232 */       .flatMap(id -> Mono.justOrEmpty(this.channels.get(id)));
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<ChannelData> getChannelById(long channelId) {
/*  237 */     return Mono.justOrEmpty(this.channels.get(Long.valueOf(channelId)));
/*      */   }
/*      */ 
/*      */   
/*      */   public Flux<StickerData> getStickers() {
/*  242 */     return Flux.fromIterable(this.stickers.values());
/*      */   }
/*      */ 
/*      */   
/*      */   public Flux<StickerData> getStickersInGuild(long guildId) {
/*  247 */     return Mono.justOrEmpty(this.contentByGuild.get(Long.valueOf(guildId)))
/*  248 */       .flatMapIterable(content -> content.stickerIds)
/*  249 */       .flatMap(id -> Mono.justOrEmpty(this.stickers.get(id)));
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<StickerData> getStickerById(long guildId, long stickerId) {
/*  254 */     return Mono.justOrEmpty(this.stickers.get(Long.valueOf(stickerId)));
/*      */   }
/*      */ 
/*      */   
/*      */   public Flux<EmojiData> getEmojis() {
/*  259 */     return Flux.fromIterable(this.emojis.values()).map(WithUser::get);
/*      */   }
/*      */ 
/*      */   
/*      */   public Flux<EmojiData> getEmojisInGuild(long guildId) {
/*  264 */     return Mono.justOrEmpty(this.contentByGuild.get(Long.valueOf(guildId)))
/*  265 */       .flatMapIterable(content -> content.emojiIds)
/*  266 */       .flatMap(id -> Mono.justOrEmpty(this.emojis.get(id)))
/*  267 */       .map(WithUser::get);
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<EmojiData> getEmojiById(long guildId, long emojiId) {
/*  272 */     return Mono.justOrEmpty(this.emojis.get(Long.valueOf(emojiId))).map(WithUser::get);
/*      */   }
/*      */ 
/*      */   
/*      */   public Flux<GuildData> getGuilds() {
/*  277 */     return Flux.fromIterable(this.guilds.values()).map(WrappedGuildData::unwrap);
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<GuildData> getGuildById(long guildId) {
/*  282 */     return Mono.justOrEmpty(this.guilds.get(Long.valueOf(guildId))).map(WrappedGuildData::unwrap);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Flux<GuildScheduledEventData> getScheduledEventsInGuild(long guildId) {
/*  289 */     Objects.requireNonNull(this.scheduledEvents); return Mono.justOrEmpty(this.contentByGuild.get(Long.valueOf(guildId))).flatMapIterable(content -> content.eventIds).mapNotNull(this.scheduledEvents::get);
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<GuildScheduledEventData> getScheduledEventById(long guildId, long eventId) {
/*  294 */     return Mono.justOrEmpty(this.scheduledEvents.get(Long.valueOf(eventId)))
/*  295 */       .filter(event -> (event.guildId().asLong() == guildId));
/*      */   }
/*      */ 
/*      */   
/*      */   public Flux<Id> getScheduledEventUsersInEvent(long guildId, long eventId) {
/*  300 */     return Flux.fromIterable(this.scheduledEventsUsers.getOrDefault(new Long2(guildId, eventId), new ArrayList()))
/*  301 */       .map(Id::of);
/*      */   }
/*      */ 
/*      */   
/*      */   public Flux<MemberData> getMembers() {
/*  306 */     return Flux.fromIterable(this.members.values()).map(WithUser::get);
/*      */   }
/*      */ 
/*      */   
/*      */   public Flux<MemberData> getMembersInGuild(long guildId) {
/*  311 */     return Mono.justOrEmpty(this.contentByGuild.get(Long.valueOf(guildId)))
/*  312 */       .flatMapIterable(content -> content.memberIds)
/*  313 */       .flatMap(id -> Mono.justOrEmpty(this.members.get(id)))
/*  314 */       .map(WithUser::get);
/*      */   }
/*      */ 
/*      */   
/*      */   public Flux<MemberData> getExactMembersInGuild(long guildId) {
/*  319 */     return Mono.justOrEmpty(this.contentByGuild.get(Long.valueOf(guildId)))
/*  320 */       .filter(rec$ -> ((GuildContent)rec$).isMemberListComplete())
/*  321 */       .switchIfEmpty(Mono.error(discord4j.common.store.api.object.ExactResultNotAvailableException::new))
/*  322 */       .flatMapIterable(content -> content.memberIds)
/*  323 */       .flatMap(id -> Mono.justOrEmpty(this.members.get(id)))
/*  324 */       .map(WithUser::get);
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<MemberData> getMemberById(long guildId, long userId) {
/*  329 */     return Mono.justOrEmpty(this.members.get(new Long2(guildId, userId)))
/*  330 */       .map(WithUser::get);
/*      */   }
/*      */ 
/*      */   
/*      */   public Flux<MessageData> getMessages() {
/*  335 */     return Flux.fromIterable(this.messages.values()).map(WithUser::get);
/*      */   }
/*      */ 
/*      */   
/*      */   public Flux<MessageData> getMessagesInChannel(long channelId) {
/*  340 */     return Mono.justOrEmpty(this.contentByChannel.get(Long.valueOf(channelId)))
/*  341 */       .flatMapIterable(content -> content.messageIds)
/*  342 */       .flatMap(id -> Mono.justOrEmpty(this.messages.get(id)))
/*  343 */       .map(WithUser::get);
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<MessageData> getMessageById(long channelId, long messageId) {
/*  348 */     return Mono.justOrEmpty(this.messages.get(new Long2(channelId, messageId)))
/*  349 */       .map(WithUser::get);
/*      */   }
/*      */ 
/*      */   
/*      */   public Flux<PresenceData> getPresences() {
/*  354 */     return Flux.fromIterable(this.presences.values()).map(WithUser::get);
/*      */   }
/*      */ 
/*      */   
/*      */   public Flux<PresenceData> getPresencesInGuild(long guildId) {
/*  359 */     return Mono.justOrEmpty(this.contentByGuild.get(Long.valueOf(guildId)))
/*  360 */       .flatMapIterable(content -> content.presenceIds)
/*  361 */       .flatMap(id -> Mono.justOrEmpty(this.presences.get(id)))
/*  362 */       .map(WithUser::get);
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<PresenceData> getPresenceById(long guildId, long userId) {
/*  367 */     return Mono.justOrEmpty(this.presences.get(new Long2(guildId, userId)))
/*  368 */       .map(WithUser::get);
/*      */   }
/*      */ 
/*      */   
/*      */   public Flux<RoleData> getRoles() {
/*  373 */     return Flux.fromIterable(this.roles.values());
/*      */   }
/*      */ 
/*      */   
/*      */   public Flux<RoleData> getRolesInGuild(long guildId) {
/*  378 */     return Mono.justOrEmpty(this.contentByGuild.get(Long.valueOf(guildId)))
/*  379 */       .flatMapIterable(content -> content.roleIds)
/*  380 */       .flatMap(id -> Mono.justOrEmpty(this.roles.get(id)));
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<RoleData> getRoleById(long guildId, long roleId) {
/*  385 */     return Mono.justOrEmpty(this.roles.get(Long.valueOf(roleId)));
/*      */   }
/*      */ 
/*      */   
/*      */   public Flux<UserData> getUsers() {
/*  390 */     return Flux.fromIterable(this.users.values())
/*  391 */       .map(AtomicReference::get);
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<UserData> getUserById(long userId) {
/*  396 */     return Mono.justOrEmpty(this.users.get(Long.valueOf(userId)))
/*  397 */       .map(AtomicReference::get);
/*      */   }
/*      */ 
/*      */   
/*      */   public Flux<VoiceStateData> getVoiceStates() {
/*  402 */     return Flux.fromIterable(this.voiceStates.values());
/*      */   }
/*      */ 
/*      */   
/*      */   public Flux<VoiceStateData> getVoiceStatesInChannel(long guildId, long channelId) {
/*  407 */     return Mono.justOrEmpty(this.contentByChannel.get(Long.valueOf(channelId)))
/*  408 */       .flatMapIterable(content -> content.voiceStateIds)
/*  409 */       .flatMap(id -> Mono.justOrEmpty(this.voiceStates.get(id)));
/*      */   }
/*      */ 
/*      */   
/*      */   public Flux<VoiceStateData> getVoiceStatesInGuild(long guildId) {
/*  414 */     return Mono.justOrEmpty(this.contentByGuild.get(Long.valueOf(guildId)))
/*  415 */       .flatMapIterable(content -> content.voiceStateIds)
/*  416 */       .flatMap(id -> Mono.justOrEmpty(this.voiceStates.get(id)));
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<VoiceStateData> getVoiceStateById(long guildId, long userId) {
/*  421 */     return Mono.justOrEmpty(this.voiceStates.get(new Long2(guildId, userId)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Void> onChannelCreate(int shardIndex, ChannelCreate dispatch) {
/*  428 */     return Mono.fromRunnable(() -> dispatch.channel().guildId().toOptional().ifPresent(()));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<ChannelData> onChannelDelete(int shardIndex, ChannelDelete dispatch) {
/*  434 */     ChannelData data = dispatch.channel();
/*  435 */     return Mono.fromRunnable(() -> data.guildId().toOptional().map(Id::asLong).ifPresent(()))
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  443 */       .thenReturn(data);
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<ChannelData> onChannelUpdate(int shardIndex, ChannelUpdate dispatch) {
/*  448 */     return Mono.fromCallable(() -> (ChannelData)dispatch.channel().guildId().toOptional().map(()).orElse(null));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Void> onGuildCreate(int shardIndex, GuildCreate dispatch) {
/*  455 */     return Mono.fromRunnable(() -> {
/*      */           long guildId = dispatch.guild().id().asLong();
/*      */           GuildCreateData createData = dispatch.guild();
/*      */           List<RoleData> roles = createData.roles();
/*      */           List<EmojiData> emojis = createData.emojis();
/*      */           List<MemberData> members = createData.members();
/*      */           List<ChannelData> channels = createData.channels();
/*      */           List<PresenceData> presences = createData.presences();
/*      */           List<VoiceStateData> voiceStates = createData.voiceStates();
/*      */           ImmutableGuildData guild = ImmutableGuildData.builder().from((GuildCreateFields)createData).roles(Collections.emptyList()).emojis(Collections.emptyList()).members(Collections.emptyList()).channels(Collections.emptyList()).build();
/*      */           this.guilds.put(Long.valueOf(guildId), new WrappedGuildData(guild));
/*      */           roles.forEach(());
/*      */           emojis.forEach(());
/*      */           members.forEach(());
/*      */           channels.forEach(());
/*      */           presences.forEach(());
/*      */           voiceStates.forEach(());
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<GuildData> onGuildDelete(int shardIndex, GuildDelete dispatch) {
/*  483 */     long guildId = dispatch.guild().id().asLong();
/*  484 */     return Mono.fromCallable(() -> (GuildData)ImplUtils.ifNonNullMap(this.contentByGuild.get(Long.valueOf(guildId)), ()));
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Set<StickerData>> onGuildStickersUpdate(int shardIndex, GuildStickersUpdate dispatch) {
/*  489 */     long guildId = dispatch.guildId().asLong();
/*  490 */     return Mono.fromCallable(() -> {
/*      */           GuildContent content = computeGuildContent(guildId);
/*      */           Objects.requireNonNull(this.stickers);
/*      */           Set<StickerData> old = (Set<StickerData>)content.stickerIds.stream().map(this.stickers::get).filter(Objects::nonNull).collect(Collectors.toSet());
/*      */           this.stickers.keySet().removeAll(content.stickerIds);
/*      */           ImplUtils.ifNonNullDo(this.guilds.get(Long.valueOf(guildId)), ());
/*      */           content.stickerIds.clear();
/*      */           dispatch.stickers().forEach(());
/*      */           return old;
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Set<EmojiData>> onGuildEmojisUpdate(int shardIndex, GuildEmojisUpdate dispatch) {
/*  506 */     long guildId = dispatch.guildId().asLong();
/*  507 */     return Mono.fromCallable(() -> {
/*      */           GuildContent content = computeGuildContent(guildId);
/*      */           Objects.requireNonNull(this.emojis);
/*      */           Set<EmojiData> old = (Set<EmojiData>)content.emojiIds.stream().map(this.emojis::get).filter(Objects::nonNull).map(WithUser::get).collect(Collectors.toSet());
/*      */           this.emojis.keySet().removeAll(content.emojiIds);
/*      */           ImplUtils.ifNonNullDo(this.guilds.get(Long.valueOf(guildId)), ());
/*      */           content.emojiIds.clear();
/*      */           dispatch.emojis().forEach(());
/*      */           return old;
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Void> onGuildMemberAdd(int shardIndex, GuildMemberAdd dispatch) {
/*  524 */     return Mono.fromRunnable(() -> saveMember(dispatch.guildId().asLong(), dispatch.member()));
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<MemberData> onGuildMemberRemove(int shardIndex, GuildMemberRemove dispatch) {
/*  529 */     long guildId = dispatch.guildId().asLong();
/*  530 */     long userId = dispatch.user().id().asLong();
/*  531 */     return Mono.fromCallable(() -> {
/*      */           Long2 memberId = new Long2(guildId, userId);
/*      */           GuildContent guildContent = computeGuildContent(guildId);
/*      */           guildContent.memberIds.remove(memberId);
/*      */           ImplUtils.ifNonNullDo(this.guilds.get(Long.valueOf(guildId)), ());
/*      */           return ImplUtils.<WithUser, MemberData>ifNonNullMap(this.members.remove(memberId), WithUser::get);
/*      */         });
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Void> onGuildMembersChunk(int shardIndex, GuildMembersChunk dispatch) {
/*  542 */     long guildId = dispatch.guildId().asLong();
/*  543 */     return Mono.fromRunnable(() -> dispatch.members().forEach(()));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<MemberData> onGuildMemberUpdate(int shardIndex, GuildMemberUpdate dispatch) {
/*  549 */     long guildId = dispatch.guildId().asLong();
/*  550 */     long userId = dispatch.user().id().asLong();
/*  551 */     Long2 id = new Long2(guildId, userId);
/*  552 */     return Mono.fromCallable(() -> {
/*      */           MemberData oldData = ImplUtils.<WithUser, MemberData>ifNonNullMap(this.members.get(id), WithUser::get);
/*      */           this.members.computeIfPresent(id, ());
/*      */           return oldData;
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Void> onGuildRoleCreate(int shardIndex, GuildRoleCreate dispatch) {
/*  573 */     return Mono.fromRunnable(() -> saveRole(dispatch.guildId().asLong(), dispatch.role()));
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<RoleData> onGuildRoleDelete(int shardIndex, GuildRoleDelete dispatch) {
/*  578 */     long guildId = dispatch.guildId().asLong();
/*  579 */     Id roleId = dispatch.roleId();
/*  580 */     return Mono.fromCallable(() -> {
/*      */           GuildContent guildContent = computeGuildContent(guildId);
/*      */           guildContent.roleIds.remove(Long.valueOf(roleId.asLong()));
/*      */           ImplUtils.ifNonNullDo(this.guilds.get(Long.valueOf(guildId)), ());
/*      */           guildContent.memberIds.forEach(());
/*      */           return this.roles.remove(Long.valueOf(roleId.asLong()));
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<RoleData> onGuildRoleUpdate(int shardIndex, GuildRoleUpdate dispatch) {
/*  592 */     return Mono.fromCallable(() -> saveRole(dispatch.guildId().asLong(), dispatch.role()));
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Void> onGuildScheduledEventCreate(int shardIndex, GuildScheduledEventCreate dispatch) {
/*  597 */     long eventId = dispatch.scheduledEvent().id().asLong();
/*      */ 
/*      */     
/*  600 */     GuildContent guildContent = computeGuildContent(dispatch.scheduledEvent().guildId().asLong());
/*  601 */     guildContent.eventIds.add(Long.valueOf(eventId));
/*      */ 
/*      */     
/*  604 */     return Mono.fromRunnable(() -> this.scheduledEvents.put(Long.valueOf(eventId), ImmutableGuildScheduledEventData.copyOf(dispatch.scheduledEvent())));
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<GuildScheduledEventData> onGuildScheduledEventUpdate(int shardIndex, GuildScheduledEventUpdate dispatch) {
/*  609 */     long eventId = dispatch.scheduledEvent().id().asLong();
/*      */ 
/*      */     
/*  612 */     return Mono.fromCallable(() -> (GuildScheduledEventData)this.scheduledEvents.replace(Long.valueOf(eventId), ImmutableGuildScheduledEventData.copyOf(dispatch.scheduledEvent())));
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<GuildScheduledEventData> onGuildScheduledEventDelete(int shardIndex, GuildScheduledEventDelete dispatch) {
/*  617 */     long eventId = dispatch.scheduledEvent().id().asLong();
/*      */ 
/*      */     
/*  620 */     GuildContent guildContent = computeGuildContent(dispatch.scheduledEvent().guildId().asLong());
/*  621 */     guildContent.eventIds.remove(Long.valueOf(eventId));
/*      */ 
/*      */     
/*  624 */     return Mono.fromRunnable(() -> {
/*      */           this.scheduledEvents.remove(Long.valueOf(eventId));
/*      */           this.scheduledEventsUsers.remove(new Long2(dispatch.scheduledEvent().guildId().asLong(), eventId));
/*      */         });
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Void> onGuildScheduledEventUserAdd(int shardIndex, GuildScheduledEventUserAdd dispatch) {
/*  632 */     Long2 key = new Long2(dispatch.guildId().asLong(), dispatch.scheduledEventId().asLong());
/*      */     
/*  634 */     return Mono.fromRunnable(() -> ((List<Long>)this.scheduledEventsUsers.computeIfAbsent(key, ())).add(Long.valueOf(dispatch.userId().asLong())));
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Void> onGuildScheduledEventUserRemove(int shardIndex, GuildScheduledEventUserRemove dispatch) {
/*  639 */     Long2 key = new Long2(dispatch.guildId().asLong(), dispatch.scheduledEventId().asLong());
/*      */     
/*  641 */     return Mono.fromRunnable(() -> ((List)this.scheduledEventsUsers.computeIfAbsent(key, ())).remove(Long.valueOf(dispatch.userId().asLong())));
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<GuildData> onGuildUpdate(int shardIndex, GuildUpdate dispatch) {
/*  646 */     long guildId = dispatch.guild().id().asLong();
/*  647 */     return Mono.fromCallable(() -> {
/*      */           WrappedGuildData old = this.guilds.get(Long.valueOf(guildId));
/*      */           this.guilds.computeIfPresent(Long.valueOf(guildId), ());
/*      */           return ImplUtils.<WrappedGuildData, GuildData>ifNonNullMap(old, WrappedGuildData::unwrap);
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Void> onShardInvalidation(int shardIndex, InvalidationCause cause) {
/*  659 */     return Mono.fromRunnable(() -> {
/*      */           this.shardsConnected.remove(Integer.valueOf(shardIndex));
/*      */           if (this.config.getInvalidationFilter().contains(cause)) {
/*      */             this.contentByGuild.entrySet().stream().filter(()).map(Map.Entry::getValue).forEach(());
/*      */           }
/*      */           if (this.shardsConnected.isEmpty()) {
/*      */             this.shardCount = 0;
/*      */           }
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Void> onMessageCreate(int shardIndex, MessageCreate dispatch) {
/*  675 */     ImmutableMessageData message = ImmutableMessageData.copyOf(dispatch.message());
/*  676 */     long channelId = message.channelId().asLong();
/*  677 */     long messageId = message.id().asLong();
/*  678 */     Long2 id = new Long2(channelId, messageId);
/*  679 */     return Mono.fromRunnable(() -> {
/*      */           ChannelContent channelContent = computeChannelContent(id.a);
/*      */           this.channels.computeIfPresent(Long.valueOf(id.a), ());
/*      */           channelContent.messageIds.add(id);
/*      */           AtomicReference<ImmutableUserData> userRef = computeUserRef(message.author().id().asLong(), message, ());
/*      */           this.messages.put(id, new WithUser<>(message.withAuthor(EmptyUser.INSTANCE), userRef, ImmutableMessageData::withAuthor));
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<MessageData> onMessageDelete(int shardIndex, MessageDelete dispatch) {
/*  692 */     long messageId = dispatch.id().asLong();
/*  693 */     long channelId = dispatch.channelId().asLong();
/*  694 */     return Mono.fromCallable(() -> deleteMessage(channelId, messageId));
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Set<MessageData>> onMessageDeleteBulk(int shardIndex, MessageDeleteBulk dispatch) {
/*  699 */     return Mono.fromCallable(() -> (Set)dispatch.ids().stream().map(Id::asLong).map(()).filter(Objects::nonNull).collect(Collectors.toSet()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Void> onMessageReactionAdd(int shardIndex, MessageReactionAdd dispatch) {
/*  708 */     long channelId = dispatch.channelId().asLong();
/*  709 */     long messageId = dispatch.messageId().asLong();
/*  710 */     return Mono.fromRunnable(() -> this.messages.computeIfPresent(new Long2(channelId, messageId), ()));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Void> onMessageReactionRemove(int shardIndex, MessageReactionRemove dispatch) {
/*  716 */     long channelId = dispatch.channelId().asLong();
/*  717 */     long messageId = dispatch.messageId().asLong();
/*  718 */     return Mono.fromRunnable(() -> this.messages.computeIfPresent(new Long2(channelId, messageId), ()));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Void> onMessageReactionRemoveAll(int shardIndex, MessageReactionRemoveAll dispatch) {
/*  724 */     long channelId = dispatch.channelId().asLong();
/*  725 */     long messageId = dispatch.messageId().asLong();
/*  726 */     return Mono.fromRunnable(() -> this.messages.computeIfPresent(new Long2(channelId, messageId), ()));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<Void> onMessageReactionRemoveEmoji(int shardIndex, MessageReactionRemoveEmoji dispatch) {
/*  732 */     long channelId = dispatch.channelId().asLong();
/*  733 */     long messageId = dispatch.messageId().asLong();
/*  734 */     return Mono.fromRunnable(() -> this.messages.computeIfPresent(new Long2(channelId, messageId), ()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<MessageData> onMessageUpdate(int shardIndex, MessageUpdate dispatch) {
/*  745 */     ImmutablePartialMessageData edited = ImmutablePartialMessageData.copyOf(dispatch.message());
/*  746 */     long channelId = edited.channelId().asLong();
/*  747 */     long messageId = edited.id().asLong();
/*  748 */     Long2 id = new Long2(channelId, messageId);
/*  749 */     return Mono.fromCallable(() -> {
/*      */           MessageData old = ImplUtils.<WithUser, MessageData>ifNonNullMap(this.messages.get(id), WithUser::get);
/*      */           this.messages.computeIfPresent(id, ());
/*      */           return old;
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<PresenceAndUserData> onPresenceUpdate(int shardIndex, PresenceUpdate dispatch) {
/*  783 */     return Mono.fromCallable(() -> savePresence(dispatch.guildId().asLong(), ImplUtils.createPresence(dispatch)));
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Void> onReady(Ready dispatch) {
/*  788 */     return Mono.fromRunnable(() -> {
/*      */           int[] shardInfo = dispatch.shard().toOptional().orElseGet(());
/*      */           if (this.selfUser == null) {
/*      */             ImmutableUserData userData = ImmutableUserData.copyOf(dispatch.user());
/*      */             this.selfUser = new AtomicReference<>(userData);
/*      */             this.users.put(Long.valueOf(userData.id().asLong()), this.selfUser);
/*      */           } 
/*      */           if (this.shardCount == 0) {
/*      */             this.shardCount = shardInfo[1];
/*      */           }
/*      */           this.shardsConnected.add(Integer.valueOf(shardInfo[0]));
/*      */         });
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<UserData> onUserUpdate(int shardIndex, UserUpdate dispatch) {
/*  804 */     return Mono.fromCallable(() -> (UserData)ImplUtils.<AtomicReference, UserData>ifNonNullMap(this.users.get(Long.valueOf(dispatch.user().id().asLong())), ()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<VoiceStateData> onVoiceStateUpdateDispatch(int shardIndex, VoiceStateUpdateDispatch dispatch) {
/*  811 */     VoiceStateData voiceState = dispatch.voiceState();
/*  812 */     return Mono.justOrEmpty(voiceState.guildId().toOptional())
/*  813 */       .map(Id::asLong)
/*  814 */       .flatMap(guildId -> Mono.fromCallable(()));
/*      */   }
/*      */ 
/*      */   
/*      */   public Mono<Void> onGuildMembersCompletion(long guildId) {
/*  819 */     return Mono.fromRunnable(() -> ImplUtils.ifNonNullDo(this.contentByGuild.get(Long.valueOf(guildId)), ()));
/*      */   }
/*      */ 
/*      */   
/*      */   public DataAccessor getDataAccessor() {
/*  824 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public GatewayDataUpdater getGatewayDataUpdater() {
/*  829 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private GuildContent computeGuildContent(long guildId) {
/*  835 */     return this.contentByGuild.computeIfAbsent(Long.valueOf(guildId), x$0 -> new GuildContent(x$0));
/*      */   }
/*      */   
/*      */   private ChannelContent computeChannelContent(long channelId) {
/*  839 */     return this.contentByChannel.computeIfAbsent(Long.valueOf(channelId), x$0 -> new ChannelContent(x$0));
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   private ChannelData saveChannel(long guildId, ChannelData channel) {
/*  844 */     long channelId = channel.id().asLong();
/*  845 */     GuildContent guildContent = computeGuildContent(guildId);
/*  846 */     guildContent.channelIds.add(Long.valueOf(channelId));
/*  847 */     ImplUtils.ifNonNullDo(this.guilds.get(Long.valueOf(guildId)), guild -> guild.getChannels().add(Id.of(channelId)));
/*  848 */     return (ChannelData)this.channels.put(Long.valueOf(channelId), ImmutableChannelData.copyOf(channel).withGuildId(guildId));
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   private RoleData saveRole(long guildId, RoleData role) {
/*  853 */     long roleId = role.id().asLong();
/*  854 */     GuildContent guildContent = computeGuildContent(guildId);
/*  855 */     guildContent.roleIds.add(Long.valueOf(roleId));
/*  856 */     ImplUtils.ifNonNullDo(this.guilds.get(Long.valueOf(guildId)), guild -> guild.getRoles().add(Id.of(roleId)));
/*  857 */     return (RoleData)this.roles.put(Long.valueOf(roleId), ImmutableRoleData.copyOf(role));
/*      */   }
/*      */   
/*      */   private void saveSticker(long guildId, StickerData sticker) {
/*  861 */     long stickerId = sticker.id().asLong();
/*  862 */     (computeGuildContent(guildId)).stickerIds.add(Long.valueOf(stickerId));
/*  863 */     ImplUtils.ifNonNullDo(this.guilds.get(Long.valueOf(guildId)), guild -> guild.getStickers().add(Id.of(stickerId)));
/*  864 */     this.stickers.put(Long.valueOf(stickerId), ImmutableStickerData.copyOf(sticker));
/*      */   }
/*      */   
/*      */   private void saveEmoji(long guildId, EmojiData emoji) {
/*  868 */     emoji.id().map(Id::asLong).ifPresent(emojiId -> {
/*      */           (computeGuildContent(guildId)).emojiIds.add(emojiId);
/*      */           ImplUtils.ifNonNullDo(this.guilds.get(Long.valueOf(guildId)), ());
/*      */           AtomicReference<ImmutableUserData> userRef = ImplUtils.<Long, AtomicReference<ImmutableUserData>>ifNonNullMap(emoji.user().toOptional().map(()).orElse(null), ());
/*      */           this.emojis.put(emojiId, new WithUser<>(ImmutableEmojiData.copyOf(emoji).withUser(Possible.absent()), userRef, ()));
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void saveMember(long guildId, MemberData member) {
/*  880 */     Long2 memberId = new Long2(guildId, member.user().id().asLong());
/*  881 */     GuildContent guildContent = computeGuildContent(guildId);
/*  882 */     guildContent.memberIds.add(memberId);
/*  883 */     ImplUtils.ifNonNullDo(this.guilds.get(Long.valueOf(guildId)), guild -> guild.getMembers().add(Id.of(memberId.b)));
/*  884 */     AtomicReference<ImmutableUserData> userRef = computeUserRef(memberId.b, member, (m, u) -> ImmutableUserData.copyOf(m.user()));
/*      */     
/*  886 */     this.members.put(memberId, new WithUser<>(ImmutableMemberData.copyOf(member).withUser(EmptyUser.INSTANCE), userRef, ImmutableMemberData::withUser));
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private PresenceAndUserData savePresence(long guildId, PresenceData presence) {
/*  892 */     Long2 presenceId = new Long2(guildId, presence.user().id().asLong());
/*  893 */     ImmutableUserData oldUser = ImplUtils.<AtomicReference, ImmutableUserData>ifNonNullMap(this.users.get(Long.valueOf(presenceId.b)), AtomicReference::get);
/*  894 */     return ImplUtils.<AtomicReference<ImmutableUserData>, PresenceAndUserData>ifNonNullMap(computeUserRef(presenceId.b, presence, LocalStoreLayout::userFromPresence), userRef -> {
/*      */           GuildContent guildContent = computeGuildContent(guildId);
/*      */ 
/*      */ 
/*      */           
/*      */           guildContent.presenceIds.add(presenceId);
/*      */ 
/*      */ 
/*      */           
/*      */           WithUser<ImmutablePresenceData> oldPresence = this.presences.put(presenceId, new WithUser<>(ImmutablePresenceData.copyOf(presence).withUser(EmptyPartialUser.INSTANCE), userRef, ()));
/*      */ 
/*      */           
/*  906 */           return (oldPresence == null && oldUser == null) ? null : PresenceAndUserData.of(ImplUtils.<WithUser<ImmutablePresenceData>, PresenceData>ifNonNullMap(oldPresence, WithUser::get), (UserData)oldUser);
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private static ImmutableUserData userFromPresence(PresenceData newPresence, @Nullable ImmutableUserData oldUser) {
/*  915 */     if (oldUser == null) return null; 
/*  916 */     ImmutablePartialUserData partialUserData = ImmutablePartialUserData.copyOf(newPresence.user());
/*      */ 
/*      */     
/*  919 */     Objects.requireNonNull(oldUser);
/*      */ 
/*      */     
/*  922 */     Objects.requireNonNull(oldUser); return UserData.builder().from((UserData)oldUser).globalName(ImplUtils.or(Possible.flatOpt(partialUserData.globalName()), oldUser::globalName)).username(partialUserData.usernameOrElse(oldUser.username())).discriminator(partialUserData.discriminatorOrElse(oldUser.discriminator())).avatar(ImplUtils.or(Possible.flatOpt(partialUserData.avatar()), oldUser::avatar))
/*  923 */       .banner(Possible.of(ImplUtils.or(Possible.flatOpt(partialUserData.banner()), () -> Possible.flatOpt(oldUser.banner()))))
/*      */       
/*  925 */       .accentColor(Possible.of(ImplUtils.or(Possible.flatOpt(partialUserData.accentColor()), () -> Possible.flatOpt(oldUser.accentColor()))))
/*      */       
/*  927 */       .build();
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   private VoiceStateData saveOrRemoveVoiceState(long guildId, VoiceStateData voiceState) {
/*  932 */     Long2 voiceStateId = new Long2(guildId, voiceState.userId().asLong());
/*  933 */     GuildContent guildContent = computeGuildContent(guildId);
/*  934 */     VoiceStateData old = (VoiceStateData)this.voiceStates.remove(voiceStateId);
/*  935 */     if (old != null && old.channelId().isPresent()) {
/*  936 */       (computeChannelContent(((Id)old.channelId().get()).asLong())).voiceStateIds.remove(voiceStateId);
/*      */     }
/*  938 */     if (voiceState.channelId().isPresent()) {
/*  939 */       guildContent.voiceStateIds.add(voiceStateId);
/*  940 */       (computeChannelContent(((Id)voiceState.channelId().get()).asLong())).voiceStateIds.add(voiceStateId);
/*  941 */       this.voiceStates.put(voiceStateId, ImmutableVoiceStateData.copyOf(voiceState)
/*  942 */           .withGuildId(guildId)
/*  943 */           .withMember(Possible.absent()));
/*      */     } else {
/*  945 */       guildContent.voiceStateIds.remove(voiceStateId);
/*      */     } 
/*  947 */     return old;
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   private MessageData deleteMessage(long channelId, long messageId) {
/*  952 */     Long2 id = new Long2(channelId, messageId);
/*  953 */     ChannelContent channelContent = computeChannelContent(channelId);
/*  954 */     channelContent.messageIds.remove(id);
/*  955 */     return ImplUtils.<WithUser, MessageData>ifNonNullMap(this.messages.remove(id), WithUser::get);
/*      */   }
/*      */   
/*      */   private ImmutableMessageData addReaction(ImmutableMessageData message, MessageReactionAdd dispatch) {
/*  959 */     boolean me = (dispatch.userId().asLong() == ((ImmutableUserData)this.selfUser.get()).id().asLong());
/*  960 */     List<ReactionData> reactions = message.reactions().toOptional().orElse(Collections.emptyList());
/*  961 */     if (reactions.stream().anyMatch(EmojiKey.predicateEquals(dispatch.emoji()))) {
/*  962 */       return message.withReactions(Possible.of(reactions.stream()
/*  963 */             .map(r -> EmojiKey.predicateEquals(dispatch.emoji()).test(r) ? (ReactionData)ImmutableReactionData.builder().from(r).count(r.count() + 1).me((r.me() || me)).build() : r)
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  968 */             .collect(Collectors.toList())));
/*      */     }
/*  970 */     return message.withReactions(Possible.of(
/*  971 */           ImplUtils.add(reactions, ImmutableReactionData.of(1, me, dispatch.emoji()))));
/*      */   }
/*      */   
/*      */   private ImmutableMessageData removeReaction(ImmutableMessageData message, MessageReactionRemove dispatch) {
/*  975 */     boolean me = (dispatch.userId().asLong() == ((ImmutableUserData)this.selfUser.get()).id().asLong());
/*  976 */     List<ReactionData> reactions = message.reactions().toOptional().orElse(Collections.emptyList());
/*  977 */     return message.withReactions(Possible.of(reactions.stream()
/*  978 */           .map(r -> EmojiKey.predicateEquals(dispatch.emoji()).test(r) ? (ReactionData)ImmutableReactionData.builder().from(r).count(r.count() - 1).me((!me && r.me())).build() : r)
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  983 */           .filter(r -> (r.count() > 0))
/*  984 */           .collect(Collectors.toList())));
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private <T> AtomicReference<ImmutableUserData> computeUserRef(long userId, T newData, BiFunction<T, ImmutableUserData, ImmutableUserData> userUpdater) {
/*      */     AtomicReference<ImmutableUserData> ref;
/*      */     while (true) {
/*  992 */       AtomicReference<ImmutableUserData> existing = this.users.get(Long.valueOf(userId));
/*      */       
/*  994 */       if (existing == null) {
/*  995 */         ImmutableUserData immutableUserData = userUpdater.apply(newData, null);
/*  996 */         if (immutableUserData == null) {
/*  997 */           return null;
/*      */         }
/*  999 */         AtomicReference<ImmutableUserData> atomicReference = new AtomicReference<>(immutableUserData);
/* 1000 */         if (this.users.putIfAbsent(Long.valueOf(userId), atomicReference) != null) {
/*      */           continue;
/*      */         }
/*      */         break;
/*      */       } 
/* 1005 */       ref = existing;
/* 1006 */       ImmutableUserData oldUser = ref.get();
/* 1007 */       ImmutableUserData newUser = userUpdater.apply(newData, oldUser);
/* 1008 */       if (newUser != null && 
/* 1009 */         !ref.compareAndSet(oldUser, newUser)) {
/*      */         continue;
/*      */       }
/*      */       break;
/*      */     } 
/* 1014 */     return ref;
/*      */   }
/*      */ 
/*      */   
/*      */   private static class Long2
/*      */   {
/*      */     private final long a;
/*      */     private final long b;
/*      */     
/*      */     private Long2(long a, long b) {
/* 1024 */       this.a = a;
/* 1025 */       this.b = b;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean equals(Object o) {
/* 1030 */       if (this == o) return true; 
/* 1031 */       if (!(o instanceof Long2)) return false; 
/* 1032 */       Long2 long2 = (Long2)o;
/* 1033 */       return (this.a == long2.a && this.b == long2.b);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public int hashCode() {
/* 1039 */       return Objects.hash(new Object[] { Long.valueOf(this.a), Long.valueOf(this.b) });
/*      */     }
/*      */   }
/*      */   
/*      */   private static class EmojiKey
/*      */   {
/*      */     private final long id;
/*      */     private final String name;
/*      */     
/*      */     private EmojiKey(EmojiData emoji) {
/* 1049 */       this.id = ((Long)emoji.id().map(Id::asLong).orElse(Long.valueOf(-1L))).longValue();
/* 1050 */       this.name = emoji.name().orElse(null);
/*      */     }
/*      */     
/*      */     private static Predicate<ReactionData> predicateEquals(EmojiData emoji) {
/* 1054 */       return r -> (new EmojiKey(r.emoji())).equals(new EmojiKey(emoji));
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean equals(Object o) {
/* 1059 */       if (this == o) return true; 
/* 1060 */       if (o == null || getClass() != o.getClass()) return false; 
/* 1061 */       EmojiKey emojiKey = (EmojiKey)o;
/* 1062 */       return (this.id != -1L) ? ((this.id == emojiKey.id)) : Objects.equals(this.name, emojiKey.name);
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/* 1067 */       return (this.id != -1L) ? Long.hashCode(this.id) : Objects.hash(new Object[] { this.name });
/*      */     }
/*      */   }
/*      */   
/*      */   private class GuildContent
/*      */   {
/*      */     private final long guildId;
/* 1074 */     private final Set<Long> channelIds = new HashSet<>();
/* 1075 */     private final Set<Long> emojiIds = new HashSet<>();
/* 1076 */     private final Set<Long> eventIds = new HashSet<>();
/* 1077 */     private final Set<Long> stickerIds = new HashSet<>();
/* 1078 */     private final Set<LocalStoreLayout.Long2> memberIds = new HashSet<>();
/* 1079 */     private final Set<LocalStoreLayout.Long2> presenceIds = new HashSet<>();
/* 1080 */     private final Set<Long> roleIds = new HashSet<>();
/* 1081 */     private final Set<LocalStoreLayout.Long2> voiceStateIds = new HashSet<>();
/*      */     private volatile boolean memberListComplete;
/*      */     
/*      */     public GuildContent(long guildId) {
/* 1085 */       this.guildId = guildId;
/*      */     }
/*      */     
/*      */     private void completeMemberList() {
/* 1089 */       this.memberListComplete = true;
/*      */     }
/*      */     
/*      */     private boolean isMemberListComplete() {
/* 1093 */       return this.memberListComplete;
/*      */     }
/*      */     
/*      */     @Nullable
/*      */     private GuildData dispose() {
/* 1098 */       WrappedGuildData old = (WrappedGuildData)LocalStoreLayout.this.guilds.remove(Long.valueOf(this.guildId));
/* 1099 */       LocalStoreLayout.this.contentByGuild.remove(Long.valueOf(this.guildId));
/* 1100 */       ((Set)LocalStoreLayout.this.contentByChannel.values().stream()
/* 1101 */         .filter(content -> this.channelIds.contains(Long.valueOf(content.channelId)))
/* 1102 */         .collect(Collectors.toSet()))
/* 1103 */         .forEach(rec$ -> ((LocalStoreLayout.ChannelContent)rec$).dispose());
/* 1104 */       LocalStoreLayout.this.emojis.keySet().removeAll(this.emojiIds);
/* 1105 */       LocalStoreLayout.this.stickers.keySet().removeAll(this.stickerIds);
/* 1106 */       LocalStoreLayout.this.members.keySet().removeAll(this.memberIds);
/* 1107 */       LocalStoreLayout.this.presences.keySet().removeAll(this.presenceIds);
/* 1108 */       LocalStoreLayout.this.roles.keySet().removeAll(this.roleIds);
/* 1109 */       LocalStoreLayout.this.scheduledEvents.keySet().removeAll(this.eventIds);
/* 1110 */       LocalStoreLayout.this.voiceStates.keySet().removeAll(this.voiceStateIds);
/* 1111 */       return ImplUtils.<WrappedGuildData, GuildData>ifNonNullMap(old, WrappedGuildData::unwrap);
/*      */     }
/*      */   }
/*      */   
/*      */   private class ChannelContent
/*      */   {
/*      */     private final long channelId;
/* 1118 */     private final Set<LocalStoreLayout.Long2> messageIds = new HashSet<>();
/* 1119 */     private final Set<LocalStoreLayout.Long2> voiceStateIds = new HashSet<>();
/*      */     
/*      */     public ChannelContent(long channelId) {
/* 1122 */       this.channelId = channelId;
/*      */     }
/*      */     
/*      */     private void dispose() {
/* 1126 */       LocalStoreLayout.this.channels.remove(Long.valueOf(this.channelId));
/* 1127 */       LocalStoreLayout.this.contentByChannel.remove(Long.valueOf(this.channelId));
/* 1128 */       LocalStoreLayout.this.messages.keySet().removeAll(this.messageIds);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\store\impl\LocalStoreLayout.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */