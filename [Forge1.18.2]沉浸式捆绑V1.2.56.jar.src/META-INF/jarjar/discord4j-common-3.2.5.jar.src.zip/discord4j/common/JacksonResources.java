/*     */ package discord4j.common;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonInclude;
/*     */ import com.fasterxml.jackson.annotation.PropertyAccessor;
/*     */ import com.fasterxml.jackson.databind.Module;
/*     */ import com.fasterxml.jackson.databind.ObjectMapper;
/*     */ import com.fasterxml.jackson.databind.SerializationFeature;
/*     */ import com.fasterxml.jackson.databind.deser.DeserializationProblemHandler;
/*     */ import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
/*     */ import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
/*     */ import discord4j.common.jackson.UnknownPropertyHandler;
/*     */ import discord4j.discordjson.possible.PossibleFilter;
/*     */ import discord4j.discordjson.possible.PossibleModule;
/*     */ import java.util.function.Function;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JacksonResources
/*     */ {
/*     */   public static final Function<ObjectMapper, ObjectMapper> INITIALIZER;
/*     */   public static final Function<ObjectMapper, ObjectMapper> HANDLE_UNKNOWN_PROPERTIES;
/*     */   private final ObjectMapper objectMapper;
/*     */   
/*     */   static {
/*  42 */     INITIALIZER = (mapper -> mapper.registerModule((Module)new PossibleModule()).registerModule((Module)new JavaTimeModule()).configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false).registerModule((Module)new Jdk8Module()).setVisibility(PropertyAccessor.ALL, JsonAutoDetect.Visibility.NONE).setVisibility(PropertyAccessor.GETTER, JsonAutoDetect.Visibility.PUBLIC_ONLY).setVisibility(PropertyAccessor.CREATOR, JsonAutoDetect.Visibility.ANY).setDefaultPropertyInclusion(JsonInclude.Value.construct(JsonInclude.Include.CUSTOM, JsonInclude.Include.ALWAYS, PossibleFilter.class, null)));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  56 */     HANDLE_UNKNOWN_PROPERTIES = (mapper -> mapper.addHandler((DeserializationProblemHandler)new UnknownPropertyHandler(true)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public JacksonResources() {
/*  69 */     this(HANDLE_UNKNOWN_PROPERTIES);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public JacksonResources(Function<ObjectMapper, ObjectMapper> mapper) {
/*  80 */     this.objectMapper = INITIALIZER.<ObjectMapper>andThen(mapper).apply(new ObjectMapper());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public JacksonResources(ObjectMapper objectMapper) {
/*  93 */     this.objectMapper = objectMapper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JacksonResources create() {
/* 100 */     return new JacksonResources(HANDLE_UNKNOWN_PROPERTIES);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JacksonResources createFromObjectMapper(ObjectMapper objectMapper) {
/* 107 */     return new JacksonResources(INITIALIZER.<ObjectMapper>andThen(HANDLE_UNKNOWN_PROPERTIES).apply(objectMapper));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JacksonResources withMapperFunction(Function<ObjectMapper, ObjectMapper> transformer) {
/* 117 */     return new JacksonResources(transformer.apply(this.objectMapper));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectMapper getObjectMapper() {
/* 126 */     return this.objectMapper;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\JacksonResources.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */