/*    */ package discord4j.common.close;
/*    */ 
/*    */ import java.util.Optional;
/*    */ import reactor.util.annotation.Nullable;
/*    */ import reactor.util.context.ContextView;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CloseException
/*    */   extends RuntimeException
/*    */ {
/*    */   private final CloseStatus closeStatus;
/*    */   private final ContextView context;
/*    */   
/*    */   public CloseException(CloseStatus closeStatus, ContextView context) {
/* 43 */     this(closeStatus, context, null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CloseException(CloseStatus closeStatus, ContextView context, @Nullable Throwable cause) {
/* 54 */     super(cause);
/* 55 */     this.closeStatus = closeStatus;
/* 56 */     this.context = context;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CloseStatus getCloseStatus() {
/* 65 */     return this.closeStatus;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getCode() {
/* 74 */     return this.closeStatus.getCode();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Optional<String> getReason() {
/* 83 */     return this.closeStatus.getReason();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ContextView getContext() {
/* 92 */     return this.context;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getMessage() {
/* 97 */     return "WebSocket closed: " + this.closeStatus.toString() + (
/* 98 */       (getCause() != null) ? (" caused by " + getCause().toString()) : "");
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\close\CloseException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */