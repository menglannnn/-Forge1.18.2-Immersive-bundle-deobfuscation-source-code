/*    */ package discord4j.common.close;
/*    */ 
/*    */ import java.util.Optional;
/*    */ import reactor.util.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CloseStatus
/*    */ {
/* 30 */   public static final CloseStatus NORMAL_CLOSE = new CloseStatus(1000, "Logging off");
/* 31 */   public static final CloseStatus ABNORMAL_CLOSE = new CloseStatus(1006, null);
/*    */ 
/*    */ 
/*    */   
/*    */   private final int code;
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   private final String reason;
/*    */ 
/*    */ 
/*    */   
/*    */   public CloseStatus(int code, @Nullable String reason) {
/* 44 */     this.code = code;
/* 45 */     this.reason = reason;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getCode() {
/* 54 */     return this.code;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Optional<String> getReason() {
/* 63 */     return Optional.<String>ofNullable(this.reason).filter(r -> !r.isEmpty());
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 68 */     return this.code + ((this.reason == null || this.reason.isEmpty()) ? "" : (" " + this.reason));
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\close\CloseStatus.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */