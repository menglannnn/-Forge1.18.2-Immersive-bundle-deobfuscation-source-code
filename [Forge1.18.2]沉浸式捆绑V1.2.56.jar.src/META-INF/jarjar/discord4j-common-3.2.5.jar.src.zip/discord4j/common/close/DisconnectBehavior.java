/*     */ package discord4j.common.close;
/*     */ 
/*     */ import reactor.util.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DisconnectBehavior
/*     */ {
/*     */   private final Action action;
/*     */   private final Throwable cause;
/*     */   
/*     */   public static DisconnectBehavior retry(@Nullable Throwable cause) {
/*  37 */     return new DisconnectBehavior(Action.RETRY, cause);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DisconnectBehavior stop(@Nullable Throwable cause) {
/*  47 */     return new DisconnectBehavior(Action.STOP, cause);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DisconnectBehavior retryAbruptly(@Nullable Throwable cause) {
/*  57 */     return new DisconnectBehavior(Action.RETRY_ABRUPTLY, cause);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DisconnectBehavior stopAbruptly(@Nullable Throwable cause) {
/*  67 */     return new DisconnectBehavior(Action.STOP_ABRUPTLY, cause);
/*     */   }
/*     */   
/*     */   private DisconnectBehavior(Action action, @Nullable Throwable cause) {
/*  71 */     this.action = action;
/*  72 */     this.cause = cause;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Action getAction() {
/*  81 */     return this.action;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Throwable getCause() {
/*  91 */     return this.cause;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Action
/*     */   {
/*  98 */     RETRY, STOP, RETRY_ABRUPTLY, STOP_ABRUPTLY;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 103 */     return String.format("%s%s", new Object[] { this.action, (this.cause != null) ? (" due to " + this.cause) : "" });
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\close\DisconnectBehavior.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */