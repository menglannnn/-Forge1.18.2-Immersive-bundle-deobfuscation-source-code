/*    */ package discord4j.common.retry;
/*    */ 
/*    */ import java.time.Duration;
/*    */ import java.util.concurrent.atomic.AtomicInteger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReconnectContext
/*    */ {
/*    */   private final Duration firstBackoff;
/*    */   private final Duration maxBackoffInterval;
/* 34 */   private final AtomicInteger attempts = new AtomicInteger(1);
/* 35 */   private final AtomicInteger resetCount = new AtomicInteger(0);
/*    */   
/*    */   public ReconnectContext(Duration firstBackoff, Duration maxBackoffInterval) {
/* 38 */     this.firstBackoff = firstBackoff;
/* 39 */     this.maxBackoffInterval = maxBackoffInterval;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void next() {
/* 46 */     this.attempts.incrementAndGet();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void reset() {
/* 53 */     this.attempts.set(1);
/* 54 */     this.resetCount.incrementAndGet();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void clear() {
/* 61 */     this.attempts.set(1);
/* 62 */     this.resetCount.set(0);
/*    */   }
/*    */   
/*    */   public Duration getFirstBackoff() {
/* 66 */     return this.firstBackoff;
/*    */   }
/*    */   
/*    */   public Duration getMaxBackoffInterval() {
/* 70 */     return this.maxBackoffInterval;
/*    */   }
/*    */   
/*    */   public int getAttempts() {
/* 74 */     return this.attempts.get();
/*    */   }
/*    */   
/*    */   public int getResetCount() {
/* 78 */     return this.resetCount.get();
/*    */   }
/*    */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\retry\ReconnectContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */