/*     */ package discord4j.common.retry;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Supplier;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ import reactor.core.scheduler.Schedulers;
/*     */ import reactor.retry.Backoff;
/*     */ import reactor.retry.BackoffDelay;
/*     */ import reactor.retry.IterationContext;
/*     */ import reactor.retry.Jitter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReconnectOptions
/*     */ {
/*     */   public static final Supplier<Scheduler> DEFAULT_BACKOFF_SCHEDULER = () -> Schedulers.newParallel("d4j-backoff", Schedulers.DEFAULT_POOL_SIZE, true);
/*     */   private final Duration firstBackoff;
/*     */   private final Duration maxBackoffInterval;
/*     */   private final long maxRetries;
/*     */   private final Backoff backoff;
/*     */   private final Jitter jitter;
/*     */   private final Scheduler backoffScheduler;
/*     */   private final double jitterFactor;
/*     */   
/*     */   protected ReconnectOptions(Builder builder) {
/*  47 */     this.firstBackoff = Objects.<Duration>requireNonNull(builder.firstBackoff, "firstBackoff");
/*  48 */     this.maxBackoffInterval = Objects.<Duration>requireNonNull(builder.maxBackoffInterval, "maxBackoffInterval");
/*  49 */     this.maxRetries = builder.maxRetries;
/*  50 */     this.backoff = Objects.<Backoff>requireNonNull(builder.backoff, "backoff");
/*  51 */     this.jitter = Objects.<Jitter>requireNonNull(builder.jitter, "jitter");
/*  52 */     if (builder.backoffScheduler == null) {
/*  53 */       this.backoffScheduler = DEFAULT_BACKOFF_SCHEDULER.get();
/*     */     } else {
/*  55 */       this.backoffScheduler = builder.backoffScheduler;
/*     */     } 
/*  57 */     this.jitterFactor = builder.jitterFactor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ReconnectOptions create() {
/*  66 */     return (new Builder()).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/*  75 */     return new Builder();
/*     */   }
/*     */   
/*     */   public static class Builder
/*     */   {
/*  80 */     private Duration firstBackoff = Duration.ofSeconds(2L);
/*  81 */     private Duration maxBackoffInterval = Duration.ofSeconds(30L);
/*  82 */     private long maxRetries = Long.MAX_VALUE; protected Builder() {
/*  83 */       this.backoff = (context -> {
/*     */           Duration nextBackoff;
/*     */           ReconnectContext appContext = (ReconnectContext)context.applicationContext();
/*     */           try {
/*     */             long factor = (long)Math.pow(2.0D, (appContext.getAttempts() - 1));
/*     */             nextBackoff = appContext.getFirstBackoff().multipliedBy(factor);
/*  89 */           } catch (ArithmeticException e) {
/*     */             nextBackoff = appContext.getMaxBackoffInterval();
/*     */           } 
/*     */           return new BackoffDelay(appContext.getFirstBackoff(), appContext.getMaxBackoffInterval(), nextBackoff);
/*     */         });
/*  94 */       this.jitter = Jitter.random();
/*  95 */       this.backoffScheduler = null;
/*  96 */       this.jitterFactor = 0.5D;
/*     */     }
/*     */ 
/*     */     
/*     */     private Backoff backoff;
/*     */     
/*     */     private Jitter jitter;
/*     */     
/*     */     private Scheduler backoffScheduler;
/*     */     private double jitterFactor;
/*     */     
/*     */     public Builder setFirstBackoff(Duration firstBackoff) {
/* 108 */       if (firstBackoff.minus(Duration.ofSeconds(2L)).isNegative()) {
/* 109 */         throw new IllegalArgumentException("firstBackoff duration must be at least 2 seconds");
/*     */       }
/* 111 */       this.firstBackoff = firstBackoff;
/* 112 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setMaxBackoffInterval(Duration maxBackoffInterval) {
/* 122 */       if (maxBackoffInterval.minus(this.firstBackoff).isNegative()) {
/* 123 */         throw new IllegalArgumentException("maxBackoffInterval must be at least the same as firstBackoff");
/*     */       }
/* 125 */       this.maxBackoffInterval = maxBackoffInterval;
/* 126 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setMaxRetries(long maxRetries) {
/* 137 */       if (maxRetries < 0L) {
/* 138 */         throw new IllegalArgumentException("maxRetries must be a positive integer");
/*     */       }
/* 140 */       this.maxRetries = maxRetries;
/* 141 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public Builder setBackoff(Backoff backoff) {
/* 155 */       this.backoff = backoff;
/* 156 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public Builder setJitter(Jitter jitter) {
/* 169 */       this.jitter = jitter;
/* 170 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setBackoffScheduler(Scheduler backoffScheduler) {
/* 181 */       this.backoffScheduler = backoffScheduler;
/* 182 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setJitterFactor(double jitterFactor) {
/* 193 */       if (jitterFactor < 0.0D || jitterFactor > 1.0D) {
/* 194 */         throw new IllegalArgumentException("Invalid jitter factor value");
/*     */       }
/* 196 */       this.jitterFactor = jitterFactor;
/* 197 */       return this;
/*     */     }
/*     */     
/*     */     public ReconnectOptions build() {
/* 201 */       return new ReconnectOptions(this);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Duration getFirstBackoff() {
/* 211 */     return this.firstBackoff;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Duration getMaxBackoffInterval() {
/* 220 */     return this.maxBackoffInterval;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getMaxRetries() {
/* 229 */     return this.maxRetries;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Backoff getBackoff() {
/* 242 */     return this.backoff;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Jitter getJitter() {
/* 254 */     return this.jitter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Scheduler getBackoffScheduler() {
/* 263 */     return this.backoffScheduler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getJitterFactor() {
/* 272 */     return this.jitterFactor;
/*     */   }
/*     */ }


/* Location:              C:\Users\小亮傻逼\Desktop\[Forge1.18.2]沉浸式捆绑V1.2.56.jar!\META-INF\jarjar\discord4j-common-3.2.5.jar!\discord4j\common\retry\ReconnectOptions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */